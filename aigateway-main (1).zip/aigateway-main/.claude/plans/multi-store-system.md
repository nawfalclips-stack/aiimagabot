# خطة: نظام Multi-Store (متجرين مستقلين)

## الهدف
إنشاء نظام يدعم متجرين مستقلين تماماً:
1. **المتجر الأول (الحالي)**: AeroLink - يبقى كما هو
2. **المتجر الثاني (الجديد)**: ChefAPI - نسخة مستقلة بألوان وخط مختلف

## المتطلبات الأساسية

### 1. البنية التحتية
- كل متجر له:
  - صفحة هبوط مستقلة (`/` للمتجر الأول، `/chefapi` للمتجر الثاني)
  - لوحة تحكم للعملاء مستقلة (`/portal` و `/chefapi/portal`)
  - لوحة تحكم إدارية مستقلة (`/admin` و `/chefapi/admin`)
  - قاعدة بيانات مستقلة تماماً (عملاء، طلبات، تذاكر، إلخ)
  - رابط متجر GamsGo مختلف
  - ألوان وخط مختلف

### 2. مفهوم Store (المتجر)
سنضيف مفهوم **Store** إلى النظام:
- كل Store له `storeId` فريد (`"aerolink"` و `"chefapi"`)
- كل جدول في قاعدة البيانات يحتاج `storeId`
- Admin يمكنه التبديل بين المتاجر
- العملاء يرون فقط متجرهم

## التغييرات المطلوبة

### المرحلة 1: تحديث قاعدة البيانات

#### 1.1 إضافة جدول Store
```prisma
model Store {
  id        String   @id // "aerolink" | "chefapi"
  name      String   // "AeroLink API" | "ChefAPI"
  logoText  String
  storeUrl  String   // رابط GamsGo
  
  // Theme
  primaryColor    String  // "#0ea5e9" for AeroLink, different for ChefAPI
  fontFamily      String  // font family name
  
  createdAt DateTime @default(now())
  updatedAt DateTime @updatedAt
}
```

#### 1.2 إضافة storeId لكل جدول
إضافة `storeId String` لـ:
- Customer
- Admin (Admin يمكن أن يكون له access لأكثر من متجر)
- Order
- ActivityLog
- Setting
- Documentation
- ApiPoolKey
- UsageLog
- Ticket
- RechargeRequest

#### 1.3 إنشاء AdminStoreAccess للتحكم في صلاحيات الإدمن
```prisma
model AdminStoreAccess {
  id       String @id @default(cuid())
  adminId  String
  admin    Admin  @relation(...)
  storeId  String
  store    Store  @relation(...)
  
  @@unique([adminId, storeId])
}
```

### المرحلة 2: تحديث Auth & Session

#### 2.1 تحديث Session
إضافة `currentStoreId` إلى session:
```typescript
// lib/auth.ts
interface SessionData {
  adminId?: string;
  customerId?: string;
  currentStoreId?: string; // للـ Admin فقط
}
```

#### 2.2 تحديث requireAdmin و requireCustomer
- `requireAdmin()` → يرجع Admin + currentStoreId
- `requireCustomer()` → يرجع Customer (معه storeId تلقائياً)

### المرحلة 3: Store Routing

#### 3.1 هيكل المسارات الجديد
```
/                          → AeroLink landing
/portal                    → AeroLink customer portal
/admin                     → Admin panel (يختار المتجر)

/chefapi                   → ChefAPI landing
/chefapi/portal            → ChefAPI customer portal
/chefapi/admin             → ChefAPI admin panel
```

#### 3.2 Route Groups
استخدام Next.js Route Groups:
```
app/
  (aerolink)/
    page.tsx              → AeroLink landing
    login/
    portal/
  (chefapi)/
    chefapi/
      page.tsx            → ChefAPI landing
      login/
      portal/
  admin/
    login/
    (dashboard)/
      layout.tsx          → Store selector
      [storeId]/          → Store-specific routes
        customers/
        orders/
        ...
```

### المرحلة 4: Theme System

#### 4.1 Store Theme Provider
```typescript
// components/theme-provider.tsx
export function StoreThemeProvider({ 
  storeId, 
  children 
}: { 
  storeId: string; 
  children: React.ReactNode 
}) {
  const store = useStore(storeId);
  
  return (
    <div 
      style={{
        '--primary': store.primaryColor,
        '--font-family': store.fontFamily,
      }}
    >
      {children}
    </div>
  );
}
```

#### 4.2 تطبيق الثيم على كل صفحة
- في `layout.tsx` لكل متجر، نضيف `StoreThemeProvider`
- CSS variables تتغير حسب المتجر

### المرحلة 5: Admin Store Switcher

#### 5.1 Store Selector في Admin Panel
```tsx
// components/admin/store-selector.tsx
export function StoreSelector({ 
  stores, 
  currentStoreId 
}: { 
  stores: Store[]; 
  currentStoreId: string 
}) {
  return (
    <Select 
      value={currentStoreId}
      onValueChange={switchStore}
    >
      {stores.map(s => (
        <SelectItem key={s.id} value={s.id}>
          {s.name}
        </SelectItem>
      ))}
    </Select>
  );
}
```

#### 5.2 Switch Store Action
```typescript
// app/admin/actions.ts
export async function switchStoreAction(storeId: string) {
  const admin = await requireAdmin();
  
  // تحقق من أن Admin له access
  const hasAccess = await prisma.adminStoreAccess.findUnique({
    where: { adminId_storeId: { adminId: admin.id, storeId } }
  });
  
  if (!hasAccess) {
    return { error: "No access to this store" };
  }
  
  // تحديث Session
  await updateSession({ currentStoreId: storeId });
  revalidatePath("/admin");
}
```

### المرحلة 6: Data Isolation

#### 6.1 تحديث كل Prisma Query
كل query يجب أن يفلتر حسب `storeId`:
```typescript
// قبل
const customers = await prisma.customer.findMany();

// بعد
const customers = await prisma.customer.findMany({
  where: { storeId: currentStoreId }
});
```

#### 6.2 Helper Functions
```typescript
// lib/store.ts
export function withStoreFilter<T>(
  storeId: string, 
  where?: T
): T & { storeId: string } {
  return { ...where, storeId };
}

// الاستخدام
const customers = await prisma.customer.findMany({
  where: withStoreFilter(currentStoreId, { status: "ACTIVE" })
});
```

### المرحلة 7: Settings Per Store

#### 7.1 تحديث Settings
```prisma
model Setting {
  // ... existing fields
  storeId String
  
  @@unique([storeId, key])
}
```

#### 7.2 تحديث getSettings
```typescript
export async function getSettings(storeId: string) {
  const settings = await prisma.setting.findMany({
    where: { storeId }
  });
  // ...
}
```

### المرحلة 8: Seeding

#### 8.1 Seed للمتجرين
```typescript
// prisma/seed.ts
await prisma.store.createMany({
  data: [
    {
      id: "aerolink",
      name: "AeroLink API",
      logoText: "AeroLink",
      storeUrl: "https://www.gamsgo.com/shop-store/...",
      primaryColor: "#0ea5e9",
      fontFamily: "Inter",
    },
    {
      id: "chefapi",
      name: "ChefAPI",
      logoText: "ChefAPI",
      storeUrl: "https://www.gamsgo.com/shop-store/3dcf9b33-e8d1-b908-8069-d6603ca4ab78?category_id=e994486e-b21a-fcfc-8844-360b39ae878e",
      primaryColor: "#f97316", // برتقالي مثلاً
      fontFamily: "Plus Jakarta Sans", // خط مختلف
    }
  ]
});

// Admin له access للمتجرين
await prisma.adminStoreAccess.createMany({
  data: [
    { adminId: admin.id, storeId: "aerolink" },
    { adminId: admin.id, storeId: "chefapi" },
  ]
});
```

## Migration Strategy

### الخطوة 1: إضافة الجداول والحقول الجديدة
- إضافة Store model
- إضافة storeId لكل جدول (nullable أولاً)
- Migration

### الخطوة 2: Data Migration
- تعيين `storeId = "aerolink"` لكل البيانات الموجودة
- جعل storeId required

### الخطوة 3: Code Update
- تحديث كل queries
- إضافة store filtering
- تحديث UI

### الخطوة 4: Testing
- اختبار المتجر الأول (يجب أن يعمل كما هو)
- إضافة بيانات تجريبية للمتجر الثاني
- اختبار التبديل بين المتجرين

## الـ Deliverables

عند الانتهاء، سيكون عندك:

1. **ChefAPI Admin Panel**
   - URL: `https://aerolink-portal.vercel.app/chefapi/admin`
   - Email: (نفس email الإدمن الحالي)
   - Password: (نفس password الإدمن الحالي)

2. **ChefAPI Customer Portal**
   - URL: `https://aerolink-portal.vercel.app/chefapi`
   - يمكن للعملاء التسجيل من خلال Order Number من رابط GamsGo الجديد

3. **Store Switcher في Admin Panel**
   - الإدمن يمكنه التبديل بين "AeroLink" و "ChefAPI"
   - كل البيانات مستقلة تماماً

## التقدير الزمني

- المرحلة 1 (Database): 30 دقيقة
- المرحلة 2 (Auth): 20 دقيقة
- المرحلة 3 (Routing): 40 دقيقة
- المرحلة 4 (Theme): 30 دقيقة
- المرحلة 5 (Admin Switcher): 20 دقيقة
- المرحلة 6 (Data Isolation): 60 دقيقة
- المرحلة 7 (Settings): 20 دقيقة
- المرحلة 8 (Seeding): 20 دقيقة
- Testing: 30 دقيقة

**المجموع**: ~4 ساعات عمل

## ملاحظات مهمة

1. **Data Isolation كامل**: كل متجر له عملائه، طلباته، تذاكره - لا يوجد أي تداخل
2. **Admin واحد للكل**: نفس الإدمن يمكنه إدارة المتجرين بالتبديل بينهما
3. **Theme مختلف**: ألوان وخطوط مختلفة لكل متجر
4. **Links مختلفة**: كل متجر يوجه لرابط GamsGo مختلف

هل الخطة واضحة؟
