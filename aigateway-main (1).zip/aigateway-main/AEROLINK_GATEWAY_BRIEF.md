## 0. Your role and how to work

You are acting as a senior engineer implementing an architect's brief on an existing, working production codebase. The codebase already contains a functioning LLM gateway (branch with the "feature/redesign" work). Your job is to **harden it, fix the places where money can leak, make the product honest about what customers buy, and automate GamsGo activations** — not to rewrite it.

Operating rules:

1. **Start with Phase 0 (Discovery). Do not modify code until I approve the audit.** Produce `docs/gateway-audit.md` and stop.
2. Work **phase by phase**. Each phase ends with: migrations applied, typecheck + lint + tests + `next build` passing, docs updated, and a short summary of what changed and what I must configure.
3. **Never break existing features.** Customer portal, admin back-office, multi-store scoping, affiliate, loyalty, review bonus, tickets, docs editor, and the existing Order-ID activation flow must keep working.
4. **Follow existing conventions**: App Router, Server Actions, Prisma, shadcn/ui, Tailwind v4, `storeId` scoping on every table, role-based admin write access, soft delete with restore, the in-app notification bell, the admin activity log.
5. **Money is BigInt.** All balance, price, cost and token amounts are integers (`BigInt` in Prisma, `bigint` in TS). Never use `Number` or floats for money. Preserve the existing µ$ units and sub-cent carry-forward.
6. **Additive migrations only** (expand/contract). Never drop or rename a column in the same release that stops using it.
7. **Feature-flag every behaviour change** listed in §13 so it can be rolled back without a deploy.
8. **Verify, don't assume.** §15 lists facts you must confirm against live docs or real responses before relying on them. If something differs from this brief, follow reality and note it in the audit.
9. **Out of scope: payment processing.** Do not add Paddle, Lemon Squeezy, Stripe, crypto or any checkout. That will be a separate spec. Design the ledger so a future payment source is just another `LedgerEntry` type.
10. When a requirement conflicts with existing code or is ambiguous, **ask me** instead of guessing. §16 lists questions I expect.

---

## 1. Context

AeroLink is a multi-store (AeroLink, ChefAPI, …) prepaid API-access platform. Customers buy a pack on **GamsGo**, activate it with their Order ID, and receive a metered balance plus a bonus pot, which they spend on LLM inference from Claude Code, Codex CLI, or any OpenAI/Anthropic-compatible SDK.

Stack: Next.js 16 (App Router, Server Actions), React 19, TypeScript, Tailwind v4 + shadcn/ui, Prisma 6 (SQLite locally, PostgreSQL in production), Framer Motion, Recharts. Deployed on Vercel with a self-migrating, self-seeding build.

What the gateway branch already does (keep and build on it):

- `POST /v1/chat/completions` (OpenAI), `POST /v1/messages` + `/v1/messages/count_tokens` (Anthropic, translated to/from OpenAI chat including streaming SSE), `GET /v1/models`.
- Bearer auth with `al_…` tokens stored as SHA-256 hashes, max 5 active per customer, proper 401/402/403.
- Provider registry, `GatewayModel` catalog with honest slugs (e.g. `deepseek-v3`), `ProviderModel` mappings with priority, failover on 429/5xx **before the first byte**.
- In-memory circuit breaker (3 failures → 60 s open).
- `UsageLog` per request; provider cost from µ$/MTok prices or DeepInfra `estimated_cost`; multiplied by the customer's rate; deducted 80/20 from balance/bonus with sub-cent carry-forward; daily rollups. Billing runs in `after()`.
- Hardening: body allowlist, 20 MB cap, `max_tokens` clamped, `n=1`, `x-request-id`, proxy bypass for `/v1/*`.
- Provider keys AES-GCM encrypted with a key derived from `SESSION_SECRET`.
- `Plan` model with USD mode ("$100 pack = $5 of real provider usage") and TOKENS mode ("$100 pack = 50M tokens"), auto-assigned by price when exactly one plan matches.
- Admin Providers / Models / Plans pages; customer `/portal/api-access` page.

---

## 2. Goals and non-goals

**Goals**

- G1. A customer can never consume more than their balance, even with many parallel requests.
- G2. Gateway state that must be shared (circuit breakers, rate limits, concurrency) is shared across Vercel instances.
- G3. We stop paying for tokens nobody reads (upstream abort on disconnect) and bill partial streams fairly.
- G4. Cached tokens are priced correctly.
- G5. Every movement of credit is recorded in an append-only ledger that reconciles with cached balances.
- G6. Customers see honest units: what their pack buys, in credits or tokens, for the models actually served.
- G7. GamsGo purchases activate automatically, with no admin step, using single-use vouchers.
- G8. More than one provider per model, with per-attempt visibility, health, and cost reconciliation.
- G9. Claude Code works reliably, using native Anthropic passthrough where a provider supports it.
- G10. No customer ever receives or sees an upstream provider key.

**Non-goals**

- Payment processing (separate spec).
- Moving the gateway off Vercel (design so it's possible later; don't do it now).
- Redesigning the UI. Add pages and cards using existing components.

---

## 3. Global engineering constraints

- **Runtime.** Every `/v1/*` route: `export const runtime = 'nodejs'`, `export const dynamic = 'force-dynamic'`, `export const maxDuration = Number(process.env.GATEWAY_MAX_DURATION ?? 800)`. Never Edge: Edge requires the first byte within 25 s, which reasoning models can exceed.
- **Hot path budget.** A gateway request should do at most: 1 cached auth lookup, 1 Redis rate-limit/lease call, 1 SQL reservation statement, then stream, then 1 settlement transaction. Catalog/provider config is cached (60 s).
- **Local dev parity.** SQLite locally is fine for UI work, but **all concurrency tests run against PostgreSQL** (add `docker-compose.test.yml` with Postgres and Redis). SQLite serialises writes and hides race conditions.
- **Redis.** Use Upstash Redis (`@upstash/redis`, `@upstash/ratelimit`). Wrap it in `lib/redis.ts` with a `REDIS_DISABLED=true` fallback to an in-process implementation for local dev only, with a loud warning log. In production, define explicit fail-open/fail-closed behaviour per feature (stated in each workstream).
- **Error shapes match the wire.** Errors from `/v1/chat/completions` use the OpenAI error object. Errors from `/v1/messages` use the Anthropic shape `{"type":"error","error":{"type":"…","message":"…"}}`. Always include `x-request-id`. Put a single `lib/gateway/errors.ts` in charge of this.
- **Never leak upstream details.** Don't pass upstream error bodies, provider names, account IDs or upstream model IDs to customers. Log them server-side with the request ID; return a sanitised message.
- **No prompt/completion logging by default.** If any debug logging of content exists, gate it behind a per-store setting that is off by default, with a retention limit.
- **Secrets.** Every new env var goes into `.env.example` with a comment. Never log decrypted keys; redact in thrown errors.
- **Single source of truth for balance mutation.** All writes to balance/bonus/reserved fields go through `lib/billing/balance-service.ts`. Add a test that greps the codebase and fails if any other file writes those fields via Prisma.

---

## 4. Phase 0 — Discovery and audit (stop after this)

Read the codebase and produce `docs/gateway-audit.md` containing:

1. **Request flow map** for each `/v1/*` endpoint, with file paths and function names: auth → validation → routing → upstream call → stream transform → billing.
2. **Every balance write site**: file, function, what triggers it (usage, activation approval, recharge approval, review bonus, affiliate reward, loyalty cash reward, admin edit, expiry, soft delete/restore).
3. **All in-memory state** that assumes a single process (circuit breaker, rate limiters, caches, counters).
4. **How `after()` billing works today**, including what happens when the client disconnects, when the upstream errors mid-stream, and when the function times out.
5. **Whether `request.signal` is passed to the upstream fetch.**
6. **How usage is parsed** from each provider and how cached tokens are handled.
7. **Plan assignment logic** and what happens with zero or multiple matching plans; how many current customers have no plan.
8. **API Pool**: every code path that reads, assigns or displays upstream keys, especially anything customer-visible.
9. **Build/migration/seed behaviour** on Vercel, including preview deployments and which database they point at.
10. **Test setup**: framework, how to run, current coverage of the gateway.
11. **Prisma schema summary** of relevant models with actual table/column names (needed for raw SQL).
12. **Customer-facing copy** that names models or versions (see WS7).
13. **Deviations** between this brief and reality, and your proposed adjustments.
14. **A phase plan** with an estimate per phase.

Then stop and wait for approval.

---

## 5. Phase plan (implement in this order after approval)

| Phase | Workstreams | Why this order |
|---|---|---|
| 1 | WS1 Ledger, WS2 Reservations | Highest financial risk; everything else writes through these |
| 2 | WS3 Rate limits & concurrency, WS4 Shared circuit breaker | Protects providers and other customers |
| 3 | WS5 Upstream abort & partial metering, WS6 Cache-aware pricing | Stops paying for unused tokens; fixes billing accuracy |
| 4 | WS12 Platform hardening | Body limit, pooling, key secret, migration safety |
| 5 | WS8 Packs & plan binding, WS9 GamsGo vouchers | Automatic activation |
| 6 | WS7 Honest units & copy, WS10 Retire API Pool | Customer-facing trust |
| 7 | WS11 Multi-provider depth, WS13 Anthropic passthrough | Reliability and Claude Code quality |
| 8 | WS14 Observability & reconciliation, final load test | Operate it confidently |

---

## 6. Workstreams — money core

### WS1 — Append-only credit ledger

**Problem.** Balances are (very likely) updated in place from many places. When a customer disputes a balance, there is no provable history, and bugs in any write site silently corrupt money.

**Analysis.** A ledger turns "balance" from a mutable number into a derived fact. The cached fields on `Customer` stay (for speed), but every change to them is accompanied, in the same transaction, by a ledger row. Drift between the two becomes detectable. This is also the hook the future payment spec will plug into. It must cover the bonus pot separately, because the 80/20 split and bonus-only rewards (review bonus, loyalty) are real liabilities.

**Requirements.**

- New model `LedgerEntry`:
  - `id`, `storeId`, `customerId`
  - `pot` enum: `BALANCE | BONUS`
  - `type` enum: `OPENING_BALANCE, ORDER_ACTIVATION, RECHARGE, VOUCHER_REDEMPTION, USAGE, REVIEW_BONUS, AFFILIATE_REWARD, LOYALTY_REWARD, REFUND, CLAWBACK, ADMIN_ADJUSTMENT, EXPIRY, RESTORE`
  - `amount` BigInt, signed (credit positive, debit negative), in the customer's balance unit
  - `balanceAfter` BigInt (value of that pot after the entry)
  - `refType` + `refId` (e.g. `UsageLog`/id, `Voucher`/id, `Order`/id)
  - `idempotencyKey` String **unique** (e.g. `usage:{requestId}:balance`, `voucher:{voucherId}`)
  - `actorAdminId` nullable, `note` nullable (required for `ADMIN_ADJUSTMENT` and `CLAWBACK`)
  - `createdAt`
  - Indexes: `(storeId, customerId, createdAt)`, `(refType, refId)`.
- `lib/billing/balance-service.ts` exposes the only functions allowed to change money: `credit()`, `debit()`, `reserve()`, `settle()`, `release()`, `adjust()`, `clawback()`. Each runs in a transaction, writes the ledger row(s), updates the cached field(s), and is idempotent via `idempotencyKey` (catch unique violation → return the existing result).
- Refactor **every** write site found in the audit to call the service. Admin balance edits become `ADMIN_ADJUSTMENT` with a mandatory reason, visible in the customer timeline.
- **Backfill migration**: one `OPENING_BALANCE` entry per customer per pot equal to the current cached values, created in a one-off script (`npm run ledger:backfill`), idempotent, safe to re-run.
- Customer timeline (admin) and a "Balance history" section in the portal read from the ledger.

**Acceptance.**

- After the full test suite, for every customer: `sum(ledger where pot=X) == cached field X`.
- The grep test (see §3) passes.
- Running the backfill twice produces no duplicates.

---

### WS2 — Atomic reservation and settlement

**Problem.** Billing happens in `after()`, after the response. A customer with almost no balance can open 20 parallel streams; all pass the "balance > 0" check, all are served, and the non-negative clamp means we absorb the overspend. Coding agents open parallel requests routinely, so this happens without any abuse.

**Analysis.** The standard fix is reserve-then-settle. Before forwarding, atomically hold the worst-case cost; after the stream ends, charge the real cost and release the rest. The check-and-hold must be a single SQL statement so two requests cannot both see the same available amount. Because balance and bonus are separate pots and the hold is taken against both, the condition compares columns to each other, which Prisma's `updateMany` cannot express — use a raw, portable SQL statement. There are three extra failure modes to design for: settlement running twice (idempotency), the function dying before settlement (orphaned holds that lock customer money), and the real cost exceeding the hold (must never go negative).

**Requirements.**

- Add `reserved` BigInt (default 0) to `Customer`.
- New model `GatewayReservation`: `id` (= request ID), `storeId`, `customerId`, `amount`, `status` (`HELD | SETTLED | RELEASED | EXPIRED`), `createdAt`, `expiresAt`, `settledAt`, `chargedAmount` nullable.
- **Hold estimation** (`lib/billing/estimate.ts`):
  - Input estimate: `ceil(utf8ByteLength(serialised messages + system + tools) / 3)`. Conservative on purpose.
  - Output: the clamped `max_tokens` (plus the reasoning budget for models flagged as reasoning, if the model exposes one).
  - Price the input at the **uncached** input rate and the output at the output rate, apply the customer's plan pricing (WS8), add a small safety margin (setting, default 5%), apply a minimum hold (setting).
- **Reserve** (single statement, adapt identifiers to the actual table/column names from the audit):

  ```sql
  UPDATE "Customer"
     SET "reserved" = "reserved" + $hold
   WHERE "id" = $customerId
     AND "balance" + "bonus" - "reserved" >= $hold
  ```

  One affected row = success. Then insert the `GatewayReservation` row. Do both in one transaction.
- **Fit-to-balance** (setting, default on): if the reservation fails but the customer can afford at least `GATEWAY_MIN_OUTPUT_TOKENS` (default 256) of output, lower `max_tokens` to what fits and retry once. Otherwise return 402 `insufficient_balance` in the correct wire shape.
- **Settle** (in a transaction, idempotent):
  1. `UPDATE GatewayReservation SET status='SETTLED' … WHERE id=$id AND status='HELD'` — if 0 rows, settlement already happened: stop.
  2. `reserved -= hold`.
  3. Compute the real charge (WS6). Split it using the existing 80/20 rule; if one pot is short, take the remainder from the other.
  4. If the charge exceeds what's available, charge only what's available and record the shortfall in `UsageLog.uncollected`. Never go negative.
  5. Write `USAGE` ledger entries (one per pot touched), update cached fields, preserve sub-cent carry-forward.
  6. Write/update the `UsageLog`, link it to the reservation.
- **Settlement trigger**: settlement is started from the stream's completion **and** cancellation paths (WS5), and kept alive with `waitUntil` (from `@vercel/functions`) or `after()` — whichever the audit shows is reliable for streaming responses in Next 16 (verify; see §15).
- **Sweeper cron** (every 5 min): reservations still `HELD` after `expiresAt` (= createdAt + maxDuration + 120 s) are released (`reserved -= amount`, status `EXPIRED`). If a `UsageLog` exists for that request, settle from it instead of releasing. Raise an admin notification when the sweeper acts, since it means a function died mid-request.
- **Shadow mode first**: flag `GATEWAY_RESERVATIONS=shadow|enforce|off`. In `shadow`, compute and log what would have been rejected without rejecting. Run shadow for 24–48 h in production before `enforce`.
- TOKENS-mode plans use the same service; the "unit" is tokens instead of µcredits. The pricing engine (WS8) hides the difference.

**Acceptance.**

- 50 parallel requests against a balance that covers ~3: at most the affordable number are served, the balance never goes below zero, and `reserved` returns to exactly 0 afterwards.
- Killing a request mid-stream (simulated function death) leaves a `HELD` reservation that the sweeper releases.
- Calling settle twice for one request charges once.

---

## 7. Workstreams — gateway protection

### WS3 — Rate limits and concurrency caps

**Problem.** Login is rate-limited, but `/v1/*` apparently isn't. One customer can exhaust our provider rate limits for everyone, and any in-memory limiter is per-instance on Vercel, so it isn't a limit at all.

**Analysis.** Two different limits are needed. Requests per minute stops floods. A concurrency cap stops the more realistic problem: coding agents opening many long streams at once, each holding provider capacity for minutes. Concurrency needs a lease with an expiry, because a crashed function must not hold a slot forever. Limits should come from the plan, so upgrading means more throughput — a legitimate reason to buy a bigger pack.

**Requirements.**

- Add to `Plan`: `rpm` Int, `maxConcurrent` Int (nullable → store default). Store settings: defaults plus a **store-wide concurrency ceiling** that protects provider limits.
- RPM: `@upstash/ratelimit` sliding window, keyed per token **and** per customer (both apply).
- Concurrency lease: Redis sorted set `conc:{customerId}` with member = request ID, score = expiry timestamp. On start: remove expired members, check the count, add. On settle/cancel: remove. Lease TTL = maxDuration + 60 s. Use one Lua script so check-and-add is atomic.
- The store-wide ceiling uses the same technique on `conc:store:{storeId}`.
- On limit: HTTP 429 with `Retry-After`, OpenAI `rate_limit_exceeded` / Anthropic `rate_limit_error` shape. Claude Code and Codex retry 429 with backoff, so this degrades gracefully.
- **Redis outage**: RPM fails open (serve, log a warning); concurrency fails open but falls back to a per-instance counter. Reservations (WS2) still protect the money.
- Move any in-memory login and redemption limiters to the same Redis limiter.

**Acceptance.** Exceeding RPM returns 429 with `Retry-After` in the correct wire format; opening `maxConcurrent + 1` streams rejects the extra one; leases from a killed request expire on their own.

---

### WS4 — Shared circuit breaker and provider health

**Problem.** The breaker lives in memory. On Vercel Fluid compute, instances come and go and don't share memory, so instances disagree about which provider is down, and a provider outage is rediscovered by every new instance with real customer requests.

**Analysis.** Move breaker state to Redis at **provider + upstream model** granularity (providers often fail for one model while others work). Distinguish failures that should trip the breaker and trigger failover (network errors, time-to-first-byte timeout, 429, 5xx) from client errors that should not (400 invalid request, 413) — those go straight back to the customer, because retrying a malformed request on another provider wastes money and hides the real error. Reasoning models are slow to the first token, so the TTFB timeout must be per provider/model, not global.

**Requirements.**

- Keys: `cb:{providerModelId}:fails` (INCR with a rolling window TTL), `cb:{providerModelId}:open` (SET with cooldown TTL), `cb:{providerModelId}:probe` (SET NX for half-open: exactly one request tests a recovering provider).
- Thresholds configurable per provider (defaults: 3 failures in 60 s → open 60 s).
- `Provider`/`ProviderModel` get `ttfbTimeoutMs` (default 60 000 for reasoning models, 20 000 otherwise) and `totalTimeoutMs`.
- Failover only on: network error, TTFB timeout, 429, 5xx, breaker open. Never on 4xx other than 429.
- After the first byte has been sent, no failover. If the upstream fails mid-stream, send a terminal error event in the endpoint's streaming format, close the stream, and settle for what was delivered (WS5).
- Hourly cron snapshots breaker state and recent success rate into the existing `Provider` health status for the admin UI. Breaker transitions to open raise an admin notification.
- **Redis outage**: fall back to the current in-memory breaker.

**Acceptance.** Two separate processes pointed at the same Redis see the same open breaker (proves sharing). A 400 from the upstream does not trigger failover or trip the breaker.

---

### WS5 — Upstream abort on disconnect, and partial metering

**Problem.** When a customer presses Ctrl-C in Claude Code, the upstream may keep generating (and billing us) until `max_tokens`. And if the stream ends without a usage chunk, the current billing path may charge nothing, or crash.

**Analysis.** Three signals must abort the upstream fetch: the client disconnecting, the TTFB timeout, and the total timeout. `AbortSignal.any()` combines them. On Vercel, the reliable way to detect a disconnect in a streaming response is the `cancel()` callback of the `ReadableStream` we return (and `request.signal`); verify which fires in Next 16 on the Node runtime (see §15). When a stream is cut short, providers don't send a usage chunk, so we estimate output from what we actually forwarded. We charge for delivered tokens because the provider bills us for them; the policy for upstream-caused failures is a business decision, so make it a setting.

**Requirements.**

- Every upstream `fetch` receives `AbortSignal.any([clientSignal, ttfbTimeoutSignal, totalTimeoutSignal])`. The TTFB timer is cleared on the first byte.
- The stream `TransformStream` (the metering transform) implements `cancel()` → abort upstream → trigger settlement with estimated usage.
- The metering transform accumulates forwarded content length: text deltas, tool-call argument deltas, reasoning deltas.
- `UsageLog.usageSource` enum: `PROVIDER | ESTIMATED`. Prefer provider-reported usage whenever present, even on partial streams.
- Estimation when no usage chunk arrived: input = the WS2 estimate; output = `ceil(forwardedBytes / 3.5)`.
- Store setting `partialChargePolicy`: `CHARGE_DELIVERED` (default) or `WAIVE_ON_UPSTREAM_ERROR` (charge client disconnects, waive failures caused by the upstream).
- `UsageLog.outcome` enum: `COMPLETED | CLIENT_DISCONNECTED | UPSTREAM_ERROR | TIMEOUT`.

**Acceptance.** Using the mock upstream (§14), aborting the client mid-stream causes the mock to observe the upstream cancellation within 1 s; the usage log is `ESTIMATED` + `CLIENT_DISCONNECTED`; the reservation is settled.

---

### WS6 — Cache-aware usage normalisation and pricing

**Problem.** DeepSeek-family models report cache hits separately, and cache hits cost a small fraction of normal input. Coding agents resend the same large context every turn, so most of their input tokens are cache hits. Billing all prompt tokens at the full rate overcharges customers; billing at the cache rate undercharges us.

**Analysis.** Each provider reports usage in its own dialect. Normalise every response into one internal shape, price each component separately, and keep the raw usage for audit. The customer-facing charge must pass cache savings through in a way that matches the plan type; for TOKENS-mode plans that's a product decision (see §16).

**Requirements.**

- Normalised usage type: `{ inputUncached, inputCached, cacheWrite, output, reasoning }` (all bigint). Reasoning tokens are billed as output unless the provider prices them separately.
- `lib/gateway/usage/` with one normaliser per dialect: `openai` (`prompt_tokens_details.cached_tokens`), `deepseek` (`prompt_cache_hit_tokens` / `prompt_cache_miss_tokens`), `anthropic` (`cache_read_input_tokens` / `cache_creation_input_tokens`), `deepinfra` (confirm fields, including `estimated_cost`), `openrouter` (confirm fields). Field names **must** be confirmed against real responses and saved as test fixtures.
- `Provider.usageDialect` selects the normaliser.
- `GatewayModel` / `ProviderModel` pricing fields: `inputPerMTok`, `cachedInputPerMTok`, `cacheWritePerMTok`, `outputPerMTok` (µ$ bigint). Backfill `cachedInputPerMTok = inputPerMTok` for existing rows so behaviour doesn't change until an admin sets real cache prices.
- `UsageLog` stores each normalised component, the provider cost, the customer charge, and `rawUsage` JSON (the usage object only — never content).
- The Anthropic translator maps cache fields both ways so Claude Code shows correct cache statistics.
- Inject `stream_options: { include_usage: true }` on OpenAI-format upstream streams when the provider supports it (`Provider.supportsStreamUsage`).

**Acceptance.** Fixture-driven tests for every dialect; an agent-style replay with 90% cache hits is charged the correct blended amount; DeepInfra `estimated_cost`, when present, is compared against our computed cost and large disagreements are logged.

---

## 8. Workstreams — packs, honesty, GamsGo


### WS8 — Packs, plan binding and the pricing engine

**Problem.** Plans are auto-assigned "by price when exactly one plan matches". With zero or two matches, the customer silently falls back to the global multiplier and is billed at an unintended rate.

**Analysis.** Introduce an explicit `Pack` (the thing sold on GamsGo), bound to exactly one plan. Activations and vouchers reference a pack, so there's nothing to guess. A single pricing engine converts normalised usage into the customer's unit for any plan mode, so reservation, settlement and display all agree.

**Requirements.**

- New model `Pack`: `id`, `storeId`, `name`, `planId` (required), `balanceGrant` BigInt, `bonusGrant` BigInt, `listingPriceLabel` String (display only, e.g. "€9.99 on GamsGo"), `gamsgoOfferRef` nullable, `active`, soft delete.
- Manual Order-ID activation and recharge approval: the admin **must choose a pack** (price matching becomes a pre-selected suggestion only). Approval is blocked without a pack.
- Customers with no plan: keep the global-multiplier fallback for now, but show a "No plan" warning badge in admin, a count on the dashboard, and a bulk "assign plan" action.
- `lib/billing/pricing-engine.ts`: `quote(plan, model, normalisedUsage) → bigint` in the customer's unit; `estimateHold(plan, model, estimate) → bigint`. CREDITS mode = provider cost × plan multiplier (cache discounts pass through proportionally). TOKENS mode = weighted token count × flat rate, with `cachedTokenWeight` on the plan (see §16).
- The portal API Access page and catalog use the engine to display effective prices.

**Acceptance.** No code path assigns a plan by price matching; the engine has unit tests for both modes, including cache-heavy usage.

---

### WS9 — GamsGo automatic activation with single-use vouchers

**Finding.** GamsGo does not document a seller API or order webhook. Its seller automation is **Automatic Delivery**: the seller pre-loads inventory entries (a username/password pair per item) on the offer, and when a buyer orders, GamsGo instantly sends one entry to the buyer. Manual delivery notifies the seller, who must deliver within the promised time.

**Design.** Use Automatic Delivery as the webhook. We pre-generate single-use **voucher codes** for a pack, upload them as GamsGo inventory, and GamsGo hands one to each buyer instantly. The buyer redeems it on our site and is activated immediately — no admin step, no polling, no dependency on a GamsGo API.

**Analysis of the risks and how the design handles them.**

- *Inventory exposure.* Codes live on a third-party platform, so they must be single-use, high-entropy, and useless once redeemed. Never put gateway tokens or portal access codes into GamsGo inventory — those are long-lived secrets.
- *Database leak.* Store only an HMAC of each code with a server-side pepper, plus the last 4 characters for support lookup.
- *Double redemption.* Claim the voucher with a conditional update (`WHERE status='ISSUED'`), so parallel redemptions of the same code produce exactly one success.
- *Typos.* A check character catches mistyped codes on the client before a server round-trip, and normalisation tolerates dashes, spaces, case, and O/0, I/L/1 confusion.
- *Refunds and disputes.* GamsGo buyers can request refunds. An unredeemed voucher can be revoked; a redeemed one can be clawed back from the remaining balance, through the ledger, with a reason.
- *Stock visibility.* We can't read GamsGo's inventory count, so we approximate stock as "issued, uploaded, not yet redeemed" per pack, and alert on low stock.
- *Batch compromise.* Revoke all unredeemed codes in a batch in one action.
- *Abuse.* Rate-limit redemptions, return uniform responses, and route suspicious patterns to the existing manual review queue instead of auto-approving.

**Requirements.**

- Models:
  - `VoucherBatch`: `id`, `storeId`, `packId`, `quantity`, `channel` (`GAMSGO`), `createdByAdminId`, `createdAt`, `exportedAt`, `markedUploadedAt` nullable, `expiresAt` nullable, `note`, `compromisedAt` nullable.
  - `Voucher`: `id`, `storeId`, `batchId`, `packId`, `codeHmac` (unique), `codeLast4`, `status` (`ISSUED | REDEEMED | REVOKED | EXPIRED`), `redeemedByCustomerId`, `redeemedAt`, `redeemIpHash`, `gamsgoOrderId` nullable, `revokedReason` nullable, `revokedByAdminId` nullable.
- Code generation (`lib/vouchers/code.ts`):
  - 20 Crockford base32 characters from `crypto.randomBytes` (100 bits of entropy) + 1 check character, formatted with a per-store prefix, e.g. `ALK-XXXXX-XXXXX-XXXXX-XXXXX-C`.
  - `normalise()` uppercases, strips separators, maps `O→0`, `I/L→1`.
  - `codeHmac = HMAC-SHA256(VOUCHER_PEPPER, normalisedCode)`.
- Admin **Vouchers** page (`/admin/vouchers`, role-gated):
  - Generate a batch: choose pack + quantity (max 1000). Plaintext codes are returned **exactly once** as a download: CSV with configurable column mapping (default `username = code`, `password = redeem URL`) **and** TXT (one per line). Codes are never retrievable again. Log to the admin activity log.
  - "Mark as uploaded to GamsGo" per batch.
  - Stock card per pack: uploaded-and-unredeemed count, redemptions in the last 7 days, days of stock left at the current rate, low-stock threshold (setting) → notification bell.
  - Lookup by full code, last 4, GamsGo order ID, or customer.
  - Actions: revoke voucher (if `ISSUED`), clawback (if `REDEEMED`: `CLAWBACK` ledger entry for min(grant, remaining balance), reason required, optional customer suspension), revoke whole batch (compromise).
  - **Listing text helper**: generate a truthful GamsGo title/description from pack data (credits, models served, how to redeem, "usage rights only", support contact) with a copy button, following GamsGo's title rules (no "official", "lifetime", "never banned", no keyword stuffing).
- Redemption:
  - Public `/redeem` page (store resolved from domain, like the rest of the site) and a code field on the existing portal Recharge page.
  - **New customer**: claim voucher → create customer + access code + plan from pack → `VOUCHER_REDEMPTION` ledger entries (balance and bonus grants) → show the access code once and sign them in. Same side effects as today's approved activation: affiliate attribution, loyalty points, repurchase tracking, welcome state.
  - **Existing, signed-in customer**: claim → credit their account with the same side effects as today's approved recharge, including the returning-customer review bonus rules.
  - Optional "GamsGo Order ID" field, stored on the voucher for support matching.
  - Claim + customer creation + ledger writes happen in one transaction.
- Auto-approval: store setting `voucherAutoApprove` (default `true`). Risk rules send a redemption to the existing Activations & Recharges queue (with `source = VOUCHER`) instead of crediting immediately: more than N redemptions per IP per day (setting), batch marked compromised, customer flagged. In that case the voucher is `REDEEMED` but the ledger credit waits for approval.
- Security: Redis rate limit per IP and per session on redemption (default 10 per 10 min); identical response body and similar timing for invalid, used, revoked and expired codes ("This code is invalid or has already been used"); optional Cloudflare Turnstile after repeated failures (setting).
- Expiry cron: `ISSUED` vouchers past `expiresAt` → `EXPIRED`.
- **Keep the existing Order-ID activation flow** unchanged as a fallback for manual-delivery listings. Both flows coexist.
- Docs: `docs/vouchers.md` explaining the GamsGo workflow step by step for the admin (generate → download → paste into GamsGo inventory → mark uploaded → monitor stock → handle refunds).

**Acceptance.**

- 20 parallel redemptions of one code → exactly 1 success, 19 identical failures.
- A redeemed code can't be redeemed again; revoked and expired codes fail with the same message.
- Plaintext codes appear in no table, log, or error.
- Clawback writes a ledger entry and never makes a balance negative.
- A new buyer goes from code to working API token with no admin involvement.

---

### WS10 — Retire API Pool key assignment

**Problem.** The admin API Pool tracks upstream keys as available / assigned / problematic, which suggests customers previously received provider keys directly. With the gateway live, no customer should hold an upstream key: sharing provider keys usually breaks the provider's terms (which is typically why keys become "problematic"), and it makes metering and revocation impossible.

**Requirements.**

- Flag `LEGACY_API_POOL_MODE=active|readonly|off`, default `readonly` after this phase.
- In `readonly`: no new assignments; any customer-facing surface that shows an upstream key is removed; admin page shows history only, with keys masked (`sk-…abcd`).
- Portal banner for customers who still have an assigned key: "Create your AeroLink API token on the API Access page — your previous access method is being retired."
- Admin action "Unassign all" and "Purge pool keys" (confirmation + activity log).
- If any pool keys are actually used as gateway upstream credentials, migrate them into `Provider` records (encrypted) instead.
- Include in the audit every code path that exposes upstream credentials; add a test asserting no portal route returns a string matching known provider key patterns.

---

## 9. Workstreams — providers, Claude Code, platform

### WS11 — Multi-provider depth

**Analysis.** DeepInfra alone is a single point of failure. DeepSeek direct is usually the cheapest source for DeepSeek models and has strong prompt caching; OpenRouter is a useful last-resort fallback because it fronts many hosts. Per-attempt logging is what tells you which provider is actually costing you reliability — today only the final outcome is visible.

**Requirements.**

- Provider capability flags on `Provider`: `supportsOpenAIChat`, `supportsAnthropicMessages`, `anthropicBaseUrl` nullable, `supportsStreamUsage`, `supportsPromptCache`, `usageDialect`, `ttfbTimeoutMs`, `totalTimeoutMs`, `extraHeaders` JSON (e.g. OpenRouter's optional attribution headers).
- Setup scripts mirroring `npm run gateway:deepinfra`: `gateway:deepseek`, `gateway:openrouter`.
- New model `GatewayAttempt`: `requestId`, `attemptNo`, `providerId`, `providerModelId`, `upstreamModel`, `wire` (`OPENAI | ANTHROPIC_NATIVE | ANTHROPIC_TRANSLATED`), `outcome` (`OK | HTTP_4XX | HTTP_429 | HTTP_5XX | TTFB_TIMEOUT | NETWORK | BREAKER_OPEN`), `statusCode`, `ttfbMs`, `errorSnippet` (sanitised, max 500 chars), `createdAt`. `UsageLog` references the successful attempt.
- Admin Providers page: live breaker state (from Redis), success rate and p50/p95 TTFB over 1 h / 24 h (from attempts), failover rate.
- Catalog models store `license`; a model can't be enabled for a store without a license value.

**Acceptance.** A mock provider returning 429 before the first byte results in two `GatewayAttempt` rows and a successful response from the second provider.

---

### WS13 — Native Anthropic passthrough for Claude Code

**Problem.** Translating `/v1/messages` to OpenAI format and back is the most fragile code in the gateway: tool use with parallel calls, `input_json_delta` streaming, thinking blocks, `cache_control` on system arrays, stop reasons, images, and error shapes all have to map perfectly or Claude Code misbehaves.

**Analysis.** Where a provider exposes an Anthropic-compatible endpoint (DeepSeek has offered one — verify), forward the request natively and meter from Anthropic usage events. Keep the translator as the fallback. Because failover can move between providers, the wire choice is made per attempt. A fixture-based conformance suite, recorded from real providers, protects both paths.

**Requirements.**

- For `/v1/messages`: per attempt, if the provider model `supportsAnthropicMessages`, forward natively (after the body allowlist, model rewrite and `max_tokens` clamp) and stream back unchanged except for the `model` field; otherwise use the translator.
- Native metering: `message_start.message.usage` (input + cache fields) and the final `message_delta.usage.output_tokens`.
- `/v1/messages/count_tokens`: forward natively when supported; otherwise keep the local estimate.
- Conformance suite with recorded SSE fixtures (secrets stripped) covering: plain text streaming; single and parallel `tool_use`; `tool_result` round-trip; `input_json_delta`; thinking/reasoning blocks (mapping to `reasoning_content` in the translator); system prompt as an array with `cache_control`; `stop_reason` values (`end_turn`, `tool_use`, `max_tokens`); image input if a model supports it; every error type in Anthropic shape (401, 402-insufficient balance, 413, 429, 5xx).
- `docs/claude-code-testing.md`: a manual end-to-end procedure with real Claude Code (env vars, a multi-file edit task, a tool-heavy task, interrupting mid-response, resuming).

**Acceptance.** The conformance suite passes on both native and translated paths; the manual Claude Code procedure succeeds against a preview deployment.

---

### WS12 — Platform hardening

**Requirements and analysis, item by item.**

1. **Body size.** Vercel rejects function request bodies above its platform limit (about 4.5 MB — verify) before our code runs, so the current 20 MB cap is unreachable and customers get a generic platform error. Set `GATEWAY_MAX_BODY_BYTES` safely below the verified limit, check `Content-Length` early and also enforce while reading, and return 413 in the right wire shape with a message explaining the limit.
2. **Database pooling.** Every gateway request touches Postgres. Use a pooled runtime URL (`DATABASE_URL`) and a direct URL for migrations (`directUrl` / `DIRECT_URL` in the Prisma datasource). Keep the Prisma client a module-level singleton; set a small per-instance `connection_limit`. Document the exact settings for our Postgres host (ask me which one).
3. **Auth cache.** Cache `sha256(token) → {tokenId, customerId, storeId, status, planId}` in Redis for 60 s. **Revocation must be immediate**: revoking a token deletes its cache key. Negative-cache unknown tokens for 10 s to blunt brute force. Cache the model/provider catalog for 60 s, invalidated on admin edits.
4. **Dedicated encryption secret.** Deriving the provider-key encryption key from `SESSION_SECRET` means rotating the session secret (which you must do after any leak) destroys every stored provider key. Add `PROVIDER_KEY_SECRET` (32 random bytes, base64). Version ciphertexts (`v1:` session-derived, `v2:` dedicated). Decrypt both; encrypt only v2. Add `npm run keys:reencrypt` to migrate all rows, idempotent. Document removing v1 support afterwards.
5. **Migration safety.** Running migrations inside every Vercel build means preview deployments can migrate production if they share env vars, and a failed deploy can leave the schema ahead of the running code. Only run `prisma migrate deploy` when `VERCEL_ENV === 'production'`; previews must use a separate database (document the env setup; fail the preview build loudly if it points at the production database host). Seeding must be idempotent and must never overwrite existing production rows.
6. **Response hygiene.** `cache-control: no-cache, no-transform` and `x-accel-buffering: no` on streams; `x-request-id` on everything; sanitised upstream errors.
7. **Cron security.** Every cron route checks `Authorization: Bearer ${CRON_SECRET}`.

---

### WS14 — Observability and reconciliation

**Requirements.**

- Structured JSON log line per request: `requestId, storeId, customerId, tokenId, model, providerAttempts, finalProvider, wire, ttfbMs, totalMs, usage components, providerCost, customerCharge, uncollected, outcome, usageSource`. Never content.
- Admin Statistics additions: requests, error rate, failover rate, and **margin** (customer charge − provider cost) by day, model and provider.
- Daily cron:
  - Ledger reconciliation: compare `sum(ledger)` per customer per pot with cached fields; report drift to the notification bell and a `/admin/reconciliation` page. **Report, never auto-fix.**
  - `ProviderCostDaily` rollup of our metered provider cost per provider.
  - Admin form to enter the provider-reported daily/monthly cost from each provider dashboard; show drift % against our metered cost; alert above a threshold (setting, default 3%).
  - Voucher expiry and low-stock checks (WS9).
- Notifications: breaker opened, sweeper released holds, ledger drift, voucher low stock, provider cost drift, redemption routed to review.

---

## 10. Data model changes (summary)

| Model | Change |
|---|---|
| `Customer` | + `reserved` BigInt |
| `LedgerEntry` | new (WS1) |
| `GatewayReservation` | new (WS2) |
| `GatewayAttempt` | new (WS11) |
| `UsageLog` | + normalised usage components, `rawUsage` JSON, `usageSource`, `outcome`, `uncollected`, `reservationId`, `attemptId` |
| `Pack` | new (WS8) |
| `VoucherBatch`, `Voucher` | new (WS9) |
| `Provider` | + capability flags, `usageDialect`, timeouts, `anthropicBaseUrl`, `extraHeaders`; key ciphertext versioning |
| `ProviderModel` / `GatewayModel` | + `cachedInputPerMTok`, `cacheWritePerMTok`, `ttfbTimeoutMs`, `license`, `attribution`, `isReasoning` |
| `ProviderCostDaily` | new (WS14) |
| Activation/recharge queue item | + `source` (`ORDER_ID | VOUCHER`), `packId` required on approval |

Every new table carries `storeId` and follows the existing soft-delete convention where it applies.

---

## 11. Environment variables (add to `.env.example`)

```
# Redis
UPSTASH_REDIS_REST_URL=
UPSTASH_REDIS_REST_TOKEN=
REDIS_DISABLED=false            # local dev only

# Database
DATABASE_URL=                   # pooled, runtime
DIRECT_URL=                     # direct, migrations only

# Secrets
PROVIDER_KEY_SECRET=            # 32 random bytes, base64
VOUCHER_PEPPER=                 # 32 random bytes, base64
CRON_SECRET=

# Gateway
GATEWAY_MAX_DURATION=800
GATEWAY_MAX_BODY_BYTES=         # below the verified Vercel limit
GATEWAY_MIN_OUTPUT_TOKENS=256
GATEWAY_RESERVATIONS=shadow     # off | shadow | enforce
GATEWAY_REDIS_BREAKER=true
GATEWAY_RATE_LIMITS=true
ANTHROPIC_PASSTHROUGH=true
LEGACY_API_POOL_MODE=readonly   # active | readonly | off
VOUCHERS_ENABLED=true

# Optional
TURNSTILE_SITE_KEY=
TURNSTILE_SECRET_KEY=
```

---

## 12. Cron jobs (`vercel.json`)

| Schedule | Route | Job |
|---|---|---|
| every 5 min | `/api/cron/reservations` | Sweep expired holds (WS2) |
| hourly | `/api/cron/provider-health` | Snapshot breaker state + success rates (WS4) |
| daily 02:00 UTC | `/api/cron/daily` | Ledger reconciliation, provider cost rollup, voucher expiry, low-stock check (WS14, WS9) |

Keep the existing support auto-fix cron untouched. Verify cron frequency limits for our Vercel plan.

---

## 13. Feature flags and rollout

| Flag | Rollout |
|---|---|
| `GATEWAY_RESERVATIONS` | `shadow` 24–48 h in production → review would-reject logs → `enforce` |
| `GATEWAY_RATE_LIMITS` | Start with generous limits; tighten from observed traffic |
| `GATEWAY_REDIS_BREAKER` | On after two-process test passes |
| `ANTHROPIC_PASSTHROUGH` | On per provider after the conformance suite passes |
| `VOUCHERS_ENABLED` | Generate a small first batch (e.g. 20), upload to one GamsGo offer, monitor, then scale |
| `LEGACY_API_POOL_MODE` | `readonly` → announce to customers → `off` after two weeks |

Order of production migration: deploy additive schema → run `ledger:backfill` → run `keys:reencrypt` → enable flags one at a time.

---

## 14. Testing plan

**Infrastructure.**

- `docker-compose.test.yml` with Postgres and Redis. Concurrency and ledger tests run only against Postgres.
- **Mock upstream server** (`test/mock-upstream/`) that speaks OpenAI chat and Anthropic messages, streaming and non-streaming, and can be scripted per test: delay before first byte, delay between chunks, fail with 429/5xx before or after first byte, omit the usage chunk, emit cache fields in each dialect, and record when a client cancels.
- Recorded fixtures from real providers (secrets stripped) for every usage dialect and for the Anthropic conformance suite.

**Required tests.**

| Area | Test |
|---|---|
| Reservations | 50 parallel requests on a balance covering ~3 → never negative, `reserved` returns to 0 |
| Reservations | Double settle → charged once; killed request → sweeper releases |
| Reservations | Fit-to-balance lowers `max_tokens` instead of rejecting |
| Ledger | Sum equals cached fields after the whole suite; backfill idempotent; grep test |
| Rate limits | RPM 429 with `Retry-After` in both wire formats; concurrency cap; lease expiry |
| Breaker | Shared across two processes; 400 doesn't trip or fail over |
| Failover | 429 before first byte → second provider; 5xx after first byte → terminal error event, no failover, partial charge |
| Abort | Client cancel → upstream cancelled < 1 s; `ESTIMATED` + `CLIENT_DISCONNECTED` |
| Pricing | Every usage dialect; cache-heavy agent replay; CREDITS and TOKENS modes |
| Vouchers | 20 parallel redemptions of one code → 1 success; uniform failure responses; revoke; clawback; batch revoke; expiry |
| Vouchers | New customer flow end-to-end; existing customer top-up; risk rule routes to queue |
| Anthropic | Conformance suite on native and translated paths |
| Security | No portal route returns provider-key-like strings; no plaintext voucher codes stored or logged |
| Body limit | Oversized request → 413 in the correct wire shape |

**Load test.** A `k6` (or `autocannon`) script run against a preview deployment pointed at the mock upstream: sustained parallel streams per customer, a customer near zero balance, mid-stream disconnects, one provider failing. Document how to run it and what to watch.

---

## 15. Verify, don't assume

Confirm each of these from current official docs or real responses, record the result in the audit, and adapt the design if reality differs:

1. Vercel function request body size limit, `maxDuration` limits for our plan, and that Fluid compute is enabled for the project.
2. In Next 16 route handlers on the Vercel Node runtime: whether `request.signal` aborts on client disconnect, and whether the returned stream's `cancel()` fires.
3. Whether `after()` runs after a streaming response fully closes, or whether `waitUntil` from `@vercel/functions` is needed for settlement.
4. DeepSeek: usage field names (cache hit/miss), `stream_options.include_usage` support, and the availability, base URL and feature coverage of its Anthropic-compatible endpoint.
5. DeepInfra: streaming usage support and the `estimated_cost` field.
6. OpenRouter: usage fields and cache reporting.
7. Upstash: Lua/`EVAL` support in the REST client and the current `@upstash/ratelimit` API.
8. Vercel cron frequency limits for our plan.
9. The license of every model before it's enabled.

**Human task (me, not you):** confirm the GamsGo Automatic Delivery inventory format and delivery template rules in Seller Center, so the CSV column mapping matches exactly. Build the export with configurable columns so this doesn't block you.

---

## 16. Questions I expect you to ask me

1. TOKENS-mode plans: should cached input tokens count fully (`cachedTokenWeight = 1.0`, current behaviour) or at a discount (e.g. `0.1`)?
2. Partial-charge policy default: `CHARGE_DELIVERED` or `WAIVE_ON_UPSTREAM_ERROR`?
3. Default `rpm` and `maxConcurrent` per plan, and the store-wide concurrency ceiling.
4. Default voucher expiry (none, or e.g. 12 months).
5. Should vouchers auto-approve from day one, and the risk-rule thresholds.
6. Which Postgres host we use in production (for pooling configuration).
7. Low-stock threshold per pack.

---

## 17. Definition of done

- All workstreams implemented behind their flags; all tests in §14 passing; `next build` clean.
- Docs written or updated: `docs/gateway-audit.md`, `docs/gateway.md` (architecture and operations), `docs/vouchers.md` (GamsGo workflow for the admin), `docs/claude-code-testing.md`, `docs/copy-audit.md`, `docs/runbook.md` (flags, crons, what each alert means and what to do).
- `.env.example` complete.
- A final summary listing: what changed per phase, migrations to run in order, env vars to set, flags to flip in order, and anything left as a TODO for me.
