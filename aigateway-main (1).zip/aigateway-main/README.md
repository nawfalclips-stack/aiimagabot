# AeroLink — API Customer Portal

A production-ready SaaS platform for managing customers who purchased API access.

- **Admin Dashboard** (`/admin`) — create customers, assign API keys, track balances, bonuses, profit, repurchases, manage documentation and settings.
- **Customer Portal** (`/`) — customers sign in with a **unique access code only** (no email, no registration) and see their assigned API key, balance, bonus, order info and setup documentation.

Built with Next.js 16 (App Router), React 19, TypeScript, Tailwind CSS v4, shadcn/ui, Framer Motion, Prisma 6, and Recharts.

---

## Quick start (local)

```bash
npm install
npm run db:setup     # creates the SQLite dev database and seeds it
npm run dev          # http://localhost:3000
```

Default admin account (change in `.env` before seeding, or via `ADMIN_*` env vars):

| | |
|---|---|
| Admin URL | `http://localhost:3000/admin/login` |
| Email | `admin@aerolink.lat` |
| Password | `ChangeMe123!` |

Locally the app uses **SQLite** (`prisma/schema.sqlite.prisma`, file `prisma/dev.db`). In production it uses **PostgreSQL** (`prisma/schema.prisma`). `scripts/prisma.mjs` picks the right schema automatically from `DATABASE_URL` — you never switch anything by hand.

---

## Deploy to Vercel (one time, ~3 minutes)

Everything is automated through the `vercel-build` script (generate client → push schema → seed → build). You only need to give Vercel a database and two secrets:

1. **Push this folder to a Git repository** (GitHub/GitLab) and import it in Vercel — or run `npx vercel` from this folder.
2. In the Vercel project: **Storage → Create Database → Postgres** (Neon / Prisma Postgres — any of them). This automatically injects `DATABASE_URL`.
3. In **Settings → Environment Variables**, add:

   | Variable | Value |
   |---|---|
   | `SESSION_SECRET` | a long random string (e.g. output of `openssl rand -base64 48`) |
   | `ADMIN_EMAIL` | your admin login email |
   | `ADMIN_PASSWORD` | your admin password |
   | `ADMIN_NAME` | display name (optional) |
   | `NEXT_PUBLIC_APP_URL` | `https://your-app.vercel.app` (optional, for SEO tags) |

4. **Deploy.** On the first build the database schema is migrated (`prisma migrate deploy`; an existing database gets the baseline marked as applied) and seeded automatically (admin account, settings, documentation). Every later deploy is safe: the seed only creates what's missing and **never overwrites** documentation or settings you edited in the dashboard.

---

## How it works

### Customer lifecycle
1. Admin creates a customer: access code (generator button), order number (generator button), API key (entered manually — the system never generates API keys), initial balance, initial bonus, profit.
2. Customer signs in at `/` with the access code and sees their key, balances and docs.
3. Admin records usage via **Update Usage** (enters only the amount used) — used/remaining are calculated automatically and can never go negative.
4. Status is automatic: remaining > threshold → **Active**; ≤ threshold (default $10, configurable in Settings) → **Low Balance**; $0 → **Balance Finished** and the customer appears in **Expired Balance** with 🟢/🔴 repurchase tracking. **Suspended/Expired** are manual.
5. Deletes are soft — restore or permanently delete from **Settings**.

### Documentation
The guides in `prisma/docs/*.md` are the source of truth (Codex CLI + Claude Code × Windows/macOS/Linux). In the customer portal, every occurrence of `YOUR_AEROLINK_API_KEY` is replaced with the customer's assigned key at render time — customers never create keys. The admin **Documentation** page has a markdown editor with live preview and full version history/rollback.

### Money
Customer credit is an append-only ledger (`LedgerEntry`, micro-USD) with cached cents on `Customer`; only `lib/billing/balance-service.ts` may move money. Gateway requests reserve their worst-case cost before being forwarded and settle the real cost afterwards. Details: [docs/gateway.md](docs/gateway.md); operations: [docs/runbook.md](docs/runbook.md).

### Security
- Admin auth: bcrypt-hashed passwords, signed JWT session cookies (`jose`), HTTP-only/SameSite, uniform-timing login, rate limiting.
- Customer auth: signed session cookie created only after access-code validation; customers can only ever read their own row.
- All admin server actions re-verify the admin session server-side. Route protection in `proxy.ts` plus security headers.

## Scripts

| Command | What it does |
|---|---|
| `npm run dev` | dev server |
| `npm run build` | production build |
| `npm run db:setup` | generate client + push schema + seed (idempotent) |
| `npm run db:push` / `db:seed` | individual steps (SQLite locally) |
| `npm run db:migrate` | apply Prisma migrations to a Postgres `DATABASE_URL` (what Vercel runs) |
| `npm run db:migrate:dev -- --name <name>` | create a new migration against a local Postgres |
| `npm run typecheck` / `lint` | TypeScript and ESLint |
| `npm test` / `test:unit` / `test:integration` | Vitest — see [docs/testing.md](docs/testing.md) |
| `npm run check` | typecheck + lint + unit tests + build (the per-phase gate) |
| `npm run mock:upstream -- 4010` | scriptable mock LLM provider for local gateway work |
| `npm run gateway:dev-seed` | register the mock providers + a dev token (after `mock:upstream`) |
| `npm run ledger:backfill` | one-off: open the credit ledger for pre-existing customers (idempotent) |
| `vercel-build` | used by Vercel automatically: generate → migrate → seed → build |
