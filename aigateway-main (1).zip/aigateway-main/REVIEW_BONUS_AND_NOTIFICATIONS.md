# Review Bonus System & Admin Notifications

## Overview
This document describes the new features added to the API Customer Portal:
1. **Review Bonus System** - Customers can claim bonus balance by writing reviews
2. **Admin Notification System** - Bell notifications for important customer actions

---

## 1. Review Bonus System

### How It Works

#### Customer Flow:
1. **Activation**: Customer activates their account with Order Number + Offer Title
2. **Banner Display**: After activation, customer sees a banner offering bonus (e.g., 10% of balance)
3. **Review Process**:
   - Customer clicks "Write a review" button → opens store page
   - Customer writes positive review on the store
   - Customer returns and clicks "Yes, I wrote a review"
4. **Bonus Credit**: Bonus is immediately added to customer's account
5. **Admin Verification**: Admin can verify or revoke the bonus later

#### Bonus Calculation:
- Bonus percentage is parsed from the Offer Title (e.g., "300$ + 10% Bonus")
- If offer title says "300$ + 30$ Bonus", the bonus is $30
- Bonus is held in `pendingBonusCents` until customer claims it

#### Review Bonus States:
- `NONE` - No bonus offered
- `OFFERED` - Bonus available, waiting for customer to claim
- `CLAIMED` - Customer claimed the bonus (credited)
- `VERIFIED` - Admin verified the review exists
- `REVOKED` - Admin removed bonus (no review found)

### Database Fields (Customer model):
```prisma
offerTitle        String    @default("")
pendingBonusCents Int       @default(0)
reviewBonusStatus String    @default("NONE") // NONE | OFFERED | CLAIMED | VERIFIED | REVOKED
reviewClaimedAt   DateTime?
```

### Files Involved:
- `components/portal/review-bonus-banner.tsx` - Banner component (already existed)
- `lib/services/review-bonus.ts` - Review bonus logic (updated with notifications)
- `app/portal/page.tsx` - Customer dashboard showing the banner

---

## 2. Admin Notification System

### Notification Types

#### 1. **REVIEW_CLAIMED**
- Triggered when: Customer clicks "Yes, I wrote a review"
- Message: "Customer [ACCESS_CODE] claimed [AMOUNT] review bonus"
- Links to: `/admin/customers`

#### 2. **ACTIVATION_PENDING**
- Triggered when: Customer successfully activates their account
- Message: "Customer [ACCESS_CODE] activated with [AMOUNT] balance"
- Links to: `/admin/activations`

#### 3. **RECHARGE_REQUESTED**
- Triggered when: Customer submits recharge request
- Message: "Customer [ACCESS_CODE] requested [AMOUNT] recharge"
- Links to: `/admin/recharges`

### Notification Bell UI
- **Location**: Admin panel header (top right, before store switcher)
- **Badge**: Red badge showing unread notification count
- **Dropdown**: Click bell → shows recent 20 notifications
- **Actions**:
  - Click notification → mark as read + navigate to relevant page
  - "Mark all read" button at top

### Database Model:
```prisma
model Notification {
  id          String   @id @default(cuid())
  storeId     String
  type        String   // REVIEW_CLAIMED | ACTIVATION_PENDING | RECHARGE_REQUESTED
  title       String
  message     String
  customerId  String?
  relatedId   String?  // ID of related entity
  isRead      Boolean  @default(false)
  createdAt   DateTime @default(now())
  updatedAt   DateTime @updatedAt

  @@index([storeId, isRead, createdAt])
  @@index([type])
}
```

### Files Created/Updated:

#### New Files:
- `lib/services/notifications.ts` - Notification service functions
- `components/admin/notification-bell.tsx` - Bell icon component with dropdown
- `prisma/schema.prisma` - Added Notification model
- `prisma/schema.sqlite.prisma` - Added Notification model

#### Updated Files:
- `app/admin/actions.ts` - Added notification actions (markAsRead, markAllAsRead)
- `app/admin/(dashboard)/layout.tsx` - Fetch and pass notifications to AdminShell
- `components/admin/admin-shell.tsx` - Added NotificationBell to header
- `lib/services/review-bonus.ts` - Create notification when review claimed
- `lib/services/redemption.ts` - Create notification when customer activates
- `app/portal/recharge/actions.ts` - Create notification when recharge requested
- `app/activate/actions.ts` - Pass storeId to redemption service

---

## 3. Store URL Configuration

The store URL for reviews can be configured per store in Settings:
- **AeroLink**: Uses existing `storeUrl` setting
- **ChefAPI**: Should use `https://www.gamsgo.com/shop-store/ab3a9d0e-937f-e93e-1b66-5dca973aa779`

To set ChefAPI store URL:
```sql
INSERT INTO "Setting" ("storeId", key, value, "createdAt", "updatedAt")
VALUES ('chefapi', 'storeUrl', 'https://www.gamsgo.com/shop-store/ab3a9d0e-937f-e93e-1b66-5dca973aa779', NOW(), NOW())
ON CONFLICT ("storeId", key) DO UPDATE SET value = EXCLUDED.value;
```

---

## 4. API Functions

### Notification Service (`lib/services/notifications.ts`):
```typescript
// Create notification
createNotification({
  storeId: 'aerolink',
  type: NOTIFICATION_TYPES.REVIEW_CLAIMED,
  title: 'Review Bonus Claimed',
  message: 'Customer ABC-123 claimed $10.00 review bonus',
  customerId: 'customer_id',
  relatedId: 'customer_id'
})

// Get unread count
getUnreadNotificationCount(storeId: string): Promise<number>

// Get recent notifications
getNotifications(storeId: string, limit = 20)

// Mark as read
markNotificationAsRead(notificationId: string)

// Mark all as read
markAllNotificationsAsRead(storeId: string)
```

---

## 5. Multi-Store Support

All notifications are scoped to `storeId`:
- Each store has its own notifications
- Bell badge shows unread count for current store only
- Admin sees notifications only for selected store

---

## 6. Testing Checklist

### Review Bonus System:
- [ ] Customer activates with offer that has bonus
- [ ] Banner shows with correct bonus amount
- [ ] Click "Write a review" opens store in new tab
- [ ] Click "Yes, I wrote a review" credits bonus
- [ ] Bonus appears in customer's bonus balance
- [ ] Admin receives notification

### Notifications:
- [ ] New activation creates notification
- [ ] Review claim creates notification
- [ ] Recharge request creates notification
- [ ] Bell shows unread count badge
- [ ] Click notification marks it as read
- [ ] Click notification navigates to correct page
- [ ] "Mark all read" clears badge
- [ ] Notifications are store-scoped

---

## 7. Future Enhancements

Potential improvements:
1. Email notifications for admins
2. Push notifications (browser)
3. Notification preferences per admin
4. Notification history filtering
5. Auto-verify reviews via API integration
6. Notification sound/toast when new notification arrives

---

## Notes

- All notifications persist across sessions
- Notifications are not deleted, only marked as read
- The system shows the most recent 20 notifications in the dropdown
- Clicking a notification navigates to the relevant admin page
- The review bonus feature was already implemented - we only added notifications for it
