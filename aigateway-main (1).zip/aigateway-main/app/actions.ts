"use server";

import { redirect } from "next/navigation";
import { headers } from "next/headers";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { createCustomerSession, destroyCustomerSession } from "@/lib/session";
import { rateLimit } from "@/lib/rate-limit";

export interface CustomerLoginState {
  error?: string;
}

const codeSchema = z
  .string()
  // Tolerate copy/paste artifacts: strip ALL whitespace before validating.
  .transform((value) => value.replace(/\s+/g, ""))
  .pipe(
    z
      .string()
      .min(6, "Enter your full access code")
      .max(64, "That code looks too long")
      .regex(/^[A-Za-z0-9-]+$/, "Access codes only contain letters, numbers and dashes")
  );

export async function customerLogin(_prev: CustomerLoginState, formData: FormData): Promise<CustomerLoginState> {
  const parsed = codeSchema.safeParse(String(formData.get("accessCode") ?? ""));
  if (!parsed.success) {
    return { error: parsed.error.issues[0].message };
  }

  const ip = ((await headers()).get("x-forwarded-for") ?? "local").split(",")[0].trim();
  const limited = await rateLimit(`customer-login:${ip}`, { limit: 12, windowMs: 15 * 60 * 1000 });
  if (!limited.ok) {
    return { error: "Too many attempts. Please wait a few minutes and try again." };
  }

  const customer = await prisma.customer.findUnique({
    where: { accessCode: parsed.data.toUpperCase() },
    select: { id: true, deletedAt: true },
  });

  if (!customer || customer.deletedAt) {
    return { error: "We couldn't find that access code. Check it and try again." };
  }

  await createCustomerSession(customer.id);
  redirect("/portal");
}

export async function customerLogout(): Promise<void> {
  await destroyCustomerSession();
  redirect("/");
}
