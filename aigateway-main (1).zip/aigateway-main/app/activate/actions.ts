"use server";

import { headers } from "next/headers";
import { z } from "zod";
import { Prisma } from "@prisma/client";
import { rateLimit } from "@/lib/rate-limit";
import { createCustomerSession } from "@/lib/session";
import { redeemOrder, RedemptionFailed } from "@/lib/services/redemption";
import { getStoreIdFromPath } from "@/lib/store";
import { getPackChoice } from "@/lib/services/packs";

export interface ActivateState {
  error?: string;
  accessCode?: string;
  balanceCents?: number;
  pendingBonusCents?: number;
}

const activateSchema = z.object({
  orderId: z
    .string()
    .transform((value) => value.trim())
    .pipe(
      z
        .string()
        .min(4, "That Order ID looks too short")
        .max(64, "That Order ID looks too long")
        .regex(/^[A-Za-z0-9\-_#]+$/, "Order IDs only contain letters, numbers, dashes and #")
    ),
  /** The pack (plan) the customer bought, picked from the list. */
  packId: z.string().trim().max(64).optional().transform((v) => v || undefined),
  /** Fallback when the store has no packs configured: the offer title from the order. */
  offerTitle: z
    .string()
    .optional()
    .transform((value) => (value ?? "").trim().replace(/\s+/g, " "))
    .pipe(z.string().max(200, "That offer title looks too long")),
  affiliateCode: z
    .string()
    .optional()
    .transform((value) => (value ?? "").trim().toUpperCase() || undefined),
});

export async function activateOrder(_prev: ActivateState, formData: FormData): Promise<ActivateState> {
  const parsed = activateSchema.safeParse({
    orderId: String(formData.get("orderId") ?? ""),
    packId: String(formData.get("packId") ?? ""),
    offerTitle: String(formData.get("offerTitle") ?? ""),
    affiliateCode: String(formData.get("affiliateCode") ?? ""),
  });
  if (!parsed.success) {
    return { error: parsed.error.issues[0].message };
  }
  if (!parsed.data.packId && parsed.data.offerTitle.length < 3) {
    return { error: "Choose the plan you bought." };
  }

  const ip = ((await headers()).get("x-forwarded-for") ?? "local").split(",")[0].trim();
  const limited = await rateLimit(`activate:${ip}`, { limit: 6, windowMs: 15 * 60 * 1000 });
  if (!limited.ok) {
    return { error: "Too many attempts. Please wait a few minutes and try again." };
  }

  try {
    // Get storeId from the request path
    const headersList = await headers();
    const pathname = headersList.get("x-pathname") || "/";

    // Referral code: form field first, then the proxy-set cookie (survives
    // navigation/cached pages when the friend arrived via /affiliate/CODE).
    const cookieRef = headersList.get("x-affiliate-ref") ?? undefined;
    const affiliateCode =
      parsed.data.affiliateCode ??
      (cookieRef && /^[A-Z0-9_-]{3,32}$/.test(cookieRef) ? cookieRef : undefined);

    const storeId = getStoreIdFromPath(pathname);

    const pack = parsed.data.packId ? await getPackChoice(storeId, parsed.data.packId) : null;
    if (parsed.data.packId && !pack) {
      return { error: "That plan is no longer available — choose another one." };
    }
    const offerTitle = pack ? `${pack.name}${pack.listingPriceLabel ? ` (${pack.listingPriceLabel})` : ""}` : parsed.data.offerTitle;

    const { customerId, accessCode, balanceCents, pendingBonusCents } = await redeemOrder(
      parsed.data.orderId,
      offerTitle,
      storeId,
      affiliateCode,
      pack
    );
    await createCustomerSession(customerId);
    return { accessCode, balanceCents, pendingBonusCents };
  } catch (error) {
    if (error instanceof RedemptionFailed) {
      if (error.reason === "ALREADY_USED") {
        return { error: "This Order ID has already been activated. If you think this is a mistake, contact support." };
      }
      return {
        error: "No API keys are available right now. Please contact support and we'll activate you manually.",
      };
    }
    if (error instanceof Prisma.PrismaClientKnownRequestError && error.code === "P2002") {
      return { error: "This Order ID has already been activated. If you think this is a mistake, contact support." };
    }
    console.error(error);
    return { error: "Something went wrong. Please try again." };
  }
}
