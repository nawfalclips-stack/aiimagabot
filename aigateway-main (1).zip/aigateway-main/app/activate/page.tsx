import { redirect } from "next/navigation";

// The activation journey now lives on the landing page itself.
export default function ActivateRedirect() {
  redirect("/");
}
