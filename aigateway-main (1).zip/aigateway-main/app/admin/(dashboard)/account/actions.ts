"use server";

import bcrypt from "bcryptjs";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/auth";
import { createAdminSession } from "@/lib/session";
import { rateLimit } from "@/lib/rate-limit";
import { logActivity } from "@/lib/services/activity";
import { getAdminStoreId } from "@/lib/store";
import type { ActionResult } from "@/app/admin/(dashboard)/customers/actions";
import { MIN_ADMIN_PASSWORD_LENGTH } from "@/lib/admin-password";

const schema = z
  .object({
    currentPassword: z.string().min(1, "Enter your current password"),
    newPassword: z
      .string()
      .min(MIN_ADMIN_PASSWORD_LENGTH, `The new password needs at least ${MIN_ADMIN_PASSWORD_LENGTH} characters`)
      .max(200, "The new password is too long"),
    confirmPassword: z.string(),
  })
  .superRefine((d, ctx) => {
    if (d.newPassword !== d.confirmPassword) ctx.addIssue({ code: "custom", path: ["confirmPassword"], message: "The two new passwords don't match" });
    if (d.newPassword === d.currentPassword) ctx.addIssue({ code: "custom", path: ["newPassword"], message: "Choose a password different from the current one" });
  });

export type ChangePasswordInput = z.input<typeof schema>;

/**
 * The signed-in admin changes their own password. Requires the current
 * password; every other session of this admin is signed out (sessions issued
 * before `passwordChangedAt` are rejected, lib/auth.ts), and this browser gets
 * a fresh session so the admin stays signed in here.
 */
export async function changeOwnPasswordAction(input: ChangePasswordInput): Promise<ActionResult> {
  try {
    const admin = await requireAdmin();
    const parsed = schema.safeParse(input);
    if (!parsed.success) return { ok: false, error: parsed.error.issues[0]?.message ?? "Invalid input" };
    const d = parsed.data;

    // Guess protection for a stolen session: 5 wrong current passwords per 15 min.
    const limited = await rateLimit(`admin-password:${admin.id}`, { limit: 5, windowMs: 15 * 60 * 1000 });
    if (!limited.ok) return { ok: false, error: `Too many attempts. Try again in ${Math.ceil(limited.retryAfterSeconds / 60)} minutes.` };

    if (!(await bcrypt.compare(d.currentPassword, admin.passwordHash))) {
      return { ok: false, error: "Your current password is not correct." };
    }

    await prisma.admin.update({
      where: { id: admin.id },
      data: { passwordHash: await bcrypt.hash(d.newPassword, 12), passwordChangedAt: new Date() },
    });
    // Re-issued after passwordChangedAt, so this browser stays signed in.
    await createAdminSession(admin.id);

    await logActivity({
      storeId: await getAdminStoreId(),
      action: "ADMIN_PASSWORD_CHANGED",
      description: `${admin.name} changed their password (other sessions signed out)`,
      adminId: admin.id,
    });
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : "Could not change the password." };
  }
}
