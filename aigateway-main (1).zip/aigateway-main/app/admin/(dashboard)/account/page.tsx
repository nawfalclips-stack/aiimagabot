import type { Metadata } from "next";
import { requireAdmin } from "@/lib/auth";
import { PageHeader } from "@/components/shared/page-header";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { LocalTime } from "@/components/shared/local-time";
import { ChangePasswordForm } from "@/components/admin/change-password-form";

export const metadata: Metadata = { title: "My account" };
export const dynamic = "force-dynamic";

/** Every signed-in admin (read-only accounts included) manages their own password here. */
export default async function AccountPage() {
  const admin = await requireAdmin();

  return (
    <div className="space-y-6">
      <PageHeader title="My account" description="Your admin sign-in details." />

      <Card>
        <CardHeader>
          <CardTitle>Account</CardTitle>
        </CardHeader>
        <CardContent className="grid gap-x-8 gap-y-3 text-sm sm:grid-cols-3">
          <div>
            <p className="eyebrow">Name</p>
            <p className="mt-1 font-medium">{admin.name}</p>
          </div>
          <div>
            <p className="eyebrow">Email</p>
            <p className="mt-1 font-medium">{admin.email}</p>
          </div>
          <div>
            <p className="eyebrow">Password last changed</p>
            <p className="mt-1 font-medium">{admin.passwordChangedAt ? <LocalTime date={admin.passwordChangedAt.toISOString()} /> : "Not since the account was created"}</p>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Change password</CardTitle>
          <CardDescription>
            Changing it signs you out everywhere else; this browser stays signed in. Forgot your password? The project owner can
            reset it from Vercel: set <code>ADMIN_PASSWORD</code> and <code>ADMIN_PASSWORD_RESET=true</code>, redeploy, then remove{" "}
            <code>ADMIN_PASSWORD_RESET</code>.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <ChangePasswordForm />
        </CardContent>
      </Card>
    </div>
  );
}
