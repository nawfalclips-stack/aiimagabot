"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { requireWriteAdmin } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { adjust, TX_OPTIONS } from "@/lib/billing/balance-service";
import { centsToMicro, formatMicroUsd } from "@/lib/billing/money";
import { logActivity } from "@/lib/services/activity";
import { awardLoyaltyPoints } from "@/lib/services/loyalty";
import { getPack } from "@/lib/services/packs";
import { creditVoucherGrants } from "@/lib/vouchers/service";
import { creditPlanBonus, purchaseRef, recordPlanProfit } from "@/lib/services/profit";
import type { ActionResult } from "@/app/admin/(dashboard)/customers/actions";
import type { StoreId } from "@/lib/store";

/**
 * Approve a pending activation. WS8: the admin must choose a pack — the pack
 * binds the plan. Order-ID activations were credited from the offer title at
 * signup; approval corrects that to exactly the price of the pack's plan
 * ($100 plan → $100 balance) with a visible ledger adjustment. Voucher
 * activations held for review are credited here from the voucher's pack.
 */
export async function approveActivationAction(customerId: string, packId: string): Promise<ActionResult> {
  try {
    const admin = await requireWriteAdmin();

    const customer = await prisma.customer.findUnique({
      where: { id: customerId },
      select: { accessCode: true, isActivated: true, rejectedAt: true, storeId: true, initialBalanceCents: true, planId: true, activationSource: true, activationVoucherId: true, packId: true, referredById: true },
    });
    if (!customer) return { ok: false, error: "Customer not found." };
    if (customer.isActivated) return { ok: false, error: "Already activated." };
    const storeId = customer.storeId as StoreId;

    const chosenPackId = customer.activationSource === "VOUCHER" ? (customer.packId ?? packId) : z.string().min(1, "Choose a pack").parse(packId);
    const pack = await getPack(storeId, chosenPackId);
    if (!pack) return { ok: false, error: "Choose the pack the customer bought before approving." };

    let creditedCents = customer.initialBalanceCents ?? 0;
    let profitCents = 0;
    let planBonusCents = 0;
    await prisma.$transaction(async (tx) => {
      await tx.customer.update({
        where: { id: customerId },
        data: {
          isActivated: true,
          rejectedAt: null,
          rejectionReason: "",
          packId: pack.id,
          // The pack's plan, unless an admin already chose one on the profile.
          ...(customer.planId ? {} : { planId: pack.plan.isActive ? pack.plan.id : null, planAssignedAt: pack.plan.isActive ? new Date() : null }),
        },
      });
      if (customer.activationSource !== "VOUCHER") {
        // The balance is the plan's price, whatever the offer title said at signup.
        const credited = await tx.ledgerEntry.aggregate({
          where: { customerId, pot: "BALANCE", type: "ORDER_ACTIVATION" },
          _sum: { amountMicroUsd: true },
        });
        const target = centsToMicro(pack.plan.priceCents);
        const delta = target - (credited._sum.amountMicroUsd ?? 0n);
        if (delta !== 0n) {
          await adjust({
            customerId,
            pot: "BALANCE",
            deltaMicroUsd: delta,
            idempotencyKey: `activation:${customerId}:plan-balance`,
            actor: { adminId: admin.id, label: admin.name },
            note: `Balance set to the ${pack.plan.name} plan price (${formatMicroUsd(target)})`,
            ref: { type: "Pack", id: pack.id },
            tx,
          });
        }
        creditedCents = pack.plan.priceCents;
      }
      if (customer.activationSource === "VOUCHER" && customer.activationVoucherId) {
        const voucher = await tx.voucher.findUnique({ where: { id: customer.activationVoucherId }, include: { pack: true } });
        if (voucher) {
          await creditVoucherGrants(tx, voucher, customerId, { adminId: admin.id, label: admin.name });
          creditedCents = Number(voucher.pack.balanceGrantMicroUsd / 10_000n);
        }
      }
      // Profit of the plan sold (voucher activations keyed by the voucher, so it is never counted twice).
      const ref = purchaseRef({ type: "Activation", id: customerId }, customer.activationSource === "VOUCHER" ? customer.activationVoucherId : null);
      profitCents = await recordPlanProfit(tx, { customerId, plan: pack.plan, ref });
      // The plan's bonus, same purchase reference (so a voucher is never credited twice).
      planBonusCents = await creditPlanBonus(tx, { customerId, plan: pack.plan, ref, actor: { adminId: admin.id, label: admin.name } });
    }, TX_OPTIONS);

    // Affiliate: an approved activation counts as a completed purchase for the
    // inviter — $5 cash + points (half the friend's, min 15). Automatic.
    const friendAward = await awardLoyaltyPoints(customerId, creditedCents);
    const { creditReferralCommission } = await import("@/lib/services/affiliate");
    await creditReferralCommission(customerId, friendAward?.earned?.totalPoints ?? 0);

    await logActivity({
      storeId,
      action: "ACTIVATION_APPROVED" as const,
      description: `${admin.name} approved activation for ${customer.accessCode} — pack "${pack.name}" (plan ${pack.plan.name}, balance $${(creditedCents / 100).toFixed(2)}${planBonusCents > 0 ? `, plan bonus $${(planBonusCents / 100).toFixed(2)}` : ""}${profitCents > 0 ? `, profit $${(profitCents / 100).toFixed(2)}` : ""})`,
      adminId: admin.id,
      customerId,
    });

    revalidatePath("/admin/activations");
    revalidatePath("/admin/customers", "layout");
    revalidatePath("/portal", "layout");
    return { ok: true };
  } catch (error) {
    if (error instanceof z.ZodError) return { ok: false, error: error.issues[0].message };
    console.error(error);
    return { ok: false, error: error instanceof Error ? error.message : "Could not approve activation." };
  }
}

export async function rejectActivationAction(customerId: string, reason: string): Promise<ActionResult> {
  try {
    const admin = await requireWriteAdmin();

    const customer = await prisma.customer.findUnique({
      where: { id: customerId },
      select: { accessCode: true, storeId: true, activationSource: true, activationVoucherId: true },
    });
    if (!customer) return { ok: false, error: "Customer not found." };

    // A rejected voucher redemption burns the code: it was never credited and must not be reusable.
    if (customer.activationSource === "VOUCHER" && customer.activationVoucherId) {
      await prisma.voucher.updateMany({
        where: { id: customer.activationVoucherId, status: "REDEEMED" },
        data: { status: "REVOKED", revokedReason: `Redemption rejected: ${reason.trim() || "not verified"}`, revokedByAdminId: admin.id },
      });
    }

    await prisma.customer.update({
      where: { id: customerId },
      data: {
        isActivated: false,
        rejectedAt: new Date(),
        rejectionReason:
          reason.trim() ||
          (customer.activationSource === "VOUCHER"
            ? "This voucher redemption could not be verified. Please contact us on our store."
            : "Your offer title does not match the order. Please verify and contact us on our store."),
      },
    });

    await logActivity({
      storeId: customer.storeId as StoreId,
      action: "ACTIVATION_REJECTED" as const,
      description: `${admin.name} rejected activation for ${customer.accessCode}: ${reason || "not verified"}`,
      adminId: admin.id,
      customerId,
    });

    revalidatePath("/admin/activations");
    revalidatePath("/portal", "layout");
    return { ok: true };
  } catch (error) {
    console.error(error);
    return { ok: false, error: "Could not reject activation." };
  }
}
