"use client";

import { useTransition, useState } from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { Loader2, XCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { approveActivationAction, rejectActivationAction } from "./actions";
import { ApproveWithPackButton } from "@/components/admin/approve-with-pack";
import type { PackOption } from "@/lib/services/packs";

export function ApproveActivationButton({
  customerId,
  packs,
  suggestedPackId,
  lockedPackId,
  customerPackId = null,
  amountCents,
}: {
  customerId: string;
  packs: PackOption[];
  suggestedPackId: string | null;
  lockedPackId: string | null;
  /** The plan the customer picked when submitting. */
  customerPackId?: string | null;
  amountCents: number;
}) {
  return (
    <ApproveWithPackButton
      packs={packs}
      suggestedPackId={suggestedPackId}
      lockedPackId={lockedPackId}
      customerPackId={customerPackId}
      amountCents={amountCents}
      approve={(packId) => approveActivationAction(customerId, packId)}
      successMessage="Activation approved — customer can now access their dashboard"
    />
  );
}

export function RejectActivationButton({ customerId }: { customerId: string }) {
  const [open, setOpen] = useState(false);
  const [reason, setReason] = useState("");
  const [pending, startTransition] = useTransition();
  const router = useRouter();

  const reject = () => {
    startTransition(async () => {
      const result = await rejectActivationAction(customerId, reason);
      if (result.ok) {
        toast.success("Activation rejected");
        setOpen(false);
        setReason("");
        router.refresh();
      } else {
        toast.error(result.error);
      }
    });
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button
          size="sm"
          variant="outline"
          className="text-destructive border-destructive/30 bg-destructive/10 hover:bg-destructive/20 hover:text-destructive"
        >
          <XCircle className="size-3.5" /> Reject
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Reject this activation</DialogTitle>
          <DialogDescription>
            The customer will see a rejection message and be asked to contact you on GamsGo.
            Optionally provide a reason.
          </DialogDescription>
        </DialogHeader>
        <Input
          value={reason}
          onChange={(e) => setReason(e.target.value)}
          placeholder="Reason (optional) — e.g. Offer title does not match order"
        />
        <DialogFooter>
          <Button variant="outline" onClick={() => setOpen(false)} disabled={pending}>
            Cancel
          </Button>
          <Button variant="destructive" onClick={reject} disabled={pending}>
            {pending ? <Loader2 className="size-3.5 animate-spin" /> : null}
            Confirm reject
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
