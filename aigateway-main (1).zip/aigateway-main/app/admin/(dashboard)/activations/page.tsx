import type { Metadata } from "next";
import Link from "next/link";
import { ShieldCheck } from "lucide-react";
import { prisma } from "@/lib/prisma";
import { Card } from "@/components/ui/card";
import { PageHeader } from "@/components/shared/page-header";
import { EmptyState } from "@/components/shared/empty-state";
import { LocalTime } from "@/components/shared/local-time";
import { formatCents } from "@/lib/money";
import { cn } from "@/lib/utils";
import { ApproveActivationButton, RejectActivationButton } from "./client";
import { getAdminStoreId } from "@/lib/store";
import { listPacks, suggestPack, toPackOption } from "@/lib/services/packs";

export const metadata: Metadata = { title: "Activations" };
export const dynamic = "force-dynamic";

export default async function ActivationsPage() {
  const storeId = await getAdminStoreId();
  const customers = await prisma.customer.findMany({
    where: {
      storeId,
      deletedAt: null,
      // Show pending (not yet reviewed) and rejected (need re-review)
      OR: [
        { isActivated: false, rejectedAt: null },
        { rejectedAt: { not: null } },
      ],
    },
    include: { order: true, pack: { select: { name: true } } },
    orderBy: { createdAt: "desc" },
  });
  const packs = (await listPacks(storeId, { includeInactive: true })).map(toPackOption);

  const pending = customers.filter((c) => !c.isActivated && !c.rejectedAt).length;

  return (
    <div className="space-y-6">
      <PageHeader
        title="Activations"
        description={`${pending} pending · ${customers.length} total awaiting or rejected`}
      />

      {customers.length === 0 ? (
        <EmptyState
          icon={ShieldCheck}
          title="No pending activations"
          description="When a customer self-activates, their account appears here until you approve or reject it."
        />
      ) : (
        <div className="space-y-3">
          {customers.map((c) => {
            const isPending = !c.isActivated && !c.rejectedAt;
            const isRejected = !!c.rejectedAt;
            return (
              <Card key={c.id} className={cn("gap-0 p-4", isRejected && "opacity-70")}>
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <div className="min-w-0 space-y-1">
                    <div className="flex items-center gap-2">
                      <Link
                        href={`/admin/customers/${c.id}`}
                        className="font-mono text-sm font-semibold text-primary hover:underline"
                      >
                        {c.accessCode}
                      </Link>
                      <span className="text-muted-foreground text-xs">·</span>
                      <span className="font-mono text-xs text-muted-foreground">
                        {c.order?.orderNumber ?? "—"}
                      </span>
                      {c.activationSource === "VOUCHER" && (
                        <span className="inline-flex rounded-full border border-primary/25 bg-primary/10 px-2 py-0.5 text-[10px] font-semibold uppercase text-primary" title="Redeemed a GamsGo voucher; held for review">
                          Voucher{c.pack ? ` · ${c.pack.name}` : ""}
                        </span>
                      )}
                    </div>

                    {/* Offer title */}
                    <p className="text-sm text-foreground">{c.offerTitle || "—"}</p>

                    {/* Parsed balance + bonus */}
                    <div className="flex flex-wrap items-center gap-3 text-xs">
                      <span className="font-medium">
                        Balance: <span className="text-primary">{formatCents(c.initialBalanceCents)}</span>
                      </span>
                      {c.pendingBonusCents > 0 && (
                        <span className="font-medium">
                          Bonus: <span className="text-success">{formatCents(c.pendingBonusCents)}</span>
                        </span>
                      )}
                      <span className="text-muted-foreground">
                        Submitted: <LocalTime date={c.createdAt.toISOString()} variant="datetime" />
                      </span>
                    </div>

                    {isRejected && c.rejectionReason && (
                      <p className="text-xs text-destructive">
                        Rejected: {c.rejectionReason}
                      </p>
                    )}
                  </div>

                  <div className="flex items-center gap-2">
                    <span
                      className={cn(
                        "inline-flex rounded-full border px-2.5 py-0.5 text-xs font-medium",
                        isPending
                          ? "bg-warning/12 text-warning border-warning/25"
                          : "bg-destructive/12 text-destructive border-destructive/25"
                      )}
                    >
                      {isPending ? "Pending" : "Rejected"}
                    </span>
                    {(isPending || isRejected) && (
                      <ApproveActivationButton
                        customerId={c.id}
                        packs={packs}
                        suggestedPackId={suggestPack(packs, c.initialBalanceCents)?.id ?? null}
                        lockedPackId={c.activationSource === "VOUCHER" ? c.packId : null}
                        customerPackId={c.activationSource === "VOUCHER" ? null : c.packId}
                        amountCents={c.initialBalanceCents}
                      />
                    )}
                    {isPending && <RejectActivationButton customerId={c.id} />}
                  </div>
                </div>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}
