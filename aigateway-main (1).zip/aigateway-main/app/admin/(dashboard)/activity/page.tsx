import type { Metadata } from "next";
import { ScrollText } from "lucide-react";
import { prisma } from "@/lib/prisma";
import { Card, CardContent } from "@/components/ui/card";
import { PageHeader } from "@/components/shared/page-header";
import { EmptyState } from "@/components/shared/empty-state";
import { ActivityFeed } from "@/components/admin/activity-feed";
import { getAdminStoreId } from "@/lib/store";

export const metadata: Metadata = { title: "Activity" };
export const dynamic = "force-dynamic";

export default async function ActivityPage() {
  const storeId = await getAdminStoreId();
  const logs = await prisma.activityLog.findMany({
    where: { storeId },
    orderBy: { createdAt: "desc" },
    take: 200,
    include: {
      admin: { select: { name: true } },
      customer: { select: { accessCode: true, deletedAt: true } },
    },
  });

  return (
    <div className="space-y-6">
      <PageHeader
        title="Activity"
        description="Complete audit trail of every important action, newest first."
      />
      <Card>
        <CardContent className="pt-6">
          {logs.length === 0 ? (
            <EmptyState
              icon={ScrollText}
              title="No activity yet"
              description="Actions like customer creation, balance updates and sign-ins will appear here."
              className="border-0"
            />
          ) : (
            <ActivityFeed items={logs} />
          )}
        </CardContent>
      </Card>
    </div>
  );
}
