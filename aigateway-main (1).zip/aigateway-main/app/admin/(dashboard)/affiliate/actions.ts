"use server";

import { revalidatePath } from "next/cache";
import { requireWriteAdmin } from "@/lib/auth";
import { approveAffiliateClaim, rejectAffiliateClaim } from "@/lib/services/affiliate-claims";

export type AffiliateActionResult = { ok: true } | { ok: false; error: string };

export async function approveAffiliateClaimAction(customerId: string): Promise<AffiliateActionResult> {
  try {
    const admin = await requireWriteAdmin();
    await approveAffiliateClaim(customerId, admin.name);
    revalidatePath("/admin/affiliate");
    revalidatePath("/portal/affiliate");
    return { ok: true };
  } catch (error) {
    console.error(error);
    return {
      ok: false,
      error: error instanceof Error ? error.message : "Could not approve this claim.",
    };
  }
}

export async function rejectAffiliateClaimAction(customerId: string, reason: string): Promise<AffiliateActionResult> {
  try {
    const admin = await requireWriteAdmin();
    await rejectAffiliateClaim(customerId, admin.name, reason);
    revalidatePath("/admin/affiliate");
    revalidatePath("/portal/affiliate");
    return { ok: true };
  } catch (error) {
    console.error(error);
    return {
      ok: false,
      error: error instanceof Error ? error.message : "Could not reject this claim.",
    };
  }
}
