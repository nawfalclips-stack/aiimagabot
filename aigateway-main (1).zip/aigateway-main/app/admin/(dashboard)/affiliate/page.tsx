import type { Metadata } from "next";
import { prisma } from "@/lib/prisma";
import { getAdminStoreId } from "@/lib/store";
import { Share2 } from "lucide-react";
import { AffiliateTable } from "./table";

export const metadata: Metadata = { title: "Affiliate Program" };
export const dynamic = "force-dynamic";

export default async function AdminAffiliatePage() {
  const storeId = await getAdminStoreId();

  const customers = await prisma.customer.findMany({
    where: { storeId, deletedAt: null },
    select: {
      id: true,
      accessCode: true,
      affiliateCode: true,
      affiliateEarnedCents: true,
      affiliateMilestoneStatus: true,
      referredById: true,
      // The referrer's access code, for the "invited by" column.
      referredBy: { select: { accessCode: true } },
    },
    orderBy: { affiliateEarnedCents: "desc" },
  });

  // Aggregate each referrer's referral count, referred spend and PACK progress
  // (count-based milestones: 10 purchases of the same pack size).
  const spendByCustomer = new Map<string, number>();
  const purchasesByCustomer = new Map<string, number[]>();
  const referralCounts = new Map<string, number>();
  for (const c of customers) {
    if (!c.referredById) continue;
    referralCounts.set(c.referredById, (referralCounts.get(c.referredById) ?? 0) + 1);
    const plan = await prisma.customer.findUnique({
      where: { id: c.id },
      select: { initialBalanceCents: true },
    });
    if (plan) {
      spendByCustomer.set(c.referredById, (spendByCustomer.get(c.referredById) ?? 0) + plan.initialBalanceCents);
      const list = purchasesByCustomer.get(c.referredById) ?? [];
      list.push(plan.initialBalanceCents);
      // Approved recharges of this referral count too.
      const recharges = await prisma.rechargeRequest.findMany({
        where: { customerId: c.id, status: "APPROVED" },
        select: { balanceCents: true },
      });
      for (const rc of recharges) list.push(rc.balanceCents);
      purchasesByCustomer.set(c.referredById, list);
    }
  }

  const rows = customers
    .filter((c) => c.affiliateCode || c.affiliateEarnedCents > 0 || c.affiliateMilestoneStatus === "PENDING")
    .map((c) => ({
      id: c.id,
      accessCode: c.accessCode,
      affiliateCode: c.affiliateCode ?? "—",
      invitedBy: c.referredBy?.accessCode ?? null,
      referralCount: referralCounts.get(c.id) ?? 0,
      referralsSpendCents: spendByCustomer.get(c.id) ?? 0,
      purchasesCents: purchasesByCustomer.get(c.id) ?? [],
      earnedCents: c.affiliateEarnedCents,
      milestoneStatus: c.affiliateMilestoneStatus,
    }));

  return (
    <div className="space-y-6">
      <div>
        <h1 className="flex items-center gap-2 text-2xl font-semibold tracking-tight">
          <Share2 className="size-6 text-primary" /> Affiliate Management
        </h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Every customer&apos;s referral code, how many friends they brought, what those friends spent,
          and their commission earnings ($5 per friend purchase). Milestone bonus claims wait here for
          your approval — nothing is paid out automatically.
        </p>
      </div>

      <AffiliateTable rows={rows} />
    </div>
  );
}
