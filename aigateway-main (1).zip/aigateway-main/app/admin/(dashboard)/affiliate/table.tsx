"use client";

import { useTransition, useState } from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { CheckCircle2, Loader2, XCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { approveAffiliateClaimAction, rejectAffiliateClaimAction } from "./actions";
import { formatCents } from "@/lib/money";
import { getReachedMilestone } from "@/lib/affiliate";

export interface AffiliateRow {
  id: string;
  accessCode: string;
  affiliateCode: string;
  invitedBy: string | null;
  referralCount: number;
  referralsSpendCents: number;
  /** Every purchase each referral made — used for pack-count milestones. */
  purchasesCents: number[];
  earnedCents: number;
  milestoneStatus: string;
}

const STATUS_STYLES: Record<string, string> = {
  PENDING: "border-warning/40 bg-warning/10 text-warning",
  APPROVED: "border-success/40 bg-success/10 text-success",
  REJECTED: "border-destructive/40 bg-destructive/10 text-destructive",
};

function ClaimActions({ customerId, rewardCents }: { customerId: string; rewardCents: number }) {
  const [pending, startTransition] = useTransition();
  const [reason, setReason] = useState("");
  const router = useRouter();

  return (
    <div className="flex items-center justify-end gap-2">
      <Button
        size="sm"
        className="h-8 gap-1.5 bg-success text-white hover:bg-success/90"
        disabled={pending}
        onClick={() =>
          startTransition(async () => {
            const result = await approveAffiliateClaimAction(customerId);
            if (result.ok) {
              toast.success(`Milestone bonus of ${formatCents(rewardCents)} credited.`);
              router.refresh();
            } else {
              toast.error(result.error);
            }
          })
        }
      >
        {pending ? <Loader2 className="size-3.5 animate-spin" /> : <CheckCircle2 className="size-3.5" />}
        Approve
      </Button>
      <Dialog>
        <DialogTrigger asChild>
          <Button size="sm" variant="outline" className="h-8 gap-1.5 text-destructive" disabled={pending}>
            <XCircle className="size-3.5" /> Reject
          </Button>
        </DialogTrigger>
        <DialogContent>
          <form
            onSubmit={(e) => {
              e.preventDefault();
              startTransition(async () => {
                const result = await rejectAffiliateClaimAction(customerId, reason || "No reason given");
                if (result.ok) {
                  toast.success("Affiliate claim rejected.");
                  router.refresh();
                } else {
                  toast.error(result.error);
                }
              });
            }}
          >
            <DialogHeader>
              <DialogTitle>Reject this affiliate claim?</DialogTitle>
              <DialogDescription>
                The customer keeps their commissions but will not receive the milestone bonus now.
                They can request again later.
              </DialogDescription>
            </DialogHeader>
            <Input
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="Reason (optional)"
              className="mt-4"
            />
            <DialogFooter className="mt-4">
              <Button type="submit" variant="destructive" size="sm">
                Confirm rejection
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}

export function AffiliateTable({ rows }: { rows: AffiliateRow[] }) {
  if (rows.length === 0) {
    return (
      <div className="rounded-xl border bg-card p-10 text-center text-sm text-muted-foreground">
        No affiliate activity yet — codes appear here as soon as customers join the program.
      </div>
    );
  }

  return (
    <section className="overflow-hidden rounded-xl border bg-card">
      <table className="w-full text-sm">
        <thead>
          <tr className="border-b bg-muted/50 text-left text-xs uppercase tracking-wide text-muted-foreground">
            <th className="px-4 py-3 font-medium">Customer</th>
            <th className="px-4 py-3 font-medium">Their code</th>
            <th className="px-4 py-3 font-medium">Invited by</th>
            <th className="px-4 py-3 font-medium">Friends</th>
            <th className="px-4 py-3 font-medium">Friends&apos; spend</th>
            <th className="px-4 py-3 font-medium">Commission earned</th>
            <th className="px-4 py-3 font-medium">Milestone claim</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((r) => {
            const reached = getReachedMilestone(r.purchasesCents);
            const isPending = r.milestoneStatus === "PENDING";
            return (
              <tr key={r.id} className="border-b last:border-b-0 hover:bg-muted/30">
                <td className="px-4 py-3 font-mono">{r.accessCode}</td>
                <td className="px-4 py-3">
                  <code className="rounded-md bg-primary/10 px-2 py-0.5 font-mono text-xs font-bold text-primary">
                    {r.affiliateCode}
                  </code>
                </td>
                <td className="px-4 py-3 text-muted-foreground">{r.invitedBy ?? "—"}</td>
                <td className="px-4 py-3 font-mono">{r.referralCount}</td>
                <td className="px-4 py-3">{formatCents(r.referralsSpendCents)}</td>
                <td className="px-4 py-3 font-semibold text-success">{formatCents(r.earnedCents)}</td>
                <td className="px-4 py-3">
                  {isPending ? (
                    <ClaimActions customerId={r.id} rewardCents={reached?.rewardCents ?? 0} />
                  ) : (
                    <span
                      className={`inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs ${
                        STATUS_STYLES[r.milestoneStatus] ?? "border-border text-muted-foreground"
                      }`}
                    >
                      {r.milestoneStatus === "APPROVED"
                        ? "Paid out"
                        : r.milestoneStatus === "REJECTED"
                          ? "Rejected"
                          : reached
                            ? "Can claim"
                            : "No claim"}
                    </span>
                  )}
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </section>
  );
}
