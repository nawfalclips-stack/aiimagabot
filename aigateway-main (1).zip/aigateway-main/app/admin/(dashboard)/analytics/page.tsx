import type { Metadata } from "next";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { PageHeader } from "@/components/shared/page-header";
import { StatCard } from "@/components/shared/stat-card";
import {
  CustomerGrowthChart,
  ExpiredChart,
  OrdersChart,
  ProfitChart,
  RevenueProfitChart,
} from "@/components/admin/charts";
import { ActivityFeed } from "@/components/admin/activity-feed";
import { PeriodSwitcher } from "@/components/admin/period-switcher";
import { PERIODS, type PeriodKey } from "@/lib/periods";
import {
  getDailySeries,
  getDashboardStats,
  getHourlySeries,
  getPortfolioStats,
  getRecentActivity,
  type DailyPoint,
} from "@/lib/services/analytics";
import { centsToUsd } from "@/lib/money";
import { getAdminStoreId, type StoreId } from "@/lib/store";

export const metadata: Metadata = { title: "Analytics" };
export const dynamic = "force-dynamic";

const PERIOD_LABELS: Record<PeriodKey, string> = {
  live: "Live — refreshes every 15s",
  today: "Today, hour by hour",
  yesterday: "Yesterday, hour by hour",
  week: "Last 7 days",
  month: "Last 30 days",
};

async function seriesForPeriod(period: PeriodKey, storeId: StoreId): Promise<DailyPoint[]> {
  switch (period) {
    case "live":
    case "today":
      return getHourlySeries(storeId, 0);
    case "yesterday":
      return getHourlySeries(storeId, 1);
    case "week":
      return getDailySeries(storeId, 7);
    default:
      return getDailySeries(storeId, 30);
  }
}

export default async function AnalyticsPage({
  searchParams,
}: {
  searchParams: Promise<{ period?: string }>;
}) {
  const { period: rawPeriod } = await searchParams;
  const period: PeriodKey = (PERIODS.find((p) => p.key === rawPeriod)?.key ?? "today") as PeriodKey;
  const storeId = await getAdminStoreId();

  const [series, stats, portfolio, activity] = await Promise.all([
    seriesForPeriod(period, storeId),
    getDashboardStats(storeId),
    getPortfolioStats(storeId),
    getRecentActivity(storeId, 12),
  ]);

  // Period totals from the series itself.
  const totals = series.reduce(
    (acc, point) => ({
      profitCents: acc.profitCents + point.profitCents,
      revenueCents: acc.revenueCents + point.revenueCents,
      customers: acc.customers + point.customers,
      orders: acc.orders + point.orders,
    }),
    { profitCents: 0, revenueCents: 0, customers: 0, orders: 0 }
  );

  const periodLabel = PERIOD_LABELS[period];

  return (
    <div className="space-y-8">
      <PageHeader
        title="Analytics"
        description="Pick a period — every card and chart below follows it."
        actions={<PeriodSwitcher active={period} />}
      />

      {/* Period stats */}
      <section aria-label="Period statistics" className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <StatCard
          title="Profit"
          value={centsToUsd(totals.profitCents)}
          format="money"
          icon="trendingUp"
          tone="success"
          hint={periodLabel}
          index={0}
        />
        <StatCard
          title="How many requests?"
          value={totals.orders}
          icon="shoppingCart"
          tone="primary"
          hint={periodLabel}
          index={1}
        />
        <StatCard title="New Customers" value={totals.customers} icon="users" tone="default" hint={periodLabel} index={2} />
        <StatCard title="Orders" value={totals.orders} icon="shoppingCart" tone="warning" hint={periodLabel} index={3} />
      </section>

      <div className="grid gap-6 lg:grid-cols-2">
        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>Sales vs Profit</CardTitle>
            <CardDescription>{periodLabel}</CardDescription>
          </CardHeader>
          <CardContent>
            <RevenueProfitChart data={series} />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Profit</CardTitle>
            <CardDescription>{periodLabel}</CardDescription>
          </CardHeader>
          <CardContent>
            <ProfitChart data={series} />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Customer Growth</CardTitle>
            <CardDescription>{periodLabel}</CardDescription>
          </CardHeader>
          <CardContent>
            <CustomerGrowthChart data={series} />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Orders</CardTitle>
            <CardDescription>{periodLabel}</CardDescription>
          </CardHeader>
          <CardContent>
            <OrdersChart data={series} />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Expired Customers</CardTitle>
            <CardDescription>{periodLabel}</CardDescription>
          </CardHeader>
          <CardContent>
            <ExpiredChart data={series} />
          </CardContent>
        </Card>

        <Card className="lg:col-span-2">
          <CardHeader>
            <CardTitle>All-Time &amp; Recent Activity</CardTitle>
            <CardDescription>
              All-time profit {`$${(stats.totalProfitCents / 100).toFixed(2)}`} · Total balance remaining{" "}
              {`$${(portfolio.totalBalanceCents / 100).toFixed(2)}`}
            </CardDescription>
          </CardHeader>
          <CardContent>
            {activity.length === 0 ? (
              <p className="py-8 text-center text-sm text-muted-foreground">No activity yet.</p>
            ) : (
              <ActivityFeed items={activity} />
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
