"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireWriteAdmin } from "@/lib/auth";
import { logActivity } from "@/lib/services/activity";
import { getAdminStoreId } from "@/lib/store";
import { ANNOUNCEMENT_KINDS, MAX_RECHARGE_BONUS_PCT } from "@/lib/announcements";
import type { ActionResult } from "@/app/admin/(dashboard)/customers/actions";

const schema = z
  .object({
    kind: z.enum(ANNOUNCEMENT_KINDS),
    title: z.string().trim().min(3, "Enter a title").max(120),
    message: z.string().trim().min(3, "Enter a message").max(2000),
    rechargeBonusPct: z.coerce.number().int().min(0).max(MAX_RECHARGE_BONUS_PCT, `At most ${MAX_RECHARGE_BONUS_PCT} %`).default(0),
    modelSlug: z.string().trim().max(64).optional().nullable(),
    /** Blank = every customer of the store; otherwise one customer's access code. */
    accessCode: z.string().trim().max(64).optional().nullable(),
    /** ISO strings from datetime-local inputs; blank = now / no end. */
    startsAt: z.string().trim().optional().nullable(),
    endsAt: z.string().trim().optional().nullable(),
  })
  .superRefine((d, ctx) => {
    if (d.kind === "PROMO" && d.rechargeBonusPct <= 0) ctx.addIssue({ code: "custom", path: ["rechargeBonusPct"], message: "A promotion needs a bonus above 0 %" });
    if (d.kind === "NEW_MODEL" && !d.modelSlug) ctx.addIssue({ code: "custom", path: ["modelSlug"], message: "Choose the model you are announcing" });
  });

export type AnnouncementInput = z.input<typeof schema>;

function parseDate(v: string | null | undefined): Date | null {
  if (!v) return null;
  const d = new Date(v);
  if (Number.isNaN(d.getTime())) throw new Error("Invalid date");
  return d;
}

function revalidate() {
  revalidatePath("/admin/announcements");
  revalidatePath("/portal", "layout");
}

export async function createAnnouncementAction(input: AnnouncementInput): Promise<ActionResult<{ id: string }>> {
  try {
    const admin = await requireWriteAdmin();
    const storeId = await getAdminStoreId();
    const parsed = schema.safeParse(input);
    if (!parsed.success) return { ok: false, error: parsed.error.issues[0]?.message ?? "Invalid input" };
    const d = parsed.data;

    let customerId: string | null = null;
    if (d.accessCode) {
      const c = await prisma.customer.findFirst({ where: { storeId, accessCode: d.accessCode, deletedAt: null }, select: { id: true } });
      if (!c) return { ok: false, error: `No customer with access code ${d.accessCode} in this store.` };
      customerId = c.id;
    }

    let modelSlug: string | null = null;
    if (d.kind === "NEW_MODEL") {
      const m = await prisma.gatewayModel.findUnique({ where: { slug: d.modelSlug! }, select: { slug: true } });
      if (!m) return { ok: false, error: "That model is not in the catalog." };
      modelSlug = m.slug;
    }

    const startsAt = parseDate(d.startsAt) ?? new Date();
    const endsAt = parseDate(d.endsAt);
    if (endsAt && endsAt <= startsAt) return { ok: false, error: "The end must be after the start." };

    const row = await prisma.announcement.create({
      data: {
        storeId,
        kind: d.kind,
        title: d.title,
        message: d.message,
        rechargeBonusPct: d.kind === "PROMO" ? d.rechargeBonusPct : 0,
        modelSlug,
        customerId,
        startsAt,
        endsAt,
        createdByAdminId: admin.id,
        createdByLabel: admin.name,
      },
    });

    await logActivity({
      storeId,
      action: "SETTINGS_CHANGED",
      description: `${admin.name} published announcement "${row.title}"${row.kind === "PROMO" ? ` (recharge promotion +${row.rechargeBonusPct}%)` : ""}${d.accessCode ? ` to ${d.accessCode}` : " to every customer"}`,
      adminId: admin.id,
      customerId: customerId ?? undefined,
    });
    revalidate();
    return { ok: true, data: { id: row.id } };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : "Could not publish the announcement." };
  }
}

/** End an announcement now: it leaves every inbox, and a promotion stops applying to new recharges. */
export async function endAnnouncementAction(id: string): Promise<ActionResult> {
  try {
    const admin = await requireWriteAdmin();
    const storeId = await getAdminStoreId();
    const row = await prisma.announcement.updateMany({ where: { id, storeId, archivedAt: null }, data: { archivedAt: new Date() } });
    if (row.count === 0) return { ok: false, error: "Announcement not found or already ended." };
    await logActivity({ storeId, action: "SETTINGS_CHANGED", description: `${admin.name} ended an announcement`, adminId: admin.id });
    revalidate();
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : "Could not end the announcement." };
  }
}

/**
 * Delete an announcement. Recharges that locked in a promotion keep their
 * snapshotted percentage, so deleting one never changes what they are owed.
 */
export async function deleteAnnouncementAction(id: string): Promise<ActionResult> {
  try {
    const admin = await requireWriteAdmin();
    const storeId = await getAdminStoreId();
    const row = await prisma.announcement.deleteMany({ where: { id, storeId } });
    if (row.count === 0) return { ok: false, error: "Announcement not found." };
    await logActivity({ storeId, action: "SETTINGS_CHANGED", description: `${admin.name} deleted an announcement`, adminId: admin.id });
    revalidate();
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : "Could not delete the announcement." };
  }
}
