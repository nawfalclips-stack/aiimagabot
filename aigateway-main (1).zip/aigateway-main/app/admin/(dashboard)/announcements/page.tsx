import type { Metadata } from "next";
import { prisma } from "@/lib/prisma";
import { PageHeader } from "@/components/shared/page-header";
import { AnnouncementsView, type AnnouncementRow, type ModelChoice } from "@/components/admin/announcements-view";
import { getAdminStoreId } from "@/lib/store";
import { publicModelId, publicModelName } from "@/lib/model-alias";

export const metadata: Metadata = { title: "Announcements" };
export const dynamic = "force-dynamic";

/** Request time for the live/scheduled/ended badge (kept out of render for the purity lint). */
function currentTime(): number {
  return Date.now();
}

export default async function AnnouncementsPage() {
  const storeId = await getAdminStoreId();
  const [rows, models, audience] = await Promise.all([
    prisma.announcement.findMany({
      where: { storeId },
      include: { _count: { select: { reads: true } } },
      orderBy: { createdAt: "desc" },
      take: 200,
    }),
    prisma.gatewayModel.findMany({ where: { enabled: true }, select: { slug: true, displayName: true, aliasSlug: true, aliasName: true, enabledStoreIds: true }, orderBy: { slug: "asc" } }),
    prisma.customer.count({ where: { storeId, deletedAt: null, isActivated: true } }),
  ]);

  const targeted = [...new Set(rows.map((r) => r.customerId).filter((id): id is string => !!id))];
  const codes = new Map(
    (await prisma.customer.findMany({ where: { id: { in: targeted } }, select: { id: true, accessCode: true } })).map((c) => [c.id, c.accessCode])
  );
  const promoUse = await prisma.rechargeRequest.groupBy({
    by: ["promoAnnouncementId"],
    where: { storeId, promoAnnouncementId: { in: rows.map((r) => r.id) } },
    _count: { _all: true },
  });
  const promoCount = new Map(promoUse.map((p) => [p.promoAnnouncementId, p._count._all]));

  const now = currentTime();
  const announcements: AnnouncementRow[] = rows.map((a) => ({
    id: a.id,
    kind: a.kind,
    title: a.title,
    message: a.message,
    rechargeBonusPct: a.rechargeBonusPct,
    modelSlug: a.modelSlug,
    audience: a.customerId ? (codes.get(a.customerId) ?? "one customer") : null,
    startsAt: a.startsAt.toISOString(),
    endsAt: a.endsAt?.toISOString() ?? null,
    state: a.archivedAt ? "ENDED" : a.startsAt.getTime() > now ? "SCHEDULED" : a.endsAt && a.endsAt.getTime() <= now ? "ENDED" : "LIVE",
    reads: a._count.reads,
    recharges: promoCount.get(a.id) ?? 0,
    createdBy: a.createdByLabel,
  }));

  const modelChoices: ModelChoice[] = models
    .filter((m) => m.enabledStoreIds === "" || m.enabledStoreIds.split(",").map((s) => s.trim()).includes(storeId))
    .map((m) => ({ slug: m.slug, publicSlug: publicModelId(m), publicName: publicModelName(m) }));

  return (
    <div className="space-y-6">
      <PageHeader
        title="Announcements"
        description={`Messages shown in every customer's portal inbox and dashboard (${audience} active customers). A recharge promotion adds its bonus to recharges submitted while it runs; a new-model notice names the model by its public alias only.`}
      />
      <AnnouncementsView announcements={announcements} models={modelChoices} />
    </div>
  );
}
