"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { getCurrentAdmin, requireWriteAdmin } from "@/lib/auth";
import { logActivity } from "@/lib/services/activity";
import type { ActionResult } from "@/app/admin/(dashboard)/customers/actions";
import { getAdminStoreId } from "@/lib/store";
import { maskKey, poolAssignmentsEnabled } from "@/lib/services/legacy-pool";

export interface OrderLookupResult {
  orderNumber: string;
  accessCode: string;
  customerId: string;
  status: string;
  initialBalanceCents: number;
  usedBalanceCents: number;
  remainingBalanceCents: number;
  initialBonusCents: number;
  usedBonusCents: number;
  remainingBonusCents: number;
  profitCents: number;
  apiKey: string | null;
  assignedAt: string | null;
  createdAt: string;
  offerTitle: string;
}

/** Look up a customer by their GamsGo Order ID and return all their info. */
export async function lookupOrderAction(
  orderId: string
): Promise<ActionResult<OrderLookupResult>> {
  try {
    await getCurrentAdmin(); // read-only is fine here
    const clean = z.string().trim().min(1).max(200).parse(orderId);

    const order = await prisma.order.findUnique({
      where: { orderNumber: clean },
      include: {
        customer: {
          include: {
            apiKey: true,
            apiPoolKey: { select: { assignedAt: true } },
          },
        },
      },
    });

    if (!order) return { ok: false, error: "No customer found with this Order ID." };

    const c = order.customer;
    return {
      ok: true,
      data: {
        orderNumber: order.orderNumber,
        accessCode: c.accessCode,
        customerId: c.id,
        status: c.status,
        initialBalanceCents: c.initialBalanceCents,
        usedBalanceCents: c.usedBalanceCents,
        remainingBalanceCents: c.initialBalanceCents - c.usedBalanceCents,
        initialBonusCents: c.initialBonusCents,
        usedBonusCents: c.usedBonusCents,
        remainingBonusCents: c.initialBonusCents - c.usedBonusCents,
        profitCents: c.profitCents,
        apiKey: c.apiKey ? (poolAssignmentsEnabled() ? c.apiKey.key : maskKey(c.apiKey.key)) : null,
        assignedAt: c.apiPoolKey?.assignedAt?.toISOString() ?? null,
        createdAt: c.createdAt.toISOString(),
        offerTitle: c.offerTitle,
      },
    };
  } catch (error) {
    if (error instanceof z.ZodError) return { ok: false, error: error.issues[0].message };
    console.error(error);
    return { ok: false, error: "Lookup failed. Please try again." };
  }
}


/**
 * Add one or many API keys to the pool — paste one key per line.
 * Duplicates (already in the pool) are skipped automatically.
 */
export async function addPoolKeysAction(raw: string): Promise<ActionResult<{ added: number; skipped: number }>> {
  try {
    const admin = await requireWriteAdmin();
    const storeId = await getAdminStoreId();
    if (!poolAssignmentsEnabled()) {
      return { ok: false, error: "The legacy API Pool is retired (LEGACY_API_POOL_MODE is not \"active\")." };
    }

    const parsed = z.string().min(1).max(100_000).parse(raw);
    const keys = Array.from(
      new Set(
        parsed
          .split(/\r?\n/)
          .map((k) => k.trim())
          .filter((k) => k.length >= 4 && k.length <= 512)
      )
    );
    if (keys.length === 0) return { ok: false, error: "Paste at least one API key (one per line)." };
    if (keys.length > 500) return { ok: false, error: "Add at most 500 keys at a time." };

    const existing = await prisma.apiPoolKey.findMany({ where: { storeId, key: { in: keys } }, select: { key: true } });
    const existingSet = new Set(existing.map((e) => e.key));
    const fresh = keys.filter((k) => !existingSet.has(k));

    if (fresh.length > 0) {
      await prisma.apiPoolKey.createMany({ data: fresh.map((key) => ({ storeId, key })) });
    }

    await logActivity({
      storeId,
      action: "SETTINGS_CHANGED",
      description: `${admin.name} added ${fresh.length} API keys to the pool`,
      adminId: admin.id,
    });

    revalidatePath("/admin/api-pool");
    return { ok: true, data: { added: fresh.length, skipped: keys.length - fresh.length } };
  } catch (error) {
    console.error(error);
    return { ok: false, error: "Could not add those keys. Please try again." };
  }
}

export async function deletePoolKeyAction(id: string): Promise<ActionResult> {
  try {
    const admin = await requireWriteAdmin();
    const storeId = await getAdminStoreId();

    const deleted = await prisma.apiPoolKey.deleteMany({ where: { id, storeId, status: "AVAILABLE" } });
    if (deleted.count === 0) {
      return { ok: false, error: "Only unassigned keys can be removed from the pool." };
    }

    await logActivity({
      storeId,
      action: "SETTINGS_CHANGED",
      description: `${admin.name} removed an API key from the pool`,
      adminId: admin.id,
    });

    revalidatePath("/admin/api-pool");
    return { ok: true };
  } catch (error) {
    console.error(error);
    return { ok: false, error: "Could not remove that key. Please try again." };
  }
}

/**
 * WS10: take every legacy key away from this store's customers. Pool keys
 * that were handed out are marked RETIRED (never AVAILABLE again — they were
 * shared) and the customers' copies are deleted. Refused while the pool is active.
 */
export async function unassignAllPoolKeysAction(): Promise<ActionResult<{ customers: number; keys: number }>> {
  try {
    const admin = await requireWriteAdmin();
    const storeId = await getAdminStoreId();
    if (poolAssignmentsEnabled()) {
      return { ok: false, error: "Set LEGACY_API_POOL_MODE to readonly or off before unassigning keys." };
    }

    const result = await prisma.$transaction(async (tx) => {
      const keys = await tx.apiPoolKey.updateMany({
        where: { storeId, status: { in: ["ASSIGNED", "PROBLEMATIC"] } },
        data: { status: "RETIRED", customerId: null },
      });
      const customers = await tx.apiKey.deleteMany({ where: { customer: { storeId } } });
      return { customers: customers.count, keys: keys.count };
    });

    await logActivity({
      storeId,
      action: "API_POOL_UNASSIGNED",
      description: `${admin.name} unassigned legacy API keys from ${result.customers} customers (${result.keys} pool keys retired)`,
      adminId: admin.id,
    });

    revalidatePath("/admin/api-pool");
    revalidatePath("/admin/customers");
    revalidatePath("/portal", "layout");
    return { ok: true, data: result };
  } catch (error) {
    console.error(error);
    return { ok: false, error: "Could not unassign the keys. Please try again." };
  }
}

/**
 * WS10: delete this store's pool keys. Keys still held by a customer are kept
 * — run "Unassign all" first. Refused while the pool is active.
 */
export async function purgePoolKeysAction(): Promise<ActionResult<{ purged: number; kept: number }>> {
  try {
    const admin = await requireWriteAdmin();
    const storeId = await getAdminStoreId();
    if (poolAssignmentsEnabled()) {
      return { ok: false, error: "Set LEGACY_API_POOL_MODE to readonly or off before purging the pool." };
    }

    const [deleted, kept] = await prisma.$transaction([
      prisma.apiPoolKey.deleteMany({ where: { storeId, customerId: null } }),
      prisma.apiPoolKey.count({ where: { storeId, customerId: { not: null } } }),
    ]);

    await logActivity({
      storeId,
      action: "API_POOL_PURGED",
      description: `${admin.name} purged ${deleted.count} legacy API keys from the pool${kept > 0 ? ` (${kept} still assigned, kept)` : ""}`,
      adminId: admin.id,
    });

    revalidatePath("/admin/api-pool");
    return { ok: true, data: { purged: deleted.count, kept } };
  } catch (error) {
    console.error(error);
    return { ok: false, error: "Could not purge the pool. Please try again." };
  }
}
