import type { Metadata } from "next";
import { prisma } from "@/lib/prisma";
import { PageHeader } from "@/components/shared/page-header";
import { ApiPoolView, type PoolKeyRow } from "@/components/admin/api-pool-view";
import { getAdminStoreId } from "@/lib/store";
import { legacyPoolMode, maskKey } from "@/lib/services/legacy-pool";

export const metadata: Metadata = { title: "API Pool" };
export const dynamic = "force-dynamic";

export default async function ApiPoolPage() {
  const storeId = await getAdminStoreId();
  const mode = legacyPoolMode();
  const keys = await prisma.apiPoolKey.findMany({
    where: { storeId },
    include: { customer: { select: { accessCode: true, deletedAt: true } } },
    orderBy: [{ status: "asc" }, { createdAt: "desc" }],
  });

  // Assign sequential numbers by creation order (oldest = #1).
  const byAge = [...keys].sort((a, b) => a.createdAt.getTime() - b.createdAt.getTime());
  const numberMap = new Map(byAge.map((k, i) => [k.id, i + 1]));

  const rows: PoolKeyRow[] = keys.map((k) => ({
    id: k.id,
    // Full keys reach the browser only while the pool is active (WS10).
    key: mode === "active" ? k.key : maskKey(k.key),
    status: k.status,
    orderId: k.orderId,
    customerId: k.customerId,
    customerAccessCode: k.customer && !k.customer.deletedAt ? k.customer.accessCode : null,
    createdAt: k.createdAt.toISOString(),
    assignedAt: k.assignedAt?.toISOString() ?? null,
    rowNumber: numberMap.get(k.id) ?? 0,
  }));

  return (
    <div className="space-y-6">
      <PageHeader
        title="API Pool"
        description={
          mode === "active"
            ? "Pre-load API keys here. Each customer who activates with an Order ID automatically receives one key."
            : "Retired. Customers use AeroLink API tokens from the API Access page; this page keeps the assignment history."
        }
      />
      <ApiPoolView keys={rows} mode={mode} />
    </div>
  );
}
