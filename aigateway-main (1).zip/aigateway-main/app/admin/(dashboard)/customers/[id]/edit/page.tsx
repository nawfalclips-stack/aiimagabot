import type { Metadata } from "next";
import { notFound } from "next/navigation";
import { prisma } from "@/lib/prisma";
import { customerInclude } from "@/lib/services/customers";
import { toCustomerRow } from "@/lib/serialize";
import { PageHeader } from "@/components/shared/page-header";
import { CustomerForm } from "@/components/admin/customers/customer-form";
import { getAdminStoreId } from "@/lib/store";

export const metadata: Metadata = { title: "Edit Customer" };
export const dynamic = "force-dynamic";

export default async function EditCustomerPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const storeId = await getAdminStoreId();
  const customer = await prisma.customer.findUnique({ where: { id, storeId }, include: customerInclude });
  if (!customer) notFound();

  return (
    <div className="space-y-6">
      <PageHeader
        title={`Edit ${customer.accessCode}`}
        description="Update the customer's access code, API key, balances or status."
      />
      <CustomerForm customer={toCustomerRow(customer)} />
    </div>
  );
}
