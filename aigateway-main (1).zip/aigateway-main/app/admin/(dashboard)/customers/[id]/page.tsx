import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, CircleDollarSign, Gift, ScrollText } from "lucide-react";
import { prisma } from "@/lib/prisma";
import { customerInclude } from "@/lib/services/customers";
import { toCustomerRow } from "@/lib/serialize";
import { formatCents, percentUsed } from "@/lib/money";
import { getAdminStoreId } from "@/lib/store";

import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { StatusBadge } from "@/components/shared/status-badge";
import { CopyButton } from "@/components/shared/copy-button";
import { EmptyState } from "@/components/shared/empty-state";
import { ActivityFeed } from "@/components/admin/activity-feed";
import { ProfileActions } from "@/components/admin/customers/profile-actions";
import { ReviewBonusCard } from "@/components/admin/customers/review-bonus-card";
import { PlanCard, type PlanOption } from "@/components/admin/customers/plan-card";
import { getUsageCostMultiplier } from "@/lib/services/settings";
import { LocalTime } from "@/components/shared/local-time";
import { LedgerTable } from "@/components/shared/ledger-table";
import { RealUsageCard } from "@/components/admin/customers/real-usage-card";
import { getRealUsage } from "@/lib/services/real-usage";
import { bonusRealAllowance, customerRealAllowance } from "@/lib/real-usage";
import { describeBonusWorth } from "@/lib/plan-usage";

export const metadata: Metadata = { title: "Customer Profile" };
export const dynamic = "force-dynamic";

export default async function CustomerProfilePage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const storeId = await getAdminStoreId();
  const customer = await prisma.customer.findUnique({
    where: { id, storeId },
    include: {
      ...customerInclude,
      balanceHistory: { orderBy: { createdAt: "desc" }, take: 50 },
      bonusHistory: { orderBy: { createdAt: "desc" }, take: 50 },
      activityLogs: { orderBy: { createdAt: "desc" }, take: 25 },
    },
  });
  if (!customer) notFound();

  const [plans, globalMultiplier, ledger, realUsage] = await Promise.all([
    prisma.plan.findMany({ where: { storeId }, orderBy: [{ sortOrder: "asc" }, { priceCents: "asc" }] }),
    getUsageCostMultiplier(storeId),
    prisma.ledgerEntry.findMany({ where: { customerId: customer.id }, orderBy: { createdAt: "desc" }, take: 50 }),
    getRealUsage(storeId, customer.id),
  ]);
  const currentPlan = plans.find((p) => p.id === customer.planId) ?? null;
  const allowance = customerRealAllowance(customer, currentPlan, globalMultiplier);
  const bonusAllowance = bonusRealAllowance(customer.initialBonusCents, currentPlan, globalMultiplier);
  const planOptions: PlanOption[] = plans.map((p) => ({
    id: p.id,
    name: p.name,
    priceCents: p.priceCents,
    limitType: p.limitType === "TOKENS" ? "TOKENS" : "USD",
    limitUsageCents: p.limitUsageCents,
    limitMTokens: p.limitMTokens,
    isActive: p.isActive,
  }));

  const row = toCustomerRow(customer);
  const balancePct = percentUsed(row.usedBalanceCents, row.initialBalanceCents);
  const bonusPct = percentUsed(row.usedBonusCents, row.initialBonusCents);

  // `copy` is only ever set on string values — the copy button casts safely.
  const infoItems: { label: string; value: React.ReactNode; mono?: boolean; copy?: boolean }[] = [
    { label: "Access Code", value: row.accessCode, mono: true, copy: true },
    { label: "Order Number", value: row.orderNumber, mono: true, copy: true },
    { label: "Legacy API Key", value: row.apiKey || "—", mono: true, copy: row.apiKeyEditable && !!row.apiKey },
    { label: "Profit", value: formatCents(row.profitCents) },
    { label: "Created", value: <LocalTime date={row.createdAt} variant="date" /> },
    { label: "Last Updated", value: <LocalTime date={row.updatedAt} variant="date" /> },
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4">
        <Button asChild variant="ghost" size="sm" className="w-fit -ml-2 text-muted-foreground">
          <Link href="/admin/customers">
            <ArrowLeft /> Customers
          </Link>
        </Button>
        <div className="flex flex-col gap-4 lg:flex-row lg:items-center lg:justify-between">
          <div className="flex items-center gap-3">
            <h1 className="font-mono text-2xl font-semibold tracking-tight">{row.accessCode}</h1>
            <StatusBadge status={row.status} />
            {row.deletedAt ? (
              <span className="rounded-full border border-destructive/40 bg-destructive/10 px-2.5 py-0.5 text-xs text-destructive">
                Deleted
              </span>
            ) : null}
          </div>
          <ProfileActions customer={row} />
        </div>
      </div>

      {/* Info grid */}
      <Card>
        <CardContent className="grid gap-x-8 gap-y-5 sm:grid-cols-2 lg:grid-cols-3">
          {infoItems.map((item) => (
            <div key={item.label} className="min-w-0">
              <p className="text-xs font-medium tracking-wide text-muted-foreground uppercase">{item.label}</p>
              <div className="mt-1 flex items-center gap-1">
                <p className={`truncate text-sm font-medium ${item.mono ? "font-mono" : ""}`}>{item.value || "—"}</p>
                {item.copy && typeof item.value === "string" && item.value ? (
                  <CopyButton value={item.value} label={item.label} size="icon-xs" />
                ) : null}
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Balance + bonus */}
      <div className="grid gap-6 lg:grid-cols-2">
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <CircleDollarSign className="size-5 text-primary" /> Balance
            </CardTitle>
            <CardDescription>{balancePct}% used</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Progress value={balancePct} className="h-2.5" />
            <div className="grid grid-cols-3 gap-4 text-center">
              <div>
                <p className="text-xs text-muted-foreground">Initial</p>
                <p className="mt-0.5 font-semibold tabular-nums">{formatCents(row.initialBalanceCents)}</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Used</p>
                <p className="mt-0.5 font-semibold tabular-nums">{formatCents(row.usedBalanceCents)}</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Remaining</p>
                <p className="mt-0.5 font-semibold text-primary tabular-nums">{formatCents(row.remainingBalanceCents)}</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Gift className="size-5 text-success" /> Bonus
            </CardTitle>
            <CardDescription>{bonusPct}% used</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Progress value={bonusPct} className="h-2.5 [&>[data-slot=progress-indicator]]:bg-success" />
            <div className="grid grid-cols-3 gap-4 text-center">
              <div>
                <p className="text-xs text-muted-foreground">Initial</p>
                <p className="mt-0.5 font-semibold tabular-nums">{formatCents(row.initialBonusCents)}</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Used</p>
                <p className="mt-0.5 font-semibold tabular-nums">{formatCents(row.usedBonusCents)}</p>
              </div>
              <div>
                <p className="text-xs text-muted-foreground">Remaining</p>
                <p className="mt-0.5 font-semibold text-success tabular-nums">{formatCents(row.remainingBonusCents)}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <RealUsageCard
        usage={realUsage}
        allowance={allowance}
        bonusAllowance={bonusAllowance}
        bonusRateLabel={currentPlan && currentPlan.bonusCents > 0 ? `${currentPlan.name} bonus: ${formatCents(currentPlan.bonusCents)} = ${describeBonusWorth(currentPlan)}` : null}
        chargedCents={customer.usedBalanceCents + customer.usedBonusCents}
        planLabel={currentPlan ? `${currentPlan.name} plan` : `no plan, ×${globalMultiplier}`}
      />

      <div className="grid gap-6 xl:grid-cols-3">
        {/* History */}
        <Card className="xl:col-span-2">
          <CardHeader>
            <CardTitle>Usage History</CardTitle>
            <CardDescription>Every recorded balance and bonus update, newest first.</CardDescription>
          </CardHeader>
          <CardContent>
            <Tabs defaultValue="balance">
              <TabsList>
                <TabsTrigger value="balance">Balance ({customer.balanceHistory.length})</TabsTrigger>
                <TabsTrigger value="bonus">Bonus ({customer.bonusHistory.length})</TabsTrigger>
              </TabsList>
              {(["balance", "bonus"] as const).map((kind) => {
                const history = kind === "balance" ? customer.balanceHistory : customer.bonusHistory;
                return (
                  <TabsContent key={kind} value={kind}>
                    {history.length === 0 ? (
                      <EmptyState
                        icon={ScrollText}
                        title={`No ${kind} history yet`}
                        description={`Recorded ${kind} usage will appear here.`}
                        className="py-8"
                      />
                    ) : (
                      <div className="overflow-x-auto">
                        <Table>
                          <TableHeader>
                            <TableRow>
                              <TableHead>Date</TableHead>
                              <TableHead>Amount Used</TableHead>
                              <TableHead>Remaining After</TableHead>
                              <TableHead>Note</TableHead>
                              <TableHead>Updated By</TableHead>
                            </TableRow>
                          </TableHeader>
                          <TableBody>
                            {history.map((h) => (
                              <TableRow key={h.id}>
                                <TableCell className="whitespace-nowrap text-muted-foreground">
                                  <LocalTime date={h.createdAt} variant="datetime" />
                                </TableCell>
                                <TableCell className="font-medium tabular-nums">
                                  −{formatCents(h.amountUsedCents)}
                                </TableCell>
                                <TableCell className="tabular-nums">{formatCents(h.remainingAfterCents)}</TableCell>
                                <TableCell className="max-w-48 truncate text-muted-foreground">{h.note || "—"}</TableCell>
                                <TableCell className="text-muted-foreground">{h.updatedBy}</TableCell>
                              </TableRow>
                            ))}
                          </TableBody>
                        </Table>
                      </div>
                    )}
                  </TabsContent>
                );
              })}
            </Tabs>
          </CardContent>
        </Card>

        {/* Timeline + notes */}
        <div className="space-y-6">
          <PlanCard
            customerId={customer.id}
            currentPlanId={customer.planId}
            assignedAt={customer.planAssignedAt?.toISOString() ?? null}
            plans={planOptions}
            globalMultiplier={globalMultiplier}
          />
          <ReviewBonusCard customer={row} />
          <Card>
            <CardHeader>
              <CardTitle>Ledger</CardTitle>
              <CardDescription>Append-only record of every credit movement (last 50).</CardDescription>
            </CardHeader>
            <CardContent>
              {ledger.length === 0 ? (
                <p className="py-6 text-center text-sm text-muted-foreground">No ledger entries yet.</p>
              ) : (
                <LedgerTable entries={ledger} />
              )}
            </CardContent>
          </Card>
          <Card>
            <CardHeader>
              <CardTitle>Activity Timeline</CardTitle>
            </CardHeader>
            <CardContent>
              {customer.activityLogs.length === 0 ? (
                <p className="py-6 text-center text-sm text-muted-foreground">No activity recorded.</p>
              ) : (
                <ActivityFeed items={customer.activityLogs} />
              )}
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Notes</CardTitle>
              <CardDescription>Internal — never shown to the customer.</CardDescription>
            </CardHeader>
            <CardContent>
              <p className="text-sm whitespace-pre-wrap text-foreground/90">{row.notes || "No notes."}</p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
