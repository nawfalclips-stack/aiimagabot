"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { Prisma } from "@prisma/client";
import { prisma } from "@/lib/prisma";
import { getCurrentAdmin, requireWriteAdmin } from "@/lib/auth";
import {
  createCustomer,
  updateCustomer,
  updateBonusUsage,
  recordAdminUsage,
  addBalanceFunds,
  addBonusFunds,
  softDeleteCustomer,
  restoreCustomer,
  permanentlyDeleteCustomer,
  duplicateCustomer,
  setPurchasedAgain,
  setCustomerStatus,
} from "@/lib/services/customers";
import { generateAccessCode, generateOrderNumber } from "@/lib/services/generators";
import { verifyReviewBonus, revokeReviewBonus } from "@/lib/services/review-bonus";
import { logActivity } from "@/lib/services/activity";
import { recordUsageFromAmount } from "@/lib/services/usage-quick";
import { usdToCents } from "@/lib/money";
import { CUSTOMER_STATUSES, PURCHASED_AGAIN_VALUES } from "@/lib/constants";
import { getAdminStoreId, type StoreId } from "@/lib/store";

export type ActionResult<T = undefined> =
  | { ok: true; data?: T }
  | { ok: false; error: string };

async function guard() {
  const admin = await requireWriteAdmin();
  return admin;
}

function fail(error: unknown): { ok: false; error: string } {
  if (error instanceof Error) {
    if (error.message === "UNAUTHORIZED") return { ok: false, error: "Your session has expired. Sign in again." };
    if (error instanceof Prisma.PrismaClientKnownRequestError && error.code === "P2002") {
      return { ok: false, error: "That access code or order number is already in use." };
    }
    if (!error.message.includes("prisma") && error.message.length < 200) {
      return { ok: false, error: error.message };
    }
  }
  console.error(error);
  return { ok: false, error: "Something went wrong. Please try again." };
}

function refresh() {
  revalidatePath("/admin", "layout");
}

const moneySchema = z.coerce.number().min(0, "Must be zero or more").max(1_000_000, "Too large");

const customerSchema = z.object({
  accessCode: z
    .string()
    .trim()
    .min(6, "Access code must be at least 6 characters")
    .max(64, "Access code is too long")
    .regex(/^[A-Za-z0-9-]+$/, "Only letters, numbers and dashes are allowed"),
  orderNumber: z.string().trim().min(3, "Order number must be at least 3 characters").max(64),
  // Legacy pool key (WS10): optional, and ignored unless LEGACY_API_POOL_MODE=active.
  apiKey: z
    .string()
    .trim()
    .max(512)
    .refine((v) => v === "" || v.length >= 4, "API key looks too short")
    .optional(),
  initialBalance: moneySchema,
  initialBonus: moneySchema,
  profit: moneySchema,
  status: z.enum(CUSTOMER_STATUSES).default("ACTIVE"),
  notes: z.string().trim().max(5000).default(""),
  /** Why the balance/bonus changed; the service rejects a money change without it. */
  balanceChangeReason: z.string().trim().max(500).optional(),
});

export type CustomerFormInput = z.input<typeof customerSchema>;

export async function createCustomerAction(input: CustomerFormInput): Promise<ActionResult<{ id: string }>> {
  try {
    const admin = await guard();
    const storeId = await getAdminStoreId();
    const data = customerSchema.parse(input);
    const customer = await createCustomer(
      {
        accessCode: data.accessCode.toUpperCase(),
        orderNumber: data.orderNumber,
        apiKey: data.apiKey,
        initialBalanceCents: usdToCents(data.initialBalance),
        initialBonusCents: usdToCents(data.initialBonus),
        profitCents: usdToCents(data.profit),
        status: data.status,
        notes: data.notes,
      },
      admin.id,
      admin.name,
      storeId
    );
    refresh();
    return { ok: true, data: { id: customer.id } };
  } catch (error) {
    if (error instanceof z.ZodError) return { ok: false, error: error.issues[0].message };
    return fail(error);
  }
}

export async function updateCustomerAction(id: string, input: CustomerFormInput): Promise<ActionResult> {
  try {
    const admin = await guard();
    const data = customerSchema.parse(input);
    await updateCustomer(
      id,
      {
        accessCode: data.accessCode.toUpperCase(),
        orderNumber: data.orderNumber,
        apiKey: data.apiKey,
        initialBalanceCents: usdToCents(data.initialBalance),
        initialBonusCents: usdToCents(data.initialBonus),
        profitCents: usdToCents(data.profit),
        status: data.status,
        notes: data.notes,
        balanceChangeReason: data.balanceChangeReason,
      },
      admin.id,
      admin.name
    );
    refresh();
    return { ok: true };
  } catch (error) {
    if (error instanceof z.ZodError) return { ok: false, error: error.issues[0].message };
    return fail(error);
  }
}

const usageSchema = z.object({
  amount: z.coerce.number().positive("Amount must be greater than zero").max(1_000_000),
  note: z.string().trim().max(500).default(""),
});

// Manual top-ups are ADMIN_ADJUSTMENT ledger entries and must say why.
const topUpSchema = usageSchema.extend({
  note: z.string().trim().min(3, "Please give a reason for this adjustment").max(500),
});

export async function updateBalanceUsageAction(id: string, input: { amount: number; note?: string }): Promise<ActionResult> {
  try {
    const admin = await guard();
    const data = usageSchema.parse(input);
    const totalCents = usdToCents(data.amount);
    const split = await recordAdminUsage(id, totalCents, admin.id, admin.name, data.note || "Usage recorded by admin");
    await logActivity({
      storeId: (await prisma.customer.findUniqueOrThrow({ where: { id }, select: { storeId: true } })).storeId as StoreId,
      action: "BALANCE_UPDATED",
      description: `${admin.name} recorded ${(totalCents / 100).toFixed(2)} USD usage (${(split.balanceCents / 100).toFixed(2)} balance / ${(split.bonusCents / 100).toFixed(2)} bonus${split.uncollectedCents > 0 ? `; ${(split.uncollectedCents / 100).toFixed(2)} uncollected` : ""})`,
      adminId: admin.id,
      customerId: id,
    });
    refresh();
    return { ok: true };
  } catch (error) {
    if (error instanceof z.ZodError) return { ok: false, error: error.issues[0].message };
    return fail(error);
  }
}

export async function updateBonusUsageAction(id: string, input: { amount: number; note?: string }): Promise<ActionResult> {
  try {
    const admin = await guard();
    const data = usageSchema.parse(input);
    await updateBonusUsage(id, usdToCents(data.amount), admin.id, admin.name, data.note);
    refresh();
    return { ok: true };
  } catch (error) {
    if (error instanceof z.ZodError) return { ok: false, error: error.issues[0].message };
    return fail(error);
  }
}

export async function addBalanceFundsAction(id: string, input: { amount: number; note?: string }): Promise<ActionResult> {
  try {
    const admin = await guard();
    const data = topUpSchema.parse(input);
    await addBalanceFunds(id, usdToCents(data.amount), admin.id, admin.name, data.note);
    refresh();
    return { ok: true };
  } catch (error) {
    if (error instanceof z.ZodError) return { ok: false, error: error.issues[0].message };
    return fail(error);
  }
}

export async function addBonusFundsAction(id: string, input: { amount: number; note?: string }): Promise<ActionResult> {
  try {
    const admin = await guard();
    const data = topUpSchema.parse(input);
    await addBonusFunds(id, usdToCents(data.amount), admin.id, admin.name, data.note);
    refresh();
    return { ok: true };
  } catch (error) {
    if (error instanceof z.ZodError) return { ok: false, error: error.issues[0].message };
    return fail(error);
  }
}

export async function deleteCustomerAction(id: string): Promise<ActionResult> {
  try {
    const admin = await guard();
    await softDeleteCustomer(id, admin.id, admin.name);
    refresh();
    return { ok: true };
  } catch (error) {
    return fail(error);
  }
}

export async function restoreCustomerAction(id: string): Promise<ActionResult> {
  try {
    const admin = await guard();
    await restoreCustomer(id, admin.id, admin.name);
    refresh();
    return { ok: true };
  } catch (error) {
    return fail(error);
  }
}

export async function permanentDeleteCustomerAction(id: string): Promise<ActionResult> {
  try {
    const admin = await guard();
    await permanentlyDeleteCustomer(id, admin.id, admin.name);
    refresh();
    return { ok: true };
  } catch (error) {
    return fail(error);
  }
}

export async function duplicateCustomerAction(id: string): Promise<ActionResult<{ id: string }>> {
  try {
    const admin = await guard();
    const customer = await duplicateCustomer(id, admin.id, admin.name);
    refresh();
    return { ok: true, data: { id: customer.id } };
  } catch (error) {
    return fail(error);
  }
}

export async function setPurchasedAgainAction(id: string, value: string): Promise<ActionResult> {
  try {
    const admin = await guard();
    const parsed = z.enum(PURCHASED_AGAIN_VALUES).parse(value);
    await setPurchasedAgain(id, parsed, admin.id, admin.name);
    refresh();
    return { ok: true };
  } catch (error) {
    return fail(error);
  }
}

export async function setCustomerStatusAction(id: string, status: string): Promise<ActionResult> {
  try {
    const admin = await guard();
    const parsed = z.enum(CUSTOMER_STATUSES).parse(status);
    await setCustomerStatus(id, parsed, admin.id, admin.name);
    refresh();
    return { ok: true };
  } catch (error) {
    return fail(error);
  }
}

/** WS8: put many customers on one plan ("" = remove the plan) — the "No plan" fix-up. */
export async function bulkAssignPlanAction(ids: string[], planId: string): Promise<ActionResult> {
  try {
    const admin = await guard();
    const storeId = await getAdminStoreId();
    const list = z.array(z.string().min(1)).min(1).max(500).parse(ids);
    const clean = z.string().max(64).parse(planId);
    const plan = clean ? await prisma.plan.findFirst({ where: { id: clean, storeId }, select: { id: true, name: true } }) : null;
    if (clean && !plan) return { ok: false, error: "Plan not found." };
    const r = await prisma.customer.updateMany({
      where: { id: { in: list }, storeId },
      data: { planId: plan?.id ?? null, planAssignedAt: plan ? new Date() : null },
    });
    await logActivity({
      storeId,
      action: "PLAN_ASSIGNED",
      description: plan ? `${admin.name} put ${r.count} customer(s) on plan "${plan.name}"` : `${admin.name} removed the plan from ${r.count} customer(s)`,
      adminId: admin.id,
    });
    refresh();
    revalidatePath("/portal/api-access");
    return { ok: true };
  } catch (error) {
    return fail(error);
  }
}

export async function bulkDeleteAction(ids: string[]): Promise<ActionResult> {
  try {
    const admin = await guard();
    const storeId = await getAdminStoreId();
    const list = z.array(z.string().min(1)).min(1).max(500).parse(ids);
    await prisma.customer.updateMany({ where: { id: { in: list }, storeId }, data: { deletedAt: new Date() } });
    await logActivity({
      storeId,
      action: "CUSTOMER_DELETED",
      description: `${admin.name} deleted ${list.length} customers (recoverable)`,
      adminId: admin.id,
    });
    refresh();
    return { ok: true };
  } catch (error) {
    return fail(error);
  }
}

export async function bulkStatusAction(ids: string[], status: string): Promise<ActionResult> {
  try {
    const admin = await guard();
    const list = z.array(z.string().min(1)).min(1).max(500).parse(ids);
    const parsed = z.enum(CUSTOMER_STATUSES).parse(status);
    for (const id of list) {
      await setCustomerStatus(id, parsed, admin.id, admin.name);
    }
    refresh();
    return { ok: true };
  } catch (error) {
    return fail(error);
  }
}

/** Set a customer's profit directly (used by the inline editor on Orders). */
export async function setProfitAction(customerId: string, profitUsd: number): Promise<ActionResult> {
  try {
    const admin = await guard();
    const profit = moneySchema.parse(profitUsd);
    await updateCustomer(customerId, { profitCents: usdToCents(profit) }, admin.id, admin.name);
    refresh();
    return { ok: true };
  } catch (error) {
    if (error instanceof z.ZodError) return { ok: false, error: error.issues[0].message };
    return fail(error);
  }
}

export async function verifyReviewBonusAction(id: string): Promise<ActionResult> {
  try {
    const admin = await guard();
    await verifyReviewBonus(id, admin.id, admin.name);
    refresh();
    return { ok: true };
  } catch (error) {
    return fail(error);
  }
}

export async function revokeReviewBonusAction(id: string): Promise<ActionResult> {
  try {
    const admin = await guard();
    await revokeReviewBonus(id, admin.id, admin.name);
    refresh();
    return { ok: true };
  } catch (error) {
    return fail(error);
  }
}

export async function generateCodeAction(): Promise<ActionResult<{ code: string }>> {
  try {
    await guard();
    return { ok: true, data: { code: await generateAccessCode() } };
  } catch (error) {
    return fail(error);
  }
}

export async function generateOrderNumberAction(): Promise<ActionResult<{ orderNumber: string }>> {
  try {
    await guard();
    return { ok: true, data: { orderNumber: await generateOrderNumber() } };
  } catch (error) {
    return fail(error);
  }
}

export async function logExportAction(count: number, format: string): Promise<void> {
  const admin = await getCurrentAdmin();
  if (!admin) return;
  const storeId = await getAdminStoreId();
  await logActivity({
    storeId,
    action: "CUSTOMERS_EXPORTED",
    description: `${admin.name} exported ${count} customers as ${format.toUpperCase()}`,
    adminId: admin.id,
  });
}

const importRowSchema = z.object({
  accessCode: z.string().trim().min(6).max(64),
  orderNumber: z.string().trim().min(3).max(64),
  apiKey: z.string().trim().max(512).optional(),
  initialBalance: moneySchema,
  initialBonus: moneySchema.optional().default(0),
  profit: moneySchema.optional().default(0),
  notes: z.string().trim().max(5000).optional().default(""),
});

export async function importCustomersAction(
  rows: unknown[]
): Promise<ActionResult<{ imported: number; skipped: { row: number; reason: string }[] }>> {
  try {
    const admin = await guard();
    const storeId = await getAdminStoreId();
    if (!Array.isArray(rows) || rows.length === 0) return { ok: false, error: "No rows to import." };
    if (rows.length > 1000) return { ok: false, error: "Import at most 1000 rows at a time." };

    let imported = 0;
    const skipped: { row: number; reason: string }[] = [];

    for (let i = 0; i < rows.length; i++) {
      const parsed = importRowSchema.safeParse(rows[i]);
      if (!parsed.success) {
        skipped.push({ row: i + 1, reason: parsed.error.issues[0].message });
        continue;
      }
      const data = parsed.data;
      const [codeExists, orderExists] = await Promise.all([
        prisma.customer.findUnique({ where: { accessCode: data.accessCode.toUpperCase() }, select: { id: true } }),
        prisma.order.findUnique({ where: { orderNumber: data.orderNumber }, select: { id: true } }),
      ]);
      if (codeExists) {
        skipped.push({ row: i + 1, reason: `Duplicate access code ${data.accessCode}` });
        continue;
      }
      if (orderExists) {
        skipped.push({ row: i + 1, reason: `Duplicate order number ${data.orderNumber}` });
        continue;
      }
      await createCustomer(
        {
          accessCode: data.accessCode.toUpperCase(),
          orderNumber: data.orderNumber,
          apiKey: data.apiKey,
          initialBalanceCents: usdToCents(data.initialBalance),
          initialBonusCents: usdToCents(data.initialBonus),
          profitCents: usdToCents(data.profit),
          notes: data.notes,
        },
        admin.id,
        admin.name,
        storeId
      );
      imported++;
    }

    await logActivity({
      storeId,
      action: "CUSTOMERS_IMPORTED",
      description: `${admin.name} imported ${imported} customers (${skipped.length} skipped)`,
      adminId: admin.id,
    });
    refresh();
    return { ok: true, data: { imported, skipped } };
  } catch (error) {
    return fail(error);
  }
}

/**
 * Quick usage entry from a customer's profile: the admin enters a total amount
 * and an optional note. One "Manual charge" row is written and the exact amount
 * is charged through the ledger (WS7: no synthesized per-model rows).
 */
const quickUsageSchema = z.object({
  customerId: z.string().min(1),
  title: z.string().trim().max(120).optional().default(""),
  amount: z.coerce.number().positive("Amount must be greater than zero").max(1_000_000),
});

export async function recordQuickUsageAction(customerId: string, title: string, amount: number): Promise<ActionResult<{ added: number; deductedCents: number }>> {
  try {
    const admin = await guard();
    const storeId = await getAdminStoreId();
    const data = quickUsageSchema.parse({ customerId, title, amount });
    const result = await recordUsageFromAmount(
      data.customerId,
      data.title,
      usdToCents(data.amount),
      admin.id,
      admin.name,
      storeId
    );
    revalidatePath("/admin", "layout");
    revalidatePath("/portal", "layout");
    return { ok: true, data: { added: result.added, deductedCents: result.deductedCents } };
  } catch (error) {
    if (error instanceof z.ZodError) return { ok: false, error: error.issues[0].message };
    return fail(error);
  }
}
