import type { Metadata } from "next";
import { PageHeader } from "@/components/shared/page-header";
import { CustomerForm } from "@/components/admin/customers/customer-form";
import { poolAssignmentsEnabled } from "@/lib/services/legacy-pool";

export const metadata: Metadata = { title: "New Customer" };

export default function NewCustomerPage() {
  return (
    <div className="space-y-6">
      <PageHeader
        title="Create customer"
        description="Generate an access code and set the starting balance. The customer creates their own API token on the API Access page."
      />
      <CustomerForm apiKeyEditable={poolAssignmentsEnabled()} />
    </div>
  );
}
