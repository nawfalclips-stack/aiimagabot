import type { Metadata } from "next";
import Link from "next/link";
import { Plus } from "lucide-react";
import { prisma } from "@/lib/prisma";
import { customerInclude } from "@/lib/services/customers";
import { toCustomerRow } from "@/lib/serialize";
import { Button } from "@/components/ui/button";
import { PageHeader } from "@/components/shared/page-header";
import { CustomersTable } from "@/components/admin/customers/customers-table";
import { ImportDialog } from "@/components/admin/customers/import-dialog";
import { getAdminStoreId } from "@/lib/store";
import { getUsageCostMultiplier } from "@/lib/services/settings";
import { getRealUsageByCustomer } from "@/lib/services/real-usage";
import { customerRealAllowance, realUsedPct } from "@/lib/real-usage";
import type { RealUsageCell } from "@/lib/types";

export const metadata: Metadata = { title: "Customers" };
export const dynamic = "force-dynamic";

export default async function CustomersPage() {
  const storeId = await getAdminStoreId();

  const [customers, plans, realUsage, multiplier] = await Promise.all([
    prisma.customer.findMany({
      where: { storeId, deletedAt: null },
      include: customerInclude,
      orderBy: { createdAt: "desc" },
    }),
    prisma.plan.findMany({ where: { storeId }, orderBy: [{ sortOrder: "asc" }, { priceCents: "asc" }] }),
    getRealUsageByCustomer(storeId),
    getUsageCostMultiplier(storeId),
  ]);
  const planById = new Map(plans.map((p) => [p.id, p]));
  // Real provider cost per customer, and how much of what their credit buys it used.
  const realCells: Record<string, RealUsageCell> = {};
  for (const c of customers) {
    const usage = realUsage[c.id];
    if (!usage) continue;
    const allowance = customerRealAllowance(c, c.planId ? (planById.get(c.planId) ?? null) : null, multiplier);
    realCells[c.id] = { costMicroUsd: usage.costMicroUsd, requests: usage.requests, pct: realUsedPct(usage, allowance) };
  }
  const noPlan = customers.filter((c) => c.isActivated && !c.planId).length;

  return (
    <div className="space-y-6">
      <PageHeader
        title="Customers"
        description={`${customers.length} ${customers.length === 1 ? "customer" : "customers"} with API access.${noPlan > 0 ? ` ${noPlan} without a plan (billed at the global multiplier).` : ""}`}
        actions={
          <>
            <ImportDialog />
            <Button asChild>
              <Link href="/admin/customers/new">
                <Plus /> New customer
              </Link>
            </Button>
          </>
        }
      />
      <CustomersTable
        customers={customers.map(toCustomerRow)}
        plans={plans.filter((p) => p.isActive).map((p) => ({ id: p.id, name: p.name }))}
        realUsage={realCells}
      />
    </div>
  );
}
