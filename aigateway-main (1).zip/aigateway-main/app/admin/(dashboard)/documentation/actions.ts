"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { getCurrentAdmin, requireWriteAdmin } from "@/lib/auth";
import { updateDoc, rollbackDoc } from "@/lib/services/documentation";
import type { ActionResult } from "@/app/admin/(dashboard)/customers/actions";
import { getAdminStoreId } from "@/lib/store";

export async function updateDocAction(id: string, content: string): Promise<ActionResult> {
  try {
    const admin = await requireWriteAdmin();
    const storeId = await getAdminStoreId();
    const parsed = z.object({ id: z.string().min(1), content: z.string().min(1).max(200_000) }).parse({ id, content });
    await updateDoc(parsed.id, parsed.content, admin.id, admin.name, storeId);
    revalidatePath("/admin/documentation");
    revalidatePath("/portal/documentation");
    return { ok: true };
  } catch (error) {
    console.error(error);
    return { ok: false, error: "Could not save the documentation. Please try again." };
  }
}

export async function rollbackDocAction(versionId: string): Promise<ActionResult> {
  try {
    const admin = await requireWriteAdmin();
    const storeId = await getAdminStoreId();
    await rollbackDoc(versionId, admin.id, admin.name, storeId);
    revalidatePath("/admin/documentation");
    revalidatePath("/portal/documentation");
    return { ok: true };
  } catch (error) {
    console.error(error);
    return { ok: false, error: "Could not roll back this version. Please try again." };
  }
}
