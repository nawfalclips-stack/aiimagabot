import type { Metadata } from "next";
import { DOC_CATEGORIES } from "@/lib/constants";
import { Suspense } from "react";
import { prisma } from "@/lib/prisma";
import { PageHeader } from "@/components/shared/page-header";
import { DocEditor, type DocItem, type DocVersion } from "@/components/admin/doc-editor";
import { getAdminStoreId } from "@/lib/store";
import { preferStoreDocs } from "@/lib/services/documentation";

export const metadata: Metadata = { title: "Documentation" };
export const dynamic = "force-dynamic";

export default async function DocumentationAdminPage() {
  const storeId = await getAdminStoreId();
  const [docs, versions] = await Promise.all([
    prisma.documentation
      .findMany({ where: { storeId }, orderBy: [{ category: "asc" }, { sortOrder: "asc" }] })
      .then((rows) => preferStoreDocs(rows, storeId)),
    prisma.documentationVersion.findMany({ where: { documentation: { storeId } }, orderBy: { createdAt: "desc" }, take: 100 }),
  ]);

  // Canonical order from DOC_CATEGORIES — also controls the default-selected
  // guide in the editor.
  const categoryOrder: string[] = [...DOC_CATEGORIES];
  const sorted = [...docs].sort((a, b) => {
    const ca = categoryOrder.indexOf(a.category);
    const cb = categoryOrder.indexOf(b.category);
    if (ca !== cb) return (ca === -1 ? 99 : ca) - (cb === -1 ? 99 : cb);
    return a.sortOrder - b.sortOrder;
  });

  const docItems: DocItem[] = sorted.map((d) => ({
    id: d.id,
    slug: d.slug,
    category: d.category,
    os: d.os,
    title: d.title,
    content: d.content,
    updatedAt: d.updatedAt.toISOString(),
  }));

  const versionMap: Record<string, DocVersion[]> = {};
  for (const v of versions) {
    (versionMap[v.documentationId] ??= []).push({
      id: v.id,
      savedBy: v.savedBy,
      createdAt: v.createdAt.toISOString(),
      content: v.content,
    });
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title="Documentation"
        description="Manage the setup guides customers see. Every save keeps a restorable version."
      />
      <Suspense>
        <DocEditor docs={docItems} versions={versionMap} />
      </Suspense>
    </div>
  );
}
