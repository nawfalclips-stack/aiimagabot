"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { creditOpening } from "@/lib/services/customers";
import { getCurrentAdmin, requireWriteAdmin } from "@/lib/auth";
import { logActivity } from "@/lib/services/activity";
import { generateAccessCode } from "@/lib/services/generators";
import { parsePastClients } from "@/lib/past-clients-parser";
import { computeStatus } from "@/lib/services/status";
import { getLowBalanceThresholdCents } from "@/lib/services/settings";
import type { ActionResult } from "@/app/admin/(dashboard)/customers/actions";
import { getAdminStoreId } from "@/lib/store";
import { poolAssignmentsEnabled } from "@/lib/services/legacy-pool";

export async function importPastClientsAction(
  raw: string
): Promise<ActionResult<{ imported: number; skipped: { block: string; reason: string }[] }>> {
  try {
    const admin = await requireWriteAdmin();
    const storeId = await getAdminStoreId();

    const input = z.string().min(1).max(500_000).parse(raw);
    const { clients, skipped } = parsePastClients(input);
    if (clients.length === 0) {
      return { ok: false, error: "No clients recognized — make sure the paste includes access codes like XXXX-XXXX-XXXX." };
    }
    if (clients.length > 500) {
      return { ok: false, error: "Import at most 500 clients at a time." };
    }

    const threshold = await getLowBalanceThresholdCents(storeId);
    let imported = 0;
    const allSkipped = [...skipped];

    for (const client of clients) {
      // Skip Cancelled records (test data / invalid)
      if (client.sourceStatus === "cancelled") {
        allSkipped.push({ block: client.accessCode, reason: "Cancelled — skipped" });
        continue;
      }

      // Check duplicates against existing data
      const codeExists = await prisma.customer.findUnique({
        where: { accessCode: client.accessCode },
        select: { id: true },
      });
      if (codeExists) {
        allSkipped.push({ block: client.accessCode, reason: `Access code ${client.accessCode} already exists` });
        continue;
      }

      // Order ID collision: make it unique
      let orderId = client.orderId;
      const orderExists = await prisma.order.findUnique({
        where: { orderNumber: orderId },
        select: { id: true },
      });
      if (orderExists) {
        orderId = `${orderId}-${client.accessCode}`;
      }

      const remaining = client.initialBalanceCents - client.usedBalanceCents;
      const status = computeStatus(remaining, threshold, client.sourceStatus === "inactive" ? "SUSPENDED" : "ACTIVE");

      // Legacy upstream keys are kept only while the pool is active (WS10).
      // Check if this API key value already exists (truncated keys can collide).
      const keepKey = !!client.apiKey && poolAssignmentsEnabled();
      const apiKeyConflict = keepKey
        ? await prisma.apiKey.findFirst({ where: { key: client.apiKey }, select: { id: true } })
        : null;
      const storeApiKey = keepKey && !apiKeyConflict;

      try {
        // Imported clients arrive with money already spent: the ledger opens
        // with the *remaining* amounts (what we still owe them), never below zero.
        await prisma.$transaction(async (tx) => {
          const row = await tx.customer.create({
            data: {
              storeId,
              accessCode: client.accessCode,
              status,
              notes: `Imported past client\n${client.raw.slice(0, 500)}`,
              offerTitle: client.raw.slice(0, 200),
              profitCents: client.profitCents,
              purchasedAgain: "UNKNOWN",
              finishedAt: remaining <= 0 ? new Date() : null,
              suspendedAt: client.sourceStatus === "inactive" ? new Date() : null,
              order: { create: { orderNumber: orderId } },
              ...(storeApiKey ? { apiKey: { create: { key: client.apiKey! } } } : {}),
            },
          });
          const actor = { adminId: admin.id, label: admin.name };
          const importNote = `Imported past client (paid ${(client.initialBalanceCents / 100).toFixed(2)}, used ${(client.usedBalanceCents / 100).toFixed(2)})`;
          await creditOpening(tx, row.id, "BALANCE", Math.max(0, client.initialBalanceCents - client.usedBalanceCents), actor, importNote);
          await creditOpening(tx, row.id, "BONUS", Math.max(0, client.initialBonusCents - client.usedBonusCents), actor, importNote);
        });
        imported++;
      } catch (e: unknown) {
        const msg = e instanceof Error ? e.message : String(e);
        // Unique constraint on accessCode means a true duplicate slipped past the earlier check.
        allSkipped.push({
          block: client.accessCode,
          reason: msg.includes("Unique constraint") ? `${client.accessCode} already exists (duplicate)` : msg.slice(0, 120),
        });
      }
    }

    await logActivity({
      storeId,
      action: "CUSTOMERS_IMPORTED",
      description: `${admin.name} imported ${imported} past clients (${allSkipped.length} skipped)`,
      adminId: admin.id,
    });

    revalidatePath("/admin", "layout");
    return { ok: true, data: { imported, skipped: allSkipped } };
  } catch (error) {
    console.error(error);
    return { ok: false, error: "Could not import those clients. Please try again." };
  }
}
