import type { Metadata } from "next";
import { prisma } from "@/lib/prisma";
import { customerInclude } from "@/lib/services/customers";
import { toCustomerRow } from "@/lib/serialize";
import { PageHeader } from "@/components/shared/page-header";
import { ExpiredView } from "@/components/admin/expired-view";
import { ImportPastClients } from "@/components/admin/import-past-clients";
import { getAdminStoreId } from "@/lib/store";

export const metadata: Metadata = { title: "Expired Balance" };
export const dynamic = "force-dynamic";

export default async function ExpiredPage() {
  const storeId = await getAdminStoreId();
  const customers = await prisma.customer.findMany({
    where: { storeId, deletedAt: null, status: { in: ["BALANCE_FINISHED", "EXPIRED"] } },
    include: customerInclude,
    orderBy: [{ finishedAt: "desc" }, { updatedAt: "desc" }],
  });

  return (
    <div className="relative space-y-6">
      <PageHeader
        title="Expired Balance"
        description="Customers whose balance is fully consumed. Click a card to filter — track who purchased again."
      />
      <ExpiredView customers={customers.map(toCustomerRow)} />

      {/* Floating button — always visible regardless of scroll or zoom level */}
      <div className="fixed bottom-6 right-6 z-50">
        <ImportPastClients />
      </div>
    </div>
  );
}
