import type { Metadata } from "next";
import { requireAdmin } from "@/lib/auth";
import { getSettings } from "@/lib/services/settings";
import { SETTING_KEYS } from "@/lib/constants";
import { prisma } from "@/lib/prisma";
import { AdminShell } from "@/components/admin/admin-shell";
import { legacyPoolMode } from "@/lib/services/legacy-pool";
import { getAdminStoreId, getAdminStores } from "@/lib/store";
import { getNotifications, getUnreadNotificationCount } from "@/lib/services/notifications";

export const metadata: Metadata = {
  robots: { index: false, follow: false },
};

export default async function AdminDashboardLayout({ children }: { children: React.ReactNode }) {
  const admin = await requireAdmin();
  const currentStoreId = await getAdminStoreId();
  const stores = await getAdminStores(admin.id);

  const [settings, openTicketCount, pendingActivationCount, notifications, unreadNotificationCount] = await Promise.all([
    getSettings(currentStoreId),
    prisma.ticket.count({ where: { storeId: currentStoreId, status: { in: ["OPEN", "AUTO_FIXING"] } } }),
    prisma.customer.count({ where: { storeId: currentStoreId, isActivated: false, rejectedAt: null, deletedAt: null } }),
    getNotifications(currentStoreId, 20),
    getUnreadNotificationCount(currentStoreId),
  ]);

  return (
    <AdminShell
      adminName={admin.name}
      adminEmail={admin.email}
      // Map the DB flag onto the roles the shell understands: read-only admins
      // get view-only navigation, everyone else gets everything.
      adminRole={admin.isReadOnly ? "API_VIEWER" : "FULL_ACCESS"}
      logoText={settings[SETTING_KEYS.logoText]}
      openTicketCount={openTicketCount}
      pendingActivationCount={pendingActivationCount}
      stores={stores}
      currentStoreId={currentStoreId}
      notifications={notifications}
      unreadNotificationCount={unreadNotificationCount}
      showApiPool={legacyPoolMode() !== "off"}
    >
      {children}
    </AdminShell>
  );
}
