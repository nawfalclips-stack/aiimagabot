"use server";

import { revalidatePath } from "next/cache";
import { requireWriteAdmin } from "@/lib/auth";
import { approveReward, rejectReward } from "@/lib/services/loyalty";

export type ActionResult = { ok: true } | { ok: false; error: string };

export async function approveRewardAction(customerId: string): Promise<ActionResult> {
  try {
    const admin = await requireWriteAdmin();
    await approveReward(customerId, admin.name);
    revalidatePath("/admin/loyalty");
    revalidatePath("/portal", "layout");
    return { ok: true };
  } catch (error) {
    console.error(error);
    return {
      ok: false,
      error: error instanceof Error ? error.message : "Could not approve this reward.",
    };
  }
}

export async function rejectRewardAction(customerId: string, reason: string): Promise<ActionResult> {
  try {
    const admin = await requireWriteAdmin();
    await rejectReward(customerId, admin.name, reason);
    revalidatePath("/admin/loyalty");
    revalidatePath("/portal", "layout");
    return { ok: true };
  } catch (error) {
    console.error(error);
    return {
      ok: false,
      error: error instanceof Error ? error.message : "Could not reject this reward.",
    };
  }
}
