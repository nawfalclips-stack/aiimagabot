import { prisma } from "@/lib/prisma";
import { getAdminStoreId } from "@/lib/store";
import type { Metadata } from "next";
import Link from "next/link";
import { Award, Gift, SlidersHorizontal } from "lucide-react";
import { Button } from "@/components/ui/button";
import { getLoyaltyProgram } from "@/lib/services/loyalty-program";
import { getTierForPoints } from "@/lib/loyalty";
import { LoyaltyTable } from "./table";

export const metadata: Metadata = { title: "Loyalty Program" };
export const dynamic = "force-dynamic";

export default async function AdminLoyaltyPage() {
  const storeId = await getAdminStoreId();

  const program = await getLoyaltyProgram(storeId);
  const customers = await prisma.customer.findMany({
    where: { storeId, deletedAt: null },
    select: {
      id: true,
      accessCode: true,
      status: true,
      loyaltyPoints: true,
      purchaseCount: true,
      rewardRequestStatus: true,
      rewardRequestedAt: true,
      createdAt: true,
    },
    orderBy: [{ loyaltyPoints: "desc" }, { createdAt: "desc" }],
  });

  const pendingRewards = customers.filter((c) => c.rewardRequestStatus === "PENDING");

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-start justify-between gap-4">
        <div>
        <h1 className="flex items-center gap-2 text-2xl font-semibold tracking-tight">
          <Award className="size-6 text-primary" /> Loyalty Program
        </h1>
        <p className="mt-1 text-sm text-muted-foreground">
          Points, levels and purchase counts for every customer. Customers whose level has a cash reward can request it
          here — you approve or reject it; nothing is credited automatically.
        </p>
        </div>
        <Button asChild variant="outline">
          <Link href="/admin/loyalty/program">
            <SlidersHorizontal /> Program settings
          </Link>
        </Button>
      </div>

      {/* Pending reward requests */}
      {pendingRewards.length > 0 ? (
        <section className="rounded-xl border border-warning/40 bg-warning/10 p-5">
          <p className="flex items-center gap-2 text-sm font-semibold text-warning">
            <Gift className="size-4" />
            {pendingRewards.length} reward request{pendingRewards.length === 1 ? "" : "s"} waiting for your decision
          </p>
        </section>
      ) : null}

      <LoyaltyTable
        customers={customers.map((c) => {
          const tier = getTierForPoints(c.loyaltyPoints, program.tiers);
          return { ...c, tierName: tier.name, tierColor: tier.colorHex, rewardAmountCents: tier.rewardAmountCents };
        })}
      />
    </div>
  );
}
