"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { requireWriteAdmin } from "@/lib/auth";
import { getAdminStoreId } from "@/lib/store";
import { logActivity } from "@/lib/services/activity";
import { setSetting } from "@/lib/services/settings";
import { saveLoyaltyProgram } from "@/lib/services/loyalty-program";
import { SETTING_KEYS } from "@/lib/constants";
import type { LoyaltyProgram } from "@/lib/loyalty";
import type { ActionResult } from "@/app/admin/(dashboard)/customers/actions";

function revalidate() {
  revalidatePath("/admin/loyalty", "layout");
  revalidatePath("/portal", "layout");
  revalidatePath("/new");
}

/** Save the store's loyalty program (levels, rewards, points per purchase). */
export async function saveLoyaltyProgramAction(input: LoyaltyProgram): Promise<ActionResult<LoyaltyProgram>> {
  try {
    const admin = await requireWriteAdmin();
    const storeId = await getAdminStoreId();
    const program = await saveLoyaltyProgram(storeId, input);
    await logActivity({
      storeId,
      action: "SETTINGS_CHANGED",
      description: `${admin.name} updated the loyalty program (${program.tiers.length} levels, ${program.brackets.length} point brackets)`,
      adminId: admin.id,
    });
    revalidate();
    return { ok: true, data: program };
  } catch (e) {
    if (e instanceof z.ZodError) return { ok: false, error: e.issues[0]?.message ?? "Invalid program" };
    return { ok: false, error: e instanceof Error ? e.message : "Could not save the loyalty program." };
  }
}

/** Go back to the built-in default program. */
export async function resetLoyaltyProgramAction(): Promise<ActionResult> {
  try {
    const admin = await requireWriteAdmin();
    const storeId = await getAdminStoreId();
    await setSetting(storeId, SETTING_KEYS.loyaltyProgram, "");
    await logActivity({ storeId, action: "SETTINGS_CHANGED", description: `${admin.name} reset the loyalty program to the default`, adminId: admin.id });
    revalidate();
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : "Could not reset the loyalty program." };
  }
}
