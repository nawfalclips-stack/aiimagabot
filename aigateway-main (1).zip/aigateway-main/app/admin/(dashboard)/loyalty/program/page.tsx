import type { Metadata } from "next";
import Link from "next/link";
import { ArrowLeft } from "lucide-react";
import { prisma } from "@/lib/prisma";
import { getAdminStoreId } from "@/lib/store";
import { getSettings } from "@/lib/services/settings";
import { getLoyaltyProgram } from "@/lib/services/loyalty-program";
import { SETTING_KEYS } from "@/lib/constants";
import { PageHeader } from "@/components/shared/page-header";
import { LoyaltyProgramEditor } from "@/components/admin/loyalty-program-editor";

export const metadata: Metadata = { title: "Loyalty program settings" };
export const dynamic = "force-dynamic";

export default async function LoyaltyProgramPage() {
  const storeId = await getAdminStoreId();
  const [program, settings, points] = await Promise.all([
    getLoyaltyProgram(storeId),
    getSettings(storeId),
    prisma.customer.findMany({ where: { storeId, deletedAt: null }, select: { loyaltyPoints: true } }),
  ]);
  const isCustom = Boolean(settings[SETTING_KEYS.loyaltyProgram]);

  return (
    <div className="space-y-6">
      <Link href="/admin/loyalty" className="inline-flex items-center gap-1.5 text-sm text-muted-foreground hover:text-foreground">
        <ArrowLeft className="size-4" /> Loyalty
      </Link>
      <PageHeader
        title="Loyalty program settings"
        description={`Levels, cash rewards and how many points each purchase earns — for this store only. ${isCustom ? "This store uses its own program." : "This store currently uses the default program."} Customers keep their points; changing a level's threshold only changes which level they are at.`}
      />
      <LoyaltyProgramEditor program={program} isCustom={isCustom} customerPoints={points.map((c) => c.loyaltyPoints)} />
    </div>
  );
}
