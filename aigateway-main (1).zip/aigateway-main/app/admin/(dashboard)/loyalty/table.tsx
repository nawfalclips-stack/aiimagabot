"use client";

import { useTransition, useState } from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { CheckCircle2, Gift, Loader2, XCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { approveRewardAction, rejectRewardAction } from "./actions";
import { formatCents } from "@/lib/money";

interface LoyaltyRow {
  id: string;
  accessCode: string;
  status: string;
  loyaltyPoints: number;
  purchaseCount: number;
  rewardRequestStatus: string;
  tierName: string;
  tierColor: string;
  /** Cash reward of the customer's current level (store program). */
  rewardAmountCents: number;
}

const STATUS_STYLES: Record<string, string> = {
  PENDING: "border-warning/40 bg-warning/10 text-warning",
  APPROVED: "border-success/40 bg-success/10 text-success",
  REJECTED: "border-destructive/40 bg-destructive/10 text-destructive",
};

function RewardActions({ customerId, rewardAmount }: { customerId: string; rewardAmount: number }) {
  const [pending, startTransition] = useTransition();
  const [reason, setReason] = useState("");
  const router = useRouter();

  return (
    <div className="flex items-center gap-2">
      <Button
        size="sm"
        className="h-8 gap-1.5 bg-success text-white hover:bg-success/90"
        disabled={pending}
        onClick={() =>
          startTransition(async () => {
            const result = await approveRewardAction(customerId);
            if (result.ok) {
              toast.success(`Reward of ${formatCents(rewardAmount)} credited to bonus balance.`);
              router.refresh();
            } else {
              toast.error(result.error);
            }
          })
        }
      >
        {pending ? <Loader2 className="size-3.5 animate-spin" /> : <CheckCircle2 className="size-3.5" />}
        Approve
      </Button>
      <Dialog>
        <DialogTrigger asChild>
          <Button size="sm" variant="outline" className="h-8 gap-1.5 text-destructive" disabled={pending}>
            <XCircle className="size-3.5" /> Reject
          </Button>
        </DialogTrigger>
        <DialogContent>
          <form
            onSubmit={(e) => {
              e.preventDefault();
              startTransition(async () => {
                const result = await rejectRewardAction(customerId, reason || "No reason given");
                if (result.ok) {
                  toast.success("Reward request rejected.");
                  router.refresh();
                } else {
                  toast.error(result.error);
                }
              });
            }}
          >
            <DialogHeader>
              <DialogTitle>Reject reward request?</DialogTitle>
              <DialogDescription>
                The customer keeps their points but cannot claim the cash reward right now. They may
                request again later.
              </DialogDescription>
            </DialogHeader>
            <Input
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              placeholder="Reason (optional)"
              className="mt-4"
            />
            <DialogFooter className="mt-4">
              <Button type="submit" variant="destructive" size="sm">
                Confirm rejection
              </Button>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}

export function LoyaltyTable({ customers }: { customers: LoyaltyRow[] }) {
  if (customers.length === 0) {
    return (
      <div className="rounded-xl border bg-card p-10 text-center text-sm text-muted-foreground">
        No customers yet — loyalty data appears here after their first purchase.
      </div>
    );
  }

  return (
    <section className="overflow-hidden rounded-xl border bg-card">
      <table className="w-full text-sm">
        <thead>
          <tr className="border-b bg-muted/50 text-left text-xs uppercase tracking-wide text-muted-foreground">
            <th className="px-4 py-3 font-medium">Customer</th>
            <th className="px-4 py-3 font-medium">Level</th>
            <th className="px-4 py-3 font-medium">Points</th>
            <th className="px-4 py-3 font-medium">Purchases</th>
            <th className="px-4 py-3 font-medium">Reward status</th>
            <th className="px-4 py-3 font-medium text-right">Actions</th>
          </tr>
        </thead>
        <tbody>
          {customers.map((c) => {
            return (
              <tr key={c.id} className="border-b last:border-b-0 hover:bg-muted/30">
                <td className="px-4 py-3">
                  <span className="font-mono font-medium">{c.accessCode}</span>
                </td>
                <td className="px-4 py-3">
                  <span
                    className="inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs font-semibold"
                    style={{ borderColor: c.tierColor, color: c.tierColor, backgroundColor: `${c.tierColor}14` }}
                  >
                    {c.tierName}
                  </span>
                </td>
                <td className="px-4 py-3 font-mono">{c.loyaltyPoints}</td>
                <td className="px-4 py-3">{c.purchaseCount}</td>
                <td className="px-4 py-3">
                  <span
                    className={`inline-flex items-center rounded-full border px-2.5 py-0.5 text-xs ${
                      STATUS_STYLES[c.rewardRequestStatus] ?? "border-border text-muted-foreground"
                    }`}
                  >
                    {c.rewardRequestStatus}
                  </span>
                </td>
                <td className="px-4 py-3 text-right">
                  {c.rewardRequestStatus === "PENDING" ? (
                    <RewardActions customerId={c.id} rewardAmount={c.rewardAmountCents} />
                  ) : c.loyaltyPoints >= 600 && c.rewardRequestStatus !== "APPROVED" ? (
                    <span className="text-xs text-muted-foreground inline-flex items-center gap-1">
                      <Gift className="size-3.5" /> Can request
                    </span>
                  ) : (
                    <span className="text-xs text-muted-foreground">—</span>
                  )}
                </td>
              </tr>
            );
          })}
        </tbody>
      </table>
    </section>
  );
}
