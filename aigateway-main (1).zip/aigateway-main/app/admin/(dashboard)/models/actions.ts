"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireWriteAdmin } from "@/lib/auth";
import { logActivity } from "@/lib/services/activity";
import { getAdminStoreId, STORE_IDS } from "@/lib/store";
import { invalidateModelRegistry } from "@/lib/gateway/registry";
import { syncModelPrices, type PriceSyncReport } from "@/lib/services/model-prices";
import type { ActionResult } from "@/app/admin/(dashboard)/customers/actions";

const modelSchema = z.object({
  slug: z
    .string()
    .trim()
    .toLowerCase()
    .min(2, "Slug is too short")
    .max(48)
    .regex(/^[a-z0-9.-]+$/, "Slug may only contain lowercase letters, numbers, dots and dashes"),
  displayName: z.string().trim().min(2, "Enter a display name").max(80),
  /** Public alias shown to customers instead of slug / displayName; "" = none. */
  aliasSlug: z
    .string()
    .trim()
    .toLowerCase()
    .max(48)
    .regex(/^([a-z0-9.-]{2,})?$/, "The alias id may only contain lowercase letters, numbers, dots and dashes (2+ characters)")
    .default(""),
  aliasName: z.string().trim().max(80).default(""),
  enabled: z.coerce.boolean().default(true),
  /** USD per 1M tokens, as typed by the admin (e.g. 0.40). */
  inputPriceUsd: z.coerce.number().min(0).max(10_000).default(0),
  outputPriceUsd: z.coerce.number().min(0).max(10_000).default(0),
  contextWindow: z.coerce.number().int().min(0).max(100_000_000).optional().nullable(),
  maxOutputTokens: z.coerce.number().int().min(0).max(10_000_000).optional().nullable(),
  enabledStoreIds: z.array(z.enum([STORE_IDS.AEROLINK, STORE_IDS.CHEFAPI])).default([]),
});

export type ModelInput = z.input<typeof modelSchema>;

const mappingSchema = z.object({
  providerId: z.string().min(1),
  upstreamModelId: z.string().trim().min(1, "Enter the provider's model id").max(200),
  priority: z.coerce.number().int().min(1).max(1000).default(100),
  enabled: z.coerce.boolean().default(true),
});

export type MappingInput = z.input<typeof mappingSchema>;

function firstIssue(e: z.ZodError): string {
  return e.issues[0]?.message ?? "Invalid input";
}

async function revalidate() {
  await invalidateModelRegistry();
  revalidatePath("/admin/models");
  revalidatePath("/admin/providers");
  revalidatePath("/portal/api-access");
}

const usdToMicroPerMTok = (usd: number) => Math.round(usd * 1_000_000);

export async function saveModelAction(id: string | null, input: ModelInput): Promise<ActionResult<{ id: string }>> {
  try {
    const admin = await requireWriteAdmin();
    const parsed = modelSchema.safeParse(input);
    if (!parsed.success) return { ok: false, error: firstIssue(parsed.error) };
    const d = parsed.data;

    const clash = await prisma.gatewayModel.findUnique({ where: { slug: d.slug }, select: { id: true } });
    if (clash && clash.id !== id) return { ok: false, error: "A model with this slug already exists." };
    // Slugs and aliases share one namespace: customers may type either, so no two models can answer to the same id.
    const taken = await prisma.gatewayModel.findFirst({
      where: {
        id: id ? { not: id } : undefined,
        OR: [{ aliasSlug: d.slug }, ...(d.aliasSlug ? [{ slug: d.aliasSlug }, { aliasSlug: d.aliasSlug }] : [])],
      },
      select: { slug: true },
    });
    if (taken) return { ok: false, error: `That id is already used by model "${taken.slug}" (as its slug or alias).` };

    const data = {
      slug: d.slug,
      displayName: d.displayName,
      aliasSlug: d.aliasSlug || null,
      aliasName: d.aliasName,
      enabled: d.enabled,
      inputPriceMicroPerMTok: usdToMicroPerMTok(d.inputPriceUsd),
      outputPriceMicroPerMTok: usdToMicroPerMTok(d.outputPriceUsd),
      contextWindow: d.contextWindow || null,
      maxOutputTokens: d.maxOutputTokens || null,
      enabledStoreIds: d.enabledStoreIds.join(","),
    };
    const row = id
      ? await prisma.gatewayModel.update({ where: { id }, data })
      : await prisma.gatewayModel.create({ data });

    await logActivity({
      storeId: await getAdminStoreId(),
      action: "SETTINGS_CHANGED",
      description: `${admin.name} ${id ? "updated" : "added"} gateway model "${row.slug}"`,
      adminId: admin.id,
    });
    await revalidate();
    return { ok: true, data: { id: row.id } };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : "Could not save the model." };
  }
}

export async function setModelEnabledAction(id: string, enabled: boolean): Promise<ActionResult> {
  try {
    await requireWriteAdmin();
    await prisma.gatewayModel.update({ where: { id }, data: { enabled } });
    await revalidate();
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : "Could not update the model." };
  }
}

export async function deleteModelAction(id: string): Promise<ActionResult> {
  try {
    const admin = await requireWriteAdmin();
    const row = await prisma.gatewayModel.delete({ where: { id } });
    await logActivity({
      storeId: await getAdminStoreId(),
      action: "SETTINGS_CHANGED",
      description: `${admin.name} removed gateway model "${row.slug}"`,
      adminId: admin.id,
    });
    await revalidate();
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : "Could not delete the model." };
  }
}

export async function saveMappingAction(modelId: string, input: MappingInput): Promise<ActionResult> {
  try {
    await requireWriteAdmin();
    const parsed = mappingSchema.safeParse(input);
    if (!parsed.success) return { ok: false, error: firstIssue(parsed.error) };
    const d = parsed.data;
    await prisma.providerModel.upsert({
      where: { providerId_modelId: { providerId: d.providerId, modelId } },
      update: { upstreamModelId: d.upstreamModelId, priority: d.priority, enabled: d.enabled },
      create: { providerId: d.providerId, modelId, upstreamModelId: d.upstreamModelId, priority: d.priority, enabled: d.enabled },
    });
    await revalidate();
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : "Could not save the provider mapping." };
  }
}

export async function deleteMappingAction(mappingId: string): Promise<ActionResult> {
  try {
    await requireWriteAdmin();
    await prisma.providerModel.delete({ where: { id: mappingId } });
    await revalidate();
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : "Could not remove the mapping." };
  }
}

/**
 * Compare catalog-backed models (OpenRouter, DeepInfra) with the providers'
 * live list prices; `apply` writes the new prices. See lib/services/model-prices.ts.
 */
export async function syncModelPricesAction(apply: boolean): Promise<ActionResult<PriceSyncReport>> {
  try {
    const admin = await requireWriteAdmin();
    const report = await syncModelPrices({ apply });
    if (apply && report.changed > 0) {
      await logActivity({
        storeId: await getAdminStoreId(),
        action: "SETTINGS_CHANGED",
        description: `${admin.name} synced provider prices: ${report.changed} model${report.changed === 1 ? "" : "s"} updated (${report.rows.filter((r) => r.changed).map((r) => r.slug).join(", ")})`,
        adminId: admin.id,
      });
      await revalidate();
    }
    return { ok: true, data: report };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : "Could not sync prices." };
  }
}
