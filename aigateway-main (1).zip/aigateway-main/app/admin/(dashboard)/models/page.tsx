import type { Metadata } from "next";
import { prisma } from "@/lib/prisma";
import { PageHeader } from "@/components/shared/page-header";
import { ModelsView, type ModelRow, type ProviderOption } from "@/components/admin/gateway/models-view";
import { getSettings } from "@/lib/services/settings";
import { SETTING_KEYS } from "@/lib/constants";
import { getAdminStoreId } from "@/lib/store";
import { describePlanRate } from "@/lib/plan-usage";
import { aliasWarnings } from "@/lib/model-alias";

export const metadata: Metadata = { title: "Models" };
export const dynamic = "force-dynamic";

export default async function ModelsPage() {
  const storeId = await getAdminStoreId();
  const [models, providers, settings, stores] = await Promise.all([
    prisma.gatewayModel.findMany({
      include: { providers: { include: { provider: { select: { id: true, name: true, slug: true, enabled: true, healthStatus: true } } }, orderBy: { priority: "asc" } } },
      orderBy: { slug: "asc" },
    }),
    prisma.provider.findMany({ orderBy: [{ priority: "asc" }, { name: "asc" }], select: { id: true, name: true, slug: true, enabled: true } }),
    getSettings(storeId),
    prisma.store.findMany({ select: { id: true, name: true }, orderBy: { id: "asc" } }),
  ]);

  const multiplier = parseFloat(settings[SETTING_KEYS.usageCostMultiplier]) || 2.2;
  const plans = await prisma.plan.findMany({ where: { storeId, isActive: true }, orderBy: { sortOrder: "asc" } });
  const tierNote =
    plans.length > 0
      ? ` Customers on a plan pay their plan's rate instead (${plans.map((p) => `${p.name}: ${describePlanRate(p).split(" — ")[0]}`).join(", ")}).`
      : "";

  const rows: ModelRow[] = models.map((m) => ({
    id: m.id,
    slug: m.slug,
    displayName: m.displayName,
    aliasSlug: m.aliasSlug ?? "",
    aliasName: m.aliasName,
    aliasWarnings: aliasWarnings(m, m.providers.map((pm) => pm.upstreamModelId)),
    enabled: m.enabled,
    inputPriceUsd: m.inputPriceMicroPerMTok / 1_000_000,
    outputPriceUsd: m.outputPriceMicroPerMTok / 1_000_000,
    contextWindow: m.contextWindow,
    maxOutputTokens: m.maxOutputTokens,
    enabledStoreIds: m.enabledStoreIds.split(",").map((s) => s.trim()).filter(Boolean),
    mappings: m.providers.map((pm) => ({
      id: pm.id,
      providerId: pm.provider.id,
      providerName: pm.provider.name,
      providerSlug: pm.provider.slug,
      providerEnabled: pm.provider.enabled,
      providerHealth: pm.provider.healthStatus,
      upstreamModelId: pm.upstreamModelId,
      priority: pm.priority,
      enabled: pm.enabled,
    })),
  }));

  const providerOptions: ProviderOption[] = providers;

  return (
    <div className="space-y-6">
      <PageHeader
        title="Models"
        description={`The catalog customers pick from. Prices are shown to customers exactly as saved here. Each request is billed at its real cost × the customer's plan rate (no plan: the default plan, else ×${multiplier}).${tierNote}`}
      />
      <ModelsView models={rows} providers={providerOptions} stores={stores} />
    </div>
  );
}
