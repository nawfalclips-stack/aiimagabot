import type { Metadata } from "next";
import { prisma } from "@/lib/prisma";
import { PageHeader } from "@/components/shared/page-header";
import { OrdersTable, type OrderRow } from "@/components/admin/orders-table";
import { getAdminStoreId } from "@/lib/store";

export const metadata: Metadata = { title: "Orders" };
export const dynamic = "force-dynamic";

export default async function OrdersPage() {
  const storeId = await getAdminStoreId();
  const orders = await prisma.order.findMany({
    where: { customer: { storeId, deletedAt: null } },
    include: { customer: true },
    orderBy: { createdAt: "desc" },
  });

  const rows: OrderRow[] = orders.map((o) => ({
    id: o.id,
    orderNumber: o.orderNumber,
    customerId: o.customerId,
    accessCode: o.customer.accessCode,
    status: o.customer.status,
    initialBalanceCents: o.customer.initialBalanceCents,
    profitCents: o.customer.profitCents,
    createdAt: o.createdAt.toISOString(),
  }));

  return (
    <div className="space-y-6">
      <PageHeader
        title="Orders"
        description={`${rows.length} ${rows.length === 1 ? "order" : "orders"} — one per customer purchase.`}
      />
      <OrdersTable orders={rows} />
    </div>
  );
}
