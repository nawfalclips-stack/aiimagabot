"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireWriteAdmin } from "@/lib/auth";
import { logActivity } from "@/lib/services/activity";
import { getAdminStoreId } from "@/lib/store";
import { usdToCents } from "@/lib/money";
import { centsToMicro } from "@/lib/billing/money";
import type { ActionResult } from "@/app/admin/(dashboard)/customers/actions";

const packSchema = z.object({
  name: z.string().trim().min(1, "Give the pack a name").max(60),
  planId: z.string().min(1, "Choose the plan this pack puts the customer on"),
  balanceGrantUsd: z.coerce.number().min(0).max(1_000_000),
  bonusGrantUsd: z.coerce.number().min(0).max(1_000_000).default(0),
  listingPriceLabel: z.string().trim().max(80).default(""),
  gamsgoOfferRef: z.string().trim().max(200).default(""),
  active: z.coerce.boolean().default(true),
  sortOrder: z.coerce.number().int().min(0).max(10_000).default(0),
});

export type PackInput = z.input<typeof packSchema>;

function revalidate() {
  revalidatePath("/admin/packs");
  revalidatePath("/admin/vouchers");
  revalidatePath("/admin/activations");
  revalidatePath("/admin/recharges");
}

export async function savePackAction(id: string | null, input: PackInput): Promise<ActionResult<{ id: string }>> {
  try {
    const admin = await requireWriteAdmin();
    const storeId = await getAdminStoreId();
    const parsed = packSchema.safeParse(input);
    if (!parsed.success) return { ok: false, error: parsed.error.issues[0]?.message ?? "Invalid input" };
    const d = parsed.data;
    if (d.balanceGrantUsd <= 0 && d.bonusGrantUsd <= 0) return { ok: false, error: "A pack must grant some balance or bonus." };
    const plan = await prisma.plan.findFirst({ where: { id: d.planId, storeId }, select: { id: true, name: true } });
    if (!plan) return { ok: false, error: "Plan not found in this store." };

    const data = {
      name: d.name,
      planId: plan.id,
      balanceGrantMicroUsd: centsToMicro(usdToCents(d.balanceGrantUsd)),
      bonusGrantMicroUsd: centsToMicro(usdToCents(d.bonusGrantUsd)),
      listingPriceLabel: d.listingPriceLabel,
      gamsgoOfferRef: d.gamsgoOfferRef || null,
      active: d.active,
      sortOrder: d.sortOrder,
    };
    let row;
    if (id) {
      const existing = await prisma.pack.findFirst({ where: { id, storeId, deletedAt: null }, select: { id: true } });
      if (!existing) return { ok: false, error: "Pack not found." };
      row = await prisma.pack.update({ where: { id }, data });
    } else {
      row = await prisma.pack.create({ data: { ...data, storeId } });
    }
    await logActivity({
      storeId,
      action: "PACK_SAVED",
      description: `${admin.name} ${id ? "updated" : "created"} pack "${row.name}" → plan "${plan.name}" ($${d.balanceGrantUsd}${d.bonusGrantUsd ? ` + $${d.bonusGrantUsd} bonus` : ""})`,
      adminId: admin.id,
    });
    revalidate();
    return { ok: true, data: { id: row.id } };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : "Could not save the pack." };
  }
}

export async function setPackActiveAction(id: string, active: boolean): Promise<ActionResult> {
  try {
    const admin = await requireWriteAdmin();
    const storeId = await getAdminStoreId();
    const row = await prisma.pack.update({ where: { id, storeId, deletedAt: null }, data: { active } });
    await logActivity({ storeId, action: "PACK_SAVED", description: `${admin.name} ${active ? "activated" : "deactivated"} pack "${row.name}"`, adminId: admin.id });
    revalidate();
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : "Could not update the pack." };
  }
}

/** Soft delete. Vouchers and customers keep their reference; the pack just disappears from pickers. */
export async function deletePackAction(id: string): Promise<ActionResult> {
  try {
    const admin = await requireWriteAdmin();
    const storeId = await getAdminStoreId();
    const unredeemed = await prisma.voucher.count({ where: { packId: id, status: "ISSUED" } });
    if (unredeemed > 0) return { ok: false, error: `${unredeemed} unredeemed voucher(s) still reference this pack. Revoke them (Vouchers page) or deactivate the pack instead.` };
    const row = await prisma.pack.update({ where: { id, storeId, deletedAt: null }, data: { deletedAt: new Date(), active: false } });
    await logActivity({ storeId, action: "PACK_SAVED", description: `${admin.name} deleted pack "${row.name}"`, adminId: admin.id });
    revalidate();
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : "Could not delete the pack." };
  }
}
