import type { Metadata } from "next";
import { prisma } from "@/lib/prisma";
import { PageHeader } from "@/components/shared/page-header";
import { PacksView, type PackRow, type PlanChoice } from "@/components/admin/packs/packs-view";
import { getAdminStoreId } from "@/lib/store";

export const metadata: Metadata = { title: "Packs" };
export const dynamic = "force-dynamic";

export default async function PacksPage() {
  const storeId = await getAdminStoreId();
  const [packs, plans] = await Promise.all([
    prisma.pack.findMany({
      where: { storeId, deletedAt: null },
      include: { plan: { select: { name: true } }, _count: { select: { customers: true, vouchers: { where: { status: "ISSUED" } } } } },
      orderBy: [{ sortOrder: "asc" }, { createdAt: "asc" }],
    }),
    prisma.plan.findMany({ where: { storeId }, orderBy: [{ sortOrder: "asc" }, { priceCents: "asc" }], select: { id: true, name: true, priceCents: true, isActive: true } }),
  ]);

  const rows: PackRow[] = packs.map((p) => ({
    id: p.id,
    name: p.name,
    planId: p.planId,
    planName: p.plan.name,
    balanceGrantCents: Number(p.balanceGrantMicroUsd / 10_000n),
    bonusGrantCents: Number(p.bonusGrantMicroUsd / 10_000n),
    listingPriceLabel: p.listingPriceLabel,
    gamsgoOfferRef: p.gamsgoOfferRef ?? "",
    active: p.active,
    sortOrder: p.sortOrder,
    customers: p._count.customers,
    vouchersIssued: p._count.vouchers,
  }));
  const planChoices: PlanChoice[] = plans;

  return (
    <div className="space-y-6">
      <PageHeader
        title="Packs"
        description="What you sell on GamsGo. Each pack grants credit and binds the buyer to one plan — approvals and voucher batches pick a pack, never guess from a price."
      />
      <PacksView packs={rows} plans={planChoices} />
    </div>
  );
}
