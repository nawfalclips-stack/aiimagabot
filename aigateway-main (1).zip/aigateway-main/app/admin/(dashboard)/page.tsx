import type { Metadata } from "next";
import Link from "next/link";
import {
  ArrowRight,
  TrendingUp,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardAction, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { PageHeader } from "@/components/shared/page-header";
import { StatCard } from "@/components/shared/stat-card";
import { EmptyState } from "@/components/shared/empty-state";
import { ActivityFeed } from "@/components/admin/activity-feed";
import { RevenueProfitChart } from "@/components/admin/charts";
import { getDashboardStats, getDailySeries, getRecentActivity, getTopSellingDays } from "@/lib/services/analytics";
import { centsToUsd, formatCents } from "@/lib/money";
import { getAdminStoreId } from "@/lib/store";

export const metadata: Metadata = { title: "Dashboard" };
export const dynamic = "force-dynamic";

export default async function AdminDashboardPage() {
  const storeId = await getAdminStoreId();

  const [stats, series, activity, topDays] = await Promise.all([
    getDashboardStats(storeId),
    getDailySeries(storeId, 30),
    getRecentActivity(storeId, 10),
    getTopSellingDays(storeId, 90, 5),
  ]);

  return (
    <div className="space-y-8">
      <PageHeader
        eyebrow="Overview"
        title="Dashboard"
        description="Business overview across customers, orders and profit."
        actions={
          <Button asChild>
            <Link href="/admin/customers/new">
              New customer <ArrowRight />
            </Link>
          </Button>
        }
      />

      {/* Customer / order stats */}
      <section aria-labelledby="stats-customers" className="space-y-3">
        <h2 id="stats-customers" className="eyebrow font-sans">Customers</h2>
        <div className="grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-4">
          <StatCard title="Total Customers" value={stats.totalCustomers} icon="users" tone="primary" index={0} />
          <StatCard title="Active Customers" value={stats.activeCustomers} icon="userCheck" tone="success" index={1} />
          <StatCard title="Expired Customers" value={stats.expiredCustomers} icon="hourglass" tone="destructive" index={2} />
          <StatCard
            title="No plan"
            value={stats.noPlanCustomers}
            icon="userCheck"
            tone={stats.noPlanCustomers > 0 ? "destructive" : "default"}
            hint={stats.noPlanCustomers > 0 ? "Billed at the global multiplier — assign a plan from Customers" : `${stats.totalOrders} orders`}
            index={3}
          />
        </div>
      </section>

      {/* Revenue / profit stats */}
      <section aria-labelledby="stats-profit" className="space-y-3">
        <h2 id="stats-profit" className="eyebrow font-sans">Profit</h2>
        <div className="grid grid-cols-2 gap-3 sm:gap-4 lg:grid-cols-4">
          <StatCard
            title="All-Time Profit"
            value={centsToUsd(stats.totalProfitCents)}
            format="money"
            icon="wallet"
            tone="primary"
            index={4}
          />
          <StatCard
            title="Today's Profit"
            value={centsToUsd(stats.todayProfitCents)}
            format="money"
            icon="trendingUp"
            tone="success"
            hint={`Yesterday ${formatCents(stats.yesterdayProfitCents)}`}
            index={5}
          />
          <StatCard
            title="Weekly Profit"
            value={centsToUsd(stats.thisWeekProfitCents)}
            format="money"
            icon="dollar"
            tone="success"
            hint={`Last week ${formatCents(stats.lastWeekProfitCents)}`}
            index={6}
          />
          <StatCard
            title="Monthly Profit"
            value={centsToUsd(stats.thisMonthProfitCents)}
            format="money"
            icon="calendar"
            tone="success"
            hint={`Last month ${formatCents(stats.lastMonthProfitCents)}`}
            index={7}
          />
        </div>
      </section>

      <div className="grid gap-6 xl:grid-cols-3">
        {/* Revenue chart */}
        <Card className="xl:col-span-2">
          <CardHeader>
            <CardTitle>Sales &amp; Profit</CardTitle>
            <CardDescription>Last 30 days</CardDescription>
            <CardAction className="flex items-center gap-4 text-xs text-muted-foreground">
              <span className="flex items-center gap-1.5">
                <span className="size-2 rounded-full bg-chart-1" /> Sales
              </span>
              <span className="flex items-center gap-1.5">
                <span className="size-2 rounded-full bg-chart-2" /> Profit
              </span>
            </CardAction>
          </CardHeader>
          <CardContent>
            <RevenueProfitChart data={series} />
          </CardContent>
        </Card>

        {/* Recent activity */}
        <Card>
          <CardHeader>
            <CardTitle>Recent Activity</CardTitle>
            <CardDescription>Latest actions across the platform</CardDescription>
          </CardHeader>
          <CardContent>
            {activity.length === 0 ? (
              <p className="py-8 text-center text-sm text-muted-foreground">No activity yet.</p>
            ) : (
              <ActivityFeed items={activity} />
            )}
            <Button asChild variant="ghost" size="sm" className="mt-4 w-full text-muted-foreground">
              <Link href="/admin/activity">
                View all activity <ArrowRight />
              </Link>
            </Button>
          </CardContent>
        </Card>
      </div>

      {/* Top selling days */}
      <Card>
        <CardHeader>
          <CardTitle>Top Selling Days</CardTitle>
          <CardDescription>Highest revenue days in the last 90 days</CardDescription>
        </CardHeader>
        <CardContent>
          {topDays.length === 0 ? (
            <EmptyState
              icon={TrendingUp}
              title="No sales yet"
              description="Create your first customer to start tracking revenue."
              className="py-10"
            />
          ) : (
            <ol className="space-y-2.5">
              {topDays.map((day, i) => {
                const pct = Math.max(4, Math.round((day.revenueCents / Math.max(1, topDays[0].revenueCents)) * 100));
                return (
                  <li
                    key={day.date}
                    className="grid grid-cols-[1.75rem_minmax(0,7rem)_1fr_auto] items-center gap-3 sm:grid-cols-[1.75rem_9rem_1fr_6rem_6rem]"
                  >
                    <span
                      className={
                        i === 0
                          ? "flex size-7 items-center justify-center rounded-lg bg-primary text-xs font-semibold text-primary-foreground"
                          : "flex size-7 items-center justify-center rounded-lg bg-muted text-xs font-semibold text-muted-foreground"
                      }
                    >
                      {i + 1}
                    </span>
                    <span className="truncate text-sm font-medium">{day.label}</span>
                    <span className="h-2 overflow-hidden rounded-full bg-muted">
                      <span
                        className={i === 0 ? "block h-full rounded-full bg-primary" : "block h-full rounded-full bg-primary/45"}
                        style={{ width: `${pct}%` }}
                      />
                    </span>
                    <span className="text-right text-sm font-semibold tabular-nums">{formatCents(day.revenueCents)}</span>
                    <span className="hidden text-right text-xs text-muted-foreground sm:block">
                      {day.customers} {day.customers === 1 ? "customer" : "customers"}
                    </span>
                  </li>
                );
              })}
            </ol>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
