"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireWriteAdmin } from "@/lib/auth";
import { logActivity } from "@/lib/services/activity";
import { getAdminStoreId } from "@/lib/store";
import { usdToCents } from "@/lib/money";
import { describeBonusValue, PLAN_LIMIT_TYPES } from "@/lib/plan-usage";
import { assignPlan, invalidateDefaultPlanCache } from "@/lib/services/plan-usage";
import { setSetting } from "@/lib/services/settings";
import { SETTING_KEYS } from "@/lib/constants";
import type { ActionResult } from "@/app/admin/(dashboard)/customers/actions";

const planSchema = z
  .object({
    name: z.string().trim().min(1, "Give the plan a name").max(60),
    description: z.string().trim().max(200).default(""),
    priceUsd: z.coerce.number().positive("Price must be above $0").max(1_000_000),
    /** Profit (not sales) recorded for every purchase of this plan, USD. */
    profitUsd: z.coerce.number().min(0, "Profit cannot be negative").max(1_000_000).default(0),
    limitType: z.enum(PLAN_LIMIT_TYPES),
    /** USD plans: real provider usage in USD. */
    limitUsageUsd: z.coerce.number().min(0).max(1_000_000).default(0),
    /** TOKENS plans: millions of tokens. */
    limitMTokens: z.coerce.number().min(0).max(1_000_000).default(0),
    /** Bonus credited to the BONUS pot on every purchase, USD (0 = none). */
    bonusUsd: z.coerce.number().min(0, "Bonus cannot be negative").max(1_000_000).default(0),
    /** USD plans: real provider usage the bonus is worth, USD (0 = same rate as the balance). */
    bonusLimitUsageUsd: z.coerce.number().min(0, "Bonus real usage cannot be negative").max(1_000_000).default(0),
    /** TOKENS plans: millions of tokens the bonus is worth (0 = same rate as the balance). */
    bonusLimitMTokens: z.coerce.number().min(0, "Bonus tokens cannot be negative").max(1_000_000).default(0),
    isActive: z.coerce.boolean().default(true),
    sortOrder: z.coerce.number().int().min(0).max(10_000).default(0),
    /** Gateway limits (WS3); 0 / empty = use the store default. */
    rpm: z.coerce.number().int().min(0).max(100_000).default(0),
    maxConcurrent: z.coerce.number().int().min(0).max(10_000).default(0),
  })
  .superRefine((p, ctx) => {
    if (p.limitType === "USD" && p.limitUsageUsd <= 0) ctx.addIssue({ code: "custom", path: ["limitUsageUsd"], message: "Enter how many dollars of real API usage the plan buys" });
    if (p.limitType === "USD" && p.limitUsageUsd > p.priceUsd) ctx.addIssue({ code: "custom", path: ["limitUsageUsd"], message: "A plan cannot be worth more API usage than its price" });
    if (p.profitUsd > p.priceUsd) ctx.addIssue({ code: "custom", path: ["profitUsd"], message: "Profit cannot be more than the plan price" });
    if (p.limitType === "TOKENS" && p.limitMTokens <= 0) ctx.addIssue({ code: "custom", path: ["limitMTokens"], message: "Enter how many million tokens the plan includes" });
    const bonusValue = p.limitType === "USD" ? p.bonusLimitUsageUsd : p.bonusLimitMTokens;
    if (bonusValue > 0 && p.bonusUsd <= 0) ctx.addIssue({ code: "custom", path: ["bonusUsd"], message: "Enter the bonus amount before its real usage" });
    if (p.limitType === "USD" && p.bonusLimitUsageUsd > p.bonusUsd) ctx.addIssue({ code: "custom", path: ["bonusLimitUsageUsd"], message: "A bonus cannot be worth more API usage than its amount" });
  });

export type PlanInput = z.input<typeof planSchema>;

function firstIssue(e: z.ZodError): string {
  return e.issues[0]?.message ?? "Invalid input";
}

function revalidate() {
  // Plan edits change what customers without a plan are billed at.
  invalidateDefaultPlanCache();
  revalidatePath("/admin/plans");
  revalidatePath("/admin/models");
  revalidatePath("/admin/customers", "layout");
  revalidatePath("/portal/api-access");
}

export async function savePlanAction(id: string | null, input: PlanInput): Promise<ActionResult<{ id: string }>> {
  try {
    const admin = await requireWriteAdmin();
    const storeId = await getAdminStoreId();
    const parsed = planSchema.safeParse(input);
    if (!parsed.success) return { ok: false, error: firstIssue(parsed.error) };
    const d = parsed.data;
    const data = {
      name: d.name,
      description: d.description,
      priceCents: usdToCents(d.priceUsd),
      profitCents: usdToCents(d.profitUsd),
      limitType: d.limitType,
      limitUsageCents: d.limitType === "USD" ? usdToCents(d.limitUsageUsd) : 0,
      limitMTokens: d.limitType === "TOKENS" ? Math.round(d.limitMTokens) : 0,
      bonusCents: usdToCents(d.bonusUsd),
      bonusLimitUsageCents: d.limitType === "USD" && d.bonusUsd > 0 ? usdToCents(d.bonusLimitUsageUsd) : 0,
      bonusLimitMTokens: d.limitType === "TOKENS" && d.bonusUsd > 0 ? Math.round(d.bonusLimitMTokens) : 0,
      isActive: d.isActive,
      sortOrder: d.sortOrder,
      rpm: d.rpm > 0 ? d.rpm : null,
      maxConcurrent: d.maxConcurrent > 0 ? d.maxConcurrent : null,
    };

    let row;
    if (id) {
      const existing = await prisma.plan.findFirst({ where: { id, storeId }, select: { id: true } });
      if (!existing) return { ok: false, error: "Plan not found." };
      row = await prisma.plan.update({ where: { id }, data });
    } else {
      row = await prisma.plan.create({ data: { ...data, storeId } });
    }

    await logActivity({
      storeId,
      action: "SETTINGS_CHANGED",
      description: `${admin.name} ${id ? "updated" : "created"} plan "${row.name}" ($${(row.priceCents / 100).toFixed(0)}; ${describeBonusValue(row).toLowerCase()})`,
      adminId: admin.id,
    });
    revalidate();
    return { ok: true, data: { id: row.id } };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : "Could not save the plan." };
  }
}

export async function setPlanActiveAction(id: string, isActive: boolean): Promise<ActionResult> {
  try {
    const admin = await requireWriteAdmin();
    const storeId = await getAdminStoreId();
    const row = await prisma.plan.update({ where: { id, storeId }, data: { isActive } });
    await logActivity({
      storeId,
      action: "SETTINGS_CHANGED",
      description: `${admin.name} ${isActive ? "activated" : "deactivated"} plan "${row.name}"`,
      adminId: admin.id,
    });
    revalidate();
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : "Could not update the plan." };
  }
}

/** Deletes a plan; customers on it fall back to the global multiplier. */
export async function deletePlanAction(id: string): Promise<ActionResult> {
  try {
    const admin = await requireWriteAdmin();
    const storeId = await getAdminStoreId();
    const packs = await prisma.pack.count({ where: { planId: id, deletedAt: null } });
    if (packs > 0) return { ok: false, error: `${packs} pack(s) are bound to this plan. Point them at another plan (Packs page) first.` };
    const row = await prisma.plan.delete({ where: { id, storeId } });
    await logActivity({
      storeId,
      action: "SETTINGS_CHANGED",
      description: `${admin.name} deleted plan "${row.name}"`,
      adminId: admin.id,
    });
    revalidate();
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : "Could not delete the plan." };
  }
}

/** Put a customer on a plan ("" = no plan). */
export async function assignCustomerPlanAction(customerId: string, planId: string): Promise<ActionResult> {
  try {
    const admin = await requireWriteAdmin();
    const storeId = await getAdminStoreId();
    const customer = await prisma.customer.findFirst({ where: { id: customerId, storeId }, select: { accessCode: true } });
    if (!customer) return { ok: false, error: "Customer not found." };
    const clean = z.string().max(64).parse(planId);
    if (clean) {
      const plan = await prisma.plan.findFirst({ where: { id: clean, storeId }, select: { id: true } });
      if (!plan) return { ok: false, error: "Plan not found." };
    }
    const plan = await assignPlan(customerId, clean || null);
    await logActivity({
      storeId,
      action: "CUSTOMER_EDITED",
      description: plan
        ? `${admin.name} put ${customer.accessCode} on plan "${plan.name}"`
        : `${admin.name} removed ${customer.accessCode} from their plan`,
      adminId: admin.id,
      customerId,
    });
    revalidatePath(`/admin/customers/${customerId}`);
    revalidatePath("/admin/customers");
    revalidatePath("/portal/api-access");
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : "Could not change the plan." };
  }
}

/**
 * Choose the plan customers without one are billed at ("" = none: they pay
 * provider cost × the usage cost multiplier). Takes effect on the next request.
 */
export async function setDefaultPlanAction(planId: string): Promise<ActionResult> {
  try {
    const admin = await requireWriteAdmin();
    const storeId = await getAdminStoreId();
    const clean = z.string().max(64).parse(planId);
    let name = "";
    if (clean) {
      const plan = await prisma.plan.findFirst({ where: { id: clean, storeId }, select: { name: true, isActive: true } });
      if (!plan) return { ok: false, error: "Plan not found." };
      if (!plan.isActive) return { ok: false, error: "Activate the plan before making it the default." };
      name = plan.name;
    }
    await setSetting(storeId, SETTING_KEYS.defaultPlanId, clean);
    await logActivity({
      storeId,
      action: "SETTINGS_CHANGED",
      description: clean ? `${admin.name} made "${name}" the default plan for customers without one` : `${admin.name} removed the default plan (customers without a plan use the usage cost multiplier)`,
      adminId: admin.id,
    });
    revalidate();
    revalidatePath("/portal/api-access");
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : "Could not change the default plan." };
  }
}
