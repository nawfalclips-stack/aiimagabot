import type { Metadata } from "next";
import { prisma } from "@/lib/prisma";
import { PageHeader } from "@/components/shared/page-header";
import { PlansView, type PlanRow } from "@/components/admin/plans/plans-view";
import { getSettings } from "@/lib/services/settings";
import { SETTING_KEYS } from "@/lib/constants";
import { getAdminStoreId } from "@/lib/store";
import { profitByPlan } from "@/lib/services/profit";

export const metadata: Metadata = { title: "Plans" };
export const dynamic = "force-dynamic";

export default async function PlansPage() {
  const storeId = await getAdminStoreId();
  const [plans, settings, customersWithoutPlan, profits] = await Promise.all([
    prisma.plan.findMany({
      where: { storeId },
      orderBy: [{ sortOrder: "asc" }, { priceCents: "asc" }],
      include: { _count: { select: { customers: true } } },
    }),
    getSettings(storeId),
    prisma.customer.count({ where: { storeId, deletedAt: null, planId: null } }),
    profitByPlan(storeId),
  ]);
  const multiplier = parseFloat(settings[SETTING_KEYS.usageCostMultiplier]) || 2.2;

  const rows: PlanRow[] = plans.map((p) => ({
    id: p.id,
    name: p.name,
    description: p.description,
    priceCents: p.priceCents,
    profitCents: p.profitCents,
    profitRecordedCents: profits.get(p.id)?.profitCents ?? 0,
    purchases: profits.get(p.id)?.purchases ?? 0,
    limitType: p.limitType === "TOKENS" ? "TOKENS" : "USD",
    limitUsageCents: p.limitUsageCents,
    limitMTokens: p.limitMTokens,
    bonusCents: p.bonusCents,
    bonusLimitUsageCents: p.bonusLimitUsageCents,
    bonusLimitMTokens: p.bonusLimitMTokens,
    isActive: p.isActive,
    sortOrder: p.sortOrder,
    rpm: p.rpm,
    maxConcurrent: p.maxConcurrent,
    customers: p._count.customers,
  }));

  return (
    <div className="space-y-6">
      <PageHeader
        title="Plans"
        description="What each plan costs and how much real API usage it buys — in dollars or in tokens. Customers land on a plan through the pack they bought (Packs page) or from their profile."
      />
      <PlansView
        plans={rows}
        globalMultiplier={multiplier}
        defaultPlanId={settings[SETTING_KEYS.defaultPlanId] ?? ""}
        customersWithoutPlan={customersWithoutPlan}
      />
    </div>
  );
}
