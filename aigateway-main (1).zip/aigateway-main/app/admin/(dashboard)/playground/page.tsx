import type { Metadata } from "next";
import { requireWriteAdmin } from "@/lib/auth";
import { PageHeader } from "@/components/shared/page-header";
import { ApiPlayground } from "@/components/admin/api-playground";

export const metadata: Metadata = { title: "API Playground" };

// Read-only inspector accounts are blocked: every message is a real, billed request.
export default async function PlaygroundPage() {
  await requireWriteAdmin();

  return (
    <div className="space-y-6">
      <PageHeader
        eyebrow="Gateway"
        title="API Playground"
        description="Chat with any enabled model through the public gateway using a customer token — the same path Codex and Claude Code take."
      />
      <ApiPlayground />
    </div>
  );
}
