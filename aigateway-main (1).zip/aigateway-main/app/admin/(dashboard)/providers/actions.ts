"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { requireWriteAdmin } from "@/lib/auth";
import { logActivity } from "@/lib/services/activity";
import { getAdminStoreId } from "@/lib/store";
import { encryptSecret, decryptSecret } from "@/lib/gateway/crypto";
import { invalidateModelRegistry } from "@/lib/gateway/registry";
import { resetProviderBreakers } from "@/lib/gateway/breaker";
import { listModels, probe } from "@/lib/gateway/providers/openai-compatible";
import { inferUsageDialect, loadProviderCatalog } from "@/lib/gateway/providers/catalog";
import { catalogPriceFields } from "@/lib/services/model-prices";
import type { ActionResult } from "@/app/admin/(dashboard)/customers/actions";

const providerSchema = z.object({
  slug: z
    .string()
    .trim()
    .toLowerCase()
    .min(2, "Slug is too short")
    .max(32)
    .regex(/^[a-z0-9-]+$/, "Slug may only contain lowercase letters, numbers and dashes"),
  name: z.string().trim().min(2, "Enter a name").max(60),
  baseUrl: z
    .string()
    .trim()
    .url("Enter a valid URL")
    .transform((u) => u.replace(/\/+$/, "")),
  apiKey: z.string().trim().max(500).optional().default(""),
  priority: z.coerce.number().int().min(1).max(1000).default(100),
  enabled: z.coerce.boolean().default(true),
});

export type ProviderInput = z.input<typeof providerSchema>;

function firstIssue(e: z.ZodError): string {
  return e.issues[0]?.message ?? "Invalid input";
}

async function revalidate() {
  await invalidateModelRegistry();
  revalidatePath("/admin/providers");
  revalidatePath("/admin/models");
  revalidatePath("/portal/api-access");
}

export async function saveProviderAction(id: string | null, input: ProviderInput): Promise<ActionResult<{ id: string }>> {
  try {
    const admin = await requireWriteAdmin();
    const parsed = providerSchema.safeParse(input);
    if (!parsed.success) return { ok: false, error: firstIssue(parsed.error) };
    const data = parsed.data;

    const existingSlug = await prisma.provider.findUnique({ where: { slug: data.slug }, select: { id: true } });
    if (existingSlug && existingSlug.id !== id) return { ok: false, error: "A provider with this slug already exists." };

    const keyUpdate = data.apiKey ? { apiKeyEnc: await encryptSecret(data.apiKey) } : {};
    const base = { slug: data.slug, name: data.name, baseUrl: data.baseUrl, priority: data.priority, enabled: data.enabled };

    let row;
    if (id) {
      row = await prisma.provider.update({ where: { id }, data: { ...base, ...keyUpdate } });
    } else {
      if (!data.apiKey) return { ok: false, error: "Enter the provider API key." };
      row = await prisma.provider.create({ data: { ...base, usageDialect: inferUsageDialect(data.baseUrl, "openai"), apiKeyEnc: await encryptSecret(data.apiKey) } });
    }
    await resetProviderBreakers(row.id);

    await logActivity({
      storeId: await getAdminStoreId(),
      action: "SETTINGS_CHANGED",
      description: `${admin.name} ${id ? "updated" : "added"} gateway provider "${row.name}"`,
      adminId: admin.id,
    });
    await revalidate();
    return { ok: true, data: { id: row.id } };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : "Could not save the provider." };
  }
}

export async function setProviderEnabledAction(id: string, enabled: boolean): Promise<ActionResult> {
  try {
    const admin = await requireWriteAdmin();
    const row = await prisma.provider.update({ where: { id }, data: { enabled } });
    await resetProviderBreakers(id);
    await logActivity({
      storeId: await getAdminStoreId(),
      action: "SETTINGS_CHANGED",
      description: `${admin.name} ${enabled ? "enabled" : "disabled"} gateway provider "${row.name}"`,
      adminId: admin.id,
    });
    await revalidate();
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : "Could not update the provider." };
  }
}

export async function deleteProviderAction(id: string): Promise<ActionResult> {
  try {
    const admin = await requireWriteAdmin();
    const row = await prisma.provider.delete({ where: { id } });
    await resetProviderBreakers(id);
    await logActivity({
      storeId: await getAdminStoreId(),
      action: "SETTINGS_CHANGED",
      description: `${admin.name} removed gateway provider "${row.name}"`,
      adminId: admin.id,
    });
    await revalidate();
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : "Could not delete the provider." };
  }
}

/** Ping the provider's /models endpoint and store the health result. */
export async function testProviderAction(id: string): Promise<ActionResult<{ ok: boolean; message: string; ms: number }>> {
  try {
    await requireWriteAdmin();
    const row = await prisma.provider.findUniqueOrThrow({ where: { id } });
    const result = await probe({ baseUrl: row.baseUrl, apiKey: await decryptSecret(row.apiKeyEnc) });
    await prisma.provider.update({
      where: { id },
      data: { healthStatus: result.ok ? "UP" : "DOWN", lastCheckedAt: new Date(), lastError: result.ok ? "" : result.message.slice(0, 500) },
    });
    if (result.ok) await resetProviderBreakers(id);
    revalidatePath("/admin/providers");
    return { ok: true, data: result };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : "Could not reach the provider." };
  }
}

export interface UpstreamModelOption {
  id: string;
  /** Already mapped to a catalog model? */
  mappedTo: string | null;
  /** Provider prices in USD per 1M tokens when the provider publishes them (DeepInfra, OpenRouter). */
  inputUsdPerMTok?: number;
  outputUsdPerMTok?: number;
  contextWindow?: number | null;
  deprecated?: boolean;
}

/** List the models a provider exposes so the admin can import them. */
export async function fetchProviderModelsAction(id: string): Promise<ActionResult<UpstreamModelOption[]>> {
  try {
    await requireWriteAdmin();
    const row = await prisma.provider.findUniqueOrThrow({ where: { id }, include: { models: { include: { model: true } } } });
    const [upstream, catalog] = await Promise.all([
      listModels({ baseUrl: row.baseUrl, apiKey: await decryptSecret(row.apiKeyEnc) }),
      loadProviderCatalog(row.baseUrl),
    ]);
    const mapped = new Map(row.models.map((m) => [m.upstreamModelId, m.model.slug]));
    const options: UpstreamModelOption[] = upstream
      // When we have the catalog, hide non-chat models (embeddings, TTS…).
      .filter((m) => catalog.size === 0 || catalog.has(m.id))
      .map((m) => {
        const c = catalog.get(m.id);
        return {
          id: m.id,
          mappedTo: mapped.get(m.id) ?? null,
          ...(c
            ? {
                inputUsdPerMTok: c.inputMicroPerMTok / 1_000_000,
                outputUsdPerMTok: c.outputMicroPerMTok / 1_000_000,
                contextWindow: c.contextWindow,
                deprecated: c.deprecated,
              }
            : {}),
        };
      })
      .sort((a, b) => Number(a.deprecated ?? false) - Number(b.deprecated ?? false) || a.id.localeCompare(b.id));
    return { ok: true, data: options };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : "Could not list the provider's models." };
  }
}

/** Turn an upstream id like "deepseek-ai/DeepSeek-V3.1" into "deepseek-v3.1". */
function slugFromUpstream(id: string): string {
  const tail = id.includes("/") ? id.slice(id.lastIndexOf("/") + 1) : id;
  return tail
    .toLowerCase()
    .replace(/[^a-z0-9.]+/g, "-")
    .replace(/^-+|-+$/g, "")
    .slice(0, 48);
}

/**
 * Import upstream models: creates a catalog entry per id (if the slug is
 * new) and maps it to this provider. Prices and context size come from the
 * provider's public catalog when it has one (DeepInfra, OpenRouter); otherwise they start
 * at 0 and the admin fills them in on the Models page.
 */
export async function importProviderModelsAction(id: string, upstreamIds: string[]): Promise<ActionResult<{ created: number; mapped: number }>> {
  try {
    const admin = await requireWriteAdmin();
    const ids = z.array(z.string().trim().min(1).max(200)).min(1, "Pick at least one model").max(200).parse(upstreamIds);
    const provider = await prisma.provider.findUniqueOrThrow({ where: { id } });
    const catalog = await loadProviderCatalog(provider.baseUrl);

    let created = 0;
    let mapped = 0;
    for (const upstreamId of ids) {
      const slug = slugFromUpstream(upstreamId);
      const c = catalog.get(upstreamId);
      const priced = c ? catalogPriceFields(c) : {};
      let model = await prisma.gatewayModel.findUnique({ where: { slug } });
      if (!model) {
        model = await prisma.gatewayModel.create({ data: { slug, displayName: upstreamId.split("/").pop() ?? upstreamId, ...priced } });
        created++;
      } else if (c && model.inputPriceMicroPerMTok === 0 && model.outputPriceMicroPerMTok === 0) {
        // Existing unpriced entry (e.g. imported earlier from a provider without a catalog).
        model = await prisma.gatewayModel.update({ where: { id: model.id }, data: priced });
      }
      const existing = await prisma.providerModel.findUnique({ where: { providerId_modelId: { providerId: id, modelId: model.id } } });
      if (!existing) {
        await prisma.providerModel.create({ data: { providerId: id, modelId: model.id, upstreamModelId: upstreamId } });
        mapped++;
      }
    }

    await logActivity({
      storeId: await getAdminStoreId(),
      action: "SETTINGS_CHANGED",
      description: `${admin.name} imported ${mapped} models from "${provider.name}" (${created} new catalog entries)`,
      adminId: admin.id,
    });
    await revalidate();
    return { ok: true, data: { created, mapped } };
  } catch (e) {
    return { ok: false, error: e instanceof z.ZodError ? firstIssue(e) : e instanceof Error ? e.message : "Import failed." };
  }
}
