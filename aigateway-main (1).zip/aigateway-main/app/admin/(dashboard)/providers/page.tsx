import type { Metadata } from "next";
import { prisma } from "@/lib/prisma";
import { PageHeader } from "@/components/shared/page-header";
import { ProvidersView, type ProviderRow } from "@/components/admin/gateway/providers-view";
import { decryptSecret, maskSecret } from "@/lib/gateway/crypto";

export const metadata: Metadata = { title: "Providers" };
export const dynamic = "force-dynamic";

export default async function ProvidersPage() {
  const providers = await prisma.provider.findMany({
    include: { _count: { select: { models: true } } },
    orderBy: [{ priority: "asc" }, { name: "asc" }],
  });

  const rows: ProviderRow[] = [];
  for (const p of providers) {
    rows.push({
      id: p.id,
      slug: p.slug,
      name: p.name,
      baseUrl: p.baseUrl,
      apiKeyMasked: maskSecret(await decryptSecret(p.apiKeyEnc)),
      enabled: p.enabled,
      priority: p.priority,
      healthStatus: p.healthStatus,
      lastCheckedAt: p.lastCheckedAt?.toISOString() ?? null,
      lastError: p.lastError,
      modelCount: p._count.models,
    });
  }

  return (
    <div className="space-y-6">
      <PageHeader
        title="Providers"
        description="Upstream inference providers the gateway forwards customer requests to. Lower priority wins; when a provider fails, the next one serving the same model takes over automatically."
      />
      <ProvidersView providers={rows} />
    </div>
  );
}
