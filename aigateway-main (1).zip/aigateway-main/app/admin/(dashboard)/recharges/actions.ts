"use server";

import { revalidatePath } from "next/cache";
import { requireWriteAdmin } from "@/lib/auth";
import { z } from "zod";
import { awardLoyaltyPoints } from "@/lib/services/loyalty";
import { getPack } from "@/lib/services/packs";
import { creditVoucherGrants } from "@/lib/vouchers/service";
import { prisma } from "@/lib/prisma";
import { logActivity } from "@/lib/services/activity";
import { credit, TX_OPTIONS } from "@/lib/billing/balance-service";
import { centsToMicro } from "@/lib/billing/money";
import { swapPoolKey } from "@/lib/services/legacy-pool";
import { creditPromoBonus } from "@/lib/services/announcements";
import { creditPlanBonus, purchaseRef, recordPlanProfit } from "@/lib/services/profit";
import type { ActionResult } from "@/app/admin/(dashboard)/customers/actions";
import type { StoreId } from "@/lib/store";

/**
 * Approve a recharge. WS8: the admin must choose a pack (pre-selected when a
 * single pack matches the amount); the pack binds the plan. Voucher
 * redemptions held for review carry their pack already and are credited from
 * the voucher's grants instead of the parsed offer title.
 */
export async function approveRechargeAction(requestId: string, packId: string): Promise<ActionResult> {
  try {
    const admin = await requireWriteAdmin();

    const req = await prisma.rechargeRequest.findUnique({
      where: { id: requestId },
      include: { customer: { include: { order: { select: { orderNumber: true } } } } },
    });
    if (!req) return { ok: false, error: "Request not found." };
    if (req.status !== "PENDING") return { ok: false, error: "This request has already been processed." };

    const customer = req.customer;
    const isVoucher = req.source === "VOUCHER" && !!req.voucherId;
    const chosenPackId = isVoucher ? (req.packId ?? packId) : z.string().min(1, "Choose a pack").parse(packId);
    const pack = await getPack(customer.storeId as StoreId, chosenPackId);
    if (!pack) return { ok: false, error: "Choose the pack the customer bought before approving." };

    // What the recharge credits: the price of the pack's plan ($100 plan →
    // $100), not the amount parsed from the offer title. Vouchers keep their
    // pack's grant.
    const rechargeCents = isVoucher ? req.balanceCents : pack.plan.priceCents;

    // Returning-customer review bonus: 15% of the recharged balance for
    // EVERYONE — the recharge flow itself is what makes them a returning
    // customer. Credited only when they confirm they wrote a review.
    const pendingBonusCents = Math.round(rechargeCents * 0.15);
    // The bonus is NOT credited here — the banner shows on their dashboard and
    // claimReviewBonus moves the money once they attest the review.
    const newReviewStatus = pendingBonusCents > 0 ? "OFFERED" : customer.reviewBonusStatus;

    let promoCents = 0;
    let profitCents = 0;
    let planBonusCents = 0;
    await prisma.$transaction(async (tx) => {
      // Mark request as approved (conditional so a double click cannot credit twice).
      const approved = await tx.rechargeRequest.updateMany({
        where: { id: requestId, status: "PENDING" },
        data: { status: "APPROVED", processedAt: new Date() },
      });
      if (approved.count === 0) throw new Error("This request has already been processed.");

      await tx.customer.update({
        where: { id: customer.id },
        data: {
          offerTitle: req.offerTitle,
          reviewBonusStatus: newReviewStatus,
          // The banner tracks THIS bonus until the customer attests the review.
          pendingBonusCents,
          reviewClaimedAt: null,
          // A recharge is a new purchase: the customer moves onto the pack's plan.
          packId: pack.id,
          ...(pack.plan.isActive ? { planId: pack.plan.id, planAssignedAt: new Date() } : {}),
        },
      });
      if (isVoucher) {
        const voucher = await tx.voucher.findUniqueOrThrow({ where: { id: req.voucherId! }, include: { pack: true } });
        await creditVoucherGrants(tx, voucher, customer.id, { adminId: admin.id, label: admin.name });
      } else {
        // Credit the customer through the ledger (status/finishedAt are re-derived there).
        await credit({
          customerId: customer.id,
          pot: "BALANCE",
          amountMicroUsd: centsToMicro(rechargeCents),
          type: "RECHARGE",
          idempotencyKey: `recharge:${req.id}:BALANCE`,
          ref: { type: "RechargeRequest", id: req.id },
          actor: { adminId: admin.id, label: admin.name },
          note: `Recharge approved: ${pack.plan.name} plan (${req.offerTitle})`,
          tx,
        });
        // Update order number to the new one.
        await tx.order.upsert({
          where: { customerId: customer.id },
          update: { orderNumber: req.orderNumber },
          create: { customerId: customer.id, orderNumber: req.orderNumber },
        });
      }
      // Recharge promotion locked in when the customer submitted the request.
      promoCents = await creditPromoBonus(tx, {
        customerId: customer.id,
        balanceCents: rechargeCents,
        pct: req.promoBonusPct,
        ref: { type: "RechargeRequest", id: req.id },
        actor: { adminId: admin.id, label: admin.name },
      });
      // Profit of the plan sold (voucher recharges keyed by the voucher, so it is never counted twice).
      const ref = purchaseRef({ type: "RechargeRequest", id: req.id }, isVoucher ? req.voucherId : null);
      profitCents = await recordPlanProfit(tx, { customerId: customer.id, plan: pack.plan, ref });
      // The plan's bonus, same purchase reference (so a voucher is never credited twice).
      planBonusCents = await creditPlanBonus(tx, { customerId: customer.id, plan: pack.plan, ref, actor: { adminId: admin.id, label: admin.name } });
      // Legacy pool (WS10): a new upstream key only while LEGACY_API_POOL_MODE=active.
      await swapPoolKey(tx, { customerId: customer.id, storeId: customer.storeId, orderId: req.orderNumber });
    }, TX_OPTIONS);

    await logActivity({
      storeId: customer.storeId as StoreId,
      action: "RECHARGE_APPROVED" as const,
      description: `${admin.name} approved recharge for ${customer.accessCode}: +$${(rechargeCents / 100).toFixed(2)} (${isVoucher ? "voucher" : `order ${req.orderNumber}`}, pack "${pack.name}")${promoCents > 0 ? ` + $${(promoCents / 100).toFixed(2)} promotion bonus (${req.promoBonusPct}%)` : ""}${planBonusCents > 0 ? ` + $${(planBonusCents / 100).toFixed(2)} plan bonus` : ""}${profitCents > 0 ? `, profit $${(profitCents / 100).toFixed(2)}` : ""}`,
      adminId: admin.id,
      customerId: customer.id,
    });

    revalidatePath("/admin/recharges");
    revalidatePath("/portal", "layout");

    // Loyalty: approved recharge counts as a completed purchase → points.
    const friendAward = await awardLoyaltyPoints(customer.id, rechargeCents);

    // Affiliate: the inviter earns their commission on every repurchase too.
    const { creditReferralCommission } = await import("@/lib/services/affiliate");
    await creditReferralCommission(customer.id, friendAward?.earned?.totalPoints ?? 0);

    return { ok: true };
  } catch (error) {
    if (error instanceof z.ZodError) return { ok: false, error: error.issues[0].message };
    console.error(error);
    return { ok: false, error: error instanceof Error ? error.message : "Could not approve this request." };
  }
}

export async function rejectRechargeAction(requestId: string, reason: string): Promise<ActionResult> {
  try {
    const admin = await requireWriteAdmin();

    const req = await prisma.rechargeRequest.findUnique({
      where: { id: requestId },
      include: { customer: { select: { accessCode: true, storeId: true } } },
    });
    if (!req) return { ok: false, error: "Request not found." };
    if (req.status !== "PENDING") return { ok: false, error: "This request has already been processed." };

    await prisma.rechargeRequest.update({
      where: { id: requestId },
      data: { status: "REJECTED", rejectedReason: reason.trim() || "Order not verified.", processedAt: new Date() },
    });
    // A rejected voucher redemption burns the code: it was never credited and must not be reusable.
    if (req.source === "VOUCHER" && req.voucherId) {
      await prisma.voucher.updateMany({
        where: { id: req.voucherId, status: "REDEEMED" },
        data: { status: "REVOKED", revokedReason: `Redemption rejected: ${reason.trim() || "not verified"}`, revokedByAdminId: admin.id },
      });
    }

    await logActivity({
      storeId: req.customer.storeId as StoreId,
      action: "RECHARGE_REJECTED" as const,
      description: `${admin.name} rejected recharge for ${req.customer.accessCode}: order ${req.orderNumber} — ${reason || "not verified"}`,
      adminId: admin.id,
      customerId: req.customerId,
    });

    revalidatePath("/admin/recharges");
    return { ok: true };
  } catch (error) {
    console.error(error);
    return { ok: false, error: "Could not reject this request." };
  }
}
