import type { Metadata } from "next";
import Link from "next/link";
import { RefreshCw } from "lucide-react";
import { prisma } from "@/lib/prisma";
import { Card } from "@/components/ui/card";
import { PageHeader } from "@/components/shared/page-header";
import { EmptyState } from "@/components/shared/empty-state";
import { LocalTime } from "@/components/shared/local-time";
import { formatCents } from "@/lib/money";
import { cn } from "@/lib/utils";
import { ApproveButton, RejectButton } from "./client";
import { getAdminStoreId } from "@/lib/store";
import { listPacks, suggestPack, toPackOption } from "@/lib/services/packs";

export const metadata: Metadata = { title: "Recharge Requests" };
export const dynamic = "force-dynamic";

const STATUS_STYLE: Record<string, string> = {
  PENDING: "bg-warning/12 text-warning border-warning/25",
  APPROVED: "bg-success/12 text-success border-success/25",
  REJECTED: "bg-destructive/12 text-destructive border-destructive/25",
};

export default async function RechargesPage() {
  const storeId = await getAdminStoreId();
  const requests = await prisma.rechargeRequest.findMany({
    where: { storeId },
    orderBy: { createdAt: "desc" },
    include: {
      customer: { select: { id: true, accessCode: true } },
      pack: { select: { name: true } },
    },
  });
  const packs = (await listPacks(storeId, { includeInactive: true })).map(toPackOption);

  const pending = requests.filter((r) => r.status === "PENDING").length;

  return (
    <div className="space-y-6">
      <PageHeader
        title="Recharge Requests to clients"
        description={`${requests.length} total · ${pending} pending approval`}
      />

      {requests.length === 0 ? (
        <EmptyState
          icon={RefreshCw}
          title="No recharge requests yet"
          description="When customers submit a recharge request it will appear here for your approval."
        />
      ) : (
        <div className="space-y-3">
          {requests.map((req) => (
            <Card key={req.id} className="gap-0 p-4">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div className="min-w-0 space-y-1">
                  {/* Customer link + order number */}
                  <div className="flex items-center gap-2">
                    <Link
                      href={`/admin/customers/${req.customer.id}`}
                      className="font-mono text-sm font-medium text-primary hover:underline"
                    >
                      {req.customer.accessCode}
                    </Link>
                    <span className="text-muted-foreground">·</span>
                    <span className="font-mono text-xs text-muted-foreground">{req.orderNumber}</span>
                    {req.source === "VOUCHER" && (
                      <span className="inline-flex rounded-full border border-primary/25 bg-primary/10 px-2 py-0.5 text-[10px] font-semibold uppercase text-primary" title="Redeemed a GamsGo voucher; held for review">
                        Voucher{req.pack ? ` · ${req.pack.name}` : ""}
                      </span>
                    )}
                  </div>

                  {/* Offer title */}
                  <p className="text-sm text-foreground">{req.offerTitle}</p>

                  {/* Balance + bonus */}
                  <div className="flex items-center gap-3 text-xs">
                    <span className="font-medium text-foreground">
                      Balance: <span className="text-primary">+{formatCents(req.balanceCents)}</span>
                    </span>
                    {req.bonusCents > 0 && (
                      <span className="font-medium text-foreground">
                        Bonus: <span className="text-success">+{formatCents(req.bonusCents)}</span>
                      </span>
                    )}
                    {req.promoBonusPct > 0 && (
                      <span className="font-medium text-foreground" title="Recharge promotion locked in when the customer submitted; credited to the bonus pot on approval">
                        Promotion: <span className="text-success">+{req.promoBonusPct}% ({formatCents(Math.floor((req.balanceCents * req.promoBonusPct) / 100))})</span>
                      </span>
                    )}
                    <span className="text-muted-foreground">
                      <LocalTime date={req.createdAt.toISOString()} variant="datetime" />
                    </span>
                  </div>

                  {req.status === "REJECTED" && req.rejectedReason && (
                    <p className="text-xs text-destructive">Reason: {req.rejectedReason}</p>
                  )}
                </div>

                <div className="flex items-center gap-2">
                  <span className={cn("inline-flex rounded-full border px-2.5 py-0.5 text-xs font-medium", STATUS_STYLE[req.status])}>
                    {req.status.charAt(0) + req.status.slice(1).toLowerCase()}
                  </span>
                  {req.status === "PENDING" && (
                    <>
                      <ApproveButton
                        requestId={req.id}
                        packs={packs}
                        suggestedPackId={suggestPack(packs, req.balanceCents)?.id ?? null}
                        lockedPackId={req.source === "VOUCHER" ? req.packId : null}
                        customerPackId={req.source === "VOUCHER" ? null : req.packId}
                        amountCents={req.balanceCents}
                      />
                      <RejectButton requestId={req.id} />
                    </>
                  )}
                </div>
              </div>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
}
