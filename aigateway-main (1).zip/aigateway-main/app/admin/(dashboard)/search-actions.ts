"use server";

import { prisma } from "@/lib/prisma";
import { getCurrentAdmin } from "@/lib/auth";

export interface SearchResult {
  type: "customer" | "documentation";
  id: string;
  title: string;
  subtitle: string;
  href: string;
  status?: string;
}

export async function globalSearch(query: string): Promise<SearchResult[]> {
  const admin = await getCurrentAdmin();
  if (!admin) return [];

  const q = query.trim();
  if (q.length < 2) return [];

  const [customers, docs] = await Promise.all([
    prisma.customer.findMany({
      where: {
        deletedAt: null,
        OR: [
          { accessCode: { contains: q } },
          { notes: { contains: q } },
          { status: { contains: q.toUpperCase().replace(/\s+/g, "_") } },
          { order: { orderNumber: { contains: q } } },
          { apiKey: { key: { contains: q } } },
        ],
      },
      include: { order: true },
      take: 8,
      orderBy: { createdAt: "desc" },
    }),
    prisma.documentation.findMany({
      where: { OR: [{ title: { contains: q } }, { content: { contains: q } }] },
      take: 4,
    }),
  ]);

  return [
    ...customers.map((c) => ({
      type: "customer" as const,
      id: c.id,
      title: c.accessCode,
      subtitle: c.order?.orderNumber ?? "No order",
      href: `/admin/customers/${c.id}`,
      status: c.status,
    })),
    ...docs.map((d) => ({
      type: "documentation" as const,
      id: d.id,
      title: d.title,
      subtitle: "Documentation",
      href: `/admin/documentation?doc=${d.slug}`,
    })),
  ];
}
