"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import bcrypt from "bcryptjs";
import { getCurrentAdmin, requireWriteAdmin } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { setSetting } from "@/lib/services/settings";
import { logActivity } from "@/lib/services/activity";
import { PARTIAL_CHARGE_POLICIES, SETTING_KEYS } from "@/lib/constants";
import { usdToCents } from "@/lib/money";
import type { ActionResult } from "@/app/admin/(dashboard)/customers/actions";
import { getAdminStoreId } from "@/lib/store";
import { validateSocialLinks } from "@/lib/social-links";

const settingsSchema = z.object({
  siteName: z.string().trim().min(1, "Website name is required").max(80),
  logoText: z.string().trim().min(1, "Logo text is required").max(40),
  supportEmail: z.string().trim().email("Enter a valid support email"),
  brandColor: z
    .string()
    .trim()
    .regex(/^#[0-9a-fA-F]{6}$/, "Brand color must be a hex value like #2563EB"),
  footerText: z.string().trim().max(200),
  lowBalanceThreshold: z.coerce.number().min(0, "Threshold cannot be negative").max(100_000),
  defaultCurrency: z.string().trim().min(3).max(3),
  timezone: z.string().trim().min(1).max(64),
  usageCostMultiplier: z.coerce
    .number()
    .min(0.1, "Multiplier must be at least 0.1")
    .max(100, "Multiplier is too large"),
  signupBalance: z.coerce.number().min(0, "Cannot be negative").max(1_000_000),
  signupBonus: z.coerce.number().min(0, "Cannot be negative").max(1_000_000),
  storeUrl: z.string().trim().url("Enter a valid store URL").max(500),
  socialLinks: z
    .array(z.object({ label: z.string().trim().max(40), url: z.string().trim().max(500) }))
    .max(12)
    .default([]),
});

export type SettingsInput = z.input<typeof settingsSchema>;

export async function saveSettingsAction(input: SettingsInput): Promise<ActionResult> {
  try {
    const admin = await requireWriteAdmin();
    const storeId = await getAdminStoreId();

    const data = settingsSchema.parse(input);

    // Blank rows are ignored; everything else must be well-formed.
    const socialLinks = data.socialLinks.filter((l) => l.label.trim() || l.url.trim());
    const socialError = validateSocialLinks(socialLinks);
    if (socialError) return { ok: false, error: socialError };

    await Promise.all([
      setSetting(storeId, SETTING_KEYS.siteName, data.siteName),
      setSetting(storeId, SETTING_KEYS.logoText, data.logoText),
      setSetting(storeId, SETTING_KEYS.supportEmail, data.supportEmail),
      setSetting(storeId, SETTING_KEYS.brandColor, data.brandColor.toUpperCase()),
      setSetting(storeId, SETTING_KEYS.footerText, data.footerText),
      setSetting(storeId, SETTING_KEYS.lowBalanceThresholdCents, String(usdToCents(data.lowBalanceThreshold))),
      setSetting(storeId, SETTING_KEYS.defaultCurrency, data.defaultCurrency.toUpperCase()),
      setSetting(storeId, SETTING_KEYS.timezone, data.timezone),
      setSetting(storeId, SETTING_KEYS.usageCostMultiplier, String(data.usageCostMultiplier)),
      setSetting(storeId, SETTING_KEYS.signupBalanceCents, String(usdToCents(data.signupBalance))),
      setSetting(storeId, SETTING_KEYS.signupBonusCents, String(usdToCents(data.signupBonus))),
      setSetting(storeId, SETTING_KEYS.storeUrl, data.storeUrl),
      setSetting(storeId, SETTING_KEYS.socialLinks, JSON.stringify(socialLinks.map((l) => ({ label: l.label.trim(), url: l.url.trim() })))),
    ]);

    await logActivity({
      storeId,
      action: "SETTINGS_CHANGED",
      description: `${admin.name} updated the platform settings`,
      adminId: admin.id,
    });

    revalidatePath("/admin", "layout");
    revalidatePath("/", "layout");
    return { ok: true };
  } catch (error) {
    if (error instanceof z.ZodError) return { ok: false, error: error.issues[0].message };
    console.error(error);
    return { ok: false, error: "Could not save settings. Please try again." };
  }
}

/** Creates (or updates password for) the GamsGo inspector admin account. */
export async function createGamsGoAdminAction(): Promise<ActionResult> {
  try {
    const admin = await requireWriteAdmin();
    const storeId = await getAdminStoreId();

    const password = "aerolink2026";
    const passwordHash = await bcrypt.hash(password, 12);

    await prisma.admin.upsert({
      where: { email: "sellerjoin@gamsgo.com" },
      update: { passwordHash, name: "GamsGo Inspector" },
      create: { email: "sellerjoin@gamsgo.com", name: "GamsGo Inspector", passwordHash },
    });

    await logActivity({
      storeId,
      action: "SETTINGS_CHANGED",
      description: `${admin.name} created/updated the GamsGo inspector account`,
      adminId: admin.id,
    });

    return { ok: true };
  } catch (error) {
    console.error(error);
    return { ok: false, error: "Could not create the account." };
  }
}

// ─── Gateway & voucher settings (Phases 1–5) ─────────────────────────────────

const gatewaySettingsSchema = z.object({
  holdMarginPct: z.coerce.number().min(0).max(100),
  minHoldUsd: z.coerce.number().min(0).max(100),
  defaultMaxTokens: z.coerce.number().int().min(1).max(1_000_000),
  defaultRpm: z.coerce.number().int().min(1).max(100_000),
  defaultMaxConcurrent: z.coerce.number().int().min(1).max(10_000),
  storeMaxConcurrent: z.coerce.number().int().min(1).max(100_000),
  partialChargePolicy: z.enum(PARTIAL_CHARGE_POLICIES),
  voucherAutoApprove: z.coerce.boolean(),
  voucherMaxRedemptionsPerIpDay: z.coerce.number().int().min(0).max(1000),
  voucherExpiryMonths: z.coerce.number().int().min(0).max(120),
  voucherLowStockCount: z.coerce.number().int().min(0).max(100_000),
  voucherLowStockDays: z.coerce.number().int().min(0).max(365),
  voucherTurnstileAfterFailures: z.coerce.number().int().min(0).max(1000),
});

export type GatewaySettingsInput = z.input<typeof gatewaySettingsSchema>;

export async function saveGatewaySettingsAction(input: GatewaySettingsInput): Promise<ActionResult> {
  try {
    const admin = await requireWriteAdmin();
    const storeId = await getAdminStoreId();
    const d = gatewaySettingsSchema.parse(input);
    await Promise.all([
      setSetting(storeId, SETTING_KEYS.gatewayHoldMarginPct, String(d.holdMarginPct)),
      setSetting(storeId, SETTING_KEYS.gatewayMinHoldMicroUsd, String(Math.round(d.minHoldUsd * 1_000_000))),
      setSetting(storeId, SETTING_KEYS.gatewayDefaultMaxTokens, String(d.defaultMaxTokens)),
      setSetting(storeId, SETTING_KEYS.gatewayDefaultRpm, String(d.defaultRpm)),
      setSetting(storeId, SETTING_KEYS.gatewayDefaultMaxConcurrent, String(d.defaultMaxConcurrent)),
      setSetting(storeId, SETTING_KEYS.gatewayStoreMaxConcurrent, String(d.storeMaxConcurrent)),
      setSetting(storeId, SETTING_KEYS.partialChargePolicy, d.partialChargePolicy),
      setSetting(storeId, SETTING_KEYS.voucherAutoApprove, d.voucherAutoApprove ? "true" : "false"),
      setSetting(storeId, SETTING_KEYS.voucherMaxRedemptionsPerIpDay, String(d.voucherMaxRedemptionsPerIpDay)),
      setSetting(storeId, SETTING_KEYS.voucherExpiryMonths, String(d.voucherExpiryMonths)),
      setSetting(storeId, SETTING_KEYS.voucherLowStockCount, String(d.voucherLowStockCount)),
      setSetting(storeId, SETTING_KEYS.voucherLowStockDays, String(d.voucherLowStockDays)),
      setSetting(storeId, SETTING_KEYS.voucherTurnstileAfterFailures, String(d.voucherTurnstileAfterFailures)),
    ]);
    await logActivity({
      storeId,
      action: "SETTINGS_CHANGED",
      description: `${admin.name} updated the gateway & voucher settings (auto-approve ${d.voucherAutoApprove ? "on" : "off"}, ${d.partialChargePolicy})`,
      adminId: admin.id,
    });
    revalidatePath("/admin", "layout");
    return { ok: true };
  } catch (error) {
    if (error instanceof z.ZodError) return { ok: false, error: error.issues[0].message };
    console.error(error);
    return { ok: false, error: "Could not save settings. Please try again." };
  }
}
