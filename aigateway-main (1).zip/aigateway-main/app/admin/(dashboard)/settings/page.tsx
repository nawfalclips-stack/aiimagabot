import type { Metadata } from "next";
import { prisma } from "@/lib/prisma";
import { getSettings } from "@/lib/services/settings";
import { customerInclude } from "@/lib/services/customers";
import { toCustomerRow } from "@/lib/serialize";
import { SETTING_KEYS } from "@/lib/constants";
import { PageHeader } from "@/components/shared/page-header";
import { SettingsForm } from "@/components/admin/settings-form";
import { GatewaySettingsForm } from "@/components/admin/gateway-settings-form";
import { DeletedCustomers } from "@/components/admin/deleted-customers";
import { getAdminStoreId } from "@/lib/store";
import { parseSocialLinks } from "@/lib/social-links";

export const metadata: Metadata = { title: "Settings" };
export const dynamic = "force-dynamic";

export default async function SettingsPage() {
  const storeId = await getAdminStoreId();
  const [settings, deleted] = await Promise.all([
    getSettings(storeId),
    prisma.customer.findMany({
      where: { storeId, deletedAt: { not: null } },
      include: customerInclude,
      orderBy: { deletedAt: "desc" },
    }),
  ]);

  return (
    <div className="space-y-6">
      <PageHeader title="Settings" description="Branding, business rules, and data recovery." />
      <SettingsForm
        initial={{
          siteName: settings[SETTING_KEYS.siteName],
          logoText: settings[SETTING_KEYS.logoText],
          supportEmail: settings[SETTING_KEYS.supportEmail],
          brandColor: settings[SETTING_KEYS.brandColor],
          footerText: settings[SETTING_KEYS.footerText],
          lowBalanceThreshold: parseInt(settings[SETTING_KEYS.lowBalanceThresholdCents], 10) / 100,
          defaultCurrency: settings[SETTING_KEYS.defaultCurrency],
          timezone: settings[SETTING_KEYS.timezone],
          usageCostMultiplier: parseFloat(settings[SETTING_KEYS.usageCostMultiplier]) || 2.2,
          signupBalance: (parseInt(settings[SETTING_KEYS.signupBalanceCents], 10) || 0) / 100,
          signupBonus: (parseInt(settings[SETTING_KEYS.signupBonusCents], 10) || 0) / 100,
          storeUrl: settings[SETTING_KEYS.storeUrl],
          socialLinks: parseSocialLinks(settings[SETTING_KEYS.socialLinks]),
        }}
      />
      <GatewaySettingsForm
        initial={{
          holdMarginPct: Number(settings[SETTING_KEYS.gatewayHoldMarginPct]) || 0,
          minHoldUsd: (Number(settings[SETTING_KEYS.gatewayMinHoldMicroUsd]) || 0) / 1_000_000,
          defaultMaxTokens: Number(settings[SETTING_KEYS.gatewayDefaultMaxTokens]) || 4096,
          defaultRpm: Number(settings[SETTING_KEYS.gatewayDefaultRpm]) || 20,
          defaultMaxConcurrent: Number(settings[SETTING_KEYS.gatewayDefaultMaxConcurrent]) || 4,
          storeMaxConcurrent: Number(settings[SETTING_KEYS.gatewayStoreMaxConcurrent]) || 200,
          partialChargePolicy: settings[SETTING_KEYS.partialChargePolicy] === "CHARGE_DELIVERED" ? "CHARGE_DELIVERED" : "WAIVE_ON_UPSTREAM_ERROR",
          voucherAutoApprove: settings[SETTING_KEYS.voucherAutoApprove] === "true",
          voucherMaxRedemptionsPerIpDay: Number(settings[SETTING_KEYS.voucherMaxRedemptionsPerIpDay]) || 0,
          voucherExpiryMonths: Number(settings[SETTING_KEYS.voucherExpiryMonths]) || 0,
          voucherLowStockCount: Number(settings[SETTING_KEYS.voucherLowStockCount]) || 0,
          voucherLowStockDays: Number(settings[SETTING_KEYS.voucherLowStockDays]) || 0,
          voucherTurnstileAfterFailures: Number(settings[SETTING_KEYS.voucherTurnstileAfterFailures]) || 0,
        }}
      />
      <DeletedCustomers customers={deleted.map(toCustomerRow)} />
    </div>
  );
}
