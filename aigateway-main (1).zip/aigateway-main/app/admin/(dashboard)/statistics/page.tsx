import type { Metadata } from "next";
import { PackageOpen } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { PageHeader } from "@/components/shared/page-header";
import { StatCard } from "@/components/shared/stat-card";
import { getPortfolioStats } from "@/lib/services/analytics";
import { centsToUsd, formatCents } from "@/lib/money";
import { getAdminStoreId } from "@/lib/store";

export const metadata: Metadata = { title: "Statistics" };
export const dynamic = "force-dynamic";

export default async function StatisticsPage() {
  const storeId = await getAdminStoreId();
  const stats = await getPortfolioStats(storeId);

  return (
    <div className="space-y-8">
      <PageHeader
        title="Statistics"
        description="Live totals across balances, usage, users and the API pool."
      />

      <section aria-label="Portfolio statistics" className="grid grid-cols-2 gap-4 lg:grid-cols-3 xl:grid-cols-5">
        <StatCard
          title="Total Balance"
          value={centsToUsd(stats.totalBalanceCents)}
          format="money"
          icon="wallet"
          tone="primary"
          hint="Remaining across all customers"
          index={0}
        />
        <StatCard
          title="Total Used"
          value={centsToUsd(stats.totalUsedCents)}
          format="money"
          icon="dollar"
          tone="warning"
          hint="Consumed to date"
          index={1}
        />
        <StatCard title="Active Users" value={stats.activeUsers} icon="userCheck" tone="success" index={2} />
        <StatCard
          title="Total APIs"
          value={stats.totalApis}
          icon="key"
          tone="default"
          hint={`${stats.availableApis} available · ${stats.assignedApis} assigned`}
          index={3}
        />
        <StatCard
          title="Not Started"
          value={stats.notStarted}
          icon="pause"
          tone="destructive"
          hint="No usage recorded yet"
          index={4}
        />
      </section>

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <PackageOpen className="size-5 text-primary" /> At a glance
          </CardTitle>
          <CardDescription>How the numbers fit together.</CardDescription>
        </CardHeader>
        <CardContent className="grid gap-x-8 gap-y-4 text-sm sm:grid-cols-2">
          <div className="flex items-center justify-between border-b pb-3">
            <span className="text-muted-foreground">Balance still available to customers</span>
            <span className="font-semibold tabular-nums">{formatCents(stats.totalBalanceCents)}</span>
          </div>
          <div className="flex items-center justify-between border-b pb-3">
            <span className="text-muted-foreground">Balance consumed so far</span>
            <span className="font-semibold tabular-nums">{formatCents(stats.totalUsedCents)}</span>
          </div>
          <div className="flex items-center justify-between border-b pb-3">
            <span className="text-muted-foreground">Customers actively using their balance</span>
            <span className="font-semibold tabular-nums">{stats.activeUsers}</span>
          </div>
          <div className="flex items-center justify-between border-b pb-3">
            <span className="text-muted-foreground">Customers who haven&apos;t started yet</span>
            <span className="font-semibold tabular-nums">{stats.notStarted}</span>
          </div>
          <div className="flex items-center justify-between pb-1">
            <span className="text-muted-foreground">API keys ready to hand out</span>
            <span className="font-semibold tabular-nums">{stats.availableApis}</span>
          </div>
          <div className="flex items-center justify-between pb-1">
            <span className="text-muted-foreground">API keys already assigned</span>
            <span className="font-semibold tabular-nums">{stats.assignedApis}</span>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
