import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, Bot, ShieldCheck, User } from "lucide-react";
import { prisma } from "@/lib/prisma";
import { requireAdmin } from "@/lib/auth";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { LocalTime } from "@/components/shared/local-time";
import { CopyButton } from "@/components/shared/copy-button";
import { AdminReplyBox } from "@/components/admin/admin-reply-box";
import { TICKET_TYPE_LABELS, TICKET_STATUS_LABELS, type TicketType, type TicketStatus } from "@/lib/constants";
import { cn } from "@/lib/utils";
import { getAdminStoreId } from "@/lib/store";

export const metadata: Metadata = { title: "Ticket" };
export const dynamic = "force-dynamic";

const STATUS_STYLE: Record<string, string> = {
  OPEN: "bg-primary/12 text-primary",
  AUTO_FIXING: "bg-warning/12 text-warning",
  AUTO_RESOLVED: "bg-success/12 text-success",
  RESOLVED: "bg-success/12 text-success",
  CLOSED: "bg-muted text-muted-foreground",
};

export default async function AdminTicketDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const storeId = await getAdminStoreId();
  await requireAdmin();
  // Also trigger auto-fix when admin opens a ticket.
  await import("@/lib/services/tickets").then(({ runAutoFix }) => runAutoFix()).catch(() => null);
  const ticket = await prisma.ticket.findUnique({
    where: { id, storeId },
    include: {
      customer: { select: { accessCode: true, id: true, order: { select: { orderNumber: true } } } },
      messages: { orderBy: { createdAt: "asc" } },
    },
  });
  if (!ticket) notFound();

  const isClosed = ticket.status === "RESOLVED" || ticket.status === "CLOSED";

  return (
    <div className="max-w-2xl space-y-5">
      <Button asChild variant="ghost" size="sm" className="-ml-2 text-muted-foreground">
        <Link href="/admin/tickets"><ArrowLeft /> All tickets</Link>
      </Button>

      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <h1 className="text-xl font-semibold">{ticket.title}</h1>
          <p className="mt-0.5 text-xs text-muted-foreground">
            <Link href={`/admin/customers/${ticket.customer.id}`} className="font-mono hover:underline">{ticket.customer.accessCode}</Link>
            {ticket.customer.order?.orderNumber ? (
              <>
                {" · "}
                <span className="font-mono">{ticket.customer.order.orderNumber}</span>
                <CopyButton value={ticket.customer.order.orderNumber} label="Order number" size="icon-xs" className="ml-0.5 inline-flex align-middle" />
              </>
            ) : null}
            {" · "}{TICKET_TYPE_LABELS[ticket.type as TicketType]}
            {" · "}<LocalTime date={ticket.createdAt} variant="datetime" />
          </p>
        </div>
        <span className={cn("inline-flex rounded-full px-3 py-1 text-xs font-semibold", STATUS_STYLE[ticket.status])}>
          {TICKET_STATUS_LABELS[ticket.status as TicketStatus] ?? ticket.status}
        </span>
      </div>

      <Card>
        <CardContent className="pt-4">
          <p className="text-sm whitespace-pre-wrap text-foreground/90">{ticket.description}</p>
          {ticket.screenshotUrl ? (
            <a href={ticket.screenshotUrl} target="_blank" rel="noopener noreferrer" className="mt-3 block overflow-hidden rounded-lg border">
              <img src={ticket.screenshotUrl} alt="Screenshot" className="max-h-48 w-full object-contain" />
            </a>
          ) : null}
        </CardContent>
      </Card>

      <div className="space-y-3">
        {ticket.messages.map((msg) => {
          const isCustomer = !msg.fromAdmin && !msg.isBot;
          return (
            <div key={msg.id} className={cn("flex gap-2.5", msg.fromAdmin && "flex-row-reverse")}>
              <span className={cn(
                "flex size-8 shrink-0 items-center justify-center rounded-full",
                msg.isBot ? "bg-primary/12 text-primary" : msg.fromAdmin ? "bg-success/12 text-success" : "bg-muted text-muted-foreground"
              )}>
                {msg.isBot ? <Bot className="size-4" /> : msg.fromAdmin ? <ShieldCheck className="size-4" /> : <User className="size-4" />}
              </span>
              <div className={cn("max-w-[80%]", msg.fromAdmin && "items-end text-right")}>
                <div className={cn(
                  "rounded-2xl px-4 py-2.5 text-sm leading-relaxed",
                  msg.isBot ? "bg-primary/8 border border-primary/15" :
                  msg.fromAdmin ? "bg-success/8 border border-success/15" :
                  "bg-muted/60"
                )}>
                  <p className="whitespace-pre-wrap">{msg.body}</p>
                </div>
                <p className="mt-0.5 px-1 text-[11px] text-muted-foreground">
                  {msg.isBot ? "🤖 Auto-reply" : msg.fromAdmin ? "You (Admin)" : "Customer"} ·{" "}
                  <LocalTime date={msg.createdAt} variant="log" />
                </p>
              </div>
            </div>
          );
        })}
      </div>

      {!isClosed ? (
        <div className="border-t pt-4">
          <AdminReplyBox ticketId={ticket.id} />
        </div>
      ) : (
        <p className="border-t pt-4 text-center text-sm text-muted-foreground">This ticket is closed.</p>
      )}
    </div>
  );
}
