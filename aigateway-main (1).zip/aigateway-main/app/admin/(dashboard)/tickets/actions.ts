"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { getCurrentAdmin, requireWriteAdmin } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { replyToTicket, closeTicket } from "@/lib/services/tickets";
import type { ActionResult } from "@/app/admin/(dashboard)/customers/actions";
import { getAdminStoreId } from "@/lib/store";

export async function adminReplyAction(ticketId: string, body: string): Promise<ActionResult> {
  try {
    const admin = await requireWriteAdmin();
    const clean = z.string().trim().min(1).max(5000).parse(body);
    await replyToTicket({ ticketId, body: clean, fromAdmin: true });
    revalidatePath("/admin/tickets", "layout");
    revalidatePath(`/portal/support/${ticketId}`);
    return { ok: true };
  } catch (error) {
    console.error(error);
    return { ok: false, error: "Could not send reply." };
  }
}

export async function adminCloseTicketAction(ticketId: string): Promise<ActionResult> {
  try {
    const admin = await requireWriteAdmin();
    const storeId = await getAdminStoreId();
    await closeTicket(ticketId, admin.id, admin.name, storeId);
    revalidatePath("/admin/tickets", "layout");
    revalidatePath(`/portal/support/${ticketId}`);
    return { ok: true };
  } catch (error) {
    console.error(error);
    return { ok: false, error: "Could not close ticket." };
  }
}

export async function markApiKeyProblematicAction(key: string): Promise<ActionResult> {
  try {
    const admin = await requireWriteAdmin();
    await prisma.apiPoolKey.updateMany({ where: { key }, data: { status: "PROBLEMATIC" } });
    revalidatePath("/admin/api-pool");
    return { ok: true };
  } catch (error) {
    console.error(error);
    return { ok: false, error: "Could not mark that key." };
  }
}
