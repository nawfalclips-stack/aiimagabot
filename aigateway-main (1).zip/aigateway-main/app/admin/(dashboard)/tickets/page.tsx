import type { Metadata } from "next";
import Link from "next/link";
import { Ticket } from "lucide-react";
import { prisma } from "@/lib/prisma";
import { Card } from "@/components/ui/card";
import { PageHeader } from "@/components/shared/page-header";
import { EmptyState } from "@/components/shared/empty-state";
import { LocalTime } from "@/components/shared/local-time";
import { TICKET_TYPE_LABELS, TICKET_STATUS_LABELS, type TicketType, type TicketStatus } from "@/lib/constants";
import { cn } from "@/lib/utils";
import { getAdminStoreId } from "@/lib/store";

export const metadata: Metadata = { title: "Report an Issue" };
export const dynamic = "force-dynamic";

const STATUS_STYLE: Record<string, string> = {
  OPEN: "bg-primary/12 text-primary border-primary/25",
  AUTO_FIXING: "bg-warning/12 text-warning border-warning/25",
  AUTO_RESOLVED: "bg-success/12 text-success border-success/25",
  RESOLVED: "bg-success/12 text-success border-success/25",
  CLOSED: "bg-muted text-muted-foreground border-border",
};

export default async function AdminTicketsPage() {
  const storeId = await getAdminStoreId();
  const tickets = await prisma.ticket.findMany({
    where: { storeId },
    orderBy: { createdAt: "desc" },
    include: {
      customer: { select: { accessCode: true } },
      messages: { orderBy: { createdAt: "desc" }, take: 1 },
    },
  });

  const open = tickets.filter((t) => t.status === "OPEN" || t.status === "AUTO_FIXING").length;

  return (
    <div className="space-y-6">
      <PageHeader
        title="Report an Issue"
        description={`${tickets.length} total · ${open} open · All communication with customers is through GamsGo`}
      />

      {tickets.length === 0 ? (
        <EmptyState icon={Ticket} title="No tickets yet" description="Customer support tickets will appear here." />
      ) : (
        <div className="space-y-2">
          {tickets.map((t) => {
            const lastMsg = t.messages[0];
            return (
              <Link key={t.id} href={`/admin/tickets/${t.id}`} className="block">
                <Card className="gap-0 p-4 transition-all duration-150 hover:-translate-y-0.5 hover:border-primary/30">
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div className="min-w-0">
                      <p className="truncate font-medium">{t.title}</p>
                      <p className="mt-0.5 text-xs text-muted-foreground">
                        <span className="font-mono">{t.customer.accessCode}</span> ·{" "}
                        {TICKET_TYPE_LABELS[t.type as TicketType]} ·{" "}
                        <LocalTime date={t.createdAt} variant="datetime" />
                      </p>
                    </div>
                    <span className={cn("inline-flex rounded-full border px-2.5 py-0.5 text-xs font-medium", STATUS_STYLE[t.status])}>
                      {TICKET_STATUS_LABELS[t.status as TicketStatus] ?? t.status}
                    </span>
                  </div>
                  {lastMsg ? (
                    <p className="mt-1.5 line-clamp-1 text-xs text-muted-foreground">
                      {lastMsg.isBot ? "🤖 " : lastMsg.fromAdmin ? "You: " : "Customer: "}
                      {lastMsg.body.slice(0, 120)}
                    </p>
                  ) : null}
                </Card>
              </Link>
            );
          })}
        </div>
      )}
    </div>
  );
}
