"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { getCurrentAdmin, requireWriteAdmin } from "@/lib/auth";
import { addUsageLogs, deleteUsageLog } from "@/lib/services/usage-logs";
import { parseUsageLogs } from "@/lib/usage-parser";
import type { ActionResult } from "@/app/admin/(dashboard)/customers/actions";
import { getAdminStoreId } from "@/lib/store";

export async function addUsageLogsAction(
  customerId: string,
  raw: string,
  multiplierOverride?: number
): Promise<ActionResult<{ added: number; deductedCents: number }>> {
  try {
    const admin = await requireWriteAdmin();
    const storeId = await getAdminStoreId();

    const input = z
      .object({ customerId: z.string().min(1), raw: z.string().min(1).max(200_000) })
      .parse({ customerId, raw });

    const rows = parseUsageLogs(input.raw);
    if (rows.length === 0) {
      return { ok: false, error: "No usage rows recognized. Paste the rows exactly as copied from the dashboard." };
    }
    if (rows.length > 1000) {
      return { ok: false, error: "Add at most 1000 rows at a time." };
    }

    // Validate multiplier override (allowed range 1–10).
    const mult = multiplierOverride !== undefined
      ? z.number().min(1).max(10).parse(multiplierOverride)
      : undefined;

    const result = await addUsageLogs(input.customerId, rows, admin.id, admin.name, storeId, mult);
    revalidatePath("/admin", "layout");
    revalidatePath("/portal", "layout");
    return { ok: true, data: { added: result.added, deductedCents: result.deductedCents } };
  } catch (error) {
    console.error(error);
    const message = error instanceof Error && error.message.length < 200 ? error.message : "Could not add the usage logs.";
    return { ok: false, error: message };
  }
}

export async function deleteUsageLogAction(logId: string): Promise<ActionResult> {
  try {
    const admin = await requireWriteAdmin();
    const storeId = await getAdminStoreId();
    await deleteUsageLog(logId, admin.id, admin.name, storeId);
    revalidatePath("/admin", "layout");
    revalidatePath("/portal", "layout");
    return { ok: true };
  } catch (error) {
    console.error(error);
    return { ok: false, error: "Could not remove that usage log." };
  }
}
