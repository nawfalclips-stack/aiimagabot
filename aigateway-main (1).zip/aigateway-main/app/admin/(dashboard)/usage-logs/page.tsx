import type { Metadata } from "next";
import { prisma } from "@/lib/prisma";
import { getUsageCostMultiplier } from "@/lib/services/settings";
import { PageHeader } from "@/components/shared/page-header";
import { UsageLogsView, type UsageCustomerOption, type UsageLogRow } from "@/components/admin/usage-logs-view";
import { maskKey, poolAssignmentsEnabled, redactKeys } from "@/lib/services/legacy-pool";
import { getAdminStoreId } from "@/lib/store";

export const metadata: Metadata = { title: "Usage Logs" };
export const dynamic = "force-dynamic";

export default async function UsageLogsPage({
  searchParams,
}: {
  searchParams: Promise<{ customer?: string }>;
}) {
  const { customer: customerId } = await searchParams;
  const storeId = await getAdminStoreId();

  const [customers, multiplier] = await Promise.all([
    prisma.customer.findMany({
      where: { storeId, deletedAt: null },
      include: { order: true, apiKey: true },
      orderBy: { createdAt: "desc" },
    }),
    getUsageCostMultiplier(storeId),
  ]);

  const options: UsageCustomerOption[] = customers.map((c) => ({
    id: c.id,
    accessCode: c.accessCode,
    orderNumber: c.order?.orderNumber ?? "",
    apiKey: poolAssignmentsEnabled() ? (c.apiKey?.key ?? "") : maskKey(c.apiKey?.key),
    status: c.status,
    remainingBalanceCents: c.initialBalanceCents - c.usedBalanceCents,
  }));

  const selected = options.find((c) => c.id === customerId) ?? null;

  const logs: UsageLogRow[] = selected
    ? (
        await prisma.usageLog.findMany({
          where: { customerId: selected.id },
          orderBy: { happenedAt: "desc" },
          take: 200,
        })
      ).map((log) => ({
        id: log.id,
        happenedAt: log.happenedAt.toISOString(),
        keyLabel: redactKeys(log.keyLabel),
        model: log.model,
        tokens: log.tokens,
        costMicroUsd: log.costMicroUsd,
        latency: log.latency,
        status: log.status,
      }))
    : [];

  return (
    <div className="space-y-6">
      <PageHeader
        title="Usage Logs"
      />
      <UsageLogsView customers={options} selected={selected} logs={logs} multiplier={multiplier} />
    </div>
  );
}
