"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { requireWriteAdmin, requireAdmin } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { getAdminStoreId } from "@/lib/store";
import { getSettings } from "@/lib/services/settings";
import { SETTING_KEYS } from "@/lib/constants";
import { listModelsForStore } from "@/lib/gateway/registry";
import { resolveBaseUrl } from "@/lib/base-url";
import {
  clawbackVoucher,
  createVoucherBatch,
  listingText,
  lookupVouchers,
  markBatchUploaded,
  MAX_BATCH_QUANTITY,
  revokeBatch,
  revokeVoucher,
  updateBatchExpiry,
} from "@/lib/vouchers/service";
import { voucherPepperConfigured } from "@/lib/vouchers/code";
import type { ActionResult } from "@/app/admin/(dashboard)/customers/actions";

function revalidate() {
  revalidatePath("/admin/vouchers");
  revalidatePath("/admin/packs");
}

const generateSchema = z.object({
  packId: z.string().min(1, "Choose a pack"),
  quantity: z.coerce.number().int().min(1).max(MAX_BATCH_QUANTITY, `At most ${MAX_BATCH_QUANTITY} codes per batch`),
  expiryMonths: z.coerce.number().int().min(0).max(120),
  note: z.string().trim().max(200).default(""),
});
export type GenerateBatchInput = z.input<typeof generateSchema>;

export interface GeneratedBatch {
  batchId: string;
  packName: string;
  codes: string[];
  redeemUrl: string;
}

/** Plaintext codes are returned exactly once, in this response, and never again. */
export async function generateBatchAction(input: GenerateBatchInput): Promise<ActionResult<GeneratedBatch>> {
  try {
    const admin = await requireWriteAdmin();
    const storeId = await getAdminStoreId();
    if (!voucherPepperConfigured()) return { ok: false, error: "VOUCHER_PEPPER is not configured on the server. Set it (docs/vouchers.md) and redeploy first." };
    const d = generateSchema.parse(input);
    const expiresAt = d.expiryMonths > 0 ? new Date(new Date().setMonth(new Date().getMonth() + d.expiryMonths)) : null;
    const { batch, codes } = await createVoucherBatch({ storeId, packId: d.packId, quantity: d.quantity, note: d.note, expiresAt, adminId: admin.id, adminName: admin.name });
    const pack = await prisma.pack.findUniqueOrThrow({ where: { id: batch.packId }, select: { name: true } });
    revalidate();
    return { ok: true, data: { batchId: batch.id, packName: pack.name, codes, redeemUrl: `${await resolveBaseUrl()}/redeem` } };
  } catch (e) {
    if (e instanceof z.ZodError) return { ok: false, error: e.issues[0].message };
    return { ok: false, error: e instanceof Error ? e.message : "Could not generate the batch." };
  }
}

export async function markUploadedAction(batchId: string): Promise<ActionResult> {
  try {
    const admin = await requireWriteAdmin();
    await markBatchUploaded(await getAdminStoreId(), z.string().min(1).parse(batchId), admin.id, admin.name);
    revalidate();
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : "Could not update the batch." };
  }
}

export async function updateBatchExpiryAction(batchId: string, expiresAt: string | null): Promise<ActionResult> {
  try {
    await requireWriteAdmin();
    const date = expiresAt ? new Date(expiresAt) : null;
    if (date && Number.isNaN(date.getTime())) return { ok: false, error: "Invalid date." };
    await updateBatchExpiry(await getAdminStoreId(), z.string().min(1).parse(batchId), date);
    revalidate();
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : "Could not update the batch." };
  }
}

export async function revokeBatchAction(batchId: string, reason: string): Promise<ActionResult<{ revoked: number }>> {
  try {
    const admin = await requireWriteAdmin();
    const n = await revokeBatch(await getAdminStoreId(), z.string().min(1).parse(batchId), reason, admin.id, admin.name);
    revalidate();
    return { ok: true, data: { revoked: n } };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : "Could not revoke the batch." };
  }
}

export async function revokeVoucherAction(voucherId: string, reason: string): Promise<ActionResult> {
  try {
    const admin = await requireWriteAdmin();
    await revokeVoucher(await getAdminStoreId(), z.string().min(1).parse(voucherId), reason, admin.id, admin.name);
    revalidate();
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : "Could not revoke the voucher." };
  }
}

export async function clawbackVoucherAction(voucherId: string, reason: string, suspendCustomer: boolean): Promise<ActionResult<{ balanceCents: number; bonusCents: number }>> {
  try {
    const admin = await requireWriteAdmin();
    const storeId = await getAdminStoreId();
    const r = await clawbackVoucher(storeId, z.string().min(1).parse(voucherId), { reason, suspendCustomer, adminId: admin.id, adminName: admin.name });
    revalidate();
    revalidatePath("/admin/customers", "layout");
    return { ok: true, data: { balanceCents: Number(r.balanceMicroUsd / 10_000n), bonusCents: Number(r.bonusMicroUsd / 10_000n) } };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : "Could not claw back the voucher." };
  }
}

export interface VoucherLookupResult {
  id: string;
  last4: string;
  status: string;
  packName: string;
  batchId: string;
  createdAt: string;
  redeemedAt: string | null;
  customerId: string | null;
  customerAccessCode: string | null;
  gamsgoOrderId: string | null;
  revokedReason: string | null;
  clawedBackAt: string | null;
  expiresAt: string | null;
  uploaded: boolean;
}

export async function lookupVouchersAction(query: string): Promise<ActionResult<VoucherLookupResult[]>> {
  try {
    await requireAdmin();
    const storeId = await getAdminStoreId();
    const q = z.string().trim().max(120).parse(query);
    if (!q) return { ok: true, data: [] };
    const rows = await lookupVouchers(storeId, q);
    return {
      ok: true,
      data: rows.map((v) => ({
        id: v.id,
        last4: v.codeLast4,
        status: v.status,
        packName: v.pack.name,
        batchId: v.batchId,
        createdAt: v.createdAt.toISOString(),
        redeemedAt: v.redeemedAt?.toISOString() ?? null,
        customerId: v.redeemedByCustomerId,
        customerAccessCode: v.customer?.accessCode ?? null,
        gamsgoOrderId: v.gamsgoOrderId,
        revokedReason: v.revokedReason,
        clawedBackAt: v.clawedBackAt?.toISOString() ?? null,
        expiresAt: v.batch.expiresAt?.toISOString() ?? null,
        uploaded: v.batch.markedUploadedAt !== null,
      })),
    };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : "Lookup failed." };
  }
}

export async function listingTextAction(packId: string): Promise<ActionResult<{ title: string; description: string }>> {
  try {
    await requireAdmin();
    const storeId = await getAdminStoreId();
    const pack = await prisma.pack.findFirst({ where: { id: z.string().min(1).parse(packId), storeId, deletedAt: null }, include: { plan: true } });
    if (!pack) return { ok: false, error: "Pack not found." };
    const [models, settings, baseUrl] = await Promise.all([listModelsForStore(storeId), getSettings(storeId), resolveBaseUrl()]);
    const months = Number(settings[SETTING_KEYS.voucherExpiryMonths]) || null;
    return {
      ok: true,
      data: listingText({
        pack,
        planName: pack.plan.name,
        models: models.map((m) => m.displayName),
        supportEmail: settings[SETTING_KEYS.supportEmail],
        redeemUrl: `${baseUrl}/redeem`,
        expiryMonths: months,
      }),
    };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : "Could not build the listing text." };
  }
}
