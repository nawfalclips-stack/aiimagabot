import type { Metadata } from "next";
import { prisma } from "@/lib/prisma";
import { PageHeader } from "@/components/shared/page-header";
import { VouchersView, type BatchRow, type PackChoice, type StockRow } from "@/components/admin/vouchers/vouchers-view";
import { getAdminStoreId } from "@/lib/store";
import { getCurrentAdmin } from "@/lib/auth";
import { getSettings } from "@/lib/services/settings";
import { SETTING_KEYS } from "@/lib/constants";
import { packStock } from "@/lib/vouchers/service";
import { voucherPepperConfigured } from "@/lib/vouchers/code";

export const metadata: Metadata = { title: "Vouchers" };
export const dynamic = "force-dynamic";

export default async function VouchersPage() {
  const storeId = await getAdminStoreId();
  const admin = await getCurrentAdmin();
  const [stock, batches, packs, settings, admins] = await Promise.all([
    packStock(storeId),
    prisma.voucherBatch.findMany({
      where: { storeId },
      include: { pack: { select: { name: true } }, vouchers: { select: { status: true } } },
      orderBy: { createdAt: "desc" },
      take: 100,
    }),
    prisma.pack.findMany({ where: { storeId, deletedAt: null }, orderBy: [{ sortOrder: "asc" }, { createdAt: "asc" }], select: { id: true, name: true, active: true } }),
    getSettings(storeId),
    prisma.admin.findMany({ select: { id: true, name: true } }),
  ]);
  const adminName = new Map(admins.map((a) => [a.id, a.name]));
  const activeById = new Map(packs.map((p) => [p.id, p.active]));

  const stockRows: StockRow[] = stock.map((s) => ({ ...s, active: activeById.get(s.packId) ?? false }));
  const batchRows: BatchRow[] = batches.map((b) => {
    const count = (status: string) => b.vouchers.filter((v) => v.status === status).length;
    return {
      id: b.id,
      packName: b.pack.name,
      quantity: b.quantity,
      issued: count("ISSUED"),
      redeemed: count("REDEEMED"),
      revoked: count("REVOKED"),
      expired: count("EXPIRED"),
      createdAt: b.createdAt.toISOString(),
      createdBy: (b.createdByAdminId && adminName.get(b.createdByAdminId)) || "—",
      markedUploadedAt: b.markedUploadedAt?.toISOString() ?? null,
      expiresAt: b.expiresAt?.toISOString() ?? null,
      compromisedAt: b.compromisedAt?.toISOString() ?? null,
      note: b.note,
    };
  });
  const packChoices: PackChoice[] = packs;

  return (
    <div className="space-y-6">
      <PageHeader
        title="Vouchers"
        description="Single-use codes sold through GamsGo Automatic Delivery: generate → download once → paste into the offer's inventory → mark uploaded → watch stock. Step by step in docs/vouchers.md."
      />
      <VouchersView
        stock={stockRows}
        batches={batchRows}
        packs={packChoices}
        defaultExpiryMonths={Number(settings[SETTING_KEYS.voucherExpiryMonths]) || 0}
        pepperConfigured={voucherPepperConfigured()}
        canWrite={!!admin && !admin.isReadOnly}
      />
    </div>
  );
}
