"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { setAdminStoreId, hasStoreAccess, type StoreId, getAdminStoreId } from "@/lib/store";
import { requireAdmin } from "@/lib/auth";
import { markNotificationAsRead, markAllNotificationsAsRead } from "@/lib/services/notifications";

export async function switchStoreAction(storeId: StoreId) {
  const admin = await requireAdmin();

  // Check if admin has access to this store
  const hasAccess = await hasStoreAccess(admin.id, storeId);
  if (!hasAccess) {
    return { error: "You don't have access to this store" };
  }

  // Set the new store ID in cookie
  await setAdminStoreId(storeId);

  // Revalidate and redirect to refresh data
  revalidatePath("/admin", "layout");
  redirect("/admin");
}

export async function markNotificationAsReadAction(notificationId: string) {
  await requireAdmin();
  await markNotificationAsRead(notificationId);
  revalidatePath("/admin", "layout");
}

export async function markAllNotificationsAsReadAction() {
  await requireAdmin();
  const storeId = await getAdminStoreId();
  await markAllNotificationsAsRead(storeId);
  revalidatePath("/admin", "layout");
}
