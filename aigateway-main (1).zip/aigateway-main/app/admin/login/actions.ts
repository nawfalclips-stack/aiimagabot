"use server";

import { redirect } from "next/navigation";
import { headers } from "next/headers";
import bcrypt from "bcryptjs";
import { z } from "zod";
import { prisma } from "@/lib/prisma";
import { createAdminSession, destroyAdminSession } from "@/lib/session";
import { rateLimit } from "@/lib/rate-limit";
import { logActivity } from "@/lib/services/activity";
import { getCurrentAdmin } from "@/lib/auth";
import { getAdminStoreId } from "@/lib/store";

const loginSchema = z.object({
  email: z.string().trim().toLowerCase().email("Enter a valid email address"),
  password: z.string().min(1, "Enter your password"),
});

export interface LoginState {
  error?: string;
}

export async function adminLogin(_prev: LoginState, formData: FormData): Promise<LoginState> {
  const parsed = loginSchema.safeParse({
    email: formData.get("email"),
    password: formData.get("password"),
  });
  if (!parsed.success) {
    return { error: parsed.error.issues[0].message };
  }

  const ip = ((await headers()).get("x-forwarded-for") ?? "local").split(",")[0].trim();
  const limited = await rateLimit(`admin-login:${ip}`, { limit: 8, windowMs: 15 * 60 * 1000 });
  if (!limited.ok) {
    return { error: `Too many attempts. Try again in ${Math.ceil(limited.retryAfterSeconds / 60)} minutes.` };
  }

  const admin = await prisma.admin.findUnique({ where: { email: parsed.data.email } });
  // Compare against a dummy hash when the account doesn't exist to keep
  // response timing uniform.
  const hash = admin?.passwordHash ?? "$2a$12$invalidinvalidinvalidinvalidinvalidinvalidinvalidinva";
  const valid = await bcrypt.compare(parsed.data.password, hash);

  if (!admin || !valid) {
    return { error: "Invalid email or password." };
  }

  await createAdminSession(admin.id);
  const storeId = await getAdminStoreId();
  await logActivity({
    storeId,
    action: "ADMIN_LOGIN",
    description: `${admin.name} signed in`,
    adminId: admin.id,
  });

  redirect("/admin");
}

export async function adminLogout(): Promise<void> {
  const admin = await getCurrentAdmin();
  if (admin) {
    const storeId = await getAdminStoreId();
    await logActivity({
      storeId,
      action: "ADMIN_LOGOUT",
      description: `${admin.name} signed out`,
      adminId: admin.id,
    });
  }
  await destroyAdminSession();
  redirect("/admin/login");
}
