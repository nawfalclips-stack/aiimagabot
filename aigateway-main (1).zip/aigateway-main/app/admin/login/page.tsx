import type { Metadata } from "next";
import { redirect } from "next/navigation";
import { getCurrentAdmin } from "@/lib/auth";
import { LoginForm } from "./login-form";

export const metadata: Metadata = {
  title: "Admin Sign In",
  robots: { index: false, follow: false },
};

export const dynamic = "force-dynamic";

export default async function AdminLoginPage() {
  // Database-backed check (not just the cookie) — a stale session for a
  // deleted admin stays on the login form instead of redirect-looping.
  const admin = await getCurrentAdmin();
  if (admin) redirect("/admin");
  return (
    <main className="relative flex min-h-screen flex-1 items-center justify-center overflow-hidden px-4">
      {/* Ambient background */}
      <div aria-hidden className="pointer-events-none absolute inset-0">
        <div className="absolute top-[-20%] left-1/2 h-[480px] w-[720px] -translate-x-1/2 rounded-full bg-primary/12 blur-[140px]" />
        <div className="absolute right-[-10%] bottom-[-20%] h-[360px] w-[480px] rounded-full bg-primary/6 blur-[120px]" />
        <div className="absolute inset-0 dot-grid" />
      </div>
      <LoginForm />
    </main>
  );
}
