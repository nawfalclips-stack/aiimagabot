import { redirect } from "next/navigation";

/**
 * Affiliate referral entry point.
 *
 * Referrers share links like /affiliate/AERO-DEMO01. This route forwards the
 * visitor to the landing page's activation form with the referral code
 * pre-filled, so the inviter gets credited when the order is activated.
 */
export default async function AffiliateReferralPage({
  params,
}: {
  params: Promise<{ code: string }>;
}) {
  const { code } = await params;
  const cleaned = decodeURIComponent(code).trim().toUpperCase();
  redirect(`/?ref=${encodeURIComponent(cleaned)}`);
}
