import { cronUnauthorized, isCronAuthorized } from "@/lib/cron-auth";
import { NextResponse, type NextRequest } from "next/server";
import { runAutoFix } from "@/lib/services/tickets";

// Vercel Cron calls this route every 5 minutes with an Authorization header.
// The CRON_SECRET env var is set on Vercel and in .env for local testing.
export async function GET(request: NextRequest) {
  if (!isCronAuthorized(request)) return cronUnauthorized();

  const result = await runAutoFix();
  console.log(`[cron/fix-tickets] fixed=${result.fixed} skipped=${result.skipped}`);
  return NextResponse.json({ ok: true, ...result });
}
