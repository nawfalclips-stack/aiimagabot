import { cronUnauthorized, isCronAuthorized } from "@/lib/cron-auth";
import { NextResponse, type NextRequest } from "next/server";
import { STORE_IDS } from "@/lib/store";
import { syncModelPrices } from "@/lib/services/model-prices";
import { createNotification, NOTIFICATION_TYPES } from "@/lib/services/notifications";

// Vercel Cron, daily (vercel.json): re-read OpenRouter / DeepInfra list prices
// and update catalog-backed models, so holds and displayed prices follow the
// provider. Each store's admins get one notification listing what changed.
// Protected by CRON_SECRET.
export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  if (!isCronAuthorized(request)) return cronUnauthorized();
  const report = await syncModelPrices({ apply: true });
  const changed = report.rows.filter((r) => r.changed).map((r) => r.slug);
  const missing = report.rows.filter((r) => !r.after).map((r) => r.slug);
  if (changed.length > 0 || missing.length > 0) {
    const parts = [
      changed.length > 0 ? `Prices updated for ${changed.join(", ")}.` : "",
      missing.length > 0 ? `No longer in the provider catalog: ${missing.join(", ")} — check the mapping.` : "",
    ].filter(Boolean);
    for (const storeId of Object.values(STORE_IDS)) {
      await createNotification({
        storeId,
        type: NOTIFICATION_TYPES.MODEL_PRICES_SYNCED,
        title: changed.length > 0 ? "Model prices updated" : "Model missing from provider catalog",
        message: parts.join(" "),
      });
    }
  }
  console.log(`[cron/model-prices] changed=${changed.length} unchanged=${report.unchanged} missing=${missing.length}`);
  return NextResponse.json({ ok: true, changed, unchanged: report.unchanged, missing });
}
