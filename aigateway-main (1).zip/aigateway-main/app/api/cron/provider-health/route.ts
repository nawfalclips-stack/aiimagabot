import { cronUnauthorized, isCronAuthorized } from "@/lib/cron-auth";
import { NextResponse, type NextRequest } from "next/server";
import { prisma } from "@/lib/prisma";
import { breakerSnapshot } from "@/lib/gateway/breaker";

// Hourly (vercel.json): fold the live breaker state and the last hour's
// gateway outcomes into Provider.healthStatus for the admin Providers page.
export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  if (!isCronAuthorized(request)) return cronUnauthorized();

  const since = new Date(Date.now() - 60 * 60 * 1000);
  const providers = await prisma.provider.findMany({ include: { models: { where: { enabled: true }, select: { id: true, upstreamModelId: true } } } });
  const outcomes = await prisma.usageLog.groupBy({
    by: ["providerSlug", "status"],
    where: { gatewayTokenId: { not: null }, happenedAt: { gte: since }, providerSlug: { not: "" } },
    _count: { _all: true },
  });

  const report: Record<string, string> = {};
  for (const p of providers) {
    const snaps = await Promise.all(p.models.map(async (m) => ({ ...m, ...(await breakerSnapshot(m.id)) })));
    const open = snaps.filter((s) => s.open);
    const rows = outcomes.filter((o) => o.providerSlug === p.slug);
    const total = rows.reduce((n, r) => n + r._count._all, 0);
    const errors = rows.filter((r) => r.status === "error").reduce((n, r) => n + r._count._all, 0);
    const success = total > 0 ? Math.round(((total - errors) / total) * 100) : null;

    const healthStatus = !p.enabled ? "UNKNOWN" : open.length > 0 && open.length === snaps.length && snaps.length > 0 ? "DOWN" : "UP";
    const parts = [
      open.length > 0 ? `breaker open for ${open.map((s) => s.upstreamModelId).join(", ")}` : "",
      success !== null ? `last hour: ${success}% ok over ${total} requests` : "no gateway traffic in the last hour",
    ].filter(Boolean);
    const lastError = parts.join(" · ");
    await prisma.provider.update({ where: { id: p.id }, data: { healthStatus, lastCheckedAt: new Date(), lastError } });
    report[p.slug] = `${healthStatus}: ${lastError}`;
  }
  return NextResponse.json({ ok: true, providers: report });
}
