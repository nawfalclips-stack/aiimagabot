import { cronUnauthorized, isCronAuthorized } from "@/lib/cron-auth";
import { NextResponse, type NextRequest } from "next/server";
import { sweepExpiredReservations } from "@/lib/billing/reservations";

// Vercel Cron, every 5 minutes (vercel.json): release gateway holds whose
// function died before settlement. Protected by CRON_SECRET like every cron.
export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  if (!isCronAuthorized(request)) return cronUnauthorized();
  const result = await sweepExpiredReservations();
  if (result.expired.length || result.settledFromLog.length) {
    console.warn(`[cron/reservations] expired=${result.expired.join(",")} settledFromLog=${result.settledFromLog.join(",")}`);
  }
  return NextResponse.json({ ok: true, expired: result.expired.length, settledFromLog: result.settledFromLog.length });
}
