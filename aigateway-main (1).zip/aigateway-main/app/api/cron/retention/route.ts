import { cronUnauthorized, isCronAuthorized } from "@/lib/cron-auth";
import { NextResponse, type NextRequest } from "next/server";
import { runRetention } from "@/lib/services/retention";

// Vercel Cron, daily (vercel.json): delete finished gateway reservations and
// empty old raw usage payloads (lib/services/retention.ts). The ledger is
// never touched. `?dry=1` only reports what would change. Protected by CRON_SECRET.
export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 300;

export async function GET(request: NextRequest) {
  if (!isCronAuthorized(request)) return cronUnauthorized();
  const dryRun = request.nextUrl.searchParams.get("dry") === "1";
  const report = await runRetention({ dryRun });
  console.log(`[cron/retention] ${JSON.stringify(report)}`);
  return NextResponse.json({ ok: true, ...report });
}
