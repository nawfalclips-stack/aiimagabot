import { cronUnauthorized, isCronAuthorized } from "@/lib/cron-auth";
import { NextResponse, type NextRequest } from "next/server";
import { STORE_IDS } from "@/lib/store";
import { expireVouchers, notifyLowStock } from "@/lib/vouchers/service";

// Vercel Cron, daily (vercel.json): ISSUED codes past their batch expiry
// become EXPIRED, and each store gets a low-stock notification per pack
// (decision #7: below 10 codes or 7 days). Protected by CRON_SECRET.
export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  if (!isCronAuthorized(request)) return cronUnauthorized();
  const expired = await expireVouchers();
  const lowStock: Record<string, string[]> = {};
  for (const storeId of Object.values(STORE_IDS)) {
    lowStock[storeId] = await notifyLowStock(storeId);
  }
  console.log(`[cron/vouchers] expired=${expired} lowStock=${JSON.stringify(lowStock)}`);
  return NextResponse.json({ ok: true, expired, lowStock });
}
