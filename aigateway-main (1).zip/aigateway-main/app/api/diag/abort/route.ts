import { cronUnauthorized, isCronAuthorized } from "@/lib/cron-auth";
import { after } from "next/server";
import type { NextRequest } from "next/server";

/**
 * Empirical check for WS5 on the real platform (docs/gateway-audit.md §15.2–15.3):
 * which disconnect signals fire on Vercel's Node runtime, and whether after()
 * still runs when the client hangs up mid-stream.
 *
 *   curl -N -H "Authorization: Bearer $CRON_SECRET" https://<preview>/api/diag/abort
 *   … press Ctrl-C after a few ticks, then read the function logs for
 *   "[diag/abort]" lines. Expected: "request.signal aborted", "cancel() fired"
 *   and "after() ran" all appear within a second or two of the interrupt.
 *
 * Protected by CRON_SECRET; streams for at most 60 s.
 */
export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 120;

export async function GET(request: NextRequest) {
  if (!isCronAuthorized(request)) return cronUnauthorized();

  const started = Date.now();
  const id = Math.random().toString(36).slice(2, 8);
  const log = (msg: string) => console.log(`[diag/abort] ${id} ${msg} at ${Date.now() - started} ms`);
  let ended = false;
  const end = (why: string) => {
    if (ended) return;
    ended = true;
    log(`ended: ${why}`);
  };

  request.signal.addEventListener("abort", () => log("request.signal aborted"), { once: true });

  const encoder = new TextEncoder();
  let timer: ReturnType<typeof setInterval> | null = null;
  const stream = new ReadableStream<Uint8Array>({
    start(controller) {
      let tick = 0;
      controller.enqueue(encoder.encode(`: diag ${id} — interrupt this stream, then check the logs\n\n`));
      timer = setInterval(() => {
        tick++;
        try {
          controller.enqueue(encoder.encode(`data: tick ${tick}\n\n`));
        } catch {
          if (timer) clearInterval(timer);
          end("enqueue failed (client gone)");
          return;
        }
        if (tick >= 120) {
          if (timer) clearInterval(timer);
          controller.close();
          end("completed 60 s");
        }
      }, 500);
    },
    cancel(reason) {
      if (timer) clearInterval(timer);
      log(`cancel() fired (${reason instanceof Error ? reason.message : String(reason ?? "no reason")})`);
      end("cancelled");
    },
  });

  after(async () => {
    // Runs after the response is finished from the platform's point of view.
    log("after() ran");
    await new Promise((r) => setTimeout(r, 1500));
    log("after() work completed 1.5 s later");
  });

  return new Response(stream, {
    headers: { "content-type": "text/event-stream; charset=utf-8", "cache-control": "no-cache, no-transform", "x-accel-buffering": "no" },
  });
}
