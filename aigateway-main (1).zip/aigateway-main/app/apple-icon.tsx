import { ImageResponse } from "next/og";

// Home-screen icon (iOS / PWA): the AeroLink mark, full-bleed — the OS applies its own corner mask.
export const size = { width: 180, height: 180 };
export const contentType = "image/png";

/** Same geometry as components/shared/brand-mark.tsx (literal copies: this file renders at the edge). */
const LETTER = "M5.25 26 15.25 5 25.25 26Z M9.85 26 15.25 14.66 20.65 26Z M16.6 17.5H21.2L21.63 18.4H17.03Z M18.22 20.9H22.82L23.25 21.8H18.65Z";
const BAR = "M13.47 18.4H26.75V20.9H12.28Z";

export default function AppleIcon() {
  return new ImageResponse(
    (
      <div style={{ width: "100%", height: "100%", display: "flex", alignItems: "center", justifyContent: "center", background: "#2563eb" }}>
        <svg width="132" height="132" viewBox="4 4 24 24">
          <path d={LETTER} fill="#f8fafc" fillRule="evenodd" />
          <path d={BAR} fill="#f8fafc" />
        </svg>
      </div>
    ),
    size
  );
}
