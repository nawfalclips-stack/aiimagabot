import type { Metadata } from "next";
import Link from "next/link";
import { KeyRound, Zap } from "lucide-react";
import { resolveBaseUrl } from "@/lib/base-url";
import { listModelsForStore } from "@/lib/gateway/registry";
import { getAllDocs, renderDocForCustomer } from "@/lib/services/documentation";
import { getSettings } from "@/lib/services/settings";
import { resolvePublicStoreId } from "@/lib/store";
import { SETTING_KEYS } from "@/lib/constants";
import { DocsViewer, type PortalDoc } from "@/components/portal/docs-viewer";
import { ThemeToggle } from "@/components/theme/theme-toggle";
import { BrandMark } from "@/components/shared/brand-mark";

export const metadata: Metadata = {
  title: "Documentation",
  description: "Set up Claude Code, Claude Desktop, Codex CLI, OpenCode and other agents — or call the API from your own code.",
};
export const dynamic = "force-dynamic";

/**
 * Public documentation: the same guides as /portal/documentation, readable
 * without an account (every category, since there is no offer to filter by).
 * The token stays the YOUR_AEROLINK_API_KEY placeholder; the example model is
 * a public alias, never an upstream model name.
 */
export default async function PublicDocsPage() {
  const storeId = await resolvePublicStoreId();
  const [docs, baseUrl, models, settings] = await Promise.all([
    getAllDocs(storeId),
    resolveBaseUrl(),
    listModelsForStore(storeId),
    getSettings(storeId),
  ]);
  const vars = { baseUrl, model: models[0]?.publicSlug ?? null };
  const rendered: PortalDoc[] = docs.map((d) => ({
    slug: d.slug,
    category: d.category,
    os: d.os,
    title: d.title,
    content: renderDocForCustomer(d.content, vars),
  }));

  return (
    <div className="app-canvas flex min-h-screen flex-col">
      <header className="glass sticky top-0 z-40 border-b">
        <div className="mx-auto flex w-full max-w-6xl items-center justify-between gap-4 px-4 py-3 sm:px-6">
          <Link href="/new" className="flex items-center gap-2.5">
            <span className="flex size-8 items-center justify-center overflow-hidden rounded-lg">
              <BrandMark className="size-8" />
            </span>
            <span className="font-display text-[15px] font-semibold tracking-tight">{settings[SETTING_KEYS.logoText]}</span>
          </Link>
          <div className="flex items-center gap-1.5">
            <ThemeToggle />
            <Link
              href="/login"
              className="hidden items-center gap-1.5 rounded-lg border px-3 py-1.5 text-sm font-medium text-muted-foreground transition-colors hover:border-primary/40 hover:text-foreground sm:flex"
            >
              <KeyRound className="size-4" /> Sign in
            </Link>
            <Link
              href="/"
              className="flex items-center gap-1.5 rounded-lg bg-primary px-3 py-1.5 text-sm font-medium text-primary-foreground transition-opacity hover:opacity-90"
            >
              <Zap className="size-4" /> Activate
            </Link>
          </div>
        </div>
      </header>

      <main className="mx-auto w-full max-w-6xl flex-1 px-4 py-8 sm:px-6 lg:py-10">
        <DocsViewer docs={rendered} baseUrl={baseUrl} />
      </main>
    </div>
  );
}
