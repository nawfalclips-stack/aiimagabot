"use client";

import { useEffect } from "react";
import { RotateCcw, TriangleAlert } from "lucide-react";
import { Button } from "@/components/ui/button";

export default function ErrorPage({ error, reset }: { error: Error & { digest?: string }; reset: () => void }) {
  useEffect(() => {
    console.error(error);
  }, [error]);

  return (
    <main className="relative flex min-h-screen flex-1 flex-col items-center justify-center overflow-hidden px-6 text-center">
      <div aria-hidden className="pointer-events-none absolute inset-0">
        <div className="absolute top-[-20%] left-1/2 h-[420px] w-[640px] -translate-x-1/2 rounded-full bg-destructive/8 blur-[140px]" />
      </div>
      <div className="relative z-10">
        <div className="mx-auto flex size-12 items-center justify-center rounded-2xl bg-destructive/12 ring-1 ring-destructive/25">
          <TriangleAlert className="size-6 text-destructive" />
        </div>
        <h1 className="mt-4 text-2xl font-semibold tracking-tight">Something went wrong</h1>
        <p className="mx-auto mt-2 max-w-sm text-sm text-muted-foreground">
          An unexpected error occurred. Please try again — if the problem continues, contact support.
        </p>
        <Button onClick={reset} className="mt-6">
          <RotateCcw /> Try again
        </Button>
      </div>
    </main>
  );
}
