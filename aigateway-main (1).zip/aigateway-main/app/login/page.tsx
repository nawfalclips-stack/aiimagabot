import type { Metadata } from "next";
import Link from "next/link";
import { ArrowLeft, KeyRound } from "lucide-react";
import { getSettings } from "@/lib/services/settings";
import { SETTING_KEYS } from "@/lib/constants";
import { AccessForm } from "@/components/portal/access-form";
import { STORE_IDS } from "@/lib/store";
import { parseSocialLinks } from "@/lib/social-links";
import { SocialLinks } from "@/components/shared/social-links";
import { ThemeToggle } from "@/components/theme/theme-toggle";
import { BrandMark } from "@/components/shared/brand-mark";

export const metadata: Metadata = { title: "Sign in with your access code" };
export const dynamic = "force-dynamic";

export default async function CustomerLoginPage() {
  const settings = await getSettings(STORE_IDS.AEROLINK);
  const storeUrl = settings[SETTING_KEYS.storeUrl];

  return (
    <main className="relative flex min-h-screen flex-1 flex-col overflow-hidden">
      {/* Ambient background */}
      <div aria-hidden className="pointer-events-none absolute inset-0">
        <div className="absolute top-[-20%] left-1/2 h-[480px] w-[720px] -translate-x-1/2 rounded-full bg-primary/12 blur-[140px]" />
        <div className="absolute inset-0 dot-grid" />
      </div>

      <header className="relative z-10 mx-auto flex w-full max-w-5xl items-center justify-between px-6 py-6">
        <Link href="/" className="flex items-center gap-2.5">
          <span className="flex size-9 items-center justify-center rounded-xl overflow-hidden">
            <BrandMark className="size-9" />
          </span>
          <span className="text-lg font-semibold tracking-tight">{settings[SETTING_KEYS.logoText]}</span>
        </Link>
        <div className="flex items-center gap-3">
          <Link href="/" className="flex items-center gap-1.5 text-sm text-muted-foreground transition-colors hover:text-foreground">
            <ArrowLeft className="size-4" /> New here? Activate your access
          </Link>
          <ThemeToggle />
        </div>
      </header>

      <div className="relative z-10 flex flex-1 items-center justify-center px-4 pb-16">
        <div className="w-full max-w-lg">
          <div className="mb-8 flex flex-col items-center text-center">
            <div className="flex size-12 items-center justify-center rounded-2xl bg-primary/15 ring-1 ring-primary/30">
              <KeyRound className="size-6 text-primary" />
            </div>
            <h1 className="mt-4 text-2xl font-semibold tracking-tight">Welcome back</h1>
            <p className="mt-1 text-sm text-muted-foreground">
              Enter your access code to open your dashboard — your API key, balance and documentation are waiting.
            </p>
          </div>
          <AccessForm />
        </div>
      </div>

      <footer className="relative z-10 border-t border-border">
        <div className="mx-auto flex w-full max-w-5xl flex-col items-center justify-between gap-2 px-6 py-6 text-xs text-muted-foreground sm:flex-row">
          <p>{settings[SETTING_KEYS.footerText]}</p>
          <SocialLinks links={parseSocialLinks(settings[SETTING_KEYS.socialLinks])} />
          <a href={storeUrl} target="_blank" rel="noopener noreferrer" className="transition-colors hover:text-foreground">
            Our store — contact & support
          </a>
        </div>
      </footer>
    </main>
  );
}
