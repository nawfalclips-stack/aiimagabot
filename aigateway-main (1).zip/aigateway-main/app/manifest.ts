import type { MetadataRoute } from "next";

export default function manifest(): MetadataRoute.Manifest {
  return {
    name: "AeroLink API Portal",
    short_name: "AeroLink",
    description: "Premium API access portal — view your API key, balance, and setup documentation.",
    start_url: "/",
    display: "standalone",
    background_color: "#0d0e12",
    theme_color: "#2563EB",
    icons: [
      { src: "/icon.svg", sizes: "any", type: "image/svg+xml" },
      { src: "/apple-icon", sizes: "180x180", type: "image/png" },
    ],
  };
}
