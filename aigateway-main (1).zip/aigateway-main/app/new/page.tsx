import type { Metadata } from "next";
import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { getSettings } from "@/lib/services/settings";
import { SETTING_KEYS } from "@/lib/constants";
import { STORE_IDS } from "@/lib/store";
import { Button } from "@/components/ui/button";
import { LandingNav } from "@/components/landing/landing-nav";
import { HeroRoutes } from "@/components/landing/hero-routes";
import { Reveal } from "@/components/landing/reveal";
import { LandingFooter, LandingSections } from "@/components/landing/landing-sections";

export const metadata: Metadata = {
  title: "AeroLink — one key for your coding agents, pay per token",
  description:
    "Point Claude Code, Claude Desktop, Codex or any OpenAI/Anthropic SDK at AeroLink. Prepaid, no subscription, and the exact cost of every request in your dashboard.",
};
export const dynamic = "force-dynamic";

export default async function NewLandingPage() {
  const storeId = STORE_IDS.AEROLINK;
  const settings = await getSettings(storeId);
  const logoText = settings[SETTING_KEYS.logoText];

  const tools = ["Claude Code", "Claude Desktop", "Codex CLI", "OpenCode", "Cline", "any OpenAI or Anthropic SDK"];

  return (
    <main className="relative flex min-h-screen flex-col overflow-x-clip bg-background">
      <LandingNav logoText={logoText} />

      {/* ── Hero ─────────────────────────────────────────────────────────── */}
      <section className="relative">
        <div className="mx-auto grid w-full max-w-6xl gap-14 px-6 pt-16 pb-20 sm:pt-20 lg:grid-cols-12 lg:gap-10 lg:pt-28 lg:pb-28">
          <Reveal className="lg:col-span-6">
            <p className="flex items-center gap-3 text-sm font-medium text-muted-foreground">
              <span aria-hidden className="h-px w-6 bg-primary" />
              Prepaid API access for coding agents
            </p>
            <h1 className="mt-6 font-display text-[2.6rem] leading-[1.02] font-semibold tracking-[-0.025em] text-balance sm:text-6xl lg:text-[4.1rem]">
              One key for your coding agents.
            </h1>
            <p className="mt-6 max-w-xl text-lg leading-relaxed text-muted-foreground text-pretty">
              Point Claude Code, Codex or any OpenAI- or Anthropic-compatible SDK at {logoText}. Prepaid, no subscription — and the exact
              cost of every request, down to the fraction of a cent.
            </p>
            <div className="mt-9 flex flex-wrap items-center gap-x-6 gap-y-4">
              <Button asChild size="lg" className="h-11 px-5">
                <Link href="/">
                  Activate with your Order ID <ArrowRight />
                </Link>
              </Button>
              <Link href="/login" className="text-sm font-medium text-foreground underline-offset-4 hover:underline">
                I already have a code
              </Link>
              <Link href="/docs" className="text-sm font-medium text-muted-foreground underline-offset-4 hover:text-foreground hover:underline">
                Read the docs
              </Link>
            </div>
          </Reveal>
          <Reveal className="flex items-center lg:col-span-6 lg:pl-4" delay={0.08}>
            <HeroRoutes className="w-full" />
          </Reveal>
        </div>

        {/* Works with — plain text, no badges */}
        <div className="border-t border-border/70">
          <div className="mx-auto flex w-full max-w-6xl flex-col gap-3 px-6 py-6 sm:flex-row sm:items-baseline sm:gap-8">
            <p className="shrink-0 text-sm text-muted-foreground">Works with</p>
            <p className="text-sm leading-relaxed text-foreground">
              {tools.map((t, i) => (
                <span key={t}>
                  {t}
                  {i < tools.length - 1 ? <span aria-hidden className="mx-2.5 text-border">/</span> : null}
                </span>
              ))}
            </p>
          </div>
        </div>
      </section>

      <LandingSections storeId={storeId} activateHref="/" />

      <LandingFooter storeId={storeId} />
    </main>
  );
}
