import Link from "next/link";
import { ArrowRight } from "lucide-react";
import { getSettings } from "@/lib/services/settings";
import { SETTING_KEYS } from "@/lib/constants";
import { ActivationWizard } from "@/components/portal/activation-wizard";
import { STORE_IDS } from "@/lib/store";
import { listPackChoices } from "@/lib/services/packs";
import { LandingNav } from "@/components/landing/landing-nav";
import { AccessPass } from "@/components/landing/access-pass";
import { LandingFooter, LandingSections, landingSectionLinks } from "@/components/landing/landing-sections";

export const dynamic = "force-dynamic";

const NAV_LINKS = landingSectionLinks();

/**
 * Landing page = the activation journey. New customers are greeted, read the
 * rules, enter their store Order ID and the plan they bought, and get their
 * access code generated automatically. Returning customers sign in via /login.
 * Below the hero: the same sections as /new.
 */
export default async function LandingPage({
  searchParams,
}: {
  searchParams: Promise<{ ref?: string }>;
}) {
  const [settings, { ref }, packs] = await Promise.all([getSettings(STORE_IDS.AEROLINK), searchParams, listPackChoices(STORE_IDS.AEROLINK)]);
  const storeUrl = settings[SETTING_KEYS.storeUrl];

  return (
    <main className="relative flex min-h-screen flex-1 flex-col overflow-x-clip bg-background">
      <LandingNav logoText={settings[SETTING_KEYS.logoText]} links={NAV_LINKS} cta={{ href: "/redeem", label: "Redeem a voucher" }} />

      <section id="activate" className="scroll-mt-20">
        <div className="mx-auto grid w-full max-w-6xl gap-12 px-6 pt-12 pb-12 sm:pt-16 lg:grid-cols-12 lg:gap-10 lg:pt-20 lg:pb-16">
          {/* Editorial column */}
          <div className="lg:col-span-6 lg:pr-4">
            <p className="flex items-center gap-3 text-sm font-medium text-muted-foreground">
              <span aria-hidden className="h-px w-6 bg-primary" />
              Activate your access
            </p>
            <h1 className="mt-6 font-display text-[2.4rem] leading-[1.03] font-semibold tracking-[-0.025em] text-balance sm:text-5xl lg:text-[3.6rem]">
              From your order to your agent, in three steps.
            </h1>
            <p className="mt-6 max-w-lg text-lg leading-relaxed text-muted-foreground text-pretty">
              Bought a plan on our store? Enter your Order ID and the plan you chose. Your access code is created on the spot, and your balance
              is ready once we verify the order.
            </p>
            <div className="mt-7 flex flex-wrap gap-x-6 gap-y-2 text-sm font-medium">
              <Link href="/login" className="inline-flex items-center gap-1.5 underline-offset-4 hover:underline">
                Already have a code? Sign in <ArrowRight className="size-3.5" />
              </Link>
              <Link href="/redeem" className="inline-flex items-center gap-1.5 text-muted-foreground underline-offset-4 hover:text-foreground hover:underline">
                Got a voucher? Redeem it <ArrowRight className="size-3.5" />
              </Link>
            </div>
          </div>

          {/* The activation journey */}
          <div className="flex justify-center lg:col-span-6 lg:col-start-7 lg:justify-end">
            <ActivationWizard siteName={settings[SETTING_KEYS.siteName]} storeUrl={storeUrl} initialRef={ref} packs={packs} />
          </div>
        </div>

        {/* The journey at a glance, full width under the hero */}
        <div className="mx-auto w-full max-w-6xl px-6 pb-20 lg:pb-28">
          <AccessPass />
        </div>
      </section>

      <LandingSections storeId={STORE_IDS.AEROLINK} activateHref="#activate" />

      <LandingFooter storeId={STORE_IDS.AEROLINK} />
    </main>
  );
}
