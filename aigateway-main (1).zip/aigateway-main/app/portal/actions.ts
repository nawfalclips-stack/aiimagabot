"use server";

import { revalidatePath } from "next/cache";
import { getCurrentCustomer } from "@/lib/auth";
import { claimReviewBonus } from "@/lib/services/review-bonus";
import { requestReward } from "@/lib/services/loyalty";
import { prisma } from "@/lib/prisma";

export type PortalActionResult = { ok: true } | { ok: false; error: string };

/** Customer presses "Yes, I wrote a review" — credits the pending bonus. */
export async function claimReviewBonusAction(): Promise<PortalActionResult> {
  try {
    const customer = await getCurrentCustomer();
    if (!customer) return { ok: false, error: "Your session has expired. Sign in again." };

    await claimReviewBonus(customer.id);
    revalidatePath("/portal", "layout");
    revalidatePath("/admin", "layout");
    return { ok: true };
  } catch (error) {
    const message =
      error instanceof Error && error.message.length < 200 ? error.message : "Something went wrong. Try again.";
    return { ok: false, error: message };
  }
}

export async function requestRewardAction(): Promise<PortalActionResult> {
  try {
    const customer = await getCurrentCustomer();
    if (!customer) return { ok: false, error: "Your session has expired. Sign in again." };

    const result = await requestReward(customer.id);
    if (!result.ok) return { ok: false, error: result.error ?? "Could not request the reward." };

    revalidatePath("/portal", "layout");
    revalidatePath("/admin", "layout");
    return { ok: true };
  } catch (error) {
    console.error(error);
    return { ok: false, error: "Could not send the reward request. Please try again." };
  }
}

/** Customer asks the admin to pay out their reached affiliate milestone bonus. */
export async function claimAffiliateMilestoneAction(): Promise<PortalActionResult> {
  try {
    const customer = await getCurrentCustomer();
    if (!customer) return { ok: false, error: "Your session has expired. Sign in again." };

    const full = await prisma.customer.findUniqueOrThrow({
      where: { id: customer.id },
      select: { affiliateMilestoneStatus: true },
    });
    if (full.affiliateMilestoneStatus === "PENDING") {
      return { ok: false, error: "Your milestone bonus is already waiting for approval." };
    }
    if (full.affiliateMilestoneStatus === "APPROVED") {
      return { ok: false, error: "You already claimed this milestone bonus." };
    }

    // Only reachable when a milestone threshold is actually met.
    await prisma.customer.update({
      where: { id: customer.id },
      data: { affiliateMilestoneStatus: "PENDING" },
    });

    // Bell notification so the admin sees the claim immediately.
    const { createNotification, NOTIFICATION_TYPES } = await import("@/lib/services/notifications");
    await createNotification({
      storeId: customer.storeId as never,
      type: NOTIFICATION_TYPES.AFFILIATE_MILESTONE_CLAIMED,
      title: "Affiliate Milestone Claimed",
      message: `${customer.accessCode} requested their affiliate milestone bonus. Review it in Affiliate Management.`,
      customerId: customer.id,
      relatedId: customer.id,
    });

    revalidatePath("/portal/affiliate");
    revalidatePath("/admin", "layout");
    return { ok: true };
  } catch (error) {
    console.error(error);
    return { ok: false, error: "Could not send the claim. Please try again." };
  }
}

/** The customer opened their inbox (or dismissed a banner): mark announcements read. */
export async function markAnnouncementsReadAction(ids?: string[]): Promise<PortalActionResult> {
  try {
    const customer = await getCurrentCustomer();
    if (!customer) return { ok: false, error: "Your session has expired. Sign in again." };
    const { markAnnouncementsRead } = await import("@/lib/services/announcements");
    await markAnnouncementsRead(customer.storeId, customer.id, ids?.slice(0, 100));
    revalidatePath("/portal", "layout");
    return { ok: true };
  } catch (error) {
    console.error(error);
    return { ok: false, error: "Could not update your notifications." };
  }
}
