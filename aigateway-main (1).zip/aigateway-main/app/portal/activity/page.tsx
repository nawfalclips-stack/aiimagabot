import type { Metadata } from "next";
import Link from "next/link";
import { ScrollText } from "lucide-react";
import { requireCustomer } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { formatMicroUsd } from "@/lib/billing/money";
import { Card } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { EmptyState } from "@/components/shared/empty-state";
import { PageHeader } from "@/components/shared/page-header";
import { LocalTime } from "@/components/shared/local-time";
import { cn } from "@/lib/utils";
import { redactKeys } from "@/lib/services/legacy-pool";
import { aliasFor, getCustomerUsageByModel, getModelAliases } from "@/lib/services/customer-usage";

export const metadata: Metadata = { title: "Activity Logs" };
export const dynamic = "force-dynamic";

const OUTCOME_LABELS: Record<string, string> = {
  COMPLETED: "OK",
  CLIENT_DISCONNECTED: "Cancelled",
  UPSTREAM_ERROR: "Upstream error",
  TIMEOUT: "Timeout",
};

const SUMMARY_DAYS = 30;

/** Start of the per-model summary window (kept out of render for the purity lint). */
function daysAgo(days: number): Date {
  return new Date(Date.now() - days * 24 * 60 * 60 * 1000);
}

const compactTokens = (n: number) => new Intl.NumberFormat("en", { notation: "compact", maximumFractionDigits: 1 }).format(n);

/**
 * WS7: only real requests served by the gateway are listed here, with the
 * amount actually charged. Charges entered by our team are not API requests —
 * they appear in the balance history on the dashboard.
 */
export default async function PortalActivityPage() {
  const customer = await requireCustomer();
  const aliases = await getModelAliases();
  const [logs, manualCount, byModel] = await Promise.all([
    prisma.usageLog.findMany({
      where: { customerId: customer.id, requestId: { not: null } },
      orderBy: { happenedAt: "desc" },
      take: 300,
    }),
    prisma.usageLog.count({ where: { customerId: customer.id, requestId: null } }),
    getCustomerUsageByModel(customer.id, daysAgo(SUMMARY_DAYS), aliases),
  ]);

  const totalMicro = logs.reduce((sum, log) => sum + (log.customerMicroUsd ?? 0n), 0n);

  return (
    <div className="space-y-6">
      <PageHeader
        eyebrow="Account"
        title="Activity Logs"
        description="Requests made with your AeroLink API tokens, with the amount charged for each."
        actions={
          logs.length > 0 ? (
            <div className="flex divide-x rounded-xl border bg-card shadow-card">
              <div className="px-4 py-2">
                <p className="eyebrow text-[10px]">Requests</p>
                <p className="font-display text-lg font-semibold tabular-nums">{logs.length}</p>
              </div>
              <div className="px-4 py-2">
                <p className="eyebrow text-[10px]">Total charged</p>
                <p className="font-display text-lg font-semibold tabular-nums">{formatMicroUsd(totalMicro)}</p>
              </div>
            </div>
          ) : null
        }
      />

      {manualCount > 0 ? (
        <p className="text-sm text-muted-foreground">
          Charges added by our team are not API requests and are listed in your{" "}
          <Link href="/portal#balance-history" className="font-medium text-foreground underline-offset-4 hover:underline">
            balance history
          </Link>
          .
        </p>
      ) : null}

      {byModel.length > 0 ? (
        <section className="space-y-3" aria-labelledby="by-model">
          <h2 id="by-model" className="text-sm font-semibold">
            Models you used · last {SUMMARY_DAYS} days
          </h2>
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {byModel.map((m) => (
              <Card key={m.slug} className="gap-2 p-4">
                <div className="flex items-baseline justify-between gap-2">
                  <p className="truncate font-medium" title={m.name}>
                    {m.name}
                  </p>
                  <p className="font-display text-lg font-semibold tabular-nums">{formatMicroUsd(m.chargedMicroUsd)}</p>
                </div>
                <p className="font-mono text-[11px] text-muted-foreground">{m.slug}</p>
                <p className="text-xs text-muted-foreground tabular-nums">
                  {m.requests} request{m.requests === 1 ? "" : "s"} · {compactTokens(m.inputTokens)} in / {compactTokens(m.outputTokens)} out
                  {m.lastUsedAt ? (
                    <>
                      {" "}· last <LocalTime date={m.lastUsedAt.toISOString()} variant="date" />
                    </>
                  ) : null}
                </p>
              </Card>
            ))}
          </div>
        </section>
      ) : null}

      <Card className="overflow-hidden p-0">
        {logs.length === 0 ? (
          <EmptyState
            icon={ScrollText}
            title="No requests yet"
            description="Create a token on the API Access page and point your tool at AeroLink. Your requests will appear here."
            className="border-0"
          />
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="hover:bg-transparent">
                  <TableHead className="pl-4">Time</TableHead>
                  <TableHead>Token</TableHead>
                  <TableHead>Model</TableHead>
                  <TableHead>Tokens</TableHead>
                  <TableHead>Cost</TableHead>
                  <TableHead>Latency</TableHead>
                  <TableHead className="pr-4">Status</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {logs.map((log) => {
                  const ok = log.outcome === "" || log.outcome === "COMPLETED";
                  const estimated = log.usageSource === "ESTIMATED";
                  return (
                    <TableRow key={log.id}>
                      <TableCell className="pl-4 text-xs text-muted-foreground whitespace-nowrap">
                        <LocalTime date={log.happenedAt.toISOString()} />
                      </TableCell>
                      <TableCell className="text-xs">{redactKeys(log.keyLabel) || "—"}</TableCell>
                      <TableCell>
                        {log.model ? (
                          <span className="flex flex-col">
                            <span className="text-[13px] font-medium whitespace-nowrap">{aliasFor(aliases, log.model).name}</span>
                            <span className="font-mono text-[11px] text-muted-foreground">{aliasFor(aliases, log.model).slug}</span>
                          </span>
                        ) : (
                          "—"
                        )}
                      </TableCell>
                      <TableCell className="text-xs tabular-nums text-muted-foreground" title={estimated ? "Estimated: the provider reported no usage" : undefined}>
                        {log.tokens || "—"}
                      </TableCell>
                      <TableCell className="font-medium tabular-nums">{formatMicroUsd(log.customerMicroUsd ?? 0n)}</TableCell>
                      <TableCell className="text-muted-foreground">{log.latency || "—"}</TableCell>
                      <TableCell className="pr-4">
                        <span
                          className={cn(
                            "inline-flex items-center gap-1.5 rounded-full px-2 py-0.5 text-xs font-medium before:size-1.5 before:rounded-full before:bg-current",
                            ok ? "bg-success/12 text-success" : "bg-destructive/12 text-destructive"
                          )}
                        >
                          {OUTCOME_LABELS[log.outcome] ?? (log.status || "—")}
                        </span>
                      </TableCell>
                    </TableRow>
                  );
                })}
              </TableBody>
            </Table>
          </div>
        )}
      </Card>
      {logs.some((l) => l.usageSource === "ESTIMATED") ? (
        <p className="text-xs text-muted-foreground">
          Token counts marked ~ are estimated because the provider did not report usage for that request.
        </p>
      ) : null}
    </div>
  );
}
