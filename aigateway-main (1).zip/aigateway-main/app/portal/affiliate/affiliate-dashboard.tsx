"use client";

import { useTransition } from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { motion } from "framer-motion";
import { CheckCircle2, Clock, Copy, Gift, Link2, Loader2, ShoppingBag, Users } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { PageHeader } from "@/components/shared/page-header";
import { StatCard } from "@/components/shared/stat-card";
import { Callout } from "@/components/shared/callout";
import { Steps } from "@/components/shared/steps";
import { EmptyState } from "@/components/shared/empty-state";
import { formatCents } from "@/lib/money";
import {
  getReachedMilestone,
  getNextMilestone,
  type AffiliateMilestone,
} from "@/lib/affiliate";
import { claimAffiliateMilestoneAction } from "@/app/portal/actions";

interface ReferralRow {
  accessCode: string;
  createdAt: string;
  balanceCents: number;
  status: string;
}

interface AffiliateDashboardProps {
  code: string;
  referralUrl: string;
  /** Official store URL the friend must buy from. */
  storeUrl: string;
  earnedCents: number;
  milestoneStatus: string;
  referralCount: number;
  totalSpendCents: number;
  /** Every purchase each referral made — for pack-count milestones. */
  purchasesCents: number[];
  /** Per-milestone pack progress: { id, count, requiredCount }. */
  progress: Array<{ id: string; count: number; requiredCount: number }>;
  referrals: ReferralRow[];
  milestones: Array<Pick<AffiliateMilestone, "id" | "label" | "packCents" | "requiredCount" | "rewardCents">>;
}

export function AffiliateDashboard(props: AffiliateDashboardProps) {
  const [pending, startTransition] = useTransition();
  const router = useRouter();

  const reached = getReachedMilestone(props.purchasesCents ?? []);
  const next = getNextMilestone(props.purchasesCents ?? []);
  const canClaim = reached !== null && props.milestoneStatus === "NONE";

  const copyLink = async () => {
    try {
      await navigator.clipboard.writeText(props.referralUrl);
      toast.success("Referral link copied! Share it with your friends.");
    } catch {
      toast.error("Could not copy — select the link and copy it manually.");
    }
  };

  const claim = () => {
    startTransition(async () => {
      const result = await claimAffiliateMilestoneAction();
      if (result.ok) {
        toast.success("Claim sent!", { description: "An administrator will review your milestone bonus." });
        router.refresh();
      } else if (result.error) {
        toast.error(result.error);
      }
    });
  };

  return (
    <div className="max-w-3xl space-y-6">
      <PageHeader
        eyebrow="Rewards"
        title="Affiliate Program"
        description={
          <>
            Invite friends, earn <strong className="text-foreground">$5 + points</strong> automatically for every purchase
            they make — plus big bonuses when your invites buy 10 packs of the same size.
          </>
        }
      />

      {/* Referral link — the thing people come here for */}
      <motion.section
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative overflow-hidden rounded-2xl border border-primary/25 bg-card p-5 shadow-card sm:p-6"
      >
        <span aria-hidden className="pointer-events-none absolute -top-24 -right-16 size-64 rounded-full bg-primary/10 blur-3xl" />
        <p className="relative flex items-center gap-2 text-sm font-semibold">
          <Link2 className="size-4 text-primary" /> Your referral link
        </p>
        <p className="relative mt-1 text-xs text-muted-foreground">
          Send this to your friend. They must open the site through it (or type your code) when they activate their account.
        </p>
        <div className="relative mt-4 flex flex-col gap-2 sm:flex-row">
          <code className="flex h-10 flex-1 items-center truncate rounded-xl border bg-muted/40 px-3.5 font-mono text-sm">
            {props.referralUrl}
          </code>
          <Button onClick={copyLink} className="h-10 gap-2 sm:w-auto">
            <Copy className="size-4" /> Copy link
          </Button>
        </div>
        <div className="relative mt-3 flex items-center gap-2 text-sm">
          <span className="text-muted-foreground">Your code:</span>
          <code className="rounded-md bg-primary/10 px-2 py-0.5 font-mono font-bold text-primary">{props.code}</code>
        </div>
      </motion.section>

      {/* Stats */}
      <section className="grid grid-cols-1 gap-3 sm:grid-cols-3 sm:gap-4">
        <StatCard title="Friends invited" value={props.referralCount} icon="users" tone="primary" index={0} />
        <StatCard
          title="Their total purchases"
          value={props.totalSpendCents / 100}
          format="money"
          icon="shoppingCart"
          index={1}
        />
        <StatCard
          title="Your earnings"
          value={props.earnedCents / 100}
          format="money"
          icon="wallet"
          tone="success"
          hint="$5 per purchase"
          index={2}
        />
      </section>

      {/* How it works — conditions */}
      <Card>
        <CardHeader>
          <CardTitle>Conditions &amp; how it works</CardTitle>
          <CardDescription>Your friends must buy from our official store for your commission to count.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-5">
          <Steps
            items={[
              { title: "Share your link", body: "Send the link above to your friend — it contains your personal code." },
              { title: "They buy from our GamsGo store", body: "Any offer works." },
              {
                title: "They activate on our site through YOUR link",
                body: "Their referral code field is filled with your code automatically. Without your code in their activation, the commission cannot be attributed.",
              },
              {
                title: "You earn automatically",
                body: (
                  <>
                    Once their activation is approved: <strong className="text-success">$5 cash</strong> + points (half of
                    what they earn from the purchase, minimum 15). Every repurchase of theirs earns you again.
                  </>
                ),
              },
              {
                title: "Milestones",
                body: "When your invited friends buy the same pack size 10 times in total — 10× $100 packs earn you $120, 10× $200 packs earn $250, 10× $300 packs earn $400. The reward is added to your balance after admin approval.",
              },
            ]}
          />
          <Button asChild variant="outline">
            <a href={props.storeUrl} target="_blank" rel="noopener noreferrer">
              <ShoppingBag /> Open the store
            </a>
          </Button>
        </CardContent>
      </Card>

      {/* Milestones */}
      <Card>
        <CardHeader>
          <CardTitle>Milestone bonuses</CardTitle>
          <CardDescription>
            A milestone completes when your invited friends buy the same pack size 10 times in total (their recharges count
            too). The reward is added to your main balance after admin approval.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2.5">
            {props.milestones.map((m) => {
              const progress = props.progress.find((p) => p.id === m.id);
              const count = progress?.count ?? 0;
              const required = progress?.requiredCount ?? m.requiredCount;
              const isReached = count >= required;
              const pct = Math.min(100, Math.round((count / Math.max(1, required)) * 100));
              return (
                <div
                  key={m.id}
                  className={`rounded-xl border px-4 py-3.5 ${isReached ? "border-success/35 bg-success/7" : "bg-muted/25"}`}
                >
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <div className="flex items-center gap-3">
                      <span
                        className={`flex size-8 shrink-0 items-center justify-center rounded-lg ${
                          isReached ? "bg-success/15 text-success" : "bg-card text-muted-foreground shadow-card"
                        }`}
                      >
                        <Gift className="size-4" />
                      </span>
                      <div>
                        <p className={`text-sm ${isReached ? "font-semibold text-success" : "font-medium"}`}>
                          10 × {formatCents(m.packCents)} packs
                        </p>
                        <p className="text-xs text-muted-foreground">
                          Reward <strong className="text-foreground">{formatCents(m.rewardCents)}</strong> → added to your balance
                        </p>
                      </div>
                    </div>
                    {isReached ? (
                      <span className="inline-flex items-center gap-1.5 rounded-full border border-success/40 bg-success/10 px-2.5 py-1 text-xs font-medium text-success">
                        <CheckCircle2 className="size-3.5" /> Complete
                      </span>
                    ) : (
                      <span className="text-xs font-medium text-muted-foreground tabular-nums">
                        {count}/{required} packs
                      </span>
                    )}
                  </div>
                  <div className="mt-3 h-1.5 overflow-hidden rounded-full bg-muted">
                    <div
                      className={`h-full rounded-full ${isReached ? "bg-success" : "bg-primary"}`}
                      style={{ width: `${pct}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>

          {canClaim && reached ? (
            <Callout
              icon={Gift}
              title={`Milestone complete: “${reached.label}” — your ${formatCents(reached.rewardCents)} reward is ready!`}
              action={
                <Button onClick={claim} disabled={pending} className="gap-2">
                  {pending ? <Loader2 className="size-4 animate-spin" /> : <Gift className="size-4" />}
                  Request my {formatCents(reached.rewardCents)} reward
                </Button>
              }
            >
              Press the button to request it. An administrator will verify your referrals&apos; orders and add the reward to
              your <strong className="text-foreground">main balance</strong>.
            </Callout>
          ) : props.milestoneStatus === "PENDING" ? (
            <Callout tone="warning" icon={Clock} title="Reward request pending.">
              An administrator will review it soon.
            </Callout>
          ) : props.milestoneStatus === "APPROVED" ? (
            <Callout tone="success" icon={CheckCircle2} title="Reward approved — added to your balance!">
              Keep inviting friends to complete the next milestone.
            </Callout>
          ) : null}
          {!canClaim && props.milestoneStatus === "NONE" && next ? (
            <p className="text-sm text-muted-foreground">
              Complete <strong className="text-foreground">{next.label}</strong> to unlock a {formatCents(next.rewardCents)}{" "}
              reward.
            </p>
          ) : null}
        </CardContent>
      </Card>

      {/* Referral list */}
      <Card className="gap-0 overflow-hidden pb-0">
        <CardHeader className="border-b pb-5">
          <CardTitle>Your invited friends</CardTitle>
          <CardDescription>
            {props.referrals.length} {props.referrals.length === 1 ? "friend" : "friends"} joined through your link.
          </CardDescription>
        </CardHeader>
        {props.referrals.length === 0 ? (
          <div className="p-5">
            <EmptyState
              icon={Users}
              title="No friends yet"
              description="Share your link above to start earning."
              className="py-10"
            />
          </div>
        ) : (
          <Table>
            <TableHeader>
              <TableRow className="hover:bg-transparent">
                <TableHead className="pl-6">Friend</TableHead>
                <TableHead>Joined</TableHead>
                <TableHead>Their plan</TableHead>
                <TableHead className="pr-6">Status</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {props.referrals.map((r) => (
                <TableRow key={r.accessCode}>
                  <TableCell className="pl-6 font-mono">{r.accessCode}</TableCell>
                  <TableCell className="text-muted-foreground">{new Date(r.createdAt).toLocaleDateString()}</TableCell>
                  <TableCell className="tabular-nums">{formatCents(r.balanceCents)}</TableCell>
                  <TableCell className="pr-6">{r.status}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        )}
      </Card>
    </div>
  );
}
