import type { Metadata } from "next";
import { requireCustomer } from "@/lib/auth";
import { ensureAffiliateCode, getAffiliateStats } from "@/lib/services/affiliate";
import { getSettings } from "@/lib/services/settings";
import { SETTING_KEYS } from "@/lib/constants";
import { headers } from "next/headers";
import { AFFILIATE_MILESTONES, milestoneProgress } from "@/lib/affiliate";
import type { StoreId } from "@/lib/store";
import { AffiliateDashboard } from "./affiliate-dashboard";

export const metadata: Metadata = { title: "Affiliate Program" };
export const dynamic = "force-dynamic";

export default async function AffiliatePage() {
  const customer = await requireCustomer();
  const code = await ensureAffiliateCode(customer.id);
  const stats = await getAffiliateStats(customer.id);
  const settings = await getSettings(customer.storeId as StoreId);
  const storeUrl = settings[SETTING_KEYS.storeUrl];

  const h = await headers();
  const host = h.get("x-forwarded-host") ?? h.get("host") ?? "localhost:3000";
  const proto = h.get("x-forwarded-proto") ?? "http";
  // Clean shareable link: /affiliate/CODE — forwards to the form pre-filled.
  const referralUrl = `${proto}://${host}/affiliate/${code}`;

  return (
    <AffiliateDashboard
      code={code}
      referralUrl={referralUrl}
      storeUrl={storeUrl}
      earnedCents={customer.affiliateEarnedCents}
      milestoneStatus={customer.affiliateMilestoneStatus}
      referralCount={stats.referralCount}
      totalSpendCents={stats.totalSpendCents}
      purchasesCents={stats.purchasesCents}
      progress={milestoneProgress(stats.purchasesCents).map((p) => ({
        id: p.milestone.id,
        count: p.count,
        requiredCount: p.milestone.requiredCount,
      }))}
      referrals={stats.referrals.map((r) => ({
        accessCode: r.accessCode,
        createdAt: r.createdAt.toISOString(),
        balanceCents: r.initialBalanceCents,
        status: r.status,
      }))}
      milestones={AFFILIATE_MILESTONES.map((m) => ({
        id: m.id,
        label: m.label,
        packCents: m.packCents,
        requiredCount: m.requiredCount,
        rewardCents: m.rewardCents,
      }))}
    />
  );
}
