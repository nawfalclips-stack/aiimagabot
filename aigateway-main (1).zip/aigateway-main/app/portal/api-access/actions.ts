"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { requireCustomer } from "@/lib/auth";
import { createGatewayToken, revealGatewayToken, revokeGatewayToken } from "@/lib/gateway/tokens";
import { logActivity } from "@/lib/services/activity";
import type { StoreId } from "@/lib/store";

export type TokenActionResult<T = undefined> = { ok: true; data?: T } | { ok: false; error: string };

export async function createTokenAction(name: string): Promise<TokenActionResult<{ token: string; id: string }>> {
  try {
    const customer = await requireCustomer();
    if (!customer.isActivated) return { ok: false, error: "Your account is still waiting for activation." };
    const clean = z.string().trim().max(40).parse(name);
    const { token, row } = await createGatewayToken(customer.id, customer.storeId, clean);
    await logActivity({
      storeId: customer.storeId as StoreId,
      action: "API_KEY_CHANGED",
      description: `Customer ${customer.accessCode} created gateway token "${row.name}" (${row.prefix}…)`,
      customerId: customer.id,
    });
    revalidatePath("/portal/api-access");
    return { ok: true, data: { token, id: row.id } };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : "Could not create the token." };
  }
}

export async function revokeTokenAction(tokenId: string): Promise<TokenActionResult> {
  try {
    const customer = await requireCustomer();
    const ok = await revokeGatewayToken(customer.id, z.string().min(1).parse(tokenId));
    if (!ok) return { ok: false, error: "Token not found or already revoked." };
    await logActivity({
      storeId: customer.storeId as StoreId,
      action: "API_KEY_CHANGED",
      description: `Customer ${customer.accessCode} revoked a gateway token`,
      customerId: customer.id,
    });
    revalidatePath("/portal/api-access");
    return { ok: true };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : "Could not revoke the token." };
  }
}

/** Full token text for the customer's own token (used by "select a token → copy"). */
export async function revealTokenAction(tokenId: string): Promise<TokenActionResult<{ token: string }>> {
  try {
    const customer = await requireCustomer();
    const token = await revealGatewayToken(customer.id, z.string().min(1).parse(tokenId));
    if (!token) return { ok: false, error: "This token was created before copying was supported — create a new one." };
    return { ok: true, data: { token } };
  } catch (e) {
    return { ok: false, error: e instanceof Error ? e.message : "Could not load the token." };
  }
}
