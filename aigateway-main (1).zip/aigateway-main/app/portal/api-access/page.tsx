import type { Metadata } from "next";
import { resolveBaseUrl } from "@/lib/base-url";
import { requireCustomer } from "@/lib/auth";
import type { StoreId } from "@/lib/store";
import { prisma } from "@/lib/prisma";
import { getCustomerBillingRate, tokensUsedOnPlan } from "@/lib/services/plan-usage";
import { listModelsForStore } from "@/lib/gateway/registry";
import { ApiAccessView, type TokenRow, type ModelInfo, type PlanSummary } from "@/components/portal/api-access-view";

export const metadata: Metadata = { title: "API Access" };
export const dynamic = "force-dynamic";

export default async function ApiAccessPage() {
  const customer = await requireCustomer();
  const [tokens, models, rate, baseUrl] = await Promise.all([
    prisma.gatewayToken.findMany({ where: { customerId: customer.id }, orderBy: { createdAt: "desc" } }),
    listModelsForStore(customer.storeId),
    getCustomerBillingRate(customer.id, customer.storeId as StoreId),
    resolveBaseUrl(),
  ]);

  const tokenRows: TokenRow[] = tokens.map((t) => ({
    id: t.id,
    name: t.name,
    prefix: t.prefix,
    createdAt: t.createdAt.toISOString(),
    lastUsedAt: t.lastUsedAt?.toISOString() ?? null,
    revokedAt: t.revokedAt?.toISOString() ?? null,
    canReveal: t.tokenEnc.length > 0,
  }));

  // Prices exactly as saved on the admin Models page (µ$ per 1M → cents),
  // not multiplied by the customer's plan. Billing is unaffected: each request
  // is still charged real cost × plan rate (see Activity Logs).
  const toCents = (micro: number) => micro / 10_000;
  const modelInfos: ModelInfo[] = models.map((m) => {
    const price = {
      input: toCents(m.inputPriceMicroPerMTok),
      cachedInput: toCents(m.cachedInputPriceMicroPerMTok ?? m.inputPriceMicroPerMTok),
      output: toCents(m.outputPriceMicroPerMTok),
    };
    return {
      // Public alias only — the real model stays admin-side.
      slug: m.publicSlug,
      displayName: m.publicName,
      inputCentsPerMTok: price.input,
      cachedInputCentsPerMTok: price.cachedInput,
      outputCentsPerMTok: price.output,
      contextWindow: m.contextWindow,
    };
  });

  let plan: PlanSummary | null = null;
  if (rate.plan) {
    const full = await prisma.customer.findUnique({ where: { id: customer.id }, select: { planAssignedAt: true } });
    plan = {
      name: rate.plan.name,
      description: rate.plan.description,
      priceCents: rate.plan.priceCents,
      limitType: rate.plan.limitType === "TOKENS" ? "TOKENS" : "USD",
      limitMTokens: rate.plan.limitMTokens,
      tokensUsed: rate.plan.limitType === "TOKENS" ? await tokensUsedOnPlan(customer.id, full?.planAssignedAt ?? null) : 0,
    };
  }

  return <ApiAccessView baseUrl={baseUrl} tokens={tokenRows} models={modelInfos} plan={plan} />;
}
