import type { Metadata } from "next";
import { requireCustomer } from "@/lib/auth";
import { resolveBaseUrl } from "@/lib/base-url";
import { listModelsForStore } from "@/lib/gateway/registry";
import type { StoreId } from "@/lib/store";
import { getAllDocs, renderDocForCustomer } from "@/lib/services/documentation";
import { DocsViewer, type PortalDoc } from "@/components/portal/docs-viewer";
import { UNIVERSAL_DOC_CATEGORIES } from "@/lib/constants";

export const metadata: Metadata = { title: "Documentation" };
export const dynamic = "force-dynamic";

/**
 * Detect which model-family guides (Claude Code + Claude Desktop / Codex) the customer should see
 * from their offer title. OpenCode, More agents and API & SDKs are always shown.
 */
function allowedCategories(offerTitle: string): string[] | null {
  const t = offerTitle.toLowerCase();
  const hasClaude = t.includes("claude");
  const hasCodexOrGpt = t.includes("codex") || t.includes("gpt");
  if (hasClaude && hasCodexOrGpt) return null; // show all
  if (hasClaude) return ["CLAUDE", "DESKTOP"];
  if (hasCodexOrGpt) return ["CODEX"];
  return null; // unknown offer -> show all
}

export default async function PortalDocumentationPage() {
  const customer = await requireCustomer();
  const [allDocs, baseUrl, models] = await Promise.all([
    getAllDocs(customer.storeId as StoreId),
    resolveBaseUrl(),
    listModelsForStore(customer.storeId),
  ]);
  const vars = { baseUrl, model: models[0]?.publicSlug ?? null };

  const allowed = allowedCategories(customer.offerTitle);
  const docs = allowed
    ? allDocs.filter((d) => allowed.includes(d.category) || (UNIVERSAL_DOC_CATEGORIES as readonly string[]).includes(d.category))
    : allDocs;

  const rendered: PortalDoc[] = docs.map((d) => ({
    slug: d.slug,
    category: d.category,
    os: d.os,
    title: d.title,
    content: renderDocForCustomer(d.content, vars),
  }));

  return <DocsViewer docs={rendered} baseUrl={baseUrl} />;
}
