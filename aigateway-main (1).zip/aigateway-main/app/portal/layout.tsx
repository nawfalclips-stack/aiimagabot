import type { Metadata } from "next";
import { requireCustomer } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { getSettings } from "@/lib/services/settings";
import { SETTING_KEYS } from "@/lib/constants";
import { PortalShell } from "@/components/portal/portal-shell";
import { PendingActivationScreen } from "@/components/portal/pending-activation-screen";
import { getTierForPoints } from "@/lib/loyalty";
import { getLoyaltyProgram } from "@/lib/services/loyalty-program";
import type { StoreId } from "@/lib/store";
import { parseSocialLinks } from "@/lib/social-links";
import { countUnreadAnnouncements } from "@/lib/services/announcements";

export const metadata: Metadata = {
  title: "Your Dashboard",
  robots: { index: false, follow: false },
};

export default async function PortalLayout({ children }: { children: React.ReactNode }) {
  const customer = await requireCustomer();
  const settings = await getSettings(customer.storeId as StoreId);
  const storeUrl = settings[SETTING_KEYS.storeUrl];
  const socialLinks = parseSocialLinks(settings[SETTING_KEYS.socialLinks]);

  // Fetch activation state (isActivated, rejectedAt, rejectionReason).
  const full = await prisma.customer.findUnique({
    where: { id: customer.id },
    select: { isActivated: true, rejectedAt: true, rejectionReason: true, accessCode: true, loyaltyPoints: true },
  });

  // Loyalty level tints the whole dashboard with the level accent color.
  const { tiers } = await getLoyaltyProgram(customer.storeId as StoreId);
  const tier = getTierForPoints(full?.loyaltyPoints ?? 0, tiers);

  if (full && !full.isActivated) {
    return (
      <PendingActivationScreen
        storeUrl={storeUrl}
        accessCode={full.accessCode}
        isRejected={!!full.rejectedAt}
        rejectionReason={full.rejectionReason}
        logoText={settings[SETTING_KEYS.logoText]}
        footerText={settings[SETTING_KEYS.footerText]}
        socialLinks={socialLinks}
      />
    );
  }

  const unreadNotifications = await countUnreadAnnouncements(customer.storeId, customer.id);

  return (
    <div style={{ ["--loyalty" as string]: tier.colorHex }}>
      <PortalShell
        logoText={settings[SETTING_KEYS.logoText]}
        footerText={settings[SETTING_KEYS.footerText]}
        storeUrl={storeUrl}
        socialLinks={socialLinks}
        unreadNotifications={unreadNotifications}
      >
        {children}
      </PortalShell>
    </div>
  );
}
