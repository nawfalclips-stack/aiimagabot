"use client";

import { useTransition } from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { motion } from "framer-motion";
import {
  Award,
  CheckCircle2,
  Clock,
  Gift,
  Loader2,
  ShoppingBag,
  Sparkles,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { formatCents } from "@/lib/money";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { PageHeader } from "@/components/shared/page-header";

interface Tier {
  id: string;
  name: string;
  minPoints: number;
  colorHex: string;
  rewardAmountCents: number;
}

interface EarningRules {
  basePoints: number;
  overflowPercent: number;
  /** Highest first. */
  brackets: Array<{ minCents: number; points: number }>;
}

const dollars = (cents: number) => `$${(cents / 100).toLocaleString("en-US", { maximumFractionDigits: 2 })}`;

/** The "How to earn points" lines, generated from the store's program. */
function earningLines(e: EarningRules): string[] {
  const asc = [...e.brackets].sort((a, b) => a.minCents - b.minCents);
  const lines: string[] = [];
  if (asc.length === 0) {
    lines.push(`Every purchase earns ${e.basePoints} points.`);
  } else {
    lines.push(`A purchase below ${dollars(asc[0].minCents)} earns ${e.basePoints} points.`);
    lines.push(`Bigger purchases earn more (${asc.map((b) => `${dollars(b.minCents)} → ${b.points}`).join(" · ")}).`);
    if (e.overflowPercent > 0) {
      lines.push(`Above a bracket, every extra dollar earns ${Number((e.overflowPercent / 100).toFixed(2))} points.`);
    }
  }
  lines.push("A friend who joins through your affiliate link earns you +15 points on each of their purchases (or half of their points when larger).");
  return lines;
}

interface LoyaltyPageClientProps {
  points: number;
  /** How points are earned in this store's program. */
  earning: EarningRules;
  purchaseCount: number;
  rewardRequestStatus: string; // NONE | PENDING | APPROVED | REJECTED
  tiers: Tier[];
  onRequestReward: () => Promise<{ ok: boolean; error?: string }>;
}

/**
 * The customer's dedicated Loyalty page (/portal/loyalty): everything about
 * points, levels and the cash-reward claim in one place.
 */
export function LoyaltyPageClient(props: LoyaltyPageClientProps) {
  const [pending, startTransition] = useTransition();
  const router = useRouter();

  const sorted = [...props.tiers].sort((a, b) => a.minPoints - b.minPoints);
  const current =
    [...sorted].reverse().find((t) => props.points >= t.minPoints) ?? sorted[0];
  const next = sorted.find((t) => t.minPoints > props.points) ?? null;
  const progressPct = next
    ? Math.min(100, Math.round(((props.points - current.minPoints) / (next.minPoints - current.minPoints)) * 100))
    : 100;

  const canRequest = props.rewardRequestStatus === "NONE" || props.rewardRequestStatus === "REJECTED";
  const canClaimNow = current.rewardAmountCents > 0 && canRequest;
  const unlock = sorted.find((t) => t.rewardAmountCents > 0) ?? null;

  const request = () => {
    startTransition(async () => {
      const result = await props.onRequestReward();
      if (result.ok) {
        toast.success("Reward request sent!", {
          description: "An administrator will verify it and approve or reject.",
        });
        router.refresh();
      } else if (result.error) {
        toast.error(result.error);
      }
    });
  };

  return (
    <div className="max-w-3xl space-y-6">
      {/* Header */}
      <PageHeader
        eyebrow="Rewards"
        title="Loyalty Program"
        description="Earn points with every purchase, level up, and claim your cash reward — reviewed by an administrator before payout."
      />

      {/* Level card */}
      <motion.section
        initial={{ opacity: 0, y: 8 }}
        animate={{ opacity: 1, y: 0 }}
        className="relative overflow-hidden rounded-2xl border bg-card p-6 shadow-card"
      >
        {/* The current tier's color tints this card */}
        <span
          aria-hidden
          className="pointer-events-none absolute -top-28 -left-20 size-80 rounded-full opacity-[0.14] blur-3xl"
          style={{ backgroundColor: current.colorHex }}
        />
        <span
          aria-hidden
          className="pointer-events-none absolute inset-x-0 top-0 h-px"
          style={{ background: `linear-gradient(90deg, transparent, ${current.colorHex}, transparent)` }}
        />
        <div className="relative flex flex-wrap items-start justify-between gap-4">
          <div className="flex items-start gap-4">
            <span
              className="flex size-12 shrink-0 items-center justify-center rounded-xl"
              style={{ backgroundColor: `${current.colorHex}22`, color: current.colorHex }}
            >
              <Sparkles className="size-6" />
            </span>
            <div>
              <p className="eyebrow" style={{ color: current.colorHex }}>Current level</p>
              <p className="font-display text-xl font-semibold">{current.name}</p>
              <p className="mt-0.5 flex items-center gap-4 text-sm text-muted-foreground">
                <span className="font-display text-2xl font-semibold text-foreground tabular-nums">{props.points}</span> points
                <span className="inline-flex items-center gap-1.5">
                  <ShoppingBag className="size-4" /> {props.purchaseCount} purchase{props.purchaseCount === 1 ? "" : "s"}
                </span>
              </p>
            </div>
          </div>

          {/* Claim area */}
          {props.rewardRequestStatus === "PENDING" ? (
            <span className="inline-flex items-center gap-2 rounded-lg border border-warning/40 bg-warning/10 px-4 py-2.5 text-sm font-medium text-warning">
              <Clock className="size-4" /> Reward request pending approval
            </span>
          ) : props.rewardRequestStatus === "APPROVED" ? (
            <span className="inline-flex items-center gap-2 rounded-lg border border-success/40 bg-success/10 px-4 py-2.5 text-sm font-medium text-success">
              <CheckCircle2 className="size-4" /> Reward approved &amp; credited
            </span>
          ) : next ? (
            <div className="text-right">
              <p className="font-display text-2xl font-semibold tabular-nums">{Math.max(0, next.minPoints - props.points)}</p>
              <p className="text-xs text-muted-foreground">points to {next.name}</p>
            </div>
          ) : null}
        </div>

        {/* Progress bar */}
        <div className="relative mt-6">
          <div className="h-2.5 overflow-hidden rounded-full bg-muted">
            <div
              className="h-full rounded-full transition-all"
              style={{ width: `${progressPct}%`, backgroundColor: current.colorHex }}
            />
          </div>
          {next ? (
            <p className="mt-1.5 text-xs text-muted-foreground">
              Progress toward <span className="font-medium text-foreground">{next.name}</span>
            </p>
          ) : (
            <p className="mt-1.5 text-xs font-semibold" style={{ color: current.colorHex }}>
              🎉 Max level reached!
            </p>
          )}
        </div>

        {/* Reward request */}
        <div className="relative mt-5 rounded-xl border border-primary/20 bg-primary/6 px-4 py-3.5">
          {props.rewardRequestStatus === "PENDING" ? (
            <p className="text-sm font-medium text-warning">
              Your reward claim is being verified — check back soon.
            </p>
          ) : props.rewardRequestStatus === "APPROVED" ? (
            <p className="text-sm font-medium text-success">
              Reward paid out to your balance. Keep collecting points for the next tier!
            </p>
          ) : canClaimNow ? (
            <div className="flex flex-wrap items-center justify-between gap-3">
              <div>
                <p className="text-sm font-semibold">
                  💎 Your {current.name} reward of{" "}
                  <strong>{formatCents(current.rewardAmountCents)}</strong> is ready!
                </p>
                <p className="mt-0.5 text-xs text-muted-foreground">
                  An administrator verifies every request, then adds the money to your balance.
                </p>
              </div>
              <Button onClick={request} disabled={pending} size="sm" className="gap-2">
                {pending ? <Loader2 className="size-4 animate-spin" /> : <Gift className="size-4" />}
                Request my reward
              </Button>
            </div>
          ) : (
            <div>
              <p className="text-sm font-semibold">
                {unlock ? `💎 Cash rewards unlock at ${unlock.name} (${unlock.minPoints} pts)` : "💎 Earn points with every purchase to move up the levels"}
              </p>
              <p className="mt-0.5 text-xs text-muted-foreground">
                Every purchase earns points (bigger purchases earn more), and friends&apos; purchases
                through your affiliate link earn you extra points too.
              </p>
            </div>
          )}
        </div>
      </motion.section>

      {/* Levels ladder */}
      <Card>
        <CardHeader>
          <CardTitle>Levels &amp; rewards</CardTitle>
          <CardDescription>Each level changes your dashboard color and unlocks bigger perks.</CardDescription>
        </CardHeader>
        <CardContent>
          <ol className="relative space-y-2">
            {sorted.map((t) => {
              const isCurrent = t.id === current.id;
              const unlocked = props.points >= t.minPoints;
              return (
                <li
                  key={t.id}
                  className={`flex flex-wrap items-center justify-between gap-3 rounded-xl border px-4 py-3 transition-colors ${
                    isCurrent ? "bg-card shadow-card" : unlocked ? "bg-muted/25" : "border-dashed bg-transparent"
                  }`}
                  style={isCurrent ? { borderColor: `${t.colorHex}66` } : undefined}
                >
                  <div className="flex items-center gap-3">
                    <span
                      className={`flex size-9 shrink-0 items-center justify-center rounded-lg ${unlocked ? "" : "bg-muted text-muted-foreground"}`}
                      style={unlocked ? { backgroundColor: `${t.colorHex}22`, color: t.colorHex } : undefined}
                    >
                      <Award className="size-4.5" />
                    </span>
                    <div>
                      <p className={`text-sm ${isCurrent ? "font-semibold" : "font-medium"} ${unlocked ? "" : "text-muted-foreground"}`}>
                        {t.name}
                        {isCurrent ? (
                          <span
                            className="ml-2 rounded-full px-2 py-0.5 text-[10px] font-semibold tracking-wide uppercase"
                            style={{ backgroundColor: `${t.colorHex}1f`, color: t.colorHex }}
                          >
                            You are here
                          </span>
                        ) : null}
                      </p>
                      <p className="text-xs text-muted-foreground">{t.minPoints} points required</p>
                    </div>
                  </div>
                  <div className="text-right">
                    {t.rewardAmountCents > 0 ? (
                      <>
                        <p className="text-sm font-semibold text-success tabular-nums">{formatCents(t.rewardAmountCents)}</p>
                        <p className="text-[11px] text-muted-foreground">cash reward</p>
                      </>
                    ) : (
                      <p className="text-xs text-muted-foreground">starter level</p>
                    )}
                  </div>
                </li>
              );
            })}
          </ol>
        </CardContent>
      </Card>

      {/* How to earn */}
      <Card>
        <CardHeader>
          <CardTitle>How to earn points</CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="space-y-2 text-sm leading-relaxed text-muted-foreground">
            {earningLines(props.earning).map((line) => (
              <li key={line} className="flex gap-2.5">
                <CheckCircle2 className="mt-0.5 size-4 shrink-0 text-primary" />
                <span>{line}</span>
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>
    </div>
  );
}
