import type { Metadata } from "next";
import { requireCustomer } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { getLoyaltyProgram } from "@/lib/services/loyalty-program";
import type { StoreId } from "@/lib/store";
import { LoyaltyPageClient } from "./loyalty-page-client";
import { requestRewardAction } from "@/app/portal/actions";

export const metadata: Metadata = { title: "Loyalty Program" };
export const dynamic = "force-dynamic";

export default async function LoyaltyPage() {
  const customer = await requireCustomer();
  const program = await getLoyaltyProgram(customer.storeId as StoreId);
  const full = await prisma.customer.findUniqueOrThrow({
    where: { id: customer.id },
    select: {
      loyaltyPoints: true,
      purchaseCount: true,
      rewardRequestStatus: true,
      initialBalanceCents: true,
    },
  });

  return (
    <LoyaltyPageClient
      points={full.loyaltyPoints}
      purchaseCount={full.purchaseCount}
      rewardRequestStatus={full.rewardRequestStatus}
      earning={{ basePoints: program.basePoints, overflowPercent: program.overflowPercent, brackets: program.brackets }}
      tiers={program.tiers.map((t) => ({
        id: t.id,
        name: t.name,
        minPoints: t.minPoints,
        colorHex: t.colorHex,
        rewardAmountCents: t.rewardAmountCents,
      }))}
      onRequestReward={requestRewardAction}
    />
  );
}
