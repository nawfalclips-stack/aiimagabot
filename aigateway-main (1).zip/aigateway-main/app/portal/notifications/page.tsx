import type { Metadata } from "next";
import { Bell } from "lucide-react";
import { requireCustomer } from "@/lib/auth";
import { listCustomerAnnouncements } from "@/lib/services/announcements";
import { Card } from "@/components/ui/card";
import { EmptyState } from "@/components/shared/empty-state";
import { PageHeader } from "@/components/shared/page-header";
import { AnnouncementItem, MarkAnnouncementsRead, type PortalAnnouncement } from "@/components/portal/announcements";

export const metadata: Metadata = { title: "Notifications" };
export const dynamic = "force-dynamic";

export default async function PortalNotificationsPage() {
  const customer = await requireCustomer();
  const rows = await listCustomerAnnouncements(customer.storeId, customer.id);
  const items: PortalAnnouncement[] = rows.map((a) => ({
    ...a,
    startsAt: a.startsAt.toISOString(),
    endsAt: a.endsAt?.toISOString() ?? null,
  }));
  const unread = items.filter((a) => !a.read).map((a) => a.id);

  return (
    <div className="space-y-6">
      <PageHeader eyebrow="Account" title="Notifications" description="Offers, new models and news from our team." />
      {items.length === 0 ? (
        <Card className="p-0">
          <EmptyState icon={Bell} title="Nothing new" description="Promotions and new models will show up here." className="border-0" />
        </Card>
      ) : (
        <div className="space-y-3">
          {items.map((a) => (
            <AnnouncementItem key={a.id} a={a} />
          ))}
        </div>
      )}
      <MarkAnnouncementsRead ids={unread} />
    </div>
  );
}
