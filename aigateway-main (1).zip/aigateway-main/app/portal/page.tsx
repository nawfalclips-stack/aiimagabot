import { ScrollText, ShoppingBag, TriangleAlert, OctagonAlert, Ban, CheckCircle2, KeyRound, Activity } from "lucide-react";
import Link from "next/link";
import { requireCustomer } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { getSettings } from "@/lib/services/settings";
import { SETTING_KEYS } from "@/lib/constants";
import { formatCents, percentUsed } from "@/lib/money";

import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { StatusBadge } from "@/components/shared/status-badge";
import { Callout } from "@/components/shared/callout";
import { Button } from "@/components/ui/button";
import { CopyButton } from "@/components/shared/copy-button";
import { EmptyState } from "@/components/shared/empty-state";
import { LedgerTable } from "@/components/shared/ledger-table";
import { ApiKeyCard } from "@/components/portal/api-key-card";
import { UsageCard } from "@/components/portal/usage-card";
import { ReviewBonusBanner } from "@/components/portal/review-bonus-banner";
import { LoyaltyCard } from "@/components/portal/loyalty-card";
import { getLoyaltyProgram } from "@/lib/services/loyalty-program";
import { requestRewardAction } from "@/app/portal/actions";
import { LocalTime } from "@/components/shared/local-time";
import type { StoreId } from "@/lib/store";
import { poolAssignmentsEnabled } from "@/lib/services/legacy-pool";
import { listCustomerAnnouncements } from "@/lib/services/announcements";
import { getRecentRequests } from "@/lib/services/customer-usage";
import { formatMicroUsd } from "@/lib/billing/money";
import { AnnouncementBanner, type PortalAnnouncement } from "@/components/portal/announcements";

/** Cut-off timestamp for "recently auto-fixed" tickets (kept out of render for the purity lint). */
function hoursAgo(hours: number): Date {
  return new Date(Date.now() - hours * 60 * 60 * 1000);
}

export const dynamic = "force-dynamic";

export default async function PortalDashboardPage() {
  const customer = await requireCustomer();
  // WS10: the legacy upstream key reaches the browser only while the pool is
  // active (rollback). Otherwise we only need to know that one exists.
  const poolActive = poolAssignmentsEnabled();
  const [order, apiKey, ledger, settings, resolvedApiTicket, announcements, recent, loyalty] = await Promise.all([
    prisma.order.findUnique({ where: { customerId: customer.id } }),
    prisma.apiKey.findUnique({ where: { customerId: customer.id }, select: { id: true, key: poolActive } }),
    prisma.ledgerEntry.findMany({ where: { customerId: customer.id }, orderBy: { createdAt: "desc" }, take: 40 }),
    getSettings(customer.storeId as StoreId),
    // Show a success banner for up to 48 h after the API was auto-replaced.
    // Show a success banner for up to 48 h after the API was replaced,
    // regardless of whether it was auto-fixed or resolved manually by admin.
    prisma.ticket.findFirst({
      where: {
        customerId: customer.id,
        status: { in: ["AUTO_RESOLVED", "RESOLVED"] },
        autoFixed: true,
        updatedAt: { gte: hoursAgo(48) },
      },
      orderBy: { updatedAt: "desc" },
      select: { id: true, title: true },
    }),
    listCustomerAnnouncements(customer.storeId, customer.id, 20),
    getRecentRequests(customer.id, 5),
    getLoyaltyProgram(customer.storeId as StoreId),
  ]);

  // Unread announcements on the dashboard, promotions first (max 3; the rest are in Notifications).
  const banner: PortalAnnouncement[] = announcements
    .filter((a) => !a.read)
    .sort((a, b) => Number(b.kind === "PROMO") - Number(a.kind === "PROMO"))
    .slice(0, 3)
    .map((a) => ({ ...a, startsAt: a.startsAt.toISOString(), endsAt: a.endsAt?.toISOString() ?? null }));

  const storeUrl = settings[SETTING_KEYS.storeUrl];
  const remainingBalance = customer.initialBalanceCents - customer.usedBalanceCents;
  const remainingBonus = customer.initialBonusCents - customer.usedBonusCents;
  const completionPct = percentUsed(customer.usedBalanceCents, customer.initialBalanceCents);

  const suspended = customer.status === "SUSPENDED";
  // The "fully consumed" alert only appears once BOTH the balance and the
  // bonus are used up — while bonus remains, the customer can keep going.
  const finished =
    (customer.status === "BALANCE_FINISHED" || customer.status === "EXPIRED" || remainingBalance <= 0) &&
    remainingBonus <= 0;
  const lowBalance = customer.status === "LOW_BALANCE";

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col gap-4 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <p className="eyebrow mb-1.5 text-primary">Customer portal</p>
          <h1 className="text-[1.65rem] leading-tight font-semibold tracking-tight sm:text-3xl">Your Dashboard</h1>
          <p className="mt-1.5 text-sm text-muted-foreground">
            Order <span className="font-mono text-foreground">{order?.orderNumber ?? "—"}</span> · Member since{" "}
            <LocalTime date={customer.createdAt} variant="date" />
          </p>
        </div>
        <StatusBadge status={customer.status} size="lg" />
      </div>

      {/* Alerts */}
      {suspended ? (
        <Callout tone="muted" icon={Ban} title="Your account is suspended" role="alert">
          Access to the API is currently paused. Please reach us{" "}
          <a href={storeUrl} target="_blank" rel="noopener noreferrer" className="font-medium text-foreground underline-offset-4 hover:underline">
            on our store
          </a>{" "}
          for assistance.
        </Callout>
      ) : finished ? (
        <Callout
          tone="destructive"
          icon={OctagonAlert}
          title="Your balance has been fully consumed"
          role="alert"
          action={
            <Button asChild variant="destructive">
              <a href={storeUrl} target="_blank" rel="noopener noreferrer">
                <ShoppingBag /> Renew from our store
              </a>
            </Button>
          }
        >
          If you&apos;d like to renew, purchase again from our store — and as a returning customer you now earn a{" "}
          <strong className="text-foreground">15% bonus instead of 10%</strong> on your next offer.
        </Callout>
      ) : lowBalance ? (
        <Callout tone="warning" icon={TriangleAlert} title="Your remaining balance is running low" role="alert">
          Only {formatCents(remainingBalance)} left. You can{" "}
          <a href={storeUrl} target="_blank" rel="noopener noreferrer" className="font-medium text-foreground underline-offset-4 hover:underline">
            top up from our store
          </a>{" "}
          whenever you&apos;re ready.
        </Callout>
      ) : null}

      <AnnouncementBanner items={banner} />

      {/* WS10: customers who still hold a legacy key move to gateway tokens */}
      {apiKey && !poolActive ? (
        <Callout
          icon={KeyRound}
          title="Create your AeroLink API token on the API Access page — your previous access method is being retired."
          role="status"
          action={
            <Button asChild size="sm">
              <Link href="/portal/api-access">Go to API Access →</Link>
            </Button>
          }
        />
      ) : null}

      {/* API auto-fix success banner — shown for 48 h after the key was replaced */}
      {resolvedApiTicket && poolActive ? (
        <Callout
          tone="success"
          icon={CheckCircle2}
          title="Your API issue has been resolved!"
          role="alert"
          action={
            <Link
              href={`/portal/support/${resolvedApiTicket.id}`}
              className="text-sm font-medium text-success underline-offset-4 hover:underline"
            >
              View ticket →
            </Link>
          }
        >
          Your legacy API key has been replaced with a new one. It&apos;s already active — you can see and copy it below.
        </Callout>
      ) : null}

      {/* Review-gated bonus */}
      <ReviewBonusBanner
        status={customer.reviewBonusStatus}
        pendingBonusCents={customer.pendingBonusCents}
        storeUrl={storeUrl}
        orderNumber={order?.orderNumber ?? null}
        bonusPercentLabel="10"
      />

      {/* Loyalty program — points, level and VIP reward request */}
      <LoyaltyCard
        tiers={loyalty.tiers}
        points={customer.loyaltyPoints}
        purchaseCount={customer.purchaseCount}
        rewardRequestStatus={customer.rewardRequestStatus}
        onRequestReward={requestRewardAction}
      />

      {/* Legacy API key — only while LEGACY_API_POOL_MODE=active */}
      {poolActive && apiKey?.key ? <ApiKeyCard apiKey={apiKey.key} /> : null}

      {/* Balance + bonus */}
      <div className="grid gap-6 lg:grid-cols-2">
        <UsageCard
          title="Balance"
          icon="dollar"
          initialCents={customer.initialBalanceCents}
          usedCents={customer.usedBalanceCents}
          remainingCents={remainingBalance}
          tone="primary"
        />
        <UsageCard
          title="Bonus"
          icon="gift"
          initialCents={customer.initialBonusCents}
          usedCents={customer.usedBonusCents}
          remainingCents={remainingBonus}
          tone="success"
        />
      </div>

      {/* Recent API usage — model aliases only, with what each request cost */}
      <Card>
        <CardHeader className="flex flex-row items-start justify-between gap-4">
          <div>
            <CardTitle>Recent usage</CardTitle>
            <CardDescription>Your latest requests, the model they used and what each one cost.</CardDescription>
          </div>
          <Button asChild variant="outline" size="sm">
            <Link href="/portal/activity">All activity →</Link>
          </Button>
        </CardHeader>
        <CardContent>
          {recent.length === 0 ? (
            <EmptyState
              icon={Activity}
              title="No requests yet"
              description="Create a token on API Access and point your tool at us — each request shows up here with its cost."
              className="py-8"
            />
          ) : (
            <ul className="divide-y">
              {recent.map((r) => (
                <li key={r.id} className="flex items-center justify-between gap-4 py-2.5 first:pt-0 last:pb-0">
                  <div className="min-w-0">
                    <p className="truncate text-sm font-medium">{r.model.name}</p>
                    <p className="text-xs text-muted-foreground tabular-nums">
                      <LocalTime date={r.happenedAt.toISOString()} /> · {r.inputTokens.toLocaleString("en")} in / {r.outputTokens.toLocaleString("en")} out
                      {r.outcome && r.outcome !== "COMPLETED" ? ` · ${r.outcome.toLowerCase().replace("_", " ")}` : ""}
                    </p>
                  </div>
                  <p className="shrink-0 font-medium tabular-nums">{formatMicroUsd(r.chargedMicroUsd)}</p>
                </li>
              ))}
            </ul>
          )}
        </CardContent>
      </Card>

      {/* Order information */}
      <Card>
        <CardHeader>
          <CardTitle>Order Information</CardTitle>
          <CardDescription>Your purchase details.</CardDescription>
        </CardHeader>
        <CardContent className="grid gap-x-8 sm:grid-cols-2 lg:grid-cols-3">
          {[
            { label: "Order Number", value: order?.orderNumber ?? "—", mono: true, copy: true },
            { label: "Access Code", value: customer.accessCode, mono: true, copy: true },
            { label: "Current Status", value: null },
            { label: "Created", value: <LocalTime date={customer.createdAt} variant="date" /> },
            { label: "Last Updated", value: <LocalTime date={customer.updatedAt} variant="date" /> },
            { label: "Usage Completion", value: `${completionPct}%` },
          ].map((item) => (
            <div key={item.label} className="min-w-0 border-t py-3.5 first:border-t-0 sm:[&:nth-child(-n+2)]:border-t-0 lg:[&:nth-child(-n+3)]:border-t-0">
              <p className="eyebrow">{item.label}</p>
              {item.value === null ? (
                <div className="mt-1.5">
                  <StatusBadge status={customer.status} />
                </div>
              ) : (
                <div className="mt-1 flex items-center gap-1">
                  <p className={`truncate text-sm font-medium ${item.mono ? "font-mono" : ""}`}>{item.value}</p>
                  {item.copy ? <CopyButton value={String(item.value)} label={item.label} size="icon-xs" /> : null}
                </div>
              )}
            </div>
          ))}
        </CardContent>
      </Card>

      {/* Balance history (the ledger) */}
      <Card id="balance-history" className="scroll-mt-20">
        <CardHeader>
          <CardTitle>Balance History</CardTitle>
          <CardDescription>Every movement of your balance and bonus, newest first. API usage is one line per request.</CardDescription>
        </CardHeader>
        <CardContent>
          {ledger.length === 0 ? (
            <EmptyState
              icon={ScrollText}
              title="No movements yet"
              description="Purchases, bonuses and API usage will appear here as they happen."
              className="py-10"
            />
          ) : (
            <LedgerTable entries={ledger} showActor={false} />
          )}
        </CardContent>
      </Card>
    </div>
  );
}
