"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { getCurrentCustomer } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { parseOfferTitle } from "@/lib/offer-parser";
import { createNotification, NOTIFICATION_TYPES } from "@/lib/services/notifications";
import { formatCents } from "@/lib/money";
import { activeRechargePromo, promoBonusCents } from "@/lib/services/announcements";
import { getPackChoice } from "@/lib/services/packs";
import type { StoreId } from "@/lib/store";

export type RechargeResult =
  | { ok: true; requestId: string; balanceCents: number; bonusCents: number; promoBonusCents: number }
  | { ok: false; error: string };

export async function rechargeAction(input: {
  orderId: string;
  /** The pack (plan) bought, picked from the list. */
  packId?: string;
  /** Fallback when the store has no packs configured. */
  offerTitle?: string;
}): Promise<RechargeResult> {
  try {
    const customer = await getCurrentCustomer();
    if (!customer) return { ok: false, error: "Session expired — sign in again." };

    const data = z.object({
      orderId: z.string().trim().min(3, "Enter your Order ID").max(200),
      packId: z.string().trim().max(64).optional().transform((v) => v || undefined),
      offerTitle: z.string().trim().max(300).optional().transform((v) => v ?? ""),
    }).parse(input);
    if (!data.packId && data.offerTitle.length < 2) return { ok: false, error: "Choose the plan you bought." };

    const pack = data.packId ? await getPackChoice(customer.storeId as StoreId, data.packId) : null;
    if (data.packId && !pack) return { ok: false, error: "That plan is no longer available — choose another one." };
    const offerTitle = pack ? `${pack.name}${pack.listingPriceLabel ? ` (${pack.listingPriceLabel})` : ""}` : data.offerTitle;

    // Order ID must not already be used.
    const existingOrder = await prisma.order.findUnique({
      where: { orderNumber: data.orderId },
    });
    if (existingOrder) {
      return { ok: false, error: "This Order ID has already been used. Enter the new order number from your latest purchase." };
    }

    // Check for duplicate pending/approved request with same order number.
    const existingRequest = await prisma.rechargeRequest.findUnique({
      where: { orderNumber: data.orderId },
    });
    if (existingRequest) {
      return { ok: false, error: "A recharge request with this Order ID was already submitted." };
    }

    // Amount: the picked plan's price (credited on approval), else parsed from the offer title.
    const parsedOffer = pack ? { balanceCents: pack.priceCents, bonusCents: 0 } : parseOfferTitle(offerTitle);
    const { balanceCents, bonusCents } = parsedOffer;
    if (!balanceCents || balanceCents <= 0) {
      return { ok: false, error: 'Could not read the balance from the offer title. Copy it exactly as shown (e.g. "300$ + 50$ Bonus").' };
    }

    // A recharge promotion running now is locked in with the request and
    // credited at approval, even if it ends before the admin gets to it.
    const promo = await activeRechargePromo(customer.storeId, customer.id);

    // Create PENDING recharge request — admin must approve before balance is credited.
    const request = await prisma.rechargeRequest.create({
      data: {
        storeId: customer.storeId,
        customerId: customer.id,
        orderNumber: data.orderId,
        offerTitle,
        // Pre-selected for the admin at approval (who still confirms it).
        packId: pack?.id ?? null,
        balanceCents,
        bonusCents: bonusCents ?? 0,
        status: "PENDING",
        promoAnnouncementId: promo?.id ?? null,
        promoBonusPct: promo?.rechargeBonusPct ?? 0,
      },
    });

    // Create notification for admin about new recharge request
    await createNotification({
      storeId: customer.storeId,
      type: NOTIFICATION_TYPES.RECHARGE_REQUESTED,
      title: "New Recharge Request",
      message: `Customer ${customer.accessCode} requested ${formatCents(balanceCents)} recharge${promo ? ` (promotion +${promo.rechargeBonusPct}%)` : ""}`,
      customerId: customer.id,
      relatedId: request.id,
    });

    revalidatePath("/portal/recharge");
    revalidatePath("/admin", "layout");
    return { ok: true, requestId: request.id, balanceCents, bonusCents: bonusCents ?? 0, promoBonusCents: promo ? promoBonusCents(balanceCents, promo.rechargeBonusPct) : 0 };
  } catch (error) {
    if (error instanceof z.ZodError) return { ok: false, error: error.issues[0].message };
    console.error(error);
    return { ok: false, error: "Could not submit the recharge request. Please try again." };
  }
}

export type RedeemVoucherResult =
  | { ok: true; credited: boolean; balanceCents: number; bonusCents: number; planName: string }
  | { ok: false; error: string; requiresCaptcha?: boolean };

/** Portal top-up with a GamsGo voucher code (WS9). Same rules as /redeem, for the signed-in customer. */
export async function redeemVoucherAction(input: { code: string; gamsgoOrderId?: string; turnstileToken?: string }): Promise<RedeemVoucherResult> {
  try {
    const customer = await getCurrentCustomer();
    if (!customer) return { ok: false, error: "Session expired — sign in again." };
    const data = z.object({ code: z.string().trim().min(10, "Enter the code from your order").max(64), gamsgoOrderId: z.string().trim().max(64).optional(), turnstileToken: z.string().optional() }).parse(input);
    const { performRedemption } = await import("@/lib/vouchers/redeem");
    const outcome = await performRedemption({
      storeId: customer.storeId as StoreId,
      rawCode: data.code,
      gamsgoOrderId: data.gamsgoOrderId || undefined,
      turnstileToken: data.turnstileToken,
      sessionKey: `c:${customer.id}`,
      customer,
    });
    if (!outcome.ok) return { ok: false, error: outcome.message, requiresCaptcha: outcome.requiresCaptcha };
    revalidatePath("/portal", "layout");
    revalidatePath("/admin", "layout");
    const r = outcome.result;
    return { ok: true, credited: r.credited, balanceCents: r.balanceCents, bonusCents: r.bonusCents, planName: r.planName };
  } catch (error) {
    if (error instanceof z.ZodError) return { ok: false, error: error.issues[0].message };
    console.error(error);
    return { ok: false, error: "Could not redeem the code. Please try again." };
  }
}
