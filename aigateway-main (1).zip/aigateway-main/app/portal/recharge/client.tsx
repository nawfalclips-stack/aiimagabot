"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { Clock, ExternalLink, Loader2, RefreshCw, ShoppingBag, Ticket, TriangleAlert, CheckCircle2, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { formatCents } from "@/lib/money";
import { rechargeAction, redeemVoucherAction } from "./actions";
import { normaliseVoucherCode } from "@/lib/vouchers/format";
import { PageHeader } from "@/components/shared/page-header";
import { Callout } from "@/components/shared/callout";
import { Steps } from "@/components/shared/steps";
import { LocalTime } from "@/components/shared/local-time";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import type { PackChoice } from "@/lib/services/packs";

interface PendingRequest {
  id: string;
  orderNumber: string;
  offerTitle: string;
  balanceCents: number;
  bonusCents: number;
  promoBonusPct: number;
  status: string;
  createdAt: string;
}

export interface RechargePromo {
  title: string;
  pct: number;
  endsAt: string | null;
}

interface RechargePageClientProps {
  storeUrl: string;
  vouchersEnabled?: boolean;
  currentBalance: number;
  pendingRequests: PendingRequest[];
  /** Recharge promotion running now: recharges submitted while it runs earn pct % extra as bonus. */
  promo?: RechargePromo | null;
  /** Plans (packs) on sale; empty = fall back to typing the offer title. */
  packs?: PackChoice[];
}

export function RechargePageClient({ storeUrl, currentBalance, pendingRequests, vouchersEnabled = true, promo = null, packs = [] }: RechargePageClientProps) {
  const router = useRouter();
  const [pending, startTransition] = useTransition();
  const [orderId, setOrderId] = useState("");
  const [offerTitle, setOfferTitle] = useState("");
  const [packId, setPackId] = useState("");
  const pickPack = packs.length > 0;
  const chosenPack = packs.find((p) => p.id === packId) ?? null;
  const detailsReady = pickPack ? !!packId : !!offerTitle.trim();
  const [submitted, setSubmitted] = useState<{ promoBonusCents: number } | null>(null);
  const [code, setCode] = useState("");
  const [codePending, startCodeTransition] = useTransition();
  const [redeemed, setRedeemed] = useState<{ credited: boolean; balanceCents: number; bonusCents: number; planName: string } | null>(null);
  const codeLooksValid = normaliseVoucherCode(code) !== null;

  const redeem = () => {
    if (!codeLooksValid || codePending) return;
    startCodeTransition(async () => {
      const result = await redeemVoucherAction({ code });
      if (result.ok) {
        setRedeemed(result);
        setCode("");
        router.refresh();
      } else toast.error(result.error);
    });
  };

  const submit = () => {
    if (!orderId.trim() || !detailsReady || pending) return;
    startTransition(async () => {
      const result = await rechargeAction(pickPack ? { orderId, packId } : { orderId, offerTitle });
      if (result.ok) {
        setSubmitted({ promoBonusCents: result.promoBonusCents });
        setOrderId("");
        setOfferTitle("");
        setPackId("");
        router.refresh();
      } else {
        toast.error(result.error);
      }
    });
  };

  return (
    <div className="max-w-2xl space-y-6">
      <PageHeader
        eyebrow="Account"
        title="Recharge Balance"
        description="Redeem a code instantly, or submit a GamsGo order for approval."
        actions={
          <div className="rounded-xl border bg-card px-4 py-2 shadow-card">
            <p className="eyebrow text-[10px]">Current balance</p>
            <p className="font-display text-lg font-semibold tabular-nums">{formatCents(currentBalance)}</p>
          </div>
        }
      />

      {promo ? (
        <Callout tone="success" icon={Sparkles} title={`+${promo.pct}% extra usage on your recharge`}>
          {promo.title}. Recharge while this offer runs and we add {promo.pct}% of the recharged balance to your bonus
          {promo.endsAt ? (
            <>
              {" "}— until <LocalTime date={promo.endsAt} />
            </>
          ) : null}
          .
        </Callout>
      ) : null}

      {/* Pending requests */}
      {pendingRequests.length > 0 && (
        <Card className="border-warning/30 bg-warning/5 shadow-none">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center gap-2 text-sm font-semibold text-warning">
              <Clock className="size-4" /> Pending Recharge Requests
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-2">
            {pendingRequests.map((req) => (
              <div key={req.id} className="flex items-start justify-between gap-2 rounded-xl border border-warning/20 bg-card px-3.5 py-3 text-sm">
                <div className="min-w-0">
                  <p className="truncate font-mono text-xs font-medium">{req.orderNumber}</p>
                  <p className="mt-0.5 truncate text-xs text-muted-foreground">{req.offerTitle}</p>
                  <p className="mt-0.5 text-xs text-muted-foreground">
                    +{formatCents(req.balanceCents)}{req.bonusCents > 0 ? ` + ${formatCents(req.bonusCents)} bonus` : ""}
                    {req.promoBonusPct > 0 ? ` + ${req.promoBonusPct}% promotion` : ""}
                  </p>
                </div>
                <span className="shrink-0 rounded-full border border-warning/30 bg-warning/12 px-2 py-0.5 text-[10px] font-semibold uppercase text-warning">
                  Pending
                </span>
              </div>
            ))}
            <p className="text-xs text-muted-foreground">
              Awaiting admin verification — your balance will be credited once approved.
            </p>
          </CardContent>
        </Card>
      )}

      {/* Submitted success */}
      {submitted && (
        <Callout tone="success" icon={CheckCircle2} title="Request submitted!" role="status">
          Your recharge request is pending admin approval. We will verify your order on GamsGo and credit your balance shortly.
          {submitted.promoBonusCents > 0 ? ` The promotion adds ${formatCents(submitted.promoBonusCents)} to your bonus on approval.` : ""}
        </Callout>
      )}

      {/* Voucher code (automatic-delivery offers) */}
      {vouchersEnabled && (
      <Card className="relative overflow-hidden border-primary/25">
        <span aria-hidden className="pointer-events-none absolute -top-20 -right-16 size-56 rounded-full bg-primary/10 blur-3xl" />
        <CardHeader className="relative">
          <span className="eyebrow text-primary">Fastest</span>
          <CardTitle className="flex items-center gap-2">
            <Ticket className="size-4 text-primary" /> Got a code? Redeem it instantly
          </CardTitle>
          <CardDescription>
            Offers with automatic delivery send you a single-use code right after checkout. Paste it here — no waiting for approval when auto-approve is on.
          </CardDescription>
        </CardHeader>
        <CardContent className="relative space-y-3">
          {redeemed && (
            <div className="flex items-start gap-3 rounded-xl border border-success/30 bg-success/10 px-4 py-3">
              <CheckCircle2 className="mt-0.5 size-5 shrink-0 text-success" />
              <p className="text-sm">
                {redeemed.credited
                  ? `${formatCents(redeemed.balanceCents)} added${redeemed.bonusCents ? ` (+ ${formatCents(redeemed.bonusCents)} bonus)` : ""} — you are on the ${redeemed.planName} plan.`
                  : `Code accepted. Your ${formatCents(redeemed.balanceCents)} credit is being verified and will be added once approved.`}
              </p>
            </div>
          )}
          <div className="flex gap-2">
            <Input value={code} onChange={(e) => setCode(e.target.value)} placeholder="ALK-XXXXX-XXXXX-XXXXX-XXXXX-X" className="h-10 bg-card font-mono uppercase" autoComplete="off" spellCheck={false} />
            <Button onClick={redeem} disabled={!codeLooksValid || codePending} className="h-10">
              {codePending ? <Loader2 className="animate-spin" /> : <Ticket />} Redeem
            </Button>
          </div>
          {code.replace(/[^A-Za-z0-9]/g, "").length >= 21 && !codeLooksValid && (
            <p className="text-xs text-warning">That doesn&apos;t look like a valid code — check for a typo.</p>
          )}
        </CardContent>
      </Card>
      )}

      {/* Step 1 */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <ShoppingBag className="size-4 text-primary" /> Step 1 — Buy a new package
          </CardTitle>
          <CardDescription>
            All purchases are made exclusively on GamsGo. Keep your <strong>Order Number</strong>{pickPack ? " and remember which plan you bought" : <> and <strong>Offer Title</strong></>} — you&apos;ll need them in Step 2.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Button asChild size="lg">
            <a href={storeUrl} target="_blank" rel="noopener noreferrer">
              <ExternalLink /> GamsGo — New Order / Recharge Balance
            </a>
          </Button>
        </CardContent>
      </Card>

      {/* Step 2 */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <RefreshCw className="size-4 text-primary" /> Step 2 — Submit your order details
          </CardTitle>
          <CardDescription>
            After purchasing, enter your details below. The admin will verify your order on GamsGo and approve the credit.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <Callout tone="warning" icon={TriangleAlert}>
            Enter the <strong className="text-foreground">Order Number</strong> exactly as shown on GamsGo and{" "}
            {pickPack ? <>choose the <strong className="text-foreground">plan you bought</strong></> : <>the <strong className="text-foreground">Offer Title</strong></>}. Wrong info will result in rejection.
          </Callout>

          <div className="space-y-2">
            <Label htmlFor="orderId">New Order Number</Label>
            <Input
              id="orderId"
              value={orderId}
              onChange={(e) => setOrderId(e.target.value)}
              placeholder="e.g. 874133419448209408"
              className="font-mono"
            />
          </div>

          {pickPack ? (
            <div className="space-y-2">
              <Label htmlFor="packId">Plan you bought</Label>
              <Select value={packId} onValueChange={setPackId} disabled={pending}>
                <SelectTrigger id="packId" className="w-full">
                  <SelectValue placeholder="Choose your plan" />
                </SelectTrigger>
                <SelectContent>
                  {packs.map((p) => (
                    <SelectItem key={p.id} value={p.id}>
                      {p.name} — {formatCents(p.priceCents)}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              <p className="text-xs text-muted-foreground">
                {chosenPack ? (
                  <>
                    Adds <span className="font-semibold text-foreground">{formatCents(chosenPack.priceCents)}</span> to your balance once we verify your order.
                  </>
                ) : (
                  "Pick the same plan as on your GamsGo order."
                )}
              </p>
            </div>
          ) : (
            <div className="space-y-2">
              <Label htmlFor="offerTitle">Offer Title</Label>
              <Input
                id="offerTitle"
                value={offerTitle}
                onChange={(e) => setOfferTitle(e.target.value)}
                placeholder='e.g. Codex API 300$ + 50$ Bonus'
              />
              <p className="text-xs text-muted-foreground">
                Copy the offer title exactly — this is how we know how much to add.
              </p>
            </div>
          )}

          <Button
            onClick={submit}
            disabled={!orderId.trim() || !detailsReady || pending}
            className="w-full"
            size="lg"
          >
            {pending ? <Loader2 className="animate-spin" /> : <RefreshCw />}
            Submit recharge request
          </Button>
        </CardContent>
      </Card>

      {/* How it works */}
      <Card>
        <CardHeader>
          <CardTitle>How recharging works</CardTitle>
        </CardHeader>
        <CardContent>
          <Steps
            items={[
              { title: "Buy a package from our GamsGo store using the button above." },
              {
                title: (
                  <>
                    Copy your <strong>Order Number</strong>{pickPack ? <> and note the <strong>plan</strong> you bought</> : <> and the <strong>Offer Title</strong></>}.
                  </>
                ),
              },
              { title: "Submit them in Step 2 — your request goes to admin for verification." },
              { title: "Admin checks the order on GamsGo and approves it — balance is credited instantly." },
              { title: "If the offer includes a bonus, write a review on GamsGo then claim it from your dashboard." },
            ]}
          />
        </CardContent>
      </Card>
    </div>
  );
}
