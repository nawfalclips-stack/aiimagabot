import type { Metadata } from "next";
import { requireCustomer } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { getSettings } from "@/lib/services/settings";
import { SETTING_KEYS } from "@/lib/constants";
import { RechargePageClient } from "./client";
import { vouchersEnabled } from "@/lib/vouchers/redeem";
import type { StoreId } from "@/lib/store";
import { activeRechargePromo } from "@/lib/services/announcements";
import { listPackChoices } from "@/lib/services/packs";

export const metadata: Metadata = { title: "Recharge Balance" };
export const dynamic = "force-dynamic";

export default async function RechargePage() {
  const customer = await requireCustomer();
  const [settings, pendingRequests, promo, packs] = await Promise.all([
    getSettings(customer.storeId as StoreId),
    prisma.rechargeRequest.findMany({
      where: { customerId: customer.id, status: { in: ["PENDING"] } },
      orderBy: { createdAt: "desc" },
    }),
    activeRechargePromo(customer.storeId, customer.id),
    listPackChoices(customer.storeId as StoreId),
  ]);

  const remaining = customer.initialBalanceCents - customer.usedBalanceCents;

  return (
    <RechargePageClient
      vouchersEnabled={vouchersEnabled()}
      storeUrl={settings[SETTING_KEYS.storeUrl]}
      currentBalance={remaining}
      packs={packs}
      promo={promo ? { title: promo.title, pct: promo.rechargeBonusPct, endsAt: promo.endsAt?.toISOString() ?? null } : null}
      pendingRequests={pendingRequests.map((r) => ({
        id: r.id,
        orderNumber: r.orderNumber,
        offerTitle: r.offerTitle,
        balanceCents: r.balanceCents,
        bonusCents: r.bonusCents,
        promoBonusPct: r.promoBonusPct,
        status: r.status,
        createdAt: r.createdAt.toISOString(),
      }))}
    />
  );
}
