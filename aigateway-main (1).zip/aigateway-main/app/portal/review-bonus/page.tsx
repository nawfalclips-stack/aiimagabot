import type { Metadata } from "next";
import { ArrowRight, Gift, Sparkles, TriangleAlert } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { PageHeader } from "@/components/shared/page-header";
import { Callout } from "@/components/shared/callout";
import { Steps } from "@/components/shared/steps";
import { requireCustomer } from "@/lib/auth";
import { getSettings } from "@/lib/services/settings";
import { SETTING_KEYS } from "@/lib/constants";
import { formatCents } from "@/lib/money";
import type { StoreId } from "@/lib/store";

export const metadata: Metadata = { title: "Review Bonus Conditions" };
export const dynamic = "force-dynamic";

export default async function ReviewBonusConditionsPage() {
  const customer = await requireCustomer();
  const settings = await getSettings(customer.storeId as StoreId);
  const storeUrl = settings[SETTING_KEYS.storeUrl];

  const remainingBalanceCents = customer.initialBalanceCents - customer.usedBalanceCents;
  const bonusCents = customer.pendingBonusCents;
  const percent =
    remainingBalanceCents > 0 && bonusCents > 0
      ? Math.round((bonusCents / remainingBalanceCents) * 100)
      : null;

  const steps = [
    {
      title: "Complete your order",
      body: (
        <>
          Purchase an offer from our store and finish checkout. Your order must be completed before
          the bonus becomes available.
        </>
      ),
    },
    {
      title: "Write a positive review",
      body: (
        <>
          After using the service, open our store page and post an honest{" "}
          <strong>positive review</strong>. Reviews help us grow — this is why the bonus exists.
        </>
      ),
    },
    {
      title: "Confirm it on your dashboard",
      body: (
        <>
          Come back to this site, open your dashboard, and press{" "}
          <strong>&ldquo;Yes, I wrote a review&rdquo;</strong>. The bonus is added to your account
          instantly.
        </>
      ),
    },
  ];

  return (
    <div className="max-w-2xl space-y-6">
      <PageHeader
        eyebrow="Rewards"
        title="Review Bonus Conditions"
        description="Earn free credit by writing a review of our store. Here is exactly how it works and what you need to do to get your bonus."
      />

      {bonusCents > 0 ? (
        <Callout tone="success" icon={Gift} title={`Your available bonus: ${formatCents(bonusCents)} is waiting on your account.`}>
          {percent ? (
            <>
              That equals <strong className="text-foreground">{percent}%</strong> of your current balance — credited as
              soon as both conditions below are met.
            </>
          ) : null}
        </Callout>
      ) : null}

      <Card>
        <CardHeader>
          <CardTitle>Conditions to receive the bonus</CardTitle>
          <CardDescription>Three steps — the last one happens right here on your dashboard.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-5">
          <Steps items={steps.map((step) => ({ title: step.title, body: step.body }))} />
          <Button asChild size="lg">
            <a href={storeUrl} target="_blank" rel="noopener noreferrer">
              Open our store on GamsGo <ArrowRight />
            </a>
          </Button>
        </CardContent>
      </Card>

      <Callout tone="warning" icon={TriangleAlert} title="Only confirm after you post the review">
        Press &ldquo;Yes, I wrote a review&rdquo; only after you actually posted it. We verify every claim — if no review
        is found, the bonus is removed from your account.
      </Callout>

      <Callout tone="muted" icon={Sparkles} title="And that&apos;s not all — Loyalty Points">
        Every purchase also earns <strong className="text-foreground">loyalty points</strong>. Points unlock levels
        (Silver → Gold → VIP), each with its own dashboard color and perks: bigger recharge bonuses at Silver, and cash
        rewards of $170 / $220 at Gold and VIP (always approved by an administrator first).{" "}
        <a href="/portal/rules" className="font-medium text-primary underline-offset-4 hover:underline">
          Read the full points system →
        </a>
      </Callout>
    </div>
  );
}
