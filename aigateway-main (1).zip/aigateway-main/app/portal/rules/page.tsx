import type { Metadata } from "next";
import { ArrowRight, Gift, Handshake, LifeBuoy, Lock, RefreshCw, ShoppingBag, Star, TriangleAlert } from "lucide-react";
import type { LucideIcon } from "lucide-react";
import { requireCustomer } from "@/lib/auth";
import { getSettings } from "@/lib/services/settings";
import { SETTING_KEYS } from "@/lib/constants";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { PageHeader } from "@/components/shared/page-header";
import { Callout } from "@/components/shared/callout";
import type { StoreId } from "@/lib/store";

export const metadata: Metadata = { title: "Rules & Terms" };
export const dynamic = "force-dynamic";

const SECTIONS: Array<{ id: string; label: string; icon: LucideIcon }> = [
  { id: "purchase", label: "Purchasing", icon: ShoppingBag },
  { id: "recharge", label: "Recharging", icon: RefreshCw },
  { id: "loyalty", label: "Loyalty", icon: Star },
  { id: "affiliate", label: "Affiliate", icon: Handshake },
  { id: "bonus", label: "Bonus", icon: Gift },
  { id: "security", label: "Security", icon: Lock },
  { id: "support", label: "Support", icon: LifeBuoy },
  { id: "arabic", label: "العربية", icon: ArrowRight },
];

function Section({ id, icon: Icon, title, children }: { id: string; icon: LucideIcon; title: string; children: React.ReactNode }) {
  return (
    <Card id={id} className="scroll-mt-24">
      <CardHeader>
        <CardTitle className="flex items-center gap-2.5">
          <span className="flex size-7 items-center justify-center rounded-lg bg-primary/10 text-primary">
            <Icon className="size-4" />
          </span>
          {title}
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-3 text-sm leading-relaxed text-foreground/85">{children}</CardContent>
    </Card>
  );
}

export default async function RulesPage() {
  const customer = await requireCustomer();
  const settings = await getSettings(customer.storeId as StoreId);
  const storeUrl = settings[SETTING_KEYS.storeUrl];

  return (
    <div className="max-w-2xl space-y-6">
      <PageHeader
        eyebrow="Help"
        title="Rules & Terms of Use"
        description="Please read and follow these rules to keep your account active and avoid any interruption."
      />

      {/* Jump-to-section chips */}
      <nav aria-label="Sections" className="flex flex-wrap gap-2">
        {SECTIONS.map((s) => (
          <a
            key={s.id}
            href={`#${s.id}`}
            className="inline-flex items-center gap-1.5 rounded-full border bg-card px-3 py-1.5 text-xs font-medium text-muted-foreground shadow-card transition-colors hover:border-primary/40 hover:text-foreground"
          >
            {s.id === "arabic" ? null : <s.icon className="size-3.5" />}
            {s.label}
          </a>
        ))}
      </nav>

      <Section id="purchase" icon={ShoppingBag} title="How to Purchase">
        <p>
          All purchases must be made exclusively through our store on <strong>GamsGo</strong>. Click the button below,
          choose the right offer, and complete checkout. Then activate with your Order ID (or voucher code) and create
          your API token on the API Access page.
        </p>
        <Button asChild>
          <a href={storeUrl} target="_blank" rel="noopener noreferrer">
            Open our store on GamsGo <ArrowRight />
          </a>
        </Button>
      </Section>

      <Section id="recharge" icon={RefreshCw} title="Recharging Your Balance">
        <p>To recharge your balance after it runs out:</p>
        <ol className="list-decimal space-y-1 pl-5 marker:text-muted-foreground">
          <li>Go to our GamsGo store and buy the package you want.</li>
          <li>
            Copy your new <strong>Order Number</strong> and the <strong>Offer Title</strong> exactly as shown.
          </li>
          <li>
            Go to the <strong>Recharge</strong> page and enter those details.
          </li>
          <li>Your balance is added once the recharge is approved. Your API tokens keep working — nothing to change in your tools.</li>
        </ol>
      </Section>

      <Section id="loyalty" icon={Star} title="Loyalty Points & Levels">
        <p>
          Every completed purchase earns you <strong>loyalty points</strong>. Points unlock levels, and each level
          changes your dashboard color and unlocks bigger perks:
        </p>
        <div className="overflow-hidden rounded-xl border">
          <Table className="min-w-[420px]">
            <TableHeader>
              <TableRow className="bg-muted/40 hover:bg-muted/40">
                <TableHead>Purchase amount</TableHead>
                <TableHead>Points earned</TableHead>
                <TableHead>Level unlocked</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {[
                ["First purchase (any amount under $100)", "25 pts", "Bronze · Lvl 1"],
                ["$100+", "35 pts", "Bronze · Lvl 1"],
                ["$200+", "50 pts", "Bronze · Lvl 1"],
                ["$300+", "70 pts", "Bronze · Lvl 1"],
                ["$500+", "100 pts", "Bronze · Lvl 1"],
                ["$1,000+", "250 pts", "Bronze → higher levels"],
              ].map(([amount, pts, lvl]) => (
                <TableRow key={amount}>
                  <TableCell className="whitespace-normal">{amount}</TableCell>
                  <TableCell className="font-semibold tabular-nums">{pts}</TableCell>
                  <TableCell className="text-muted-foreground">{lvl}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
        <p>
          <strong>Bonus tip:</strong> every dollar of a purchase above its bracket earns an extra{" "}
          <strong>0.15 points</strong> — so a $620 purchase gives 118 points, not 100.
        </p>

        <h3 className="pt-2 font-semibold text-foreground">Levels &amp; rewards</h3>
        <ul className="list-disc space-y-1 pl-5 marker:text-muted-foreground">
          <li>
            <strong>Silver · Lvl 2</strong> at 600 pts — your recharge bonuses are boosted from 10% to{" "}
            <strong>15%</strong>.
          </li>
          <li>
            <strong>Gold · Lvl 3</strong> at 1,000 pts — claim a <strong>$170 cash reward</strong> (admin approval
            required).
          </li>
          <li>
            <strong>VIP · Max Level</strong> at 1,500 pts — claim a <strong>$220 cash reward</strong> plus all previous
            perks (admin approval required).
          </li>
        </ul>
        <p className="text-muted-foreground">
          Rewards are never credited automatically: press the request button on your dashboard and wait for an
          administrator to approve it. Points stay yours even if a reward is rejected.
        </p>
      </Section>

      <Section id="affiliate" icon={Handshake} title="Affiliate Program — Invite & Earn">
        <p>
          Share your personal referral link (find it in the <strong>Affiliate</strong> tab) with your friends. When they
          buy from our store and activate using your code, you both win:
        </p>
        <ul className="list-disc space-y-1 pl-5 marker:text-muted-foreground">
          <li>
            You earn a <strong>$5 commission + 15 loyalty points</strong> every time an invited friend completes a
            purchase (first activation and every recharge).
          </li>
          <li>
            Your friend just opens your link — the code is filled automatically — then enters their Order ID and Offer
            Title as usual.
          </li>
        </ul>

        <h3 className="pt-2 font-semibold text-foreground">Milestone rewards</h3>
        <p>
          Milestones are counted in packs: when the friends you invited buy the same pack size 10 times in total
          (recharges included), you can claim:
        </p>
        <div className="overflow-hidden rounded-xl border">
          <Table className="min-w-[380px]">
            <TableHeader>
              <TableRow className="bg-muted/40 hover:bg-muted/40">
                <TableHead>Packs bought by your invites</TableHead>
                <TableHead>Your reward (added to balance)</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {[
                ["10 × $100 packs", "$120 reward"],
                ["10 × $200 packs", "$250 reward"],
                ["10 × $300 packs", "$400 reward"],
              ].map(([spent, reward]) => (
                <TableRow key={spent}>
                  <TableCell>{spent}</TableCell>
                  <TableCell className="font-semibold text-success tabular-nums">{reward}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>

        <p>
          Milestone bonuses are <strong>not paid automatically</strong>: when you reach one, press the claim button on
          your Affiliate page. An administrator verifies your referrals&apos; orders first, then credits the bonus to your
          account.
        </p>
        <Callout tone="warning" icon={TriangleAlert}>
          Fake or self-referrals are detected and disqualified. Only real, completed orders count.
        </Callout>
      </Section>

      <Section id="bonus" icon={Gift} title="Bonus Rules">
        <p>
          Some offers include a <strong>bonus credit</strong> that is released after you write a review on our store.
        </p>
        <ul className="list-disc space-y-1 pl-5 marker:text-muted-foreground">
          <li>Write a genuine review on GamsGo after using the service.</li>
          <li>
            Come back to your dashboard and press <strong>&ldquo;Yes, I wrote a review&rdquo;</strong>.
          </li>
          <li>The bonus is added to your account instantly.</li>
        </ul>
        <Callout tone="warning" icon={TriangleAlert}>
          Do not click the review button if you have not written a review. We verify all claims — if the review is not
          found, the bonus will be removed.
        </Callout>
      </Section>

      <Section id="security" icon={Lock} title="Security & Privacy">
        <ul className="list-disc space-y-1 pl-5 marker:text-muted-foreground">
          <li>
            Never share your <strong>API tokens</strong> with anyone. If one leaks, revoke it on the API Access page.
          </li>
          <li>
            Never share your <strong>Access Code</strong> with anyone.
          </li>
          <li>Do not share any account information with other people.</li>
          <li>You may only share information with us (the seller) through our GamsGo store.</li>
          <li>
            <strong>Reselling is strictly prohibited.</strong>
          </li>
        </ul>
      </Section>

      <Section id="support" icon={LifeBuoy} title="Support">
        <ul className="list-disc space-y-1 pl-5 marker:text-muted-foreground">
          <li>
            If you have a problem, open a support ticket from the <strong>Support</strong> tab.
          </li>
          <li>
            For direct communication, contact us through our GamsGo store — that is the <strong>only</strong> supported
            channel.
          </li>
          <li>
            Maximum response time is <strong>48 hours</strong>, but we usually reply within a few hours or even minutes.
          </li>
          <li>Avoid sending repeated or duplicate messages — it slows down the process.</li>
        </ul>
        <Button asChild variant="outline">
          <a href={storeUrl} target="_blank" rel="noopener noreferrer">
            Contact support on GamsGo <ArrowRight />
          </a>
        </Button>
      </Section>

      {/* Arabic version */}
      <Card id="arabic" dir="rtl" className="scroll-mt-24">
        <CardHeader>
          <CardTitle>القوانين بالعربية</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4 text-sm leading-relaxed text-foreground/85">
          {[
            {
              icon: ShoppingBag,
              title: "طريقة الشراء",
              body: "جميع عمليات الشراء تتم حصراً داخل منصة GamsGo. اختر العرض المناسب واكمل عملية الدفع، وستحصل على مفتاح API الخاص بك تلقائياً.",
            },
            {
              icon: RefreshCw,
              title: "إعادة التعبئة",
              body: "عند انتهاء رصيدك، اشتر باقة جديدة من المتجر ثم توجه إلى صفحة \"إعادة التعبئة\" وأدخل رقم الطلب وعنوان العرض. سيتم إضافة الرصيد وتغيير مفتاح API تلقائياً.",
            },
            {
              icon: Gift,
              title: "قانون البونص",
              body: "يُضاف البونص بعد كتابة مراجعة حقيقية على المتجر. لا تضغط على زر \"كتبت مراجعة\" إن لم تكن قد فعلت ذلك — سنتحقق من الأمر، وإن ثبت العكس سيُوقف البونص.",
            },
          ].map((item) => (
            <div key={item.title} className="flex gap-3">
              <item.icon className="mt-0.5 size-4 shrink-0 text-primary" />
              <div>
                <p className="mb-1 font-semibold text-foreground">{item.title}</p>
                <p>{item.body}</p>
              </div>
            </div>
          ))}
          <div className="flex gap-3">
            <Lock className="mt-0.5 size-4 shrink-0 text-primary" />
            <div>
              <p className="mb-1 font-semibold text-foreground">الأمان والخصوصية</p>
              <ul className="list-disc space-y-1 pr-5 marker:text-muted-foreground">
                <li>لا تشارك مفتاح API مع أي شخص.</li>
                <li>لا تشارك كود الدخول مع أي شخص.</li>
                <li>إعادة البيع ممنوعة منعاً باتاً.</li>
              </ul>
            </div>
          </div>
          <div className="flex gap-3">
            <LifeBuoy className="mt-0.5 size-4 shrink-0 text-primary" />
            <div>
              <p className="mb-1 font-semibold text-foreground">الدعم الفني</p>
              <p>
                الطريقة الوحيدة للتواصل معنا هي داخل متجرنا على GamsGo. الحد الأقصى للرد هو 48 ساعة، لكن في الغالب يكون
                الرد في ساعات قليلة أو دقائق.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
