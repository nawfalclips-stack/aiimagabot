import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { ArrowLeft, Bot, ExternalLink, ShieldCheck, User } from "lucide-react";
import { requireCustomer } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { getSettings } from "@/lib/services/settings";
import { SETTING_KEYS } from "@/lib/constants";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { LocalTime } from "@/components/shared/local-time";
import { Callout } from "@/components/shared/callout";
import { TICKET_TYPE_LABELS, TICKET_STATUS_LABELS, type TicketType, type TicketStatus } from "@/lib/constants";
import { cn } from "@/lib/utils";
import type { StoreId } from "@/lib/store";

export const metadata: Metadata = { title: "Ticket" };
export const dynamic = "force-dynamic";

const STATUS_STYLE: Record<string, string> = {
  OPEN: "bg-primary/12 text-primary",
  AUTO_FIXING: "bg-warning/12 text-warning animate-pulse",
  AUTO_RESOLVED: "bg-success/12 text-success",
  RESOLVED: "bg-success/12 text-success",
  CLOSED: "bg-muted text-muted-foreground",
};

export default async function TicketDetailPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const customer = await requireCustomer();

  await import("@/lib/services/tickets").then(({ runAutoFix }) => runAutoFix()).catch(() => null);

  const [ticket, settings] = await Promise.all([
    prisma.ticket.findUnique({
      where: { id },
      include: { messages: { orderBy: { createdAt: "asc" } } },
    }),
    getSettings(customer.storeId as StoreId),
  ]);

  if (!ticket || ticket.customerId !== customer.id) notFound();

  const storeUrl = settings[SETTING_KEYS.storeUrl];
  const isResolved = ticket.status === "RESOLVED" || ticket.status === "AUTO_RESOLVED" || ticket.status === "CLOSED";

  return (
    <div className="max-w-2xl space-y-5">
      <Button asChild variant="ghost" size="sm" className="-ml-2 text-muted-foreground">
        <Link href="/portal/support"><ArrowLeft /> All tickets</Link>
      </Button>

      <div className="flex flex-wrap items-start justify-between gap-3">
        <div className="min-w-0">
          <p className="eyebrow mb-1.5 text-primary">Support ticket</p>
          <h1 className="text-2xl leading-tight font-semibold tracking-tight">{ticket.title}</h1>
          <p className="mt-1 text-xs text-muted-foreground">
            {TICKET_TYPE_LABELS[ticket.type as TicketType]} · <LocalTime date={ticket.createdAt} variant="datetime" />
          </p>
        </div>
        <span className={cn("inline-flex rounded-full px-3 py-1 text-xs font-semibold", STATUS_STYLE[ticket.status])}>
          {TICKET_STATUS_LABELS[ticket.status as TicketStatus] ?? ticket.status}
        </span>
      </div>

      {/* Original description */}
      <Card>
        <CardContent>
          <p className="text-sm whitespace-pre-wrap text-foreground/90">{ticket.description}</p>
          {ticket.screenshotUrl ? (
            <a href={ticket.screenshotUrl} target="_blank" rel="noopener noreferrer"
               className="mt-3 block overflow-hidden rounded-lg border">
              <img src={ticket.screenshotUrl} alt="Screenshot" className="max-h-48 w-full object-contain" />
            </a>
          ) : null}
        </CardContent>
      </Card>

      {/* Contact banner — shown while ticket is open */}
      {!isResolved ? (
        <Callout
          icon={ExternalLink}
          title="Need a faster response?"
          action={
            <Button asChild size="sm">
              <a href={storeUrl} target="_blank" rel="noopener noreferrer">
                <ExternalLink /> Contact us on GamsGo
              </a>
            </Button>
          }
        >
          Contact us directly through our store. We reply within 48 hours — usually much faster.
        </Callout>
      ) : null}

      {/* Messages */}
      <div className="space-y-3">
        {ticket.messages.map((msg) => {
          const isCustomer = !msg.fromAdmin && !msg.isBot;
          return (
            <div key={msg.id} className={cn("flex gap-2.5", isCustomer && "flex-row-reverse")}>
              <span className={cn(
                "flex size-8 shrink-0 items-center justify-center rounded-full",
                msg.isBot ? "bg-primary/12 text-primary" : msg.fromAdmin ? "bg-success/12 text-success" : "bg-muted text-muted-foreground"
              )}>
                {msg.isBot ? <Bot className="size-4" /> : msg.fromAdmin ? <ShieldCheck className="size-4" /> : <User className="size-4" />}
              </span>
              <div className={cn("max-w-[80%] space-y-0.5", isCustomer && "items-end text-right")}>
                <div className={cn(
                  "rounded-2xl px-4 py-2.5 text-sm leading-relaxed",
                  msg.isBot ? "bg-primary/8 border border-primary/15" :
                  msg.fromAdmin ? "bg-success/8 border border-success/15" :
                  "bg-muted/60"
                )}>
                  <p className="whitespace-pre-wrap">{msg.body}</p>
                </div>
                <p className="px-1 text-[11px] text-muted-foreground">
                  {msg.isBot ? "🤖 Auto-reply" : msg.fromAdmin ? "Support team" : "You"} ·{" "}
                  <LocalTime date={msg.createdAt} variant="log" />
                </p>
              </div>
            </div>
          );
        })}
      </div>

      {isResolved ? (
        <p className="border-t pt-4 text-center text-sm text-muted-foreground">
          This ticket is closed. If you have a new issue, open a new ticket or{" "}
          <a href={storeUrl} target="_blank" rel="noopener noreferrer" className="font-medium text-foreground underline-offset-4 hover:underline">
            contact us on GamsGo
          </a>.
        </p>
      ) : null}
    </div>
  );
}
