"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { getCurrentCustomer } from "@/lib/auth";
import { createTicket, replyToTicket, closeTicket as svcClose } from "@/lib/services/tickets";
import { TICKET_TYPES } from "@/lib/constants";
import type { StoreId } from "@/lib/store";

export type TicketActionResult = { ok: true } | { ok: false; error: string };

export async function createTicketAction(input: {
  type: string;
  title: string;
  description: string;
  screenshotUrl?: string;
}): Promise<TicketActionResult & { ticketId?: string }> {
  try {
    const customer = await getCurrentCustomer();
    if (!customer) return { ok: false, error: "Session expired — sign in again." };

    const data = z.object({
      type: z.enum(TICKET_TYPES),
      title: z.string().trim().min(4, "Title is too short").max(120),
      description: z.string().trim().min(10, "Describe the issue in more detail").max(5000),
      screenshotUrl: z.string().url("Enter a valid URL").max(500).optional().or(z.literal("")),
    }).parse(input);

    const ticket = await createTicket({
      customerId: customer.id,
      type: data.type,
      title: data.title,
      description: data.description,
      screenshotUrl: data.screenshotUrl ?? "",
      storeId: customer.storeId as StoreId,
    });

    revalidatePath("/portal/support", "layout");
    return { ok: true, ticketId: ticket.id };
  } catch (error) {
    if (error instanceof z.ZodError) return { ok: false, error: error.issues[0].message };
    return { ok: false, error: "Could not create the ticket. Please try again." };
  }
}

export async function customerReplyAction(ticketId: string, body: string): Promise<TicketActionResult> {
  try {
    const customer = await getCurrentCustomer();
    if (!customer) return { ok: false, error: "Session expired." };

    const cleanBody = z.string().trim().min(1).max(5000).parse(body);
    const ticket = await import("@/lib/prisma").then(({ prisma }) =>
      prisma.ticket.findUnique({ where: { id: ticketId }, select: { customerId: true } })
    );
    if (!ticket || ticket.customerId !== customer.id) return { ok: false, error: "Ticket not found." };

    await replyToTicket({ ticketId, body: cleanBody, fromAdmin: false });
    revalidatePath(`/portal/support/${ticketId}`);
    return { ok: true };
  } catch (error) {
    console.error(error);
    return { ok: false, error: "Could not send your reply." };
  }
}
