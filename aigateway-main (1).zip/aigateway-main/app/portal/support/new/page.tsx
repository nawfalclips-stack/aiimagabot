import type { Metadata } from "next";
import { requireCustomer } from "@/lib/auth";
import { prisma } from "@/lib/prisma";
import { NewTicketForm } from "@/components/portal/new-ticket-form";

export const metadata: Metadata = { title: "New Ticket" };
export const dynamic = "force-dynamic";

export default async function NewTicketPage() {
  const customer = await requireCustomer();
  const order = await prisma.order.findUnique({
    where: { customerId: customer.id },
    select: { orderNumber: true },
  });
  return <NewTicketForm orderNumber={order?.orderNumber ?? ""} />;
}
