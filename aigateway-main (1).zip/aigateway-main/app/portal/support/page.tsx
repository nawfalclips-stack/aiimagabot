import type { Metadata } from "next";
import { Clock, ExternalLink, MessageSquare } from "lucide-react";
import { requireCustomer } from "@/lib/auth";
import { getSettings } from "@/lib/services/settings";
import { SETTING_KEYS } from "@/lib/constants";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { PageHeader } from "@/components/shared/page-header";
import { Steps } from "@/components/shared/steps";
import { Callout } from "@/components/shared/callout";
import type { StoreId } from "@/lib/store";

export const metadata: Metadata = { title: "Report an Issue" };
export const dynamic = "force-dynamic";

export default async function SupportPage() {
  const customer = await requireCustomer();
  const settings = await getSettings(customer.storeId as StoreId);
  const storeUrl = settings[SETTING_KEYS.storeUrl];

  return (
    <div className="max-w-2xl space-y-6">
      <PageHeader
        eyebrow="Help"
        title="Report an Issue"
        description="All support is handled through our GamsGo store. Follow the steps below to get help fast."
      />

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <MessageSquare className="size-4 text-primary" /> Three steps to get help
          </CardTitle>
          <CardDescription>A screenshot plus a short message lets us fix most issues on the first reply.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <Steps
            items={[
              {
                title: "Take a screenshot of the problem",
                body: "Capture the error message or the page where the issue appears.",
              },
              {
                title: "Write a short description of the issue",
                body: "Briefly explain what happened and what you were trying to do.",
              },
              {
                title: "Send them to us on our GamsGo store",
                body: "Open our store and send the screenshot + message.",
              },
            ]}
          />
          <Button asChild size="lg" className="w-full">
            <a href={storeUrl} target="_blank" rel="noopener noreferrer">
              <ExternalLink /> Open our GamsGo store
            </a>
          </Button>
        </CardContent>
      </Card>

      <Callout tone="muted" icon={Clock} title="Response time">
        We respond within 48 hours — usually much faster.
      </Callout>
    </div>
  );
}
