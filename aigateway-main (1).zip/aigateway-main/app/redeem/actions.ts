"use server";

import { cookies, headers } from "next/headers";
import { z } from "zod";
import { getCurrentCustomer } from "@/lib/auth";
import { createCustomerSession } from "@/lib/session";
import { resolvePublicStoreId } from "@/lib/store";
import { performRedemption } from "@/lib/vouchers/redeem";
import { hashRedeemIp } from "@/lib/vouchers/service";

export interface RedeemState {
  error?: string;
  requiresCaptcha?: boolean;
  /** New account created: show the access code once. */
  accessCode?: string;
  /** Existing signed-in customer topped up. */
  toppedUp?: boolean;
  credited?: boolean;
  balanceCents?: number;
  bonusCents?: number;
  planName?: string;
}

const schema = z.object({
  code: z.string().trim().min(10, "Enter the code from your GamsGo order").max(64),
  gamsgoOrderId: z.string().trim().max(64).optional().transform((v) => v || undefined),
  affiliateCode: z.string().optional().transform((v) => (v ?? "").trim().toUpperCase() || undefined),
  turnstileToken: z.string().optional(),
});

/**
 * Public redemption (WS9). A signed-in customer tops up their own account;
 * anyone else gets a new account and is signed in. Failures are uniform.
 */
export async function redeemCodeAction(_prev: RedeemState, formData: FormData): Promise<RedeemState> {
  const parsed = schema.safeParse({
    code: String(formData.get("code") ?? ""),
    gamsgoOrderId: String(formData.get("gamsgoOrderId") ?? ""),
    affiliateCode: String(formData.get("affiliateCode") ?? ""),
    turnstileToken: String(formData.get("cf-turnstile-response") ?? ""),
  });
  if (!parsed.success) return { error: parsed.error.issues[0].message };

  try {
    const [storeId, customer, h, c] = await Promise.all([resolvePublicStoreId(), getCurrentCustomer(), headers(), cookies()]);
    const cookieRef = h.get("x-affiliate-ref") ?? c.get("aerolink_ref")?.value ?? undefined;
    const affiliateCode = parsed.data.affiliateCode ?? (cookieRef && /^[A-Z0-9_-]{3,32}$/i.test(cookieRef) ? cookieRef.toUpperCase() : undefined);
    const sessionKey = customer ? `c:${customer.id}` : `anon:${hashRedeemIp((h.get("x-forwarded-for") ?? "local").split(",")[0].trim())}`;

    const outcome = await performRedemption({
      storeId,
      rawCode: parsed.data.code,
      gamsgoOrderId: parsed.data.gamsgoOrderId,
      turnstileToken: parsed.data.turnstileToken,
      sessionKey,
      customer,
      affiliateCode,
    });
    if (!outcome.ok) return { error: outcome.message, requiresCaptcha: outcome.requiresCaptcha };

    const r = outcome.result;
    if (r.kind === "new") {
      await createCustomerSession(r.customerId);
      return { accessCode: r.accessCode, credited: r.credited, balanceCents: r.balanceCents, bonusCents: r.bonusCents, planName: r.planName };
    }
    return { toppedUp: true, credited: r.credited, balanceCents: r.balanceCents, bonusCents: r.bonusCents, planName: r.planName };
  } catch (error) {
    console.error("[redeem]", error);
    return { error: "Something went wrong. Please try again." };
  }
}
