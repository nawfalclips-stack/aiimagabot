import type { Metadata } from "next";
import Link from "next/link";
import { ArrowLeft, Ticket } from "lucide-react";
import { getSettings } from "@/lib/services/settings";
import { SETTING_KEYS } from "@/lib/constants";
import { getCurrentCustomer } from "@/lib/auth";
import { resolvePublicStoreId } from "@/lib/store";
import { parseSocialLinks } from "@/lib/social-links";
import { SocialLinks } from "@/components/shared/social-links";
import { ThemeToggle } from "@/components/theme/theme-toggle";
import { RedeemForm } from "@/components/portal/redeem-form";
import { vouchersEnabled } from "@/lib/vouchers/redeem";
import { BrandMark } from "@/components/shared/brand-mark";

export const metadata: Metadata = { title: "Redeem your code" };
export const dynamic = "force-dynamic";

export default async function RedeemPage({ searchParams }: { searchParams: Promise<{ code?: string }> }) {
  const [storeId, customer, params] = await Promise.all([resolvePublicStoreId(), getCurrentCustomer(), searchParams]);
  const settings = await getSettings(storeId);
  const storeUrl = settings[SETTING_KEYS.storeUrl];

  return (
    <main className="relative flex min-h-screen flex-1 flex-col overflow-hidden">
      <div aria-hidden className="pointer-events-none absolute inset-0">
        <div className="absolute top-[-20%] left-1/2 h-[480px] w-[720px] -translate-x-1/2 rounded-full bg-primary/12 blur-[140px]" />
        <div className="absolute inset-0 dot-grid" />
      </div>

      <header className="relative z-10 mx-auto flex w-full max-w-5xl items-center justify-between px-6 py-6">
        <Link href="/" className="flex items-center gap-2.5">
          <span className="flex size-9 items-center justify-center overflow-hidden rounded-xl">
            <BrandMark className="size-9" />
          </span>
          <span className="text-lg font-semibold tracking-tight">{settings[SETTING_KEYS.logoText]}</span>
        </Link>
        <div className="flex items-center gap-3">
          <Link href="/login" className="flex items-center gap-1.5 text-sm text-muted-foreground transition-colors hover:text-foreground">
            <ArrowLeft className="size-4" /> Already have an access code? Sign in
          </Link>
          <ThemeToggle />
        </div>
      </header>

      <div className="relative z-10 flex flex-1 items-center justify-center px-4 pb-16">
        <div className="w-full max-w-lg">
          <div className="mb-8 flex flex-col items-center text-center">
            <div className="flex size-12 items-center justify-center rounded-2xl bg-primary/15 ring-1 ring-primary/30">
              <Ticket className="size-6 text-primary" />
            </div>
            <h1 className="mt-4 text-2xl font-semibold tracking-tight">Redeem your code</h1>
            <p className="mt-1 text-sm text-muted-foreground">
              Paste the code GamsGo sent you after checkout. Your account and credit are ready in seconds — no waiting for delivery.
            </p>
          </div>
          {vouchersEnabled() ? (
          <RedeemForm initialCode={typeof params.code === "string" ? params.code.slice(0, 64) : ""} signedInAs={customer?.accessCode ?? null} turnstileSiteKey={process.env.NEXT_PUBLIC_TURNSTILE_SITE_KEY ?? null} />
          ) : (
            <p className="rounded-xl border px-4 py-3 text-center text-sm text-muted-foreground">Code redemption is currently disabled. Please contact support through our store.</p>
          )}
          <p className="mt-6 text-center text-xs text-muted-foreground">
            Bought a manual-delivery offer instead? <Link href="/" className="text-primary hover:underline">Activate with your Order ID</Link>.
          </p>
        </div>
      </div>

      <footer className="relative z-10 border-t border-border">
        <div className="mx-auto flex w-full max-w-5xl flex-col items-center justify-between gap-2 px-6 py-6 text-xs text-muted-foreground sm:flex-row">
          <p>{settings[SETTING_KEYS.footerText]}</p>
          <SocialLinks links={parseSocialLinks(settings[SETTING_KEYS.socialLinks])} />
          <a href={storeUrl} target="_blank" rel="noopener noreferrer" className="transition-colors hover:text-foreground">
            Our store — contact & support
          </a>
        </div>
      </footer>
    </main>
  );
}
