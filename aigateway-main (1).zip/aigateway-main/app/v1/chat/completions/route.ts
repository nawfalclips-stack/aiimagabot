import { handleGateway } from "@/lib/gateway/handler";

// OpenAI-compatible endpoint used by Codex CLI (`wire_api = "chat"`) and any
// OpenAI SDK pointed at this site.
// Node runtime (Edge is deprecated and caps time-to-first-byte at 25 s, which
// reasoning models exceed). Keep maxDuration equal to GATEWAY_MAX_DURATION_S in
// lib/gateway/duration.ts (Hobby 300 s, Pro 800 s).
export const runtime = "nodejs";
export const dynamic = "force-dynamic";
export const maxDuration = 300; // Vercel Hobby maximum; 800 on Pro — see lib/gateway/duration.ts

export async function POST(request: Request) {
  return handleGateway(request, "openai");
}
