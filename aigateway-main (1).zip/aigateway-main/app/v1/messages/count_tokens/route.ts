import { authenticateGatewayRequest, AUTH_FAILURE_MESSAGES } from "@/lib/gateway/tokens";
import { asGatewayError, GatewayError, errorResponse, newRequestId, RESPONSE_HYGIENE_HEADERS } from "@/lib/gateway/errors";
import { readBodyText } from "@/lib/gateway/body";

// Claude Code calls this to size prompts. Upstream providers have no
// equivalent, so we return a conservative estimate (~4 chars per token).
export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  const requestId = newRequestId();
  const auth = await authenticateGatewayRequest(request.headers);
  if (!auth.ok) {
    const { status, message } = AUTH_FAILURE_MESSAGES[auth.reason];
    return errorResponse("anthropic", new GatewayError(status, status === 401 ? "authentication_error" : "permission_error", message), requestId);
  }
  let text = "";
  try {
    text = await readBodyText(request);
    JSON.parse(text);
  } catch (e) {
    const err = e instanceof GatewayError ? e : new GatewayError(400, "invalid_request_error", "Request body must be JSON.");
    return errorResponse("anthropic", asGatewayError(err), requestId);
  }
  return Response.json({ input_tokens: Math.max(1, Math.ceil(text.length / 4)) }, { headers: { ...RESPONSE_HYGIENE_HEADERS, "x-request-id": requestId } });
}
