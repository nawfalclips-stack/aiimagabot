import { authenticateGatewayRequest, AUTH_FAILURE_MESSAGES } from "@/lib/gateway/tokens";
import { GatewayError, errorResponse, newRequestId, RESPONSE_HYGIENE_HEADERS } from "@/lib/gateway/errors";
import { listModelsForStore } from "@/lib/gateway/registry";

// Model listing, scoped to the token's store. OpenAI shape (`object`,
// `owned_by`) plus the Anthropic fields (`type`, `display_name`,
// `created_at`, `has_more`, `first_id`, `last_id`) so Claude Desktop and the
// Anthropic SDK can discover models too. Only catalog aliases are listed.
export const runtime = "nodejs";
export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const requestId = newRequestId();
  const auth = await authenticateGatewayRequest(request.headers);
  if (!auth.ok) {
    const { status, message } = AUTH_FAILURE_MESSAGES[auth.reason];
    return errorResponse("openai", new GatewayError(status, status === 401 ? "authentication_error" : "permission_error", message), requestId);
  }
  const models = await listModelsForStore(auth.customer.storeId);
  return Response.json(
    {
      object: "list",
      data: models.map((m) => ({
        id: m.publicSlug,
        object: "model",
        type: "model",
        created: 0,
        created_at: "1970-01-01T00:00:00Z",
        owned_by: "aerolink",
        display_name: m.publicName,
        context_window: m.contextWindow,
        max_output_tokens: m.maxOutputTokens,
      })),
      has_more: false,
      first_id: models[0]?.publicSlug ?? null,
      last_id: models[models.length - 1]?.publicSlug ?? null,
    },
    { headers: { ...RESPONSE_HYGIENE_HEADERS, "x-request-id": requestId } }
  );
}
