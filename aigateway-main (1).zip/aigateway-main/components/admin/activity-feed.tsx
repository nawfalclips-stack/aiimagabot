import Link from "next/link";
import {
  BookOpen,
  CircleCheck,
  CircleDollarSign,
  Gift,
  KeyRound,
  LogIn,
  LogOut,
  Pencil,
  RefreshCcw,
  Settings2,
  ShoppingBag,
  Star,
  Trash2,
  UserPlus,
  type LucideIcon,
} from "lucide-react";
import { timeAgo } from "@/lib/format";
import { cn } from "@/lib/utils";

const ICONS: Record<string, { icon: LucideIcon; tone: string }> = {
  CUSTOMER_CREATED: { icon: UserPlus, tone: "text-success bg-success/12" },
  CUSTOMER_EDITED: { icon: Pencil, tone: "text-primary bg-primary/12" },
  CUSTOMER_DELETED: { icon: Trash2, tone: "text-destructive bg-destructive/12" },
  CUSTOMER_RESTORED: { icon: RefreshCcw, tone: "text-success bg-success/12" },
  CUSTOMER_PERMANENTLY_DELETED: { icon: Trash2, tone: "text-destructive bg-destructive/12" },
  CUSTOMER_DUPLICATED: { icon: UserPlus, tone: "text-primary bg-primary/12" },
  API_KEY_CHANGED: { icon: KeyRound, tone: "text-warning bg-warning/12" },
  API_POOL_UNASSIGNED: { icon: KeyRound, tone: "text-destructive bg-destructive/12" },
  API_POOL_PURGED: { icon: Trash2, tone: "text-destructive bg-destructive/12" },
  BALANCE_UPDATED: { icon: CircleDollarSign, tone: "text-primary bg-primary/12" },
  BONUS_UPDATED: { icon: Gift, tone: "text-primary bg-primary/12" },
  CUSTOMER_FINISHED: { icon: CircleCheck, tone: "text-destructive bg-destructive/12" },
  PURCHASED_AGAIN_UPDATED: { icon: ShoppingBag, tone: "text-success bg-success/12" },
  STATUS_CHANGED: { icon: RefreshCcw, tone: "text-warning bg-warning/12" },
  DOCUMENTATION_UPDATED: { icon: BookOpen, tone: "text-primary bg-primary/12" },
  SETTINGS_CHANGED: { icon: Settings2, tone: "text-muted-foreground bg-muted" },
  ADMIN_LOGIN: { icon: LogIn, tone: "text-muted-foreground bg-muted" },
  ADMIN_LOGOUT: { icon: LogOut, tone: "text-muted-foreground bg-muted" },
  ADMIN_PASSWORD_CHANGED: { icon: KeyRound, tone: "text-warning bg-warning/12" },
  CUSTOMERS_IMPORTED: { icon: UserPlus, tone: "text-success bg-success/12" },
  CUSTOMERS_EXPORTED: { icon: ShoppingBag, tone: "text-muted-foreground bg-muted" },
  REVIEW_BONUS_CLAIMED: { icon: Star, tone: "text-warning bg-warning/12" },
  REVIEW_BONUS_VERIFIED: { icon: CircleCheck, tone: "text-success bg-success/12" },
  REVIEW_BONUS_REVOKED: { icon: Gift, tone: "text-destructive bg-destructive/12" },
};

export interface ActivityItem {
  id: string;
  action: string;
  description: string;
  createdAt: Date;
  customer?: { accessCode: string; deletedAt: Date | null } | null;
  customerId?: string | null;
}

export function ActivityFeed({ items, className }: { items: ActivityItem[]; className?: string }) {
  return (
    <ol className={cn("relative space-y-0", className)}>
      {items.map((item, i) => {
        const meta = ICONS[item.action] ?? ICONS.CUSTOMER_EDITED;
        const Icon = meta.icon;
        return (
          <li key={item.id} className="relative flex gap-3 pb-5 last:pb-0">
            {i < items.length - 1 ? (
              <span aria-hidden className="absolute top-8 left-[15px] h-[calc(100%-24px)] w-px bg-border" />
            ) : null}
            <span className={cn("z-10 flex size-8 shrink-0 items-center justify-center rounded-full", meta.tone)}>
              <Icon className="size-3.5" />
            </span>
            <div className="min-w-0 flex-1 pt-0.5">
              <p className="text-sm leading-snug text-foreground/90">
                {item.customerId && item.customer && !item.customer.deletedAt ? (
                  <Link href={`/admin/customers/${item.customerId}`} className="hover:underline">
                    {item.description}
                  </Link>
                ) : (
                  item.description
                )}
              </p>
              <p className="mt-0.5 text-xs text-muted-foreground">{timeAgo(item.createdAt)}</p>
            </div>
          </li>
        );
      })}
    </ol>
  );
}
