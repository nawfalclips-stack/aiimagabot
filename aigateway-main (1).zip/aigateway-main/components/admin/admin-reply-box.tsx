"use client";

import { useTransition } from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { CheckCircle2, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { adminCloseTicketAction } from "@/app/admin/(dashboard)/tickets/actions";

/** Admin can only mark a ticket as resolved — no direct messaging to customers. */
export function AdminReplyBox({ ticketId }: { ticketId: string }) {
  const [pending, startTransition] = useTransition();
  const router = useRouter();

  const close = () => {
    startTransition(async () => {
      const result = await adminCloseTicketAction(ticketId);
      if (result.ok) { toast.success("Ticket marked as resolved"); router.refresh(); }
      else toast.error(result.error);
    });
  };

  return (
    <Button variant="outline" onClick={close} disabled={pending} className="text-success hover:text-success">
      {pending ? <Loader2 className="animate-spin" /> : <CheckCircle2 />}
      Mark as resolved
    </Button>
  );
}
