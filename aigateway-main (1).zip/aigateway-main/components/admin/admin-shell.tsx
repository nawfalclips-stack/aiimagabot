"use client";

import { useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { motion } from "framer-motion";
import {
  Award,
  BarChart3,
  BookOpen,
  BotMessageSquare,
  Boxes,
  CreditCard,
  Server,
  ChevronsLeft,
  Share2,
  History,
  Hourglass,
  KeyRound,
  LayoutDashboard,
  LogOut,
  Megaphone,
  Menu,
  Package,
  Ticket,
  PieChart,
  RefreshCw,
  ScrollText,
  Settings,
  ShieldCheck,
  ShoppingCart,
  Users,
  Zap,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { Tooltip, TooltipContent, TooltipTrigger } from "@/components/ui/tooltip";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { GlobalSearch } from "@/components/admin/global-search";
import { StoreSwitcher } from "@/components/admin/store-switcher";
import { NotificationBell } from "@/components/admin/notification-bell";
import { adminLogout } from "@/app/admin/login/actions";
import { cn } from "@/lib/utils";
import { ThemeToggle } from "@/components/theme/theme-toggle";
import { BrandMark } from "@/components/shared/brand-mark";

type NavItem = { href: string; label: string; icon: typeof LayoutDashboard; exact?: boolean };

const NAV_GROUPS: Array<{ label: string; items: NavItem[] }> = [
  {
    label: "Overview",
    items: [
      { href: "/admin", label: "Dashboard", icon: LayoutDashboard, exact: true },
      { href: "/admin/statistics", label: "Statistics", icon: PieChart },
      { href: "/admin/analytics", label: "Analytics", icon: BarChart3 },
      { href: "/admin/activity", label: "Activity", icon: History },
    ],
  },
  {
    label: "Customers",
    items: [
      { href: "/admin/customers", label: "Customers", icon: Users },
      { href: "/admin/orders", label: "Orders", icon: ShoppingCart },
      { href: "/admin/activations", label: "Activations", icon: ShieldCheck },
      { href: "/admin/recharges", label: "Recharges", icon: RefreshCw },
      { href: "/admin/expired", label: "Expired Balance", icon: Hourglass },
      { href: "/admin/announcements", label: "Announcements", icon: Megaphone },
    ],
  },
  {
    label: "Gateway",
    items: [
      { href: "/admin/usage-logs", label: "Usage Logs", icon: ScrollText },
      { href: "/admin/api-pool", label: "API Pool", icon: KeyRound },
      { href: "/admin/providers", label: "Providers", icon: Server },
      { href: "/admin/models", label: "Models", icon: Boxes },
      { href: "/admin/playground", label: "Playground", icon: BotMessageSquare },
    ],
  },
  {
    label: "Commerce",
    items: [
      { href: "/admin/plans", label: "Plans", icon: CreditCard },
      { href: "/admin/packs", label: "Packs", icon: Package },
      { href: "/admin/vouchers", label: "Vouchers", icon: Ticket },
      { href: "/admin/loyalty", label: "Loyalty", icon: Award },
      { href: "/admin/affiliate", label: "Affiliate", icon: Share2 },
    ],
  },
  {
    label: "System",
    items: [
      { href: "/admin/documentation", label: "Documentation", icon: BookOpen },
      { href: "/admin/settings", label: "Settings", icon: Settings },
    ],
  },
];

const NAV = NAV_GROUPS.flatMap((g) => g.items);

interface AdminShellProps {
  adminName: string;
  adminEmail: string;
  adminRole: string;
  logoText: string;
  openTicketCount?: number;
  pendingActivationCount?: number;
  stores: Array<{ id: string; name: string; logoText: string }>;
  currentStoreId: string;
  notifications: Array<{
    id: string;
    type: string;
    title: string;
    message: string;
    customerId: string | null;
    relatedId: string | null;
    isRead: boolean;
    createdAt: Date;
  }>;
  unreadNotificationCount: number;
  /** False when LEGACY_API_POOL_MODE=off (WS10): the API Pool link is hidden. */
  showApiPool?: boolean;
  children: React.ReactNode;
}

export function AdminShell({ adminName, adminEmail, adminRole, logoText, openTicketCount = 0, pendingActivationCount = 0, stores, currentStoreId, notifications, unreadNotificationCount, showApiPool = true, children }: AdminShellProps) {
  const [collapsed, setCollapsed] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const pathname = usePathname();

  // Filter navigation based on role
  const allowedPaths: string[] = (() => {
    switch (adminRole) {
      case "FULL_ACCESS":
        return NAV.map((item) => item.href);
      case "API_VIEWER":
        return [
          "/admin",
          "/admin/customers",
          "/admin/api-pool",
          "/admin/usage-logs",
          "/admin/activity",
        ];
      case "STATISTICS_ONLY":
        return [
          "/admin",
          "/admin/statistics",
          "/admin/analytics",
          "/admin/activity",
        ];
      default:
        return ["/admin"];
    }
  })();

  const visibleNav = NAV.filter(
    (item) => allowedPaths.includes(item.href) && (showApiPool || item.href !== "/admin/api-pool"),
  );

  const isActive = (item: NavItem) => (item.exact ? pathname === item.href : pathname.startsWith(item.href));

  const visibleGroups = NAV_GROUPS.map((g) => ({
    ...g,
    items: g.items.filter((item) => visibleNav.includes(item)),
  })).filter((g) => g.items.length > 0);

  // Longest matching href wins so a parent route never shadows a child one.
  const current = [...visibleNav]
    .sort((x, y) => y.href.length - x.href.length)
    .find((item) => isActive(item));
  const currentGroup = NAV_GROUPS.find((g) => current && g.items.includes(current));

  const navList = (onNavigate?: () => void, compact = collapsed) => (
    <nav className="flex flex-1 flex-col gap-5 px-3" aria-label="Admin navigation">
      {visibleGroups.map((group, gi) => (
        <div key={group.label} className="flex flex-col gap-0.5">
          {compact ? (
            gi > 0 ? <span aria-hidden className="mx-auto mb-1 h-px w-6 bg-border" /> : null
          ) : (
            <p className="eyebrow mb-1 px-3 text-[10px]">{group.label}</p>
          )}
          {group.items.map((item) => {
            const active = item === current;
            const link = (
              <Link
                key={item.href}
                href={item.href}
                onClick={onNavigate}
                aria-current={active ? "page" : undefined}
                className={cn(
                  "group/nav relative flex h-9 items-center gap-3 rounded-lg px-3 text-[13.5px] font-medium transition-colors duration-150",
                  active ? "text-foreground" : "text-muted-foreground hover:bg-accent/70 hover:text-foreground",
                  compact && "justify-center px-0"
                )}
              >
                {active ? (
                  <motion.span
                    layoutId={compact ? "admin-nav-active-compact" : "admin-nav-active"}
                    className="absolute inset-0 rounded-lg bg-card shadow-card ring-1 ring-border"
                    transition={{ type: "spring", stiffness: 420, damping: 36 }}
                  >
                    <span className="absolute top-1/2 -left-3 h-5 w-[3px] -translate-y-1/2 rounded-r-full bg-primary" />
                  </motion.span>
                ) : null}
                <span className="relative z-10 shrink-0">
                  <item.icon
                    className={cn(
                      "size-[18px] transition-transform duration-200 group-hover/nav:scale-105",
                      active && "text-primary"
                    )}
                  />
                  {compact && item.href === "/admin/activations" && pendingActivationCount > 0 ? (
                    <span className="absolute -top-0.5 -right-0.5 size-2 rounded-full bg-warning ring-2 ring-sidebar" />
                  ) : null}
                </span>
                {!compact ? (
                  <span className="relative z-10 flex flex-1 items-center justify-between gap-2">
                    <span className="truncate">{item.label}</span>
                    {item.href === "/admin/activations" && pendingActivationCount > 0 ? (
                      <span className="inline-flex h-5 min-w-5 items-center justify-center rounded-full bg-warning/15 px-1.5 text-[10px] font-bold text-warning tabular-nums ring-1 ring-warning/30">
                        {pendingActivationCount > 99 ? "99+" : pendingActivationCount}
                      </span>
                    ) : null}
                  </span>
                ) : null}
              </Link>
            );
            return compact ? (
              <Tooltip key={item.href}>
                <TooltipTrigger asChild>{link}</TooltipTrigger>
                <TooltipContent side="right">{item.label}</TooltipContent>
              </Tooltip>
            ) : (
              link
            );
          })}
        </div>
      ))}
    </nav>
  );

  const brand = (
    <Link href="/admin" className="flex items-center gap-2.5 overflow-hidden px-1">
      <span className="flex size-8 shrink-0 items-center justify-center overflow-hidden rounded-lg">
        <BrandMark className="size-8" />
      </span>
      {!collapsed ? (
        <span className="flex min-w-0 flex-col leading-tight">
          <span className="truncate font-display text-[15px] font-semibold tracking-tight">{logoText}</span>
          <span className="text-[10px] font-medium tracking-wider text-muted-foreground uppercase">Admin console</span>
        </span>
      ) : null}
    </Link>
  );

  const initials = adminName.slice(0, 2).toUpperCase();

  return (
    <div className="app-canvas flex min-h-screen w-full">
      {/* Desktop sidebar */}
      <aside
        className={cn(
          "sticky top-0 hidden h-screen shrink-0 flex-col border-r bg-sidebar/80 backdrop-blur-sm transition-[width] duration-300 ease-out lg:flex",
          collapsed ? "w-[68px]" : "w-64"
        )}
      >
        <div className={cn("flex h-16 items-center px-4", collapsed && "justify-center px-0")}>{brand}</div>
        <div className="no-scrollbar flex flex-1 flex-col overflow-y-auto pt-3 pb-4">{navList()}</div>
        <div className="flex flex-col gap-1 border-t p-3">
          {!collapsed ? (
            <div className="mb-1 flex items-center gap-2.5 rounded-lg px-2 py-1.5">
              <Avatar className="size-8">
                <AvatarFallback className="bg-primary/15 text-xs font-semibold text-primary">{initials}</AvatarFallback>
              </Avatar>
              <div className="min-w-0 flex-1 leading-tight">
                <p className="truncate text-[13px] font-medium">{adminName}</p>
                <p className="truncate text-[11px] text-muted-foreground">{adminEmail}</p>
              </div>
            </div>
          ) : null}
          <Button
            variant="ghost"
            size="sm"
            className={cn("w-full justify-start gap-2 text-muted-foreground", collapsed && "justify-center px-0")}
            onClick={() => setCollapsed((v) => !v)}
            aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"}
          >
            <ChevronsLeft className={cn("size-4 transition-transform duration-300", collapsed && "rotate-180")} />
            {!collapsed ? "Collapse" : null}
          </Button>
        </div>
      </aside>

      {/* Main column */}
      <div className="flex min-w-0 flex-1 flex-col">
        {/* Topbar */}
        <header className="glass sticky top-0 z-40 flex h-16 shrink-0 items-center gap-2 border-b px-4 sm:gap-3 sm:px-6">
          {/* Mobile nav */}
          <Sheet open={menuOpen} onOpenChange={setMenuOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon-sm" className="lg:hidden" aria-label="Open navigation">
                <Menu />
              </Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-72 bg-sidebar p-0">
              <SheetHeader className="h-16 justify-center border-b px-4">
                <SheetTitle className="flex items-center gap-2.5 text-[15px]">
                  <span className="flex size-8 items-center justify-center overflow-hidden rounded-lg">
                    <BrandMark className="size-8" />
                  </span>
                  {logoText}
                </SheetTitle>
              </SheetHeader>
              <div className="overflow-y-auto py-4">{navList(() => setMenuOpen(false), false)}</div>
            </SheetContent>
          </Sheet>

          {/* Where am I */}
          {current ? (
            <div className="hidden min-w-0 shrink-0 items-center gap-2 text-sm md:flex">
              {currentGroup ? <span className="text-muted-foreground">{currentGroup.label}</span> : null}
              {currentGroup ? <span className="text-muted-foreground/50">/</span> : null}
              <span className="truncate font-medium">{current.label}</span>
            </div>
          ) : null}

          <div className="flex min-w-0 flex-1 justify-end md:justify-center">
            <div className="w-full max-w-sm">
              <GlobalSearch />
            </div>
          </div>

          <div className="flex items-center gap-1 sm:gap-1.5">
            <NotificationBell notifications={notifications} unreadCount={unreadNotificationCount} />
            <StoreSwitcher stores={stores} currentStoreId={currentStoreId} />
            <ThemeToggle />

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="rounded-full" aria-label="Account menu">
                  <Avatar className="size-8">
                    <AvatarFallback className="bg-primary/15 text-xs font-semibold text-primary">{initials}</AvatarFallback>
                  </Avatar>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56">
                <DropdownMenuLabel>
                  <p className="text-sm font-medium">{adminName}</p>
                  <p className="text-xs font-normal text-muted-foreground">{adminEmail}</p>
                </DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem asChild>
                  <Link href="/admin/account">
                    <KeyRound /> My account
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuItem asChild>
                  <Link href="/admin/settings">
                    <Settings /> Settings
                  </Link>
                </DropdownMenuItem>
                <DropdownMenuSeparator />
                <DropdownMenuItem variant="destructive" onSelect={() => adminLogout()}>
                  <LogOut /> Sign out
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>
        </header>

        <main className="mx-auto w-full max-w-[1400px] flex-1 px-4 py-6 sm:px-8 sm:py-9">{children}</main>
      </div>
    </div>
  );
}
