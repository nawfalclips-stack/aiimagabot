"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { Boxes, Info, Loader2, Megaphone, Plus, Sparkles, Square, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { ConfirmDialog } from "@/components/shared/confirm-dialog";
import { EmptyState } from "@/components/shared/empty-state";
import { LocalTime } from "@/components/shared/local-time";
import { cn } from "@/lib/utils";
import { ANNOUNCEMENT_KIND_LABELS, MAX_RECHARGE_BONUS_PCT, type AnnouncementKind } from "@/lib/announcements";
import { createAnnouncementAction, deleteAnnouncementAction, endAnnouncementAction } from "@/app/admin/(dashboard)/announcements/actions";

export interface AnnouncementRow {
  id: string;
  kind: string;
  title: string;
  message: string;
  rechargeBonusPct: number;
  modelSlug: string | null;
  /** Access code when targeted at one customer; null = everyone. */
  audience: string | null;
  startsAt: string;
  endsAt: string | null;
  state: "LIVE" | "SCHEDULED" | "ENDED";
  reads: number;
  /** Recharge requests that locked in this promotion. */
  recharges: number;
  createdBy: string;
}

export interface ModelChoice {
  /** Internal slug (stored on the announcement). */
  slug: string;
  /** What customers see. */
  publicSlug: string;
  publicName: string;
}

const KIND_ICON: Record<string, typeof Info> = { INFO: Info, PROMO: Sparkles, NEW_MODEL: Boxes };

const STATE_STYLE: Record<AnnouncementRow["state"], string> = {
  LIVE: "bg-success/12 text-success",
  SCHEDULED: "bg-primary/12 text-primary",
  ENDED: "bg-muted text-muted-foreground",
};

/** Ready-made copy per kind; the admin edits it before publishing. */
function template(kind: AnnouncementKind, pct: number, model: ModelChoice | null): { title: string; message: string } {
  if (kind === "PROMO") {
    return {
      title: `+${pct}% extra usage on every recharge`,
      message: `For a limited time, recharge your plan and we add ${pct}% of the recharged balance to your bonus — more usage for the same price. Go to Recharge to top up.`,
    };
  }
  if (kind === "NEW_MODEL" && model) {
    return {
      title: `New model available: ${model.publicName}`,
      message: `${model.publicName} is now on your plan. Use the model id "${model.publicSlug}" in your tools — see API Access for its price per million tokens.`,
    };
  }
  return { title: "", message: "" };
}

/** datetime-local value → ISO string in the admin's own time zone ("" → null). */
const localToIso = (v: string) => (v ? new Date(v).toISOString() : null);

export function AnnouncementsView({ announcements, models }: { announcements: AnnouncementRow[]; models: ModelChoice[] }) {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [pending, startTransition] = useTransition();

  const [kind, setKind] = useState<AnnouncementKind>("PROMO");
  const [pct, setPct] = useState(15);
  const [modelSlug, setModelSlug] = useState<string>("");
  const [title, setTitle] = useState("");
  const [message, setMessage] = useState("");
  const [accessCode, setAccessCode] = useState("");
  const [startsAt, setStartsAt] = useState("");
  const [endsAt, setEndsAt] = useState("");

  const applyTemplate = (k: AnnouncementKind, p: number, slug: string) => {
    const t = template(k, p, models.find((m) => m.slug === slug) ?? null);
    setTitle(t.title);
    setMessage(t.message);
  };

  const openNew = () => {
    setKind("PROMO");
    setPct(15);
    setModelSlug("");
    setAccessCode("");
    setStartsAt("");
    setEndsAt("");
    applyTemplate("PROMO", 15, "");
    setOpen(true);
  };

  const publish = () =>
    startTransition(async () => {
      const r = await createAnnouncementAction({
        kind,
        title,
        message,
        rechargeBonusPct: kind === "PROMO" ? pct : 0,
        modelSlug: kind === "NEW_MODEL" ? modelSlug : null,
        accessCode: accessCode.trim() || null,
        startsAt: localToIso(startsAt),
        endsAt: localToIso(endsAt),
      });
      if (!r.ok) {
        toast.error(r.error);
        return;
      }
      toast.success("Announcement published");
      setOpen(false);
      router.refresh();
    });

  const end = (id: string) =>
    startTransition(async () => {
      const r = await endAnnouncementAction(id);
      if (!r.ok) toast.error(r.error);
      router.refresh();
    });

  const remove = async (id: string) => {
    const r = await deleteAnnouncementAction(id);
    if (!r.ok) toast.error(r.error);
    router.refresh();
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-end">
        <Button onClick={openNew}>
          <Plus /> New announcement
        </Button>
      </div>

      {announcements.length === 0 ? (
        <Card className="p-0">
          <EmptyState
            icon={Megaphone}
            title="No announcements yet"
            description="Tell customers about a recharge promotion or a new model. It appears in their portal inbox and on their dashboard."
            className="border-0"
          />
        </Card>
      ) : (
        <div className="grid gap-3">
          {announcements.map((a) => {
            const Icon = KIND_ICON[a.kind] ?? Info;
            return (
              <Card key={a.id} className="flex flex-col gap-3 p-4 sm:flex-row sm:items-start">
                <span className={cn("flex size-9 shrink-0 items-center justify-center rounded-lg", a.kind === "PROMO" ? "bg-success/12 text-success" : "bg-primary/10 text-primary")}>
                  <Icon className="size-[18px]" />
                </span>
                <div className="min-w-0 flex-1 space-y-1">
                  <div className="flex flex-wrap items-center gap-2">
                    <p className="font-medium">{a.title}</p>
                    <span className={cn("rounded-full px-2 py-0.5 text-[11px] font-medium", STATE_STYLE[a.state])}>{a.state.toLowerCase()}</span>
                    <span className="rounded-full border px-2 py-0.5 text-[11px] text-muted-foreground">
                      {ANNOUNCEMENT_KIND_LABELS[a.kind as AnnouncementKind] ?? a.kind}
                      {a.kind === "PROMO" ? ` +${a.rechargeBonusPct}%` : ""}
                      {a.kind === "NEW_MODEL" && a.modelSlug ? ` · ${models.find((m) => m.slug === a.modelSlug)?.publicSlug ?? a.modelSlug}` : ""}
                    </span>
                  </div>
                  <p className="text-sm whitespace-pre-line text-muted-foreground">{a.message}</p>
                  <p className="text-xs text-muted-foreground">
                    {a.audience ? `To ${a.audience}` : "To every customer"} · from <LocalTime date={a.startsAt} />
                    {a.endsAt ? (
                      <>
                        {" "}until <LocalTime date={a.endsAt} />
                      </>
                    ) : (
                      " · no end date"
                    )}
                    {" · "}
                    {a.reads} read{a.reads === 1 ? "" : "s"}
                    {a.kind === "PROMO" ? ` · ${a.recharges} recharge${a.recharges === 1 ? "" : "s"} locked in` : ""}
                    {a.createdBy ? ` · by ${a.createdBy}` : ""}
                  </p>
                </div>
                <div className="flex shrink-0 gap-1">
                  {a.state !== "ENDED" ? (
                    <Button variant="outline" size="sm" disabled={pending} onClick={() => end(a.id)} title="Remove it from inboxes now; recharges already submitted keep their promotion">
                      <Square /> End now
                    </Button>
                  ) : null}
                  <ConfirmDialog
                    trigger={
                      <Button variant="ghost" size="icon-sm" aria-label="Delete" title="Delete" className="text-destructive hover:text-destructive">
                        <Trash2 />
                      </Button>
                    }
                    title="Delete this announcement?"
                    description="It disappears from every inbox. Recharges that already locked in its promotion still receive the bonus on approval."
                    confirmLabel="Delete"
                    destructive
                    onConfirm={() => remove(a.id)}
                  />
                </div>
              </Card>
            );
          })}
        </div>
      )}

      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>New announcement</DialogTitle>
            <DialogDescription>Shown in the customer portal inbox and as a dashboard banner while it runs.</DialogDescription>
          </DialogHeader>

          <div className="grid gap-4">
            <div className="grid gap-2">
              <Label>Type</Label>
              <Select
                value={kind}
                onValueChange={(v) => {
                  const k = v as AnnouncementKind;
                  setKind(k);
                  applyTemplate(k, pct, modelSlug);
                }}
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="PROMO">{ANNOUNCEMENT_KIND_LABELS.PROMO} — extra bonus on recharges</SelectItem>
                  <SelectItem value="NEW_MODEL">{ANNOUNCEMENT_KIND_LABELS.NEW_MODEL}</SelectItem>
                  <SelectItem value="INFO">{ANNOUNCEMENT_KIND_LABELS.INFO}</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {kind === "PROMO" ? (
              <div className="grid gap-2">
                <Label htmlFor="ann-pct">Extra usage on recharges (%)</Label>
                <Input
                  id="ann-pct"
                  type="number"
                  min={1}
                  max={MAX_RECHARGE_BONUS_PCT}
                  value={pct}
                  onChange={(e) => {
                    const n = Math.max(0, Math.min(MAX_RECHARGE_BONUS_PCT, Math.round(Number(e.target.value) || 0)));
                    setPct(n);
                    applyTemplate("PROMO", n, modelSlug);
                  }}
                />
                <p className="text-xs text-muted-foreground">
                  Credited to the bonus pot when a recharge submitted during the promotion is approved (voucher top-ups: immediately). A $100
                  recharge at {pct}% adds ${((100 * pct) / 100).toFixed(2)}.
                </p>
              </div>
            ) : null}

            {kind === "NEW_MODEL" ? (
              <div className="grid gap-2">
                <Label>Model</Label>
                <Select
                  value={modelSlug}
                  onValueChange={(v) => {
                    setModelSlug(v);
                    applyTemplate("NEW_MODEL", pct, v);
                  }}
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Choose a model" />
                  </SelectTrigger>
                  <SelectContent>
                    {models.map((m) => (
                      <SelectItem key={m.slug} value={m.slug}>
                        {m.publicName} ({m.publicSlug})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <p className="text-xs text-muted-foreground">Customers see the alias and display name only — never the provider&apos;s model id.</p>
              </div>
            ) : null}

            <div className="grid gap-2">
              <Label htmlFor="ann-title">Title</Label>
              <Input id="ann-title" value={title} maxLength={120} onChange={(e) => setTitle(e.target.value)} />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="ann-message">Message</Label>
              <Textarea id="ann-message" rows={4} value={message} maxLength={2000} onChange={(e) => setMessage(e.target.value)} />
            </div>

            <div className="grid gap-4 sm:grid-cols-2">
              <div className="grid gap-2">
                <Label htmlFor="ann-start">Starts (optional)</Label>
                <Input id="ann-start" type="datetime-local" value={startsAt} onChange={(e) => setStartsAt(e.target.value)} />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="ann-end">Ends (optional)</Label>
                <Input id="ann-end" type="datetime-local" value={endsAt} onChange={(e) => setEndsAt(e.target.value)} />
              </div>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="ann-code">Only for one customer (optional)</Label>
              <Input id="ann-code" placeholder="Access code — leave blank for everyone" value={accessCode} onChange={(e) => setAccessCode(e.target.value)} />
            </div>
          </div>

          <DialogFooter>
            <Button variant="ghost" onClick={() => setOpen(false)}>
              Cancel
            </Button>
            <Button onClick={publish} disabled={pending || !title.trim() || !message.trim() || (kind === "NEW_MODEL" && !modelSlug) || (kind === "PROMO" && pct <= 0)}>
              {pending ? <Loader2 className="animate-spin" /> : <Megaphone />} Publish
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
