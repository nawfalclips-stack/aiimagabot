"use client";

import { useEffect, useRef, useState } from "react";
import { ArrowUp, Bot, Eye, EyeOff, KeyRound, Loader2, PlugZap, RotateCcw, Square, TriangleAlert, User } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { CopyButton } from "@/components/shared/copy-button";
import { Markdown } from "@/components/shared/markdown";
import { cn } from "@/lib/utils";

type Role = "user" | "assistant";

interface ChatMessage {
  role: Role;
  content: string;
  /** Set on assistant replies once the request finishes. */
  meta?: { model: string; requestId: string | null; latencyMs: number; promptTokens?: number; completionTokens?: number };
  error?: string;
}

interface ModelOption {
  id: string;
  name: string;
}

/** Turns a gateway error response into one readable line. */
async function readError(res: Response): Promise<string> {
  const text = await res.text();
  try {
    const json = JSON.parse(text) as { error?: { message?: string; type?: string } | string };
    const err = json.error;
    const message = typeof err === "string" ? err : err?.message;
    if (message) return `${res.status} · ${message}`;
  } catch {
    // not JSON
  }
  return `${res.status} · ${text.slice(0, 200) || res.statusText}`;
}

/**
 * Admin chat that calls the real public gateway (/v1/chat/completions) with a
 * customer token — the same path Codex / Claude Code take, so auth, limits,
 * routing, failover and billing are all exercised.
 */
export function ApiPlayground() {
  const [token, setToken] = useState("");
  const [showToken, setShowToken] = useState(false);
  const [models, setModels] = useState<ModelOption[]>([]);
  const [model, setModel] = useState("");
  const [connecting, setConnecting] = useState(false);
  const [connectError, setConnectError] = useState<string | null>(null);

  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState("");
  const [sending, setSending] = useState(false);
  const abortRef = useRef<AbortController | null>(null);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages]);

  const connect = async () => {
    const t = token.trim();
    if (!t) return;
    setConnecting(true);
    setConnectError(null);
    try {
      const res = await fetch("/v1/models", { headers: { Authorization: `Bearer ${t}` } });
      if (!res.ok) {
        setModels([]);
        setConnectError(await readError(res));
        return;
      }
      const json = (await res.json()) as { data: Array<{ id: string; display_name?: string }> };
      const list = json.data.map((m) => ({ id: m.id, name: m.display_name || m.id }));
      setModels(list);
      setModel((current) => (list.some((m) => m.id === current) ? current : (list[0]?.id ?? "")));
      if (list.length === 0) setConnectError("Token works, but no models are enabled for its store.");
    } catch (e) {
      setConnectError(e instanceof Error ? e.message : "Network error");
    } finally {
      setConnecting(false);
    }
  };

  const send = async () => {
    const text = input.trim();
    if (!text || !model || sending) return;

    const history: ChatMessage[] = [...messages, { role: "user", content: text }];
    setMessages([...history, { role: "assistant", content: "" }]);
    setInput("");
    setSending(true);

    const controller = new AbortController();
    abortRef.current = controller;
    const started = performance.now();
    let requestId: string | null = null;
    let usage: { prompt_tokens?: number; completion_tokens?: number } | undefined;
    let reply = "";

    const patchLast = (patch: Partial<ChatMessage>) =>
      setMessages((prev) => {
        const next = [...prev];
        next[next.length - 1] = { ...next[next.length - 1], ...patch };
        return next;
      });

    try {
      const res = await fetch("/v1/chat/completions", {
        method: "POST",
        headers: { Authorization: `Bearer ${token.trim()}`, "Content-Type": "application/json" },
        body: JSON.stringify({
          model,
          stream: true,
          // Only successful turns go back to the model.
          messages: history.filter((m) => !m.error).map((m) => ({ role: m.role, content: m.content })),
        }),
        signal: controller.signal,
      });
      requestId = res.headers.get("x-request-id");
      if (!res.ok || !res.body) {
        patchLast({ error: await readError(res), meta: { model, requestId, latencyMs: performance.now() - started } });
        return;
      }

      // Parse the SSE stream: `data: {...}` lines, terminated by `data: [DONE]`.
      const reader = res.body.getReader();
      const decoder = new TextDecoder();
      let buffer = "";
      for (;;) {
        const { value, done } = await reader.read();
        if (done) break;
        buffer += decoder.decode(value, { stream: true });
        const lines = buffer.split("\n");
        buffer = lines.pop() ?? "";
        for (const line of lines) {
          const data = line.trim();
          if (!data.startsWith("data:")) continue;
          const payload = data.slice(5).trim();
          if (payload === "[DONE]") continue;
          try {
            const chunk = JSON.parse(payload) as {
              choices?: Array<{ delta?: { content?: string } }>;
              usage?: { prompt_tokens?: number; completion_tokens?: number };
              error?: { message?: string };
            };
            if (chunk.error?.message) throw new Error(chunk.error.message);
            const delta = chunk.choices?.[0]?.delta?.content;
            if (delta) {
              reply += delta;
              patchLast({ content: reply });
            }
            if (chunk.usage) usage = chunk.usage;
          } catch (e) {
            if (e instanceof SyntaxError) continue; // partial / non-JSON line
            throw e;
          }
        }
      }
      patchLast({
        meta: {
          model,
          requestId,
          latencyMs: performance.now() - started,
          promptTokens: usage?.prompt_tokens,
          completionTokens: usage?.completion_tokens,
        },
      });
    } catch (e) {
      const aborted = e instanceof DOMException && e.name === "AbortError";
      patchLast({
        error: aborted ? (reply ? undefined : "Stopped before the first token.") : e instanceof Error ? e.message : "Request failed",
        meta: { model, requestId, latencyMs: performance.now() - started },
      });
    } finally {
      abortRef.current = null;
      setSending(false);
    }
  };

  const connected = models.length > 0;

  return (
    <div className="grid gap-6 xl:grid-cols-[20rem_minmax(0,1fr)]">
      {/* Connection panel */}
      <Card className="h-fit gap-5 p-5 xl:sticky xl:top-24">
        <div className="space-y-1.5">
          <Label htmlFor="pg-token" className="flex items-center gap-1.5">
            <KeyRound className="size-3.5 text-muted-foreground" /> Customer API token
          </Label>
          <div className="relative">
            <Input
              id="pg-token"
              type={showToken ? "text" : "password"}
              value={token}
              onChange={(e) => setToken(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && connect()}
              placeholder="al_…"
              autoComplete="off"
              spellCheck={false}
              className="pr-9 font-mono text-[13px]"
            />
            <button
              type="button"
              onClick={() => setShowToken((v) => !v)}
              className="absolute top-1/2 right-2.5 -translate-y-1/2 text-muted-foreground hover:text-foreground"
              aria-label={showToken ? "Hide token" : "Show token"}
            >
              {showToken ? <EyeOff className="size-4" /> : <Eye className="size-4" />}
            </button>
          </div>
          <p className="text-xs leading-relaxed text-muted-foreground">
            Requests are real: they are billed to this token&apos;s customer and appear in Usage Logs.
          </p>
        </div>

        <Button onClick={connect} disabled={!token.trim() || connecting} variant={connected ? "outline" : "default"}>
          {connecting ? <Loader2 className="animate-spin" /> : <PlugZap />}
          {connected ? "Reload models" : "Connect"}
        </Button>

        {connectError ? (
          <p className="flex gap-2 rounded-xl border border-destructive/25 bg-destructive/7 px-3 py-2.5 text-xs text-destructive">
            <TriangleAlert className="mt-px size-3.5 shrink-0" />
            <span className="break-words">{connectError}</span>
          </p>
        ) : null}

        {connected ? (
          <div className="space-y-1.5">
            <Label>Model</Label>
            <Select value={model} onValueChange={setModel}>
              <SelectTrigger className="w-full">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {models.map((m) => (
                  <SelectItem key={m.id} value={m.id}>
                    {m.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <p className="font-mono text-[11px] text-muted-foreground">{model}</p>
          </div>
        ) : null}

        {messages.length > 0 ? (
          <Button variant="ghost" size="sm" className="justify-start text-muted-foreground" onClick={() => setMessages([])} disabled={sending}>
            <RotateCcw /> Clear conversation
          </Button>
        ) : null}
      </Card>

      {/* Chat */}
      <Card className="h-[min(72vh,760px)] min-h-[28rem] gap-0 overflow-hidden p-0">
        <div ref={scrollRef} className="flex-1 space-y-5 overflow-y-auto px-4 py-6 sm:px-6">
          {messages.length === 0 ? (
            <div className="flex h-full flex-col items-center justify-center text-center">
              <span className="flex size-11 items-center justify-center rounded-xl border bg-card shadow-card">
                <Bot className="size-5 text-muted-foreground" />
              </span>
              <p className="mt-3 text-sm font-medium">{connected ? "Send a message to test the gateway" : "Connect a token to start"}</p>
              <p className="mt-1 max-w-xs text-xs text-muted-foreground">
                {connected
                  ? "Replies stream from /v1/chat/completions exactly as a customer's tool receives them."
                  : "Paste an al_… token from a test customer and press Connect to load its models."}
              </p>
            </div>
          ) : (
            messages.map((m, i) => {
              const isUser = m.role === "user";
              const pending = !isUser && sending && i === messages.length - 1 && !m.content && !m.error;
              return (
                <div key={i} className={cn("flex gap-3", isUser && "flex-row-reverse")}>
                  <span
                    className={cn(
                      "flex size-7 shrink-0 items-center justify-center rounded-full",
                      isUser ? "bg-muted text-muted-foreground" : "bg-primary/12 text-primary"
                    )}
                  >
                    {isUser ? <User className="size-3.5" /> : <Bot className="size-3.5" />}
                  </span>
                  <div className={cn("min-w-0 max-w-[85%] space-y-1", isUser && "flex flex-col items-end")}>
                    {isUser ? (
                      <div className="rounded-2xl rounded-tr-md bg-primary px-4 py-2.5 text-sm whitespace-pre-wrap text-primary-foreground">
                        {m.content}
                      </div>
                    ) : (
                      <div className="rounded-2xl rounded-tl-md border bg-card px-4 py-2.5 shadow-card">
                        {pending ? (
                          <span className="flex items-center gap-2 py-0.5 text-sm text-muted-foreground">
                            <Loader2 className="size-3.5 animate-spin" /> Waiting for first token…
                          </span>
                        ) : null}
                        {m.content ? (
                          <Markdown content={m.content} className="text-sm [&>*:first-child]:mt-0 [&>*:last-child]:mb-0" />
                        ) : null}
                        {m.error ? (
                          <p className={cn("flex gap-2 text-sm text-destructive", m.content && "mt-2 border-t pt-2")}>
                            <TriangleAlert className="mt-0.5 size-4 shrink-0" />
                            <span className="break-words">{m.error}</span>
                          </p>
                        ) : null}
                      </div>
                    )}
                    {m.meta ? (
                      <div className="flex flex-wrap items-center gap-x-3 gap-y-1 px-1 text-[11px] text-muted-foreground tabular-nums">
                        <span className="font-mono">{m.meta.model}</span>
                        <span>{(m.meta.latencyMs / 1000).toFixed(1)} s</span>
                        {m.meta.promptTokens !== undefined ? (
                          <span>
                            {m.meta.promptTokens} in · {m.meta.completionTokens ?? 0} out
                          </span>
                        ) : null}
                        {m.meta.requestId ? (
                          <span className="inline-flex items-center gap-0.5 font-mono">
                            {m.meta.requestId}
                            <CopyButton value={m.meta.requestId} label="Request id" size="icon-xs" />
                          </span>
                        ) : null}
                      </div>
                    ) : null}
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Composer */}
        <div className="border-t bg-muted/20 p-3 sm:p-4">
          <div className="flex items-end gap-2 rounded-2xl border bg-card p-2 shadow-card focus-within:border-ring focus-within:ring-[3px] focus-within:ring-ring/30">
            <Textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === "Enter" && !e.shiftKey) {
                  e.preventDefault();
                  send();
                }
              }}
              placeholder={connected ? "Message the model…  (Enter to send, Shift+Enter for a new line)" : "Connect a token first"}
              disabled={!connected}
              rows={1}
              className="max-h-40 min-h-9 resize-none border-0 bg-transparent px-2 py-1.5 shadow-none focus-visible:ring-0 dark:bg-transparent"
            />
            {sending ? (
              <Button size="icon" variant="outline" onClick={() => abortRef.current?.abort()} aria-label="Stop">
                <Square className="size-3.5 fill-current" />
              </Button>
            ) : (
              <Button size="icon" onClick={send} disabled={!connected || !input.trim() || !model} aria-label="Send">
                <ArrowUp />
              </Button>
            )}
          </div>
        </div>
      </Card>
    </div>
  );
}
