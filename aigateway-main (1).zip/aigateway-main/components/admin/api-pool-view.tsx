"use client";

import { useState, useTransition } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { CheckCircle2, KeyRound, Loader2, PackageOpen, Plus, Search, ShieldOff, Trash2, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Textarea } from "@/components/ui/textarea";
import { CopyButton } from "@/components/shared/copy-button";
import { EmptyState } from "@/components/shared/empty-state";
import { ConfirmDialog } from "@/components/shared/confirm-dialog";
import { StatCard } from "@/components/shared/stat-card";
import { StatusBadge } from "@/components/shared/status-badge";

import {
  addPoolKeysAction,
  deletePoolKeyAction,
  lookupOrderAction,
  purgePoolKeysAction,
  unassignAllPoolKeysAction,
  type OrderLookupResult,
} from "@/app/admin/(dashboard)/api-pool/actions";
import { cn } from "@/lib/utils";
import { LocalTime } from "@/components/shared/local-time";
import { maskApiKey, previewApiKey } from "@/lib/format";
import { formatCents } from "@/lib/money";

export interface PoolKeyRow {
  id: string;
  key: string;
  status: string;
  orderId: string | null;
  customerId: string | null;
  customerAccessCode: string | null;
  createdAt: string;
  assignedAt: string | null;
  rowNumber: number;
}

type PoolMode = "active" | "readonly" | "off";

export function ApiPoolView({ keys, mode }: { keys: PoolKeyRow[]; mode: PoolMode }) {
  // Outside "active" the keys arrive masked from the server and nothing can be assigned (WS10).
  const active = mode === "active";
  const [raw, setRaw] = useState("");
  const [pending, startTransition] = useTransition();
  const [lookupPending, startLookup] = useTransition();
  const [orderQuery, setOrderQuery] = useState("");
  const [lookupResult, setLookupResult] = useState<OrderLookupResult | null>(null);
  const [lookupError, setLookupError] = useState<string | null>(null);
  const router = useRouter();

  const available = keys.filter((k) => k.status === "AVAILABLE").length;
  const assigned = keys.filter((k) => k.customerId).length;

  const lookup = () => {
    if (!orderQuery.trim() || lookupPending) return;
    setLookupResult(null);
    setLookupError(null);
    startLookup(async () => {
      const result = await lookupOrderAction(orderQuery);
      if (result.ok && result.data) {
        setLookupResult(result.data);
      } else if (!result.ok) {
        setLookupError(result.error ?? "Not found");
      }
    });
  };

  const clearLookup = () => { setOrderQuery(""); setLookupResult(null); setLookupError(null); };

  const add = () => {
    if (!raw.trim() || pending) return;
    startTransition(async () => {
      const result = await addPoolKeysAction(raw);
      if (result.ok && result.data) {
        toast.success(`${result.data.added} API ${result.data.added === 1 ? "key" : "keys"} added to the pool`, {
          description: result.data.skipped > 0 ? `${result.data.skipped} duplicates skipped.` : undefined,
        });
        setRaw("");
        router.refresh();
      } else if (!result.ok) {
        toast.error(result.error);
      }
    });
  };

  return (
    <div className="space-y-6">
      {/* Stats */}
      <section className="grid grid-cols-3 gap-4">
        <StatCard title="Total APIs" value={keys.length} icon="key" tone="primary" index={0} />
        <StatCard title="Available" value={available} icon="package" tone="success" index={1} />
        <StatCard title="Held by customers" value={assigned} icon="check" tone="default" index={2} />
      </section>

      {/* Order ID Lookup */}
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2"><Search className="size-4 text-primary" /> Look up by Customer Order ID</CardTitle>
          <CardDescription>Enter a GamsGo Order ID to see the full customer details.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex gap-2">
            <Input
              value={orderQuery}
              onChange={(e) => setOrderQuery(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && lookup()}
              placeholder="e.g. 874133419448209408"
              className="font-mono"
            />
            <Button onClick={lookup} disabled={!orderQuery.trim() || lookupPending}>
              {lookupPending ? <Loader2 className="animate-spin" /> : <Search />}
              Search
            </Button>
            {(lookupResult || lookupError) && (
              <Button variant="ghost" size="icon" onClick={clearLookup}><X /></Button>
            )}
          </div>

          {lookupError && (
            <p className="text-sm text-destructive">{lookupError}</p>
          )}

          {lookupResult && (
            <div className="rounded-xl border bg-muted/30 p-4 space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <Link href={`/admin/customers/${lookupResult.customerId}`} className="font-mono text-sm font-semibold text-primary hover:underline">
                    {lookupResult.accessCode}
                  </Link>
                  <span className="text-muted-foreground text-xs">·</span>
                  <span className="font-mono text-xs text-muted-foreground">{lookupResult.orderNumber}</span>
                </div>
                <StatusBadge status={lookupResult.status} />
              </div>

              <div className="grid grid-cols-2 gap-3 sm:grid-cols-3 text-sm">
                <div>
                  <p className="text-xs text-muted-foreground uppercase tracking-wide font-medium">Balance</p>
                  <p className="font-semibold tabular-nums">{formatCents(lookupResult.remainingBalanceCents)}</p>
                  <p className="text-xs text-muted-foreground">{formatCents(lookupResult.usedBalanceCents)} used of {formatCents(lookupResult.initialBalanceCents)}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground uppercase tracking-wide font-medium">Bonus</p>
                  <p className="font-semibold tabular-nums text-success">{formatCents(lookupResult.remainingBonusCents)}</p>
                  <p className="text-xs text-muted-foreground">{formatCents(lookupResult.usedBonusCents)} used of {formatCents(lookupResult.initialBonusCents)}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground uppercase tracking-wide font-medium">Profit</p>
                  <p className="font-semibold tabular-nums text-success">{formatCents(lookupResult.profitCents)}</p>
                </div>
                <div>
                  <p className="text-xs text-muted-foreground uppercase tracking-wide font-medium">API Key</p>
                  {lookupResult.apiKey ? (
                    <div className="flex items-center gap-1">
                      <span className="font-mono text-xs">{active ? `${lookupResult.apiKey.slice(0, 12)}••••` : lookupResult.apiKey}</span>
                      {active && <CopyButton value={lookupResult.apiKey} label="API key" size="icon-xs" />}
                    </div>
                  ) : <span className="text-xs text-muted-foreground">Not assigned</span>}
                </div>
                <div>
                  <p className="text-xs text-muted-foreground uppercase tracking-wide font-medium">Member Since</p>
                  <p className="text-xs"><LocalTime date={lookupResult.createdAt} variant="date" /></p>
                </div>
                {lookupResult.assignedAt && (
                  <div>
                    <p className="text-xs text-muted-foreground uppercase tracking-wide font-medium">API Assigned</p>
                    <p className="text-xs"><LocalTime date={lookupResult.assignedAt} variant="date" /></p>
                  </div>
                )}
              </div>

              {lookupResult.offerTitle && (
                <p className="text-xs text-muted-foreground border-t pt-2">Offer: {lookupResult.offerTitle}</p>
              )}
            </div>
          )}
        </CardContent>
      </Card>

      {!active && (
        <Card className="border-warning/40">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <ShieldOff className="size-4 text-warning" /> Legacy pool retired ({mode})
            </CardTitle>
            <CardDescription>
              No key is assigned any more — customers create their own AeroLink API token on the API Access page. Keys
              below are masked. Unassign takes the legacy keys away from every customer of this store; purge deletes the
              pool keys that no customer holds.
            </CardDescription>
          </CardHeader>
          <CardContent className="flex flex-wrap gap-2">
            <ConfirmDialog
              trigger={
                <Button variant="outline" disabled={assigned === 0}>
                  <KeyRound /> Unassign all
                </Button>
              }
              title="Unassign every legacy key?"
              description={`${assigned} customer${assigned === 1 ? "" : "s"} will lose their legacy upstream key. Their balance and AeroLink tokens are not affected. The keys are marked Retired and are never handed out again.`}
              confirmLabel="Unassign all"
              destructive
              onConfirm={async () => {
                const result = await unassignAllPoolKeysAction();
                if (result.ok && result.data) {
                  toast.success(`Unassigned from ${result.data.customers} customers`, {
                    description: `${result.data.keys} pool keys retired.`,
                  });
                  router.refresh();
                } else if (!result.ok) toast.error(result.error);
              }}
            />
            <ConfirmDialog
              trigger={
                <Button variant="outline" className="text-destructive" disabled={keys.length === 0}>
                  <Trash2 /> Purge pool keys
                </Button>
              }
              title="Purge the pool?"
              description="Deletes every pool key of this store that no customer holds. Keys still assigned are kept — unassign them first. This cannot be undone."
              confirmLabel="Purge"
              destructive
              onConfirm={async () => {
                const result = await purgePoolKeysAction();
                if (result.ok && result.data) {
                  toast.success(`${result.data.purged} keys purged`, {
                    description: result.data.kept > 0 ? `${result.data.kept} still assigned — unassign them first.` : undefined,
                  });
                  router.refresh();
                } else if (!result.ok) toast.error(result.error);
              }}
            />
          </CardContent>
        </Card>
      )}

      {/* Add keys */}
      {active && (
      <Card>
        <CardHeader>
          <CardTitle>Add API keys</CardTitle>
          <CardDescription>
            Paste one key per line and press Add. Each key is handed to exactly one customer — automatically during
            self-activation, oldest key first.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <Textarea
            value={raw}
            onChange={(e) => setRaw(e.target.value)}
            placeholder={"sk-aerolink-xxxxxxxxxxxxxxxx\nsk-aerolink-yyyyyyyyyyyyyyyy"}
            rows={3}
            spellCheck={false}
            className="font-mono text-[13px]"
            aria-label="API keys to add, one per line"
          />
          <div className="flex justify-end">
            <Button onClick={add} disabled={!raw.trim() || pending}>
              {pending ? <Loader2 className="animate-spin" /> : <Plus />}
              Add to pool
            </Button>
          </div>
        </CardContent>
      </Card>
      )}

      {/* Pool table */}
      <Card className="overflow-hidden p-0">
        {keys.length === 0 ? (
          <EmptyState
            icon={KeyRound}
            title="The pool is empty"
            description={
              active
                ? "Add API keys above — they'll be assigned automatically when customers activate with their Order ID."
                : "Nothing left in the legacy pool."
            }
            className="border-0"
          />
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="hover:bg-transparent">
                  <TableHead className="pl-4 w-12">#</TableHead>
                  <TableHead>API Key</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead>Assigned To</TableHead>
                  <TableHead>Customer Order ID</TableHead>
                  <TableHead>Added</TableHead>
                  <TableHead>Assigned</TableHead>
                  <TableHead className="pr-4 text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {keys.map((k) => (
                  <TableRow key={k.id} className="group">
                    <TableCell className="pl-4 font-mono text-xs text-muted-foreground">
                      #{k.rowNumber}
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <span className="font-mono text-xs">{active ? previewApiKey(k.key) : k.key}</span>
                        {active && (
                          <CopyButton value={k.key} label="API key" size="icon-xs" className="opacity-0 transition-opacity group-hover:opacity-100" />
                        )}
                      </div>
                    </TableCell>
                    <TableCell>
                      <span
                        className={cn(
                          "inline-flex items-center gap-1.5 rounded-full border px-2.5 py-0.5 text-xs font-medium",
                          k.status === "AVAILABLE"
                            ? "border-success/25 bg-success/12 text-success"
                            : k.status === "PROBLEMATIC" || k.status === "RETIRED"
                            ? "border-destructive/25 bg-destructive/12 text-destructive"
                            : "border-border bg-muted text-muted-foreground"
                        )}
                      >
                        <span className={cn(
                          "size-1.5 rounded-full",
                          k.status === "AVAILABLE" ? "bg-success"
                          : k.status === "PROBLEMATIC" || k.status === "RETIRED" ? "bg-destructive"
                          : "bg-muted-foreground"
                        )} />
                        {k.status === "AVAILABLE" ? "Available"
                          : k.status === "PROBLEMATIC" ? "Problematic"
                          : k.status === "RETIRED" ? "Retired"
                          : "Assigned"}
                      </span>
                    </TableCell>
                    <TableCell>
                      {k.customerId && k.customerAccessCode ? (
                        <Link href={`/admin/customers/${k.customerId}`} className="font-mono text-[13px] text-primary hover:underline">
                          {k.customerAccessCode}
                        </Link>
                      ) : (
                        <span className="text-muted-foreground">—</span>
                      )}
                    </TableCell>
                    <TableCell className="font-mono text-[13px] text-muted-foreground">{k.orderId ?? "—"}</TableCell>
                    <TableCell className="text-muted-foreground"><LocalTime date={k.createdAt} variant="date" /></TableCell>
                    <TableCell className="text-muted-foreground"><LocalTime date={k.assignedAt} variant="date" /></TableCell>
                    <TableCell className="pr-4 text-right">
                      {k.status === "AVAILABLE" ? (
                        <ConfirmDialog
                          trigger={
                            <Button
                              variant="ghost"
                              size="icon-sm"
                              className="text-muted-foreground hover:text-destructive"
                              aria-label="Remove key from pool"
                            >
                              <Trash2 />
                            </Button>
                          }
                          title="Remove this API key?"
                          description="It will no longer be available for automatic assignment. This does not affect existing customers."
                          confirmLabel="Remove"
                          destructive
                          onConfirm={async () => {
                            const result = await deletePoolKeyAction(k.id);
                            if (result.ok) {
                              toast.success("Key removed from the pool");
                              router.refresh();
                            } else toast.error(result.error);
                          }}
                        />
                      ) : null}
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </Card>
    </div>
  );
}
