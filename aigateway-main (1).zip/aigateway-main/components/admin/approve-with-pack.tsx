"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { CheckCircle2, Loader2, TriangleAlert } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { formatCents } from "@/lib/money";
import type { PackOption } from "@/lib/services/packs";
import type { ActionResult } from "@/app/admin/(dashboard)/customers/actions";

interface ApproveWithPackProps {
  packs: PackOption[];
  /** Pre-selected when exactly one pack matches the purchased amount (suggestion only). */
  suggestedPackId: string | null;
  /** Voucher redemptions: the pack is fixed by the code that was redeemed. */
  lockedPackId?: string | null;
  /** The plan (pack) the customer picked when submitting; pre-selected, still to be confirmed. */
  customerPackId?: string | null;
  amountCents: number;
  approve: (packId: string) => Promise<ActionResult>;
  successMessage: string;
  title?: string;
}

/**
 * Approval dialog for activations and recharges (WS8): the admin must choose
 * the pack the customer bought — the pack binds the plan. Price matching is
 * only a pre-selection.
 */
export function ApproveWithPackButton({ packs, suggestedPackId, lockedPackId, customerPackId, amountCents, approve, successMessage, title = "Approve" }: ApproveWithPackProps) {
  const [open, setOpen] = useState(false);
  const customerChoice = customerPackId && packs.some((p) => p.id === customerPackId) ? customerPackId : null;
  const [packId, setPackId] = useState<string>(lockedPackId ?? customerChoice ?? suggestedPackId ?? "");
  const [pending, startTransition] = useTransition();
  const router = useRouter();
  const chosen = packs.find((p) => p.id === packId) ?? null;
  const mismatch = chosen && !lockedPackId && amountCents > 0 && chosen.planPriceCents !== amountCents;

  const submit = () => {
    if (!packId) {
      toast.error("Choose the pack the customer bought.");
      return;
    }
    startTransition(async () => {
      const result = await approve(packId);
      if (result.ok) {
        toast.success(successMessage);
        setOpen(false);
        router.refresh();
      } else {
        toast.error(result.error);
      }
    });
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button size="sm" variant="outline" className="text-success border-success/30 bg-success/10 hover:bg-success/20 hover:text-success">
          <CheckCircle2 className="size-3.5" /> {title}
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Which pack did the customer buy?</DialogTitle>
          <DialogDescription>
            The pack sets the customer&apos;s plan (rate, limits). {lockedPackId
              ? "This redemption's pack is fixed by the voucher."
              : customerChoice
                ? "Pre-selected: the plan the customer chose — check it against the order on GamsGo."
                : suggestedPackId
                  ? "Pre-selected because one pack matches the amount — confirm it."
                  : "No pack matches the amount exactly; pick the right one."}
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-2">
          <Label htmlFor="pack">Pack</Label>
          <Select value={packId} onValueChange={setPackId} disabled={!!lockedPackId || pending}>
            <SelectTrigger id="pack" className="w-full">
              <SelectValue placeholder="Choose a pack" />
            </SelectTrigger>
            <SelectContent>
              {packs.filter((p) => p.active || p.id === packId).map((p) => (
                <SelectItem key={p.id} value={p.id}>
                  {p.name} — {formatCents(p.balanceGrantCents)}{p.bonusGrantCents > 0 ? ` + ${formatCents(p.bonusGrantCents)} bonus` : ""} · plan {p.planName}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          {packs.length === 0 && (
            <p className="text-xs text-destructive">No packs exist yet. Create one under Packs before approving.</p>
          )}
          {chosen && !lockedPackId ? (
            <p className="text-xs text-muted-foreground">
              Approving sets the balance to the <strong>{chosen.planName}</strong> plan price: <strong>{formatCents(chosen.planPriceCents)}</strong>
              {chosen.planProfitCents > 0 ? <> and records <strong>{formatCents(chosen.planProfitCents)}</strong> profit</> : null}.
            </p>
          ) : null}
          {mismatch && (
            <p className="flex items-start gap-1.5 text-xs text-warning">
              <TriangleAlert className="mt-0.5 size-3.5 shrink-0" />
              The order said {formatCents(amountCents)}; the customer will get {formatCents(chosen!.planPriceCents)} (the plan price). Check you picked the right pack.
            </p>
          )}
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={() => setOpen(false)} disabled={pending}>
            Cancel
          </Button>
          <Button onClick={submit} disabled={pending || !packId}>
            {pending ? <Loader2 className="size-3.5 animate-spin" /> : <CheckCircle2 className="size-3.5" />}
            Approve
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
