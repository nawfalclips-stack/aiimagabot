"use client";

import { useState, useTransition } from "react";
import { toast } from "sonner";
import { Eye, EyeOff, KeyRound, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { MIN_ADMIN_PASSWORD_LENGTH } from "@/lib/admin-password";
import { changeOwnPasswordAction } from "@/app/admin/(dashboard)/account/actions";

/** Change the signed-in admin's password (current password required). */
export function ChangePasswordForm() {
  const [pending, startTransition] = useTransition();
  const [show, setShow] = useState(false);
  const [current, setCurrent] = useState("");
  const [next, setNext] = useState("");
  const [confirm, setConfirm] = useState("");

  const tooShort = next.length > 0 && next.length < MIN_ADMIN_PASSWORD_LENGTH;
  const mismatch = confirm.length > 0 && confirm !== next;
  const canSubmit = !!current && next.length >= MIN_ADMIN_PASSWORD_LENGTH && next === confirm && !pending;

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!canSubmit) return;
    startTransition(async () => {
      const r = await changeOwnPasswordAction({ currentPassword: current, newPassword: next, confirmPassword: confirm });
      if (!r.ok) {
        toast.error(r.error);
        return;
      }
      toast.success("Password changed. Other browsers have been signed out.");
      setCurrent("");
      setNext("");
      setConfirm("");
    });
  };

  const type = show ? "text" : "password";

  return (
    <form onSubmit={submit} className="grid max-w-md gap-4">
      <div className="grid gap-1.5">
        <Label htmlFor="pw-current">Current password</Label>
        <Input id="pw-current" type={type} autoComplete="current-password" value={current} onChange={(e) => setCurrent(e.target.value)} required />
      </div>
      <div className="grid gap-1.5">
        <Label htmlFor="pw-new">New password</Label>
        <Input id="pw-new" type={type} autoComplete="new-password" value={next} onChange={(e) => setNext(e.target.value)} aria-invalid={tooShort} required />
        <p className={tooShort ? "text-xs text-destructive" : "text-xs text-muted-foreground"}>
          At least {MIN_ADMIN_PASSWORD_LENGTH} characters. A short sentence is easier to remember than random symbols.
        </p>
      </div>
      <div className="grid gap-1.5">
        <Label htmlFor="pw-confirm">Confirm new password</Label>
        <Input id="pw-confirm" type={type} autoComplete="new-password" value={confirm} onChange={(e) => setConfirm(e.target.value)} aria-invalid={mismatch} required />
        {mismatch ? <p className="text-xs text-destructive">The two new passwords don&apos;t match.</p> : null}
      </div>
      <div className="flex flex-wrap items-center gap-2">
        <Button type="submit" disabled={!canSubmit}>
          {pending ? <Loader2 className="animate-spin" /> : <KeyRound />} Change password
        </Button>
        <Button type="button" variant="ghost" size="sm" onClick={() => setShow((s) => !s)} aria-pressed={show}>
          {show ? <EyeOff /> : <Eye />} {show ? "Hide" : "Show"} passwords
        </Button>
      </div>
    </form>
  );
}
