"use client";

import {
  Area,
  AreaChart,
  Bar,
  BarChart,
  CartesianGrid,
  Line,
  LineChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import type { DailyPoint } from "@/lib/services/analytics";
import { formatCents } from "@/lib/money";

// Theme variables, so the charts follow light/dark mode with the rest of the UI.
const GRID = "var(--border)";
const AXIS = "var(--muted-foreground)";
const BLUE = "var(--chart-1)";
const GREEN = "var(--chart-2)";
const AMBER = "var(--chart-3)";
const RED = "var(--chart-5)";

function ChartTooltip({
  active,
  payload,
  label,
  money,
}: {
  active?: boolean;
  payload?: { name: string; value: number; color: string }[];
  label?: string;
  money?: boolean;
}) {
  if (!active || !payload?.length) return null;
  return (
    <div className="rounded-xl border bg-popover/95 px-3 py-2 text-xs shadow-raised backdrop-blur-sm">
      <p className="mb-1 font-medium text-foreground">{label}</p>
      {payload.map((entry) => (
        <p key={entry.name} className="flex items-center gap-1.5 text-muted-foreground">
          <span className="size-2 rounded-full" style={{ background: entry.color }} />
          {entry.name}:{" "}
          <span className="font-medium text-foreground tabular-nums">
            {money ? formatCents(entry.value) : entry.value}
          </span>
        </p>
      ))}
    </div>
  );
}

const axisProps = {
  stroke: AXIS,
  fontSize: 11,
  tickLine: false,
  axisLine: false,
} as const;

/** Sales (new balances sold) + profit over time (area chart, values in cents). */
export function RevenueProfitChart({ data }: { data: DailyPoint[] }) {
  const chartData = data.map((d) => ({ label: d.label, Sales: d.revenueCents, Profit: d.profitCents }));
  return (
    <ResponsiveContainer width="100%" height={280}>
      <AreaChart data={chartData} margin={{ top: 8, right: 8, left: 8, bottom: 0 }}>
        <defs>
          <linearGradient id="fillSales" x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%" stopColor={BLUE} stopOpacity={0.28} />
            <stop offset="95%" stopColor={BLUE} stopOpacity={0} />
          </linearGradient>
          <linearGradient id="fillProfit" x1="0" y1="0" x2="0" y2="1">
            <stop offset="5%" stopColor={GREEN} stopOpacity={0.28} />
            <stop offset="95%" stopColor={GREEN} stopOpacity={0} />
          </linearGradient>
        </defs>
        <CartesianGrid strokeDasharray="3 3" stroke={GRID} vertical={false} />
        <XAxis dataKey="label" {...axisProps} minTickGap={28} />
        <YAxis {...axisProps} tickFormatter={(v: number) => `$${Math.round(v / 100)}`} width={44} />
        <Tooltip content={<ChartTooltip money />} cursor={{ stroke: GRID }} />
        <Area type="monotone" dataKey="Sales" stroke={BLUE} strokeWidth={2} fill="url(#fillSales)" animationDuration={800} />
        <Area type="monotone" dataKey="Profit" stroke={GREEN} strokeWidth={2} fill="url(#fillProfit)" animationDuration={800} />
      </AreaChart>
    </ResponsiveContainer>
  );
}

/** New customers per day (bar chart). */
export function CustomerGrowthChart({ data }: { data: DailyPoint[] }) {
  const chartData = data.map((d) => ({ label: d.label, Customers: d.customers }));
  return (
    <ResponsiveContainer width="100%" height={240}>
      <BarChart data={chartData} margin={{ top: 8, right: 8, left: 8, bottom: 0 }}>
        <CartesianGrid strokeDasharray="3 3" stroke={GRID} vertical={false} />
        <XAxis dataKey="label" {...axisProps} minTickGap={28} />
        <YAxis {...axisProps} allowDecimals={false} width={28} />
        <Tooltip content={<ChartTooltip />} cursor={{ fill: "oklch(1 0 0 / 4%)" }} />
        <Bar dataKey="Customers" fill={BLUE} radius={[4, 4, 0, 0]} animationDuration={800} />
      </BarChart>
    </ResponsiveContainer>
  );
}

/** Orders per day (bar chart). */
export function OrdersChart({ data }: { data: DailyPoint[] }) {
  const chartData = data.map((d) => ({ label: d.label, Orders: d.orders }));
  return (
    <ResponsiveContainer width="100%" height={240}>
      <BarChart data={chartData} margin={{ top: 8, right: 8, left: 8, bottom: 0 }}>
        <CartesianGrid strokeDasharray="3 3" stroke={GRID} vertical={false} />
        <XAxis dataKey="label" {...axisProps} minTickGap={28} />
        <YAxis {...axisProps} allowDecimals={false} width={28} />
        <Tooltip content={<ChartTooltip />} cursor={{ fill: "oklch(1 0 0 / 4%)" }} />
        <Bar dataKey="Orders" fill={AMBER} radius={[4, 4, 0, 0]} animationDuration={800} />
      </BarChart>
    </ResponsiveContainer>
  );
}

/** Customers whose balance finished per day (line chart). */
export function ExpiredChart({ data }: { data: DailyPoint[] }) {
  const chartData = data.map((d) => ({ label: d.label, Expired: d.expired }));
  return (
    <ResponsiveContainer width="100%" height={240}>
      <LineChart data={chartData} margin={{ top: 8, right: 8, left: 8, bottom: 0 }}>
        <CartesianGrid strokeDasharray="3 3" stroke={GRID} vertical={false} />
        <XAxis dataKey="label" {...axisProps} minTickGap={28} />
        <YAxis {...axisProps} allowDecimals={false} width={28} />
        <Tooltip content={<ChartTooltip />} cursor={{ stroke: GRID }} />
        <Line type="monotone" dataKey="Expired" stroke={RED} strokeWidth={2} dot={false} animationDuration={800} />
      </LineChart>
    </ResponsiveContainer>
  );
}

/** Profit per day (bar chart, cents). */
export function ProfitChart({ data }: { data: DailyPoint[] }) {
  const chartData = data.map((d) => ({ label: d.label, Profit: d.profitCents }));
  return (
    <ResponsiveContainer width="100%" height={280}>
      <BarChart data={chartData} margin={{ top: 8, right: 8, left: 8, bottom: 0 }}>
        <CartesianGrid strokeDasharray="3 3" stroke={GRID} vertical={false} />
        <XAxis dataKey="label" {...axisProps} minTickGap={28} />
        <YAxis {...axisProps} tickFormatter={(v: number) => `$${Math.round(v / 100)}`} width={44} />
        <Tooltip content={<ChartTooltip money />} cursor={{ fill: "oklch(1 0 0 / 4%)" }} />
        <Bar dataKey="Profit" fill={GREEN} radius={[4, 4, 0, 0]} animationDuration={800} />
      </BarChart>
    </ResponsiveContainer>
  );
}
