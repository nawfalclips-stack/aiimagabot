"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { CircleDollarSign, Gift, Loader2, Minus, Plus, TriangleAlert } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  addBalanceFundsAction,
  addBonusFundsAction,
  updateBalanceUsageAction,
  updateBonusUsageAction,
  recordQuickUsageAction,
} from "@/app/admin/(dashboard)/customers/actions";
import { formatCents } from "@/lib/money";
import { cn } from "@/lib/utils";

type Mode = "deduct" | "add";

interface AdjustDialogProps {
  customerId: string;
  accessCode: string;
  kind: "balance" | "bonus";
  remainingCents: number;
  trigger: React.ReactNode;
  defaultMode?: Mode;
}

/**
 * Adjust balance/bonus straight from anywhere — deduct usage or add funds.
 * Used and remaining values are recalculated automatically on the server.
 * Deductions may exceed the remaining amount (the balance goes negative).
 */
export function AdjustDialog({
  customerId,
  accessCode,
  kind,
  remainingCents,
  trigger,
  defaultMode = "deduct",
}: AdjustDialogProps) {
  const [open, setOpen] = useState(false);
  const [mode, setMode] = useState<Mode>(defaultMode);
  const [amount, setAmount] = useState("");
  const [note, setNote] = useState("");
  const [pending, startTransition] = useTransition();
  const router = useRouter();

  const label = kind === "balance" ? "Balance" : "Bonus";
  const parsed = parseFloat(amount);
  const amountCents = Number.isFinite(parsed) ? Math.round(parsed * 100) : 0;
  const valid = Number.isFinite(parsed) && parsed > 0;
  const remainingAfter = valid
    ? mode === "deduct"
      ? remainingCents - amountCents
      : remainingCents + amountCents
    : remainingCents;
  const goesNegative = valid && mode === "deduct" && remainingAfter < 0;

  const reset = () => {
    setAmount("");
    setNote("");
    setMode(defaultMode);
  };

  const submit = () => {
    if (!valid || pending) return;
    startTransition(async () => {
      // "Deduct usage" on the main balance writes one "Manual charge" row (WS7).
      if (mode === "deduct" && kind === "balance") {
        const result = await recordQuickUsageAction(customerId, note, parsed);
        if (result.ok && result.data) {
          toast.success(`Deducted ${formatCents(result.data.deductedCents)} usage`, {
            description: `Manual charge recorded for ${accessCode}. Remaining: ${formatCents(remainingAfter)}.`,
          });
          setOpen(false);
          reset();
          router.refresh();
        } else {
          toast.error(result.ok ? "Something went wrong." : result.error);
        }
        return;
      }

      const action =
        mode === "deduct"
          ? kind === "balance"
            ? updateBalanceUsageAction
            : updateBonusUsageAction
          : kind === "balance"
            ? addBalanceFundsAction
            : addBonusFundsAction;
      const result = await action(customerId, { amount: parsed, note });
      if (result.ok) {
        toast.success(`${label} ${mode === "deduct" ? "usage recorded" : "funds added"}`, {
          description: `${formatCents(amountCents)} ${mode === "deduct" ? "deducted from" : "added to"} ${accessCode}. Remaining: ${formatCents(remainingAfter)}.`,
        });
        setOpen(false);
        reset();
        router.refresh();
      } else {
        toast.error(result.error);
      }
    });
  };

  return (
    <Dialog
      open={open}
      onOpenChange={(v) => {
        setOpen(v);
        if (!v) reset();
      }}
    >
      <DialogTrigger asChild>{trigger}</DialogTrigger>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            {kind === "balance" ? (
              <CircleDollarSign className="size-5 text-primary" />
            ) : (
              <Gift className="size-5 text-success" />
            )}
            Adjust {label}
          </DialogTitle>
          <DialogDescription>
            Deduct usage or add funds for <span className="font-mono text-foreground">{accessCode}</span>. Used and
            remaining {kind} are calculated automatically.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4 py-1">
          {/* Mode switch */}
          <div className="grid grid-cols-2 gap-1 rounded-lg border bg-muted/40 p-1">
            <button
              type="button"
              onClick={() => setMode("deduct")}
              className={cn(
                "flex items-center justify-center gap-1.5 rounded-md px-3 py-1.5 text-sm font-medium transition-colors",
                mode === "deduct" ? "bg-destructive/15 text-destructive" : "text-muted-foreground hover:text-foreground"
              )}
              aria-pressed={mode === "deduct"}
            >
              <Minus className="size-4" /> Deduct usage
            </button>
            <button
              type="button"
              onClick={() => setMode("add")}
              className={cn(
                "flex items-center justify-center gap-1.5 rounded-md px-3 py-1.5 text-sm font-medium transition-colors",
                mode === "add" ? "bg-success/15 text-success" : "text-muted-foreground hover:text-foreground"
              )}
              aria-pressed={mode === "add"}
            >
              <Plus className="size-4" /> Add funds
            </button>
          </div>

          <div className="rounded-lg border bg-muted/40 px-4 py-3 text-sm">
            <div className="flex items-center justify-between">
              <span className="text-muted-foreground">Remaining {kind}</span>
              <span className={cn("font-semibold tabular-nums", remainingCents < 0 && "text-destructive")}>
                {formatCents(remainingCents)}
              </span>
            </div>
            {valid ? (
              <div className="mt-1.5 flex items-center justify-between border-t pt-1.5">
                <span className="text-muted-foreground">After this update</span>
                <span
                  className={cn(
                    "font-semibold tabular-nums",
                    remainingAfter < 0 ? "text-destructive" : mode === "add" ? "text-success" : "text-primary"
                  )}
                >
                  {formatCents(remainingAfter)}
                </span>
              </div>
            ) : null}
          </div>

          <div className="space-y-2">
            <Label htmlFor={`adjust-amount-${kind}`}>
              Amount to {mode === "deduct" ? "deduct" : "add"} (USD)
            </Label>
            <Input
              id={`adjust-amount-${kind}`}
              type="number"
              inputMode="decimal"
              min="0.01"
              step="0.01"
              placeholder="e.g. 100"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && submit()}
              autoFocus
            />
            {amount && !valid ? (
              <p className="text-xs text-destructive">Enter an amount greater than zero.</p>
            ) : null}
            {goesNegative ? (
              <p className="flex items-center gap-1.5 text-xs text-warning">
                <TriangleAlert className="size-3.5" />
                The {kind} will go negative ({formatCents(remainingAfter)}).
              </p>
            ) : null}
          </div>


          <div className="space-y-2">
            <Label htmlFor={`adjust-note-${kind}`}>
              Note <span className="text-muted-foreground">(optional)</span>
            </Label>
            <Textarea
              id={`adjust-note-${kind}`}
              placeholder={mode === "deduct" ? "e.g. March API usage" : "e.g. Renewal top-up"}
              rows={2}
              value={note}
              onChange={(e) => setNote(e.target.value)}
            />
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => setOpen(false)} disabled={pending}>
            Cancel
          </Button>
          <Button
            onClick={submit}
            disabled={!valid || pending}
            className={cn(mode === "add" && "bg-success text-white hover:bg-success/90")}
          >
            {pending ? <Loader2 className="animate-spin" /> : mode === "deduct" ? <Minus /> : <Plus />}
            {mode === "deduct" ? "Deduct" : "Add funds"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
