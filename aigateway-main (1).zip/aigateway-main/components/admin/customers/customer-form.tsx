"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { Dices, KeyRound, Loader2, Save, Sparkles } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { StatusBadge } from "@/components/shared/status-badge";
import { CUSTOMER_STATUSES, STATUS_LABELS } from "@/lib/constants";
import type { CustomerRow } from "@/lib/types";
import {
  createCustomerAction,
  updateCustomerAction,
  generateCodeAction,
  generateOrderNumberAction,
  type CustomerFormInput,
} from "@/app/admin/(dashboard)/customers/actions";

interface CustomerFormProps {
  customer?: CustomerRow;
  /** Legacy pool key field; shown only when LEGACY_API_POOL_MODE=active (WS10). */
  apiKeyEditable?: boolean;
}

export function CustomerForm({ customer, apiKeyEditable = customer?.apiKeyEditable ?? false }: CustomerFormProps) {
  const editing = Boolean(customer);
  const router = useRouter();
  const [pending, startTransition] = useTransition();
  const [generating, setGenerating] = useState<"code" | "order" | null>(null);

  const [form, setForm] = useState({
    accessCode: customer?.accessCode ?? "",
    orderNumber: customer?.orderNumber ?? "",
    apiKey: customer?.apiKey ?? "",
    initialBalance: customer ? String(customer.initialBalanceCents / 100) : "",
    initialBonus: customer ? String(customer.initialBonusCents / 100) : "0",
    profit: customer ? String(customer.profitCents / 100) : "0",
    status: customer?.status ?? "ACTIVE",
    notes: customer?.notes ?? "",
    balanceChangeReason: "",
  });

  const set = (key: keyof typeof form) => (value: string) => setForm((f) => ({ ...f, [key]: value }));

  const generate = async (kind: "code" | "order") => {
    setGenerating(kind);
    try {
      if (kind === "code") {
        const result = await generateCodeAction();
        if (result.ok && result.data) {
          set("accessCode")(result.data.code);
          toast.success("Access code generated");
        } else if (!result.ok) toast.error(result.error);
      } else {
        const result = await generateOrderNumberAction();
        if (result.ok && result.data) {
          set("orderNumber")(result.data.orderNumber);
          toast.success("Order number generated");
        } else if (!result.ok) toast.error(result.error);
      }
    } finally {
      setGenerating(null);
    }
  };

  const submit = () => {
    const input: CustomerFormInput = {
      accessCode: form.accessCode,
      orderNumber: form.orderNumber,
      apiKey: apiKeyEditable ? form.apiKey : undefined,
      initialBalance: form.initialBalance === "" ? 0 : Number(form.initialBalance),
      initialBonus: form.initialBonus === "" ? 0 : Number(form.initialBonus),
      profit: form.profit === "" ? 0 : Number(form.profit),
      status: form.status as CustomerFormInput["status"],
      notes: form.notes,
      balanceChangeReason: form.balanceChangeReason || undefined,
    };

    startTransition(async () => {
      if (editing && customer) {
        const result = await updateCustomerAction(customer.id, input);
        if (result.ok) {
          toast.success("Customer updated", { description: form.accessCode });
          router.push(`/admin/customers/${customer.id}`);
          router.refresh();
        } else toast.error(result.error);
      } else {
        const result = await createCustomerAction(input);
        if (result.ok && result.data) {
          toast.success("Customer created", { description: `Access code ${form.accessCode.toUpperCase()}` });
          router.push(`/admin/customers/${result.data.id}`);
          router.refresh();
        } else if (!result.ok) toast.error(result.error);
      }
    });
  };

  const moneyChanged =
    !!customer &&
    (Number(form.initialBalance || 0) !== customer.initialBalanceCents / 100 ||
      Number(form.initialBonus || 0) !== customer.initialBonusCents / 100);

  return (
    <form
      onSubmit={(e) => {
        e.preventDefault();
        submit();
      }}
      className="grid gap-6 lg:grid-cols-3"
    >
      <div className="space-y-6 lg:col-span-2">
        {/* Identity */}
        <Card>
          <CardHeader>
            <CardTitle>Access &amp; Order</CardTitle>
            <CardDescription>The access code is the customer&apos;s only way to sign in.</CardDescription>
          </CardHeader>
          <CardContent className="grid gap-4 sm:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="accessCode">Access Code</Label>
              <div className="flex gap-2">
                <Input
                  id="accessCode"
                  value={form.accessCode}
                  onChange={(e) => set("accessCode")(e.target.value.toUpperCase())}
                  placeholder="AERO-X8KF-93LD-72PQ"
                  className="font-mono"
                  required
                  minLength={6}
                />
                <Button
                  type="button"
                  variant="outline"
                  size="icon"
                  onClick={() => generate("code")}
                  disabled={generating !== null}
                  aria-label="Generate random access code"
                  title="Generate random code"
                >
                  {generating === "code" ? <Loader2 className="animate-spin" /> : <Dices />}
                </Button>
              </div>
            </div>
            <div className="space-y-2">
              <Label htmlFor="orderNumber">Order Number</Label>
              <div className="flex gap-2">
                <Input
                  id="orderNumber"
                  value={form.orderNumber}
                  onChange={(e) => set("orderNumber")(e.target.value)}
                  placeholder="ORD-20260802-4X8K2P"
                  className="font-mono"
                  required
                  minLength={3}
                />
                <Button
                  type="button"
                  variant="outline"
                  size="icon"
                  onClick={() => generate("order")}
                  disabled={generating !== null}
                  aria-label="Generate order number"
                  title="Generate order number"
                >
                  {generating === "order" ? <Loader2 className="animate-spin" /> : <Sparkles />}
                </Button>
              </div>
            </div>
            {apiKeyEditable && (
              <div className="space-y-2 sm:col-span-2">
                <Label htmlFor="apiKey" className="flex items-center gap-1.5">
                  <KeyRound className="size-3.5 text-muted-foreground" /> API Key
                </Label>
                <Input
                  id="apiKey"
                  value={form.apiKey}
                  onChange={(e) => set("apiKey")(e.target.value)}
                  placeholder="Legacy upstream key (optional)"
                  className="font-mono"
                  required
                  minLength={4}
                />
                <p className="text-xs text-muted-foreground">
                  Legacy API Pool is active. Customers should use a gateway token from API Access instead.
                </p>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Financials */}
        <Card>
          <CardHeader>
            <CardTitle>Balance &amp; Profit</CardTitle>
            <CardDescription>
              Used and remaining values start at zero and are updated through &quot;Update Usage&quot; — never edited
              directly.
            </CardDescription>
          </CardHeader>
          <CardContent className="grid gap-4 sm:grid-cols-3">
            <div className="space-y-2">
              <Label htmlFor="initialBalance">Initial Balance (USD)</Label>
              <Input
                id="initialBalance"
                type="number"
                inputMode="decimal"
                min="0"
                step="0.01"
                value={form.initialBalance}
                onChange={(e) => set("initialBalance")(e.target.value)}
                placeholder="300"
                required
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="initialBonus">Initial Bonus (USD)</Label>
              <Input
                id="initialBonus"
                type="number"
                inputMode="decimal"
                min="0"
                step="0.01"
                value={form.initialBonus}
                onChange={(e) => set("initialBonus")(e.target.value)}
                placeholder="0"
              />
            </div>
            {customer && moneyChanged && (
              <div className="space-y-2 sm:col-span-3">
                <Label htmlFor="balanceChangeReason">Reason for the balance change</Label>
                <Input
                  id="balanceChangeReason"
                  value={form.balanceChangeReason}
                  onChange={(e) => set("balanceChangeReason")(e.target.value)}
                  placeholder="e.g. Refund for double charge on order 12345"
                  required
                />
                <p className="text-xs text-muted-foreground">Recorded in the ledger as an admin adjustment; the customer sees it in their balance history.</p>
              </div>
            )}
            <div className="space-y-2">
              <Label htmlFor="profit">Profit (USD)</Label>
              <Input
                id="profit"
                type="number"
                inputMode="decimal"
                min="0"
                step="0.01"
                value={form.profit}
                onChange={(e) => set("profit")(e.target.value)}
                placeholder="89"
              />
            </div>
          </CardContent>
        </Card>

        {/* Notes */}
        <Card>
          <CardHeader>
            <CardTitle>Notes</CardTitle>
            <CardDescription>Internal notes — never visible to the customer.</CardDescription>
          </CardHeader>
          <CardContent>
            <Textarea
              value={form.notes}
              onChange={(e) => set("notes")(e.target.value)}
              placeholder="e.g. Purchased via Telegram, renewal expected next month…"
              rows={4}
            />
          </CardContent>
        </Card>
      </div>

      {/* Side column */}
      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle>Status</CardTitle>
            <CardDescription>Detected automatically from the remaining balance. Set Suspended or Expired manually.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <Select value={form.status} onValueChange={set("status")}>
              <SelectTrigger className="w-full" aria-label="Customer status">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {CUSTOMER_STATUSES.map((s) => (
                  <SelectItem key={s} value={s}>
                    {STATUS_LABELS[s]}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            <div className="flex items-center gap-2 text-sm text-muted-foreground">
              Preview: <StatusBadge status={form.status} />
            </div>
          </CardContent>
        </Card>

        <Card className="p-5">
          <div className="flex flex-col gap-2">
            <Button type="submit" disabled={pending} className="w-full">
              {pending ? <Loader2 className="animate-spin" /> : <Save />}
              {editing ? "Save changes" : "Save customer"}
            </Button>
            <Button type="button" variant="outline" className="w-full" onClick={() => router.back()} disabled={pending}>
              Cancel
            </Button>
          </div>
        </Card>
      </div>
    </form>
  );
}
