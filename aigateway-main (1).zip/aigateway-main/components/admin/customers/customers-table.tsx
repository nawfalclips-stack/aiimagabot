"use client";

import { useMemo, useState, useTransition } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { AnimatePresence, motion } from "framer-motion";
import { toast } from "sonner";
import {
  ArrowDown,
  ArrowUp,
  ArrowUpDown,
  ChevronLeft,
  ChevronRight,
  CircleDollarSign,
  Copy,
  CopyPlus,
  Download,
  Eye,
  FileSpreadsheet,
  FileText,
  Gift,
  MoreHorizontal,
  Pencil,
  Search,
  Star,
  Trash2,
  Users,
  X,
} from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuSub,
  DropdownMenuSubContent,
  DropdownMenuSubTrigger,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { StatusBadge } from "@/components/shared/status-badge";
import { CopyButton } from "@/components/shared/copy-button";
import { EmptyState } from "@/components/shared/empty-state";
import { AdjustDialog } from "@/components/admin/customers/adjust-dialog";
import { EditCustomerDialog } from "@/components/admin/customers/edit-customer-dialog";
import { cn } from "@/lib/utils";
import { useCopy } from "@/hooks/use-copy";
import { formatCents } from "@/lib/money";

import { CUSTOMER_STATUSES, STATUS_LABELS, type CustomerStatus } from "@/lib/constants";
import type { CustomerRow, RealUsageCell } from "@/lib/types";
import { formatMicroUsd } from "@/lib/real-usage";
import {
  bulkAssignPlanAction,
  bulkDeleteAction,
  bulkStatusAction,
  deleteCustomerAction,
  duplicateCustomerAction,
  logExportAction,
} from "@/app/admin/(dashboard)/customers/actions";
import { exportCsv, exportExcel, exportPdf } from "@/lib/export";
import { LocalTime } from "@/components/shared/local-time";
import { maskApiKey } from "@/lib/format";

type SortKey =
  | "accessCode"
  | "orderNumber"
  | "initialBalanceCents"
  | "usedBalanceCents"
  | "remainingBalanceCents"
  | "initialBonusCents"
  | "usedBonusCents"
  | "remainingBonusCents"
  | "profitCents"
  | "realCost"
  | "status"
  | "createdAt";

const PAGE_SIZE = 25;

interface CustomersTableProps {
  customers: CustomerRow[];
  /** Plans of this store, for the bulk "Assign plan" action (WS8). */
  plans?: { id: string; name: string }[];
  /** Real provider cost per customer id (missing = no usage yet). */
  realUsage?: Record<string, RealUsageCell>;
}

export function CustomersTable({ customers, plans = [], realUsage = {} }: CustomersTableProps) {
  const [query, setQuery] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("ALL");
  const [sort, setSort] = useState<{ key: SortKey; dir: "asc" | "desc" }>({ key: "createdAt", dir: "desc" });
  const [page, setPage] = useState(0);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [deleteTarget, setDeleteTarget] = useState<CustomerRow | null>(null);
  const [bulkDeleteOpen, setBulkDeleteOpen] = useState(false);
  const [pending, startTransition] = useTransition();
  const router = useRouter();
  const { copy } = useCopy();

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    let list = customers;
    if (statusFilter === "NO_PLAN") list = list.filter((c) => c.isActivated && !c.planId);
    else if (statusFilter !== "ALL") list = list.filter((c) => c.status === statusFilter);
    if (q) {
      list = list.filter((c) =>
        [c.accessCode, c.orderNumber, c.apiKey, c.notes, STATUS_LABELS[c.status as CustomerStatus] ?? c.status]
          .join(" ")
          .toLowerCase()
          .includes(q)
      );
    }
    const dir = sort.dir === "asc" ? 1 : -1;
    const value = (c: CustomerRow) => (sort.key === "realCost" ? (realUsage[c.id]?.costMicroUsd ?? 0) : c[sort.key]);
    return [...list].sort((a, b) => {
      const av = value(a);
      const bv = value(b);
      if (typeof av === "number" && typeof bv === "number") return (av - bv) * dir;
      return String(av).localeCompare(String(bv)) * dir;
    });
  }, [customers, query, statusFilter, sort, realUsage]);

  const pageCount = Math.max(1, Math.ceil(filtered.length / PAGE_SIZE));
  const safePage = Math.min(page, pageCount - 1);
  const pageRows = filtered.slice(safePage * PAGE_SIZE, (safePage + 1) * PAGE_SIZE);

  const allPageSelected = pageRows.length > 0 && pageRows.every((c) => selected.has(c.id));
  const selectedRows = customers.filter((c) => selected.has(c.id));

  const toggleSort = (key: SortKey) =>
    setSort((s) => ({ key, dir: s.key === key && s.dir === "desc" ? "asc" : "desc" }));

  const sortIcon = (key: SortKey) =>
    sort.key !== key ? (
      <ArrowUpDown className="size-3 opacity-40" />
    ) : sort.dir === "asc" ? (
      <ArrowUp className="size-3 text-primary" />
    ) : (
      <ArrowDown className="size-3 text-primary" />
    );

  const runExport = async (format: "csv" | "excel" | "pdf", rows: CustomerRow[]) => {
    if (rows.length === 0) {
      toast.error("Nothing to export");
      return;
    }
    if (format === "csv") exportCsv(rows);
    else if (format === "excel") await exportExcel(rows);
    else await exportPdf(rows);
    toast.success(`Exported ${rows.length} customers as ${format.toUpperCase()}`);
    void logExportAction(rows.length, format);
  };

  const doDelete = (customer: CustomerRow) => {
    startTransition(async () => {
      const result = await deleteCustomerAction(customer.id);
      if (result.ok) {
        toast.success("Customer deleted", { description: `${customer.accessCode} can be restored from Settings.` });
        router.refresh();
      } else toast.error(result.error);
      setDeleteTarget(null);
    });
  };

  const doBulkDelete = () => {
    const ids = Array.from(selected);
    startTransition(async () => {
      const result = await bulkDeleteAction(ids);
      if (result.ok) {
        toast.success(`Deleted ${ids.length} customers`, { description: "They can be restored from Settings." });
        setSelected(new Set());
        router.refresh();
      } else toast.error(result.error);
      setBulkDeleteOpen(false);
    });
  };

  const doBulkAssignPlan = (planId: string) => {
    const ids = Array.from(selected);
    startTransition(async () => {
      const result = await bulkAssignPlanAction(ids, planId);
      if (result.ok) {
        toast.success(planId ? `Assigned a plan to ${ids.length} customers` : `Removed the plan from ${ids.length} customers`);
        setSelected(new Set());
        router.refresh();
      } else toast.error(result.error);
    });
  };

  const doBulkStatus = (status: string) => {
    const ids = Array.from(selected);
    startTransition(async () => {
      const result = await bulkStatusAction(ids, status);
      if (result.ok) {
        toast.success(`Updated status for ${ids.length} customers`);
        setSelected(new Set());
        router.refresh();
      } else toast.error(result.error);
    });
  };

  const doDuplicate = (customer: CustomerRow) => {
    startTransition(async () => {
      const result = await duplicateCustomerAction(customer.id);
      if (result.ok) {
        toast.success("Customer duplicated", { description: "A new access code and order number were generated." });
        router.refresh();
      } else toast.error(result.error);
    });
  };

  const money = (cents: number) => (
    <span className="tabular-nums">{formatCents(cents)}</span>
  );

  return (
    <div className="space-y-4">
      {/* Toolbar */}
      <div className="flex flex-col gap-3 lg:flex-row lg:items-center">
        <div className="relative flex-1">
          <Search className="absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={query}
            onChange={(e) => {
              setQuery(e.target.value);
              setPage(0);
            }}
            placeholder="Search access code, order, API key, notes, status…"
            className="pl-9"
            aria-label="Search customers"
          />
          {query ? (
            <button
              type="button"
              onClick={() => setQuery("")}
              className="absolute top-1/2 right-3 -translate-y-1/2 text-muted-foreground hover:text-foreground"
              aria-label="Clear search"
            >
              <X className="size-4" />
            </button>
          ) : null}
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <Select
            value={statusFilter}
            onValueChange={(v) => {
              setStatusFilter(v);
              setPage(0);
            }}
          >
            <SelectTrigger className="w-[160px]" aria-label="Filter by status">
              <SelectValue placeholder="Status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="ALL">All statuses</SelectItem>
              <SelectItem value="NO_PLAN">No plan</SelectItem>
              {CUSTOMER_STATUSES.map((s) => (
                <SelectItem key={s} value={s}>
                  {STATUS_LABELS[s]}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>

          <Select
            value={`${sort.key}:${sort.dir}`}
            onValueChange={(v) => {
              const [key, dir] = v.split(":") as [SortKey, "asc" | "desc"];
              setSort({ key, dir });
            }}
          >
            <SelectTrigger className="w-[170px]" aria-label="Sort customers">
              <SelectValue placeholder="Sort" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="createdAt:desc">Newest first</SelectItem>
              <SelectItem value="createdAt:asc">Oldest first</SelectItem>
              <SelectItem value="profitCents:desc">Highest profit</SelectItem>
              <SelectItem value="profitCents:asc">Lowest profit</SelectItem>
              <SelectItem value="remainingBalanceCents:desc">Most remaining</SelectItem>
              <SelectItem value="remainingBalanceCents:asc">Least remaining</SelectItem>
            </SelectContent>
          </Select>

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="outline">
                <Download /> Export
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end">
              <DropdownMenuLabel>
                Export {selected.size > 0 ? `${selected.size} selected` : `${filtered.length} filtered`}
              </DropdownMenuLabel>
              <DropdownMenuSeparator />
              <DropdownMenuItem onSelect={() => runExport("csv", selected.size ? selectedRows : filtered)}>
                <FileText /> CSV
              </DropdownMenuItem>
              <DropdownMenuItem onSelect={() => runExport("excel", selected.size ? selectedRows : filtered)}>
                <FileSpreadsheet /> Excel
              </DropdownMenuItem>
              <DropdownMenuItem onSelect={() => runExport("pdf", selected.size ? selectedRows : filtered)}>
                <FileText /> PDF
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>

      {/* Bulk actions bar */}
      <AnimatePresence>
        {selected.size > 0 ? (
          <motion.div
            initial={{ opacity: 0, y: -8, height: 0 }}
            animate={{ opacity: 1, y: 0, height: "auto" }}
            exit={{ opacity: 0, y: -8, height: 0 }}
            className="overflow-hidden"
          >
            <div className="flex flex-wrap items-center gap-2 rounded-xl border border-primary/25 bg-primary/8 px-4 py-2.5">
              <Badge variant="secondary" className="bg-primary/15 text-primary">
                {selected.size} selected
              </Badge>
              <div className="flex flex-1 flex-wrap items-center gap-1.5">
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => {
                    copy(selectedRows.map((c) => c.accessCode).join("\n"), "Access codes");
                  }}
                >
                  <Copy /> Copy codes
                </Button>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="sm" disabled={pending}>
                      Change status
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent>
                    {CUSTOMER_STATUSES.map((s) => (
                      <DropdownMenuItem key={s} onSelect={() => doBulkStatus(s)}>
                        {STATUS_LABELS[s]}
                      </DropdownMenuItem>
                    ))}
                  </DropdownMenuContent>
                </DropdownMenu>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" size="sm" disabled={pending || plans.length === 0}>
                      Assign plan
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent>
                    {plans.map((p) => (
                      <DropdownMenuItem key={p.id} onSelect={() => doBulkAssignPlan(p.id)}>
                        {p.name}
                      </DropdownMenuItem>
                    ))}
                    <DropdownMenuItem onSelect={() => doBulkAssignPlan("")} className="text-destructive">
                      Remove plan
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
                <Button variant="ghost" size="sm" onClick={() => runExport("csv", selectedRows)}>
                  <Download /> Export
                </Button>
                <Button
                  variant="ghost"
                  size="sm"
                  className="text-destructive hover:text-destructive"
                  onClick={() => setBulkDeleteOpen(true)}
                  disabled={pending}
                >
                  <Trash2 /> Delete
                </Button>
              </div>
              <Button variant="ghost" size="icon-sm" onClick={() => setSelected(new Set())} aria-label="Clear selection">
                <X />
              </Button>
            </div>
          </motion.div>
        ) : null}
      </AnimatePresence>

      {/* Table */}
      <Card className="overflow-hidden p-0">
        {filtered.length === 0 ? (
          <EmptyState
            icon={Users}
            title={customers.length === 0 ? "No customers yet" : "No matching customers"}
            description={
              customers.length === 0
                ? "Create your first customer to generate an access code and assign an API key."
                : "Try adjusting your search or filters."
            }
            action={
              customers.length === 0 ? (
                <Button asChild>
                  <Link href="/admin/customers/new">Create customer</Link>
                </Button>
              ) : (
                <Button
                  variant="outline"
                  onClick={() => {
                    setQuery("");
                    setStatusFilter("ALL");
                  }}
                >
                  Clear filters
                </Button>
              )
            }
            className="border-0"
          />
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="hover:bg-transparent">
                  <TableHead className="w-10 pl-4">
                    <Checkbox
                      checked={allPageSelected}
                      onCheckedChange={(checked) => {
                        setSelected((prev) => {
                          const next = new Set(prev);
                          for (const c of pageRows) {
                            if (checked) next.add(c.id);
                            else next.delete(c.id);
                          }
                          return next;
                        });
                      }}
                      aria-label="Select all on page"
                    />
                  </TableHead>
                  <TableHead>Title</TableHead>
                  {(
                    [
                      ["accessCode", "Access Code"],
                      ["orderNumber", "Order"],
                    ] as [SortKey, string][]
                  ).map(([key, label]) => (
                    <TableHead key={key}>
                      <button type="button" className="flex items-center gap-1 hover:text-foreground" onClick={() => toggleSort(key)}>
                        {label} {sortIcon(key)}
                      </button>
                    </TableHead>
                  ))}
                  <TableHead>Legacy Key</TableHead>
                  {(
                    [
                      ["initialBalanceCents", "Initial"],
                      ["usedBalanceCents", "Used"],
                      ["remainingBalanceCents", "Remaining"],
                      ["remainingBonusCents", "Bonus Left"],
                      ["profitCents", "Profit"],
                      ["realCost", "Real usage"],
                      ["status", "Status"],
                      ["createdAt", "Created"],
                    ] as [SortKey, string][]
                  ).map(([key, label]) => (
                    <TableHead key={key}>
                      <button type="button" className="flex items-center gap-1 hover:text-foreground" onClick={() => toggleSort(key)}>
                        {label} {sortIcon(key)}
                      </button>
                    </TableHead>
                  ))}
                  <TableHead className="w-12 pr-4 text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {pageRows.map((c) => (
                  <TableRow
                    key={c.id}
                    className="group cursor-pointer"
                    data-state={selected.has(c.id) ? "selected" : undefined}
                    onClick={() => router.push(`/admin/customers/${c.id}`)}
                  >
                    <TableCell className="pl-4" onClick={(e) => e.stopPropagation()}>
                      <Checkbox
                        checked={selected.has(c.id)}
                        onCheckedChange={(checked) => {
                          setSelected((prev) => {
                            const next = new Set(prev);
                            if (checked) next.add(c.id);
                            else next.delete(c.id);
                            return next;
                          });
                        }}
                        aria-label={`Select ${c.accessCode}`}
                      />
                    </TableCell>
                    <TableCell>
                      <span className="text-[13px] text-foreground/80">
                        {c.offerTitle ? c.offerTitle : <span className="text-muted-foreground">—</span>}
                      </span>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <span className="font-mono text-[13px] font-medium">{c.accessCode}</span>
                        <span onClick={(e) => e.stopPropagation()}>
                          <CopyButton value={c.accessCode} label="Access code" size="icon-xs" className="opacity-0 transition-opacity group-hover:opacity-100" />
                        </span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <span className="font-mono text-[13px] text-muted-foreground">{c.orderNumber}</span>
                        <span onClick={(e) => e.stopPropagation()}>
                          <CopyButton value={c.orderNumber} label="Order number" size="icon-xs" className="opacity-0 transition-opacity group-hover:opacity-100" />
                        </span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <span className="font-mono text-xs text-muted-foreground">
                          {c.apiKeyEditable ? maskApiKey(c.apiKey) : c.apiKey || "—"}
                        </span>
                        {c.apiKeyEditable && c.apiKey && (
                          <span onClick={(e) => e.stopPropagation()}>
                            <CopyButton value={c.apiKey} label="API key" size="icon-xs" className="opacity-0 transition-opacity group-hover:opacity-100" />
                          </span>
                        )}
                      </div>
                    </TableCell>
                    <TableCell>{money(c.initialBalanceCents)}</TableCell>
                    <TableCell className="text-muted-foreground">{money(c.usedBalanceCents)}</TableCell>
                    <TableCell className={cn("font-medium", c.remainingBalanceCents < 0 && "text-destructive")}>
                      {money(c.remainingBalanceCents)}
                    </TableCell>
                    <TableCell className={cn("text-muted-foreground", c.remainingBonusCents < 0 && "text-destructive")}>
                      {money(c.remainingBonusCents)}
                    </TableCell>
                    <TableCell className="text-success">{money(c.profitCents)}</TableCell>
                    <TableCell>
                      <RealUsageValue cell={realUsage[c.id]} />
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1.5">
                        <StatusBadge status={c.status} />
                        {c.isActivated && !c.planId && (
                          <span
                            className="inline-flex items-center rounded-full border border-destructive/30 bg-destructive/10 px-2 py-0.5 text-[11px] font-medium text-destructive"
                            title="No plan assigned — billed at the global multiplier. Select and use “Assign plan”."
                          >
                            No plan
                          </span>
                        )}
                        {c.reviewBonusStatus === "CLAIMED" ? (
                          <span
                            className="inline-flex items-center gap-1 rounded-full border border-warning/30 bg-warning/12 px-2 py-0.5 text-[11px] font-medium text-warning"
                            title="Says they wrote a review — bonus credited. Verify it on the store!"
                          >
                            <Star className="size-3" /> Review?
                          </span>
                        ) : c.reviewBonusStatus === "REVOKED" ? (
                          <span
                            className="inline-flex items-center rounded-full border border-destructive/30 bg-destructive/10 px-2 py-0.5 text-[11px] font-medium text-destructive"
                            title="Review bonus was removed — no review found."
                          >
                            Bonus removed
                          </span>
                        ) : null}
                      </div>
                    </TableCell>
                    <TableCell className="text-muted-foreground"><LocalTime date={c.createdAt} variant="date" /></TableCell>
                    <TableCell className="pr-4 text-right" onClick={(e) => e.stopPropagation()}>
                      <div className="flex items-center justify-end gap-0.5">
                        {/* Quick balance adjust — no navigation needed */}
                        <AdjustDialog
                          customerId={c.id}
                          accessCode={c.accessCode}
                          kind="balance"
                          remainingCents={c.remainingBalanceCents}
                          trigger={
                            <Button
                              variant="ghost"
                              size="icon-sm"
                              aria-label={`Adjust balance for ${c.accessCode}`}
                              title="Adjust balance (add / deduct)"
                              className="text-muted-foreground hover:text-primary"
                            >
                              <CircleDollarSign />
                            </Button>
                          }
                        />
                        {/* Quick edit — everything editable in place */}
                        <EditCustomerDialog
                          customer={c}
                          trigger={
                            <Button
                              variant="ghost"
                              size="icon-sm"
                              aria-label={`Quick edit ${c.accessCode}`}
                              title="Quick edit"
                              className="text-muted-foreground hover:text-foreground"
                            >
                              <Pencil />
                            </Button>
                          }
                        />
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon-sm" aria-label={`Actions for ${c.accessCode}`}>
                            <MoreHorizontal />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end" className="w-52">
                          <DropdownMenuItem asChild>
                            <Link href={`/admin/customers/${c.id}`}>
                              <Eye /> View profile
                            </Link>
                          </DropdownMenuItem>
                          <DropdownMenuItem asChild>
                            <Link href={`/admin/customers/${c.id}/edit`}>
                              <Pencil /> Edit
                            </Link>
                          </DropdownMenuItem>
                          <DropdownMenuSeparator />
                          <AdjustDialog
                            customerId={c.id}
                            accessCode={c.accessCode}
                            kind="balance"
                            remainingCents={c.remainingBalanceCents}
                            trigger={
                              <DropdownMenuItem onSelect={(e) => e.preventDefault()}>
                                <CircleDollarSign /> Adjust balance
                              </DropdownMenuItem>
                            }
                          />
                          <AdjustDialog
                            customerId={c.id}
                            accessCode={c.accessCode}
                            kind="bonus"
                            remainingCents={c.remainingBonusCents}
                            trigger={
                              <DropdownMenuItem onSelect={(e) => e.preventDefault()}>
                                <Gift /> Adjust bonus
                              </DropdownMenuItem>
                            }
                          />
                          <DropdownMenuSeparator />
                          <DropdownMenuItem onSelect={() => doDuplicate(c)}>
                            <CopyPlus /> Duplicate
                          </DropdownMenuItem>
                          <DropdownMenuItem onSelect={() => copy(c.accessCode, "Access code")}>
                            <Copy /> Copy code
                          </DropdownMenuItem>
                          {c.apiKeyEditable && c.apiKey && (
                            <DropdownMenuItem onSelect={() => copy(c.apiKey, "API key")}>
                              <Copy /> Copy API key
                            </DropdownMenuItem>
                          )}
                          <DropdownMenuSub>
                            <DropdownMenuSubTrigger>
                              <ArrowUpDown className="mr-2 size-4" /> Set status
                            </DropdownMenuSubTrigger>
                            <DropdownMenuSubContent>
                              {CUSTOMER_STATUSES.map((s) => (
                                <DropdownMenuItem
                                  key={s}
                                  onSelect={() => {
                                    startTransition(async () => {
                                      const { setCustomerStatusAction } = await import(
                                        "@/app/admin/(dashboard)/customers/actions"
                                      );
                                      const result = await setCustomerStatusAction(c.id, s);
                                      if (result.ok) {
                                        toast.success(`Status updated to ${STATUS_LABELS[s]}`);
                                        router.refresh();
                                      } else toast.error(result.error);
                                    });
                                  }}
                                >
                                  {STATUS_LABELS[s]}
                                </DropdownMenuItem>
                              ))}
                            </DropdownMenuSubContent>
                          </DropdownMenuSub>
                          <DropdownMenuSeparator />
                          <DropdownMenuItem variant="destructive" onSelect={() => setDeleteTarget(c)}>
                            <Trash2 /> Delete
                          </DropdownMenuItem>
                        </DropdownMenuContent>
                      </DropdownMenu>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}

        {/* Pagination */}
        {filtered.length > PAGE_SIZE ? (
          <div className="flex items-center justify-between border-t px-4 py-3">
            <p className="text-sm text-muted-foreground">
              {safePage * PAGE_SIZE + 1}–{Math.min((safePage + 1) * PAGE_SIZE, filtered.length)} of {filtered.length}
            </p>
            <div className="flex items-center gap-1">
              <Button variant="outline" size="icon-sm" disabled={safePage === 0} onClick={() => setPage(safePage - 1)} aria-label="Previous page">
                <ChevronLeft />
              </Button>
              <span className="px-2 text-sm tabular-nums">
                {safePage + 1} / {pageCount}
              </span>
              <Button
                variant="outline"
                size="icon-sm"
                disabled={safePage >= pageCount - 1}
                onClick={() => setPage(safePage + 1)}
                aria-label="Next page"
              >
                <ChevronRight />
              </Button>
            </div>
          </div>
        ) : null}
      </Card>

      {/* Delete confirmations */}
      <AlertDialog open={deleteTarget !== null} onOpenChange={(open) => !open && setDeleteTarget(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete customer?</AlertDialogTitle>
            <AlertDialogDescription>
              <span className="font-mono text-foreground">{deleteTarget?.accessCode}</span> will be moved to deleted
              customers. You can restore it later from Settings — nothing is permanently lost.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={pending}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-white hover:bg-destructive/90"
              disabled={pending}
              onClick={(e) => {
                e.preventDefault();
                if (deleteTarget) doDelete(deleteTarget);
              }}
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <AlertDialog open={bulkDeleteOpen} onOpenChange={setBulkDeleteOpen}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete {selected.size} customers?</AlertDialogTitle>
            <AlertDialogDescription>
              The selected customers will be moved to deleted customers and can be restored later from Settings.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel disabled={pending}>Cancel</AlertDialogCancel>
            <AlertDialogAction
              className="bg-destructive text-white hover:bg-destructive/90"
              disabled={pending}
              onClick={(e) => {
                e.preventDefault();
                doBulkDelete();
              }}
            >
              Delete all
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

/** Real provider cost, with the share of the customer's real allowance it used. */
function RealUsageValue({ cell }: { cell?: RealUsageCell }) {
  if (!cell) return <span className="text-muted-foreground">—</span>;
  return (
    <div className="leading-tight" title={`${cell.requests} ${cell.requests === 1 ? "request" : "requests"} at provider cost`}>
      <span className="tabular-nums">{formatMicroUsd(cell.costMicroUsd)}</span>
      {cell.pct !== null ? (
        <span className={cn("block text-[11px] tabular-nums text-muted-foreground", cell.pct >= 100 && "text-destructive", cell.pct >= 80 && cell.pct < 100 && "text-warning")}>
          {cell.pct}% of allowance
        </span>
      ) : null}
    </div>
  );
}
