"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { Loader2, Save } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { CUSTOMER_STATUSES, STATUS_LABELS } from "@/lib/constants";
import type { CustomerRow } from "@/lib/types";
import { updateCustomerAction, type CustomerFormInput } from "@/app/admin/(dashboard)/customers/actions";

interface EditCustomerDialogProps {
  customer: CustomerRow;
  trigger: React.ReactNode;
}

/** Quick edit — change everything in place without leaving the table. */
export function EditCustomerDialog({ customer, trigger }: EditCustomerDialogProps) {
  const [open, setOpen] = useState(false);
  const [pending, startTransition] = useTransition();
  const router = useRouter();

  const [form, setForm] = useState({
    accessCode: customer.accessCode,
    orderNumber: customer.orderNumber,
    apiKey: customer.apiKey,
    initialBalance: String(customer.initialBalanceCents / 100),
    initialBonus: String(customer.initialBonusCents / 100),
    balanceChangeReason: "",
    profit: String(customer.profitCents / 100),
    status: customer.status,
    notes: customer.notes,
  });

  const set = (key: keyof typeof form) => (value: string) => setForm((f) => ({ ...f, [key]: value }));

  const submit = () => {
    const input: CustomerFormInput = {
      accessCode: form.accessCode,
      orderNumber: form.orderNumber,
      apiKey: customer.apiKeyEditable ? form.apiKey : undefined,
      initialBalance: form.initialBalance === "" ? 0 : Number(form.initialBalance),
      initialBonus: form.initialBonus === "" ? 0 : Number(form.initialBonus),
      profit: form.profit === "" ? 0 : Number(form.profit),
      status: form.status as CustomerFormInput["status"],
      balanceChangeReason: form.balanceChangeReason || undefined,
      notes: form.notes,
    };
    startTransition(async () => {
      const result = await updateCustomerAction(customer.id, input);
      if (result.ok) {
        toast.success("Customer updated", { description: form.accessCode });
        setOpen(false);
        router.refresh();
      } else {
        toast.error(result.error);
      }
    });
  };

  const moneyChanged =
    Number(form.initialBalance || 0) !== customer.initialBalanceCents / 100 ||
    Number(form.initialBonus || 0) !== customer.initialBonusCents / 100;

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>{trigger}</DialogTrigger>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>Quick edit</DialogTitle>
          <DialogDescription>
            Edit <span className="font-mono text-foreground">{customer.accessCode}</span> without leaving this page.
          </DialogDescription>
        </DialogHeader>

        <form
          onSubmit={(e) => {
            e.preventDefault();
            submit();
          }}
          className="grid gap-4 sm:grid-cols-2"
        >
          <div className="space-y-1.5">
            <Label htmlFor="qe-code">Access Code</Label>
            <Input
              id="qe-code"
              value={form.accessCode}
              onChange={(e) => set("accessCode")(e.target.value.toUpperCase())}
              className="font-mono"
              required
              minLength={6}
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="qe-order">Order Number</Label>
            <Input
              id="qe-order"
              value={form.orderNumber}
              onChange={(e) => set("orderNumber")(e.target.value)}
              className="font-mono"
              required
              minLength={3}
            />
          </div>
          {customer.apiKeyEditable && (
            <div className="space-y-1.5 sm:col-span-2">
              <Label htmlFor="qe-api">Legacy API Key</Label>
              <Input
                id="qe-api"
                value={form.apiKey}
                onChange={(e) => set("apiKey")(e.target.value)}
                className="font-mono"
                minLength={4}
              />
            </div>
          )}
          <div className="space-y-1.5">
            <Label htmlFor="qe-balance">Initial Balance (USD)</Label>
            <Input
              id="qe-balance"
              type="number"
              inputMode="decimal"
              min="0"
              step="0.01"
              value={form.initialBalance}
              onChange={(e) => set("initialBalance")(e.target.value)}
              required
            />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="qe-bonus">Initial Bonus (USD)</Label>
            <Input
              id="qe-bonus"
              type="number"
              inputMode="decimal"
              min="0"
              step="0.01"
              value={form.initialBonus}
              onChange={(e) => set("initialBonus")(e.target.value)}
            />
          </div>
          {moneyChanged && (
            <div className="space-y-1.5 sm:col-span-2">
              <Label htmlFor="qe-reason">Reason for the balance change</Label>
              <Input
                id="qe-reason"
                value={form.balanceChangeReason}
                onChange={(e) => set("balanceChangeReason")(e.target.value)}
                placeholder="e.g. Refund for double charge on order 12345"
                required
              />
              <p className="text-xs text-muted-foreground">Recorded in the ledger as an admin adjustment; the customer sees it in their balance history.</p>
            </div>
          )}
          <div className="space-y-1.5">
            <Label htmlFor="qe-profit">Profit (USD)</Label>
            <Input
              id="qe-profit"
              type="number"
              inputMode="decimal"
              min="0"
              step="0.01"
              value={form.profit}
              onChange={(e) => set("profit")(e.target.value)}
            />
          </div>
          <div className="space-y-1.5">
            <Label>Status</Label>
            <Select value={form.status} onValueChange={set("status")}>
              <SelectTrigger className="w-full" aria-label="Customer status">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {CUSTOMER_STATUSES.map((s) => (
                  <SelectItem key={s} value={s}>
                    {STATUS_LABELS[s]}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5 sm:col-span-2">
            <Label htmlFor="qe-notes">Notes</Label>
            <Textarea id="qe-notes" rows={2} value={form.notes} onChange={(e) => set("notes")(e.target.value)} />
          </div>
        </form>

        <DialogFooter>
          <Button variant="outline" onClick={() => setOpen(false)} disabled={pending}>
            Cancel
          </Button>
          <Button onClick={submit} disabled={pending}>
            {pending ? <Loader2 className="animate-spin" /> : <Save />}
            Save changes
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
