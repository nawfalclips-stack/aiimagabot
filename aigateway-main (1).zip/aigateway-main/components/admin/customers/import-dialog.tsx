"use client";

import { useRef, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { FileUp, Loader2, Upload } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { importCustomersAction } from "@/app/admin/(dashboard)/customers/actions";
import { parseImportFile } from "@/lib/export";

export function ImportDialog() {
  const [open, setOpen] = useState(false);
  const [fileName, setFileName] = useState<string | null>(null);
  const [rows, setRows] = useState<Record<string, unknown>[]>([]);
  const [result, setResult] = useState<{ imported: number; skipped: { row: number; reason: string }[] } | null>(null);
  const [pending, startTransition] = useTransition();
  const inputRef = useRef<HTMLInputElement>(null);
  const router = useRouter();

  const reset = () => {
    setFileName(null);
    setRows([]);
    setResult(null);
    if (inputRef.current) inputRef.current.value = "";
  };

  const handleFile = async (file: File) => {
    try {
      const parsed = await parseImportFile(file);
      if (parsed.length === 0) {
        toast.error("No rows found in the file");
        return;
      }
      setFileName(file.name);
      setRows(parsed);
      setResult(null);
    } catch {
      toast.error("Could not read that file. Use a CSV or Excel export.");
    }
  };

  const runImport = () => {
    startTransition(async () => {
      const response = await importCustomersAction(rows);
      if (response.ok && response.data) {
        setResult(response.data);
        if (response.data.imported > 0) {
          toast.success(`Imported ${response.data.imported} customers`);
          router.refresh();
        } else {
          toast.error("No customers were imported");
        }
      } else if (!response.ok) {
        toast.error(response.error);
      }
    });
  };

  return (
    <Dialog
      open={open}
      onOpenChange={(v) => {
        setOpen(v);
        if (!v) reset();
      }}
    >
      <DialogTrigger asChild>
        <Button variant="outline">
          <Upload /> Import
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>Import customers</DialogTitle>
          <DialogDescription>
            Upload a CSV or Excel file with columns: Access Code, Order Number, API Key, Initial Balance, Initial
            Bonus, Profit, Notes. Duplicates are skipped automatically.
          </DialogDescription>
        </DialogHeader>

        <input
          ref={inputRef}
          type="file"
          accept=".csv,.xlsx,.xls"
          className="hidden"
          onChange={(e) => {
            const file = e.target.files?.[0];
            if (file) void handleFile(file);
          }}
        />

        {!fileName ? (
          <button
            type="button"
            onClick={() => inputRef.current?.click()}
            className="flex flex-col items-center justify-center gap-2 rounded-xl border-2 border-dashed px-6 py-10 text-sm text-muted-foreground transition-colors hover:border-primary/50 hover:bg-primary/5"
          >
            <FileUp className="size-8" />
            <span className="font-medium text-foreground">Choose a CSV or Excel file</span>
            <span className="text-xs">Up to 1000 rows per import</span>
          </button>
        ) : (
          <div className="space-y-3">
            <div className="flex items-center justify-between rounded-lg border bg-muted/40 px-4 py-3">
              <div className="min-w-0">
                <p className="truncate text-sm font-medium">{fileName}</p>
                <p className="text-xs text-muted-foreground">{rows.length} rows detected</p>
              </div>
              <Button variant="ghost" size="sm" onClick={reset} disabled={pending}>
                Change file
              </Button>
            </div>

            {result ? (
              <div className="rounded-lg border px-4 py-3 text-sm">
                <p className="font-medium text-success">{result.imported} imported</p>
                {result.skipped.length > 0 ? (
                  <>
                    <p className="mt-1 text-muted-foreground">{result.skipped.length} skipped:</p>
                    <ScrollArea className="mt-1 max-h-32">
                      <ul className="space-y-0.5 text-xs text-muted-foreground">
                        {result.skipped.map((s) => (
                          <li key={s.row}>
                            Row {s.row}: {s.reason}
                          </li>
                        ))}
                      </ul>
                    </ScrollArea>
                  </>
                ) : null}
              </div>
            ) : null}
          </div>
        )}

        <DialogFooter>
          <Button variant="outline" onClick={() => setOpen(false)} disabled={pending}>
            {result ? "Close" : "Cancel"}
          </Button>
          {!result ? (
            <Button onClick={runImport} disabled={rows.length === 0 || pending}>
              {pending ? <Loader2 className="animate-spin" /> : <Upload />}
              Import {rows.length > 0 ? `${rows.length} rows` : ""}
            </Button>
          ) : null}
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
