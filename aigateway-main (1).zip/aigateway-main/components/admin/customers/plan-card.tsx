"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { CreditCard, Loader2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { describePlanLimit, describePlanRate, type PlanLimitType } from "@/lib/plan-usage";
import { LocalTime } from "@/components/shared/local-time";
import { assignCustomerPlanAction } from "@/app/admin/(dashboard)/plans/actions";

export interface PlanOption {
  id: string;
  name: string;
  priceCents: number;
  limitType: PlanLimitType;
  limitUsageCents: number;
  limitMTokens: number;
  isActive: boolean;
}

const NONE = "__none__";

/** Admin: which plan this customer is on, and a way to change it. */
export function PlanCard({
  customerId,
  currentPlanId,
  assignedAt,
  plans,
  globalMultiplier,
}: {
  customerId: string;
  currentPlanId: string | null;
  assignedAt: string | null;
  plans: PlanOption[];
  globalMultiplier: number;
}) {
  const router = useRouter();
  const [pending, startTransition] = useTransition();
  const [selected, setSelected] = useState(currentPlanId ?? NONE);
  const current = plans.find((p) => p.id === currentPlanId) ?? null;
  const dirty = selected !== (currentPlanId ?? NONE);

  const save = () =>
    startTransition(async () => {
      const r = await assignCustomerPlanAction(customerId, selected === NONE ? "" : selected);
      if (r.ok) {
        toast.success(selected === NONE ? "Plan removed" : "Plan assigned");
        router.refresh();
      } else toast.error(r.error);
    });

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <CreditCard className="size-4 text-muted-foreground" /> Plan
        </CardTitle>
        <CardDescription>
          {current ? (
            <>
              <span className="font-medium text-foreground">{current.name}</span> · ${(current.priceCents / 100).toFixed(0)} · {describePlanLimit(current)}
              {assignedAt ? (
                <>
                  {" "}· since <LocalTime date={new Date(assignedAt)} variant="date" />
                </>
              ) : null}
              <br />
              <span className="text-xs">Billing: {describePlanRate(current)}</span>
            </>
          ) : (
            <>No plan — billed at provider cost ×{globalMultiplier} (global multiplier).</>
          )}
        </CardDescription>
      </CardHeader>
      <CardContent className="flex flex-wrap items-center gap-2">
        <Select value={selected} onValueChange={setSelected}>
          <SelectTrigger className="w-64" aria-label="Plan">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value={NONE}>No plan (global multiplier)</SelectItem>
            {plans.map((p) => (
              <SelectItem key={p.id} value={p.id} disabled={!p.isActive && p.id !== currentPlanId}>
                {p.name} — ${(p.priceCents / 100).toFixed(0)} · {describePlanLimit(p)}
                {!p.isActive ? " (inactive)" : ""}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Button size="sm" onClick={save} disabled={!dirty || pending}>
          {pending ? <Loader2 className="animate-spin" /> : null} Apply
        </Button>
        {plans.length === 0 ? <p className="text-xs text-muted-foreground">Create plans under Admin → Plans first.</p> : null}
      </CardContent>
    </Card>
  );
}
