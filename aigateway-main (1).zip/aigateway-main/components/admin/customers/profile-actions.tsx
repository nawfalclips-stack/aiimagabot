"use client";

import { useTransition } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { Ban, CircleDollarSign, CopyPlus, Gift, MoreHorizontal, Pencil, PlayCircle, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { ConfirmDialog } from "@/components/shared/confirm-dialog";
import { AdjustDialog } from "@/components/admin/customers/adjust-dialog";
import type { CustomerRow } from "@/lib/types";
import {
  deleteCustomerAction,
  duplicateCustomerAction,
  setCustomerStatusAction,
} from "@/app/admin/(dashboard)/customers/actions";

export function ProfileActions({ customer }: { customer: CustomerRow }) {
  const router = useRouter();
  const [pending, startTransition] = useTransition();
  const suspended = customer.status === "SUSPENDED";

  const setStatus = (status: string, message: string) => {
    startTransition(async () => {
      const result = await setCustomerStatusAction(customer.id, status);
      if (result.ok) {
        toast.success(message);
        router.refresh();
      } else toast.error(result.error);
    });
  };

  return (
    <div className="flex flex-wrap items-center gap-2">
      <AdjustDialog
        customerId={customer.id}
        accessCode={customer.accessCode}
        kind="balance"
        remainingCents={customer.remainingBalanceCents}
        trigger={
          <Button variant="outline">
            <CircleDollarSign /> Adjust balance
          </Button>
        }
      />
      <AdjustDialog
        customerId={customer.id}
        accessCode={customer.accessCode}
        kind="bonus"
        remainingCents={customer.remainingBonusCents}
        trigger={
          <Button variant="outline">
            <Gift /> Adjust bonus
          </Button>
        }
      />
      <Button asChild>
        <Link href={`/admin/customers/${customer.id}/edit`}>
          <Pencil /> Edit
        </Link>
      </Button>
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="outline" size="icon" aria-label="More actions" disabled={pending}>
            <MoreHorizontal />
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="end" className="w-48">
          <DropdownMenuItem
            onSelect={() => {
              startTransition(async () => {
                const result = await duplicateCustomerAction(customer.id);
                if (result.ok && result.data) {
                  toast.success("Customer duplicated");
                  router.push(`/admin/customers/${result.data.id}`);
                  router.refresh();
                } else if (!result.ok) toast.error(result.error);
              });
            }}
          >
            <CopyPlus /> Duplicate
          </DropdownMenuItem>
          {suspended ? (
            <DropdownMenuItem onSelect={() => setStatus("ACTIVE", "Customer reactivated")}>
              <PlayCircle /> Unsuspend
            </DropdownMenuItem>
          ) : (
            <DropdownMenuItem onSelect={() => setStatus("SUSPENDED", "Customer suspended")}>
              <Ban /> Suspend
            </DropdownMenuItem>
          )}
          <DropdownMenuSeparator />
          <ConfirmDialog
            trigger={
              <DropdownMenuItem variant="destructive" onSelect={(e) => e.preventDefault()}>
                <Trash2 /> Delete
              </DropdownMenuItem>
            }
            title="Delete customer?"
            description={`${customer.accessCode} will be moved to deleted customers and can be restored later from Settings.`}
            confirmLabel="Delete"
            destructive
            onConfirm={async () => {
              const result = await deleteCustomerAction(customer.id);
              if (result.ok) {
                toast.success("Customer deleted");
                router.push("/admin/customers");
                router.refresh();
              } else toast.error(result.error);
            }}
          />
        </DropdownMenuContent>
      </DropdownMenu>
    </div>
  );
}
