import { Activity } from "lucide-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { LocalTime } from "@/components/shared/local-time";
import { formatCents } from "@/lib/money";
import { formatMicroUsd, formatTokens, realUsedPct, totalTokens, type RealAllowance, type RealUsage } from "@/lib/real-usage";
import { cn } from "@/lib/utils";

/**
 * Admin-only: what the customer's requests really cost at the provider, next
 * to what their balance was charged for them — and how much of the real usage
 * their credit buys (plan limit scaled by everything credited) is gone.
 * The bonus has its own line: what it paid at the provider against what it
 * is worth (the plan's bonus rate, or the balance rate when it has none).
 */
export function RealUsageCard({
  usage,
  allowance,
  bonusAllowance,
  bonusRateLabel,
  chargedCents,
  planLabel,
}: {
  usage: RealUsage;
  allowance: RealAllowance | null;
  /** Real usage the bonus credited so far buys; null without bonus. */
  bonusAllowance: RealAllowance | null;
  /** "Pro bonus: $10.00 = $0.50 of real API usage (×20)"; null when the plan has no bonus. */
  bonusRateLabel: string | null;
  chargedCents: number;
  planLabel: string;
}) {
  const pct = realUsedPct(usage, allowance);
  const balanceCostMicroUsd = usage.costMicroUsd - usage.bonusCostMicroUsd;
  const bonusPct = bonusAllowance?.kind === "usd" && bonusAllowance.microUsd > 0 ? Math.round((usage.bonusCostMicroUsd / bonusAllowance.microUsd) * 1000) / 10 : null;
  const marginCents = chargedCents - Math.round(usage.costMicroUsd / 10_000);

  const stats: { label: string; value: React.ReactNode; hint?: string; tone?: string }[] = [
    { label: "Provider cost", value: formatMicroUsd(usage.costMicroUsd), hint: "Real API cost" },
    { label: "Paid by balance", value: formatMicroUsd(balanceCostMicroUsd), hint: "Real cost" },
    { label: "Paid by bonus", value: formatMicroUsd(usage.bonusCostMicroUsd), hint: "Real cost" },
    { label: "Charged", value: formatCents(chargedCents), hint: "Balance + bonus used" },
    { label: "Gross margin", value: formatCents(marginCents), hint: "Charged − provider cost", tone: marginCents < 0 ? "text-destructive" : "text-success" },
    { label: "Requests", value: usage.requests.toLocaleString("en-US") },
    {
      label: "Input tokens",
      value: formatTokens(usage.inputTokens),
      hint: usage.cachedTokens > 0 ? `${formatTokens(usage.cachedTokens)} cached` : undefined,
    },
    { label: "Output tokens", value: formatTokens(usage.outputTokens) },
  ];

  const usedLabel = allowance
    ? allowance.kind === "tokens"
      ? `${formatTokens(totalTokens(usage))} of ${formatTokens(allowance.tokens)} tokens`
      : `${formatMicroUsd(usage.costMicroUsd)} of ${formatMicroUsd(allowance.microUsd)}`
    : null;

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Activity className="size-5 text-primary" /> Real API usage
        </CardTitle>
        <CardDescription>
          What this customer&rsquo;s requests cost at the provider, before the plan rate. Internal — never shown to the customer.
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {usedLabel && pct !== null ? (
          <div className="space-y-2">
            <div className="flex flex-wrap items-baseline justify-between gap-2 text-sm">
              <span className="font-medium tabular-nums">{usedLabel}</span>
              <span className={cn("tabular-nums text-muted-foreground", pct >= 100 && "text-destructive", pct >= 80 && pct < 100 && "text-warning")}>
                {pct}% of the real usage their credit buys · {planLabel}
              </span>
            </div>
            <Progress value={Math.min(100, pct)} className="h-2.5" />
          </div>
        ) : (
          <p className="text-sm text-muted-foreground">No credit yet, so there is no real-usage allowance to compare against.</p>
        )}

        {bonusAllowance || bonusRateLabel ? (
          <div className="space-y-2 rounded-lg border bg-muted/30 px-4 py-3">
            <div className="flex flex-wrap items-baseline justify-between gap-2 text-sm">
              <span className="font-medium tabular-nums">
                Bonus real usage: {formatMicroUsd(usage.bonusCostMicroUsd)}
                {bonusAllowance ? (
                  <> of {bonusAllowance.kind === "tokens" ? `${formatTokens(bonusAllowance.tokens)} tokens` : formatMicroUsd(bonusAllowance.microUsd)}</>
                ) : null}
              </span>
              {bonusPct !== null ? (
                <span className={cn("tabular-nums text-muted-foreground", bonusPct >= 100 && "text-destructive", bonusPct >= 80 && bonusPct < 100 && "text-warning")}>
                  {bonusPct}% of what the bonus buys
                </span>
              ) : null}
            </div>
            {bonusPct !== null ? <Progress value={Math.min(100, bonusPct)} className="h-2" /> : null}
            <p className="text-xs text-muted-foreground">
              {bonusRateLabel ?? "The bonus is billed at the same rate as the balance."} Only requests made after the balance ran out use the bonus.
            </p>
          </div>
        ) : null}

        <div className="grid grid-cols-2 gap-x-6 gap-y-5 sm:grid-cols-4">
          {stats.map((s) => (
            <div key={s.label} className="min-w-0">
              <p className="text-xs font-medium tracking-wide text-muted-foreground uppercase">{s.label}</p>
              <p className={cn("mt-1 font-semibold tabular-nums", s.tone)}>{s.value}</p>
              {s.hint ? <p className="text-xs text-muted-foreground">{s.hint}</p> : null}
            </div>
          ))}
        </div>

        <p className="text-xs text-muted-foreground">
          {usage.lastUsedAt ? (
            <>
              Last request <LocalTime date={usage.lastUsedAt} variant="datetime" />. Totals cover every usage row since the account was created.
            </>
          ) : (
            "No requests recorded yet."
          )}
        </p>
      </CardContent>
    </Card>
  );
}
