"use client";

import { useTransition } from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { BadgeCheck, Gift, Loader2, Star, XCircle } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ConfirmDialog } from "@/components/shared/confirm-dialog";
import { formatCents } from "@/lib/money";

import type { CustomerRow } from "@/lib/types";
import { verifyReviewBonusAction, revokeReviewBonusAction } from "@/app/admin/(dashboard)/customers/actions";
import { LocalTime } from "@/components/shared/local-time";

/**
 * Admin view of the review-gated bonus: see what the offer promised, whether
 * the customer claims to have reviewed, and keep or remove the bonus after
 * checking the store.
 */
export function ReviewBonusCard({ customer }: { customer: CustomerRow }) {
  const [pending, startTransition] = useTransition();
  const router = useRouter();

  if (customer.reviewBonusStatus === "NONE" || customer.pendingBonusCents <= 0) return null;

  const status = customer.reviewBonusStatus;

  const verify = () => {
    startTransition(async () => {
      const result = await verifyReviewBonusAction(customer.id);
      if (result.ok) {
        toast.success("Review confirmed — bonus kept");
        router.refresh();
      } else toast.error(result.error);
    });
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Gift className="size-5 text-success" /> Review Bonus
        </CardTitle>
        <CardDescription>
          {customer.offerTitle ? (
            <>
              Offer: <span className="text-foreground">{customer.offerTitle}</span>
            </>
          ) : (
            "Bonus gated behind a store review."
          )}
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="flex items-center justify-between rounded-lg border bg-muted/40 px-4 py-2.5 text-sm">
          <span className="text-muted-foreground">Bonus amount</span>
          <span className="font-semibold tabular-nums">{formatCents(customer.pendingBonusCents)}</span>
        </div>

        {status === "OFFERED" ? (
          <>
            <p className="text-sm text-muted-foreground">
              Waiting — the customer hasn&apos;t claimed the review bonus yet.
            </p>
            <ConfirmDialog
              trigger={
                <Button size="sm" variant="outline" className="text-destructive hover:text-destructive" disabled={pending}>
                  <XCircle /> No review — remove bonus
                </Button>
              }
              title="Remove the review bonus?"
              description={`${formatCents(customer.pendingBonusCents)} will be removed from ${customer.accessCode}'s account — they did not write a review.`}
              confirmLabel="Remove bonus"
              destructive
              onConfirm={async () => {
                const result = await revokeReviewBonusAction(customer.id);
                if (result.ok) {
                  toast.success("Bonus removed", { description: "The customer can see why on their dashboard." });
                  router.refresh();
                } else toast.error(result.error);
              }}
            />
          </>
        ) : null}

        {status === "CLAIMED" ? (
          <>
            <div className="flex items-start gap-2 rounded-lg border border-warning/30 bg-warning/10 px-4 py-3 text-sm">
              <Star className="mt-0.5 size-4 shrink-0 text-warning" />
              <p className="text-muted-foreground">
                <span className="font-medium text-warning">Says they wrote a review</span>
                {customer.reviewClaimedAt ? <> on <LocalTime date={customer.reviewClaimedAt} variant="datetime" /></> : ""}. The bonus is
                already credited — check the store, then keep or remove it.
              </p>
            </div>
            <div className="flex gap-2">
              <Button size="sm" onClick={verify} disabled={pending} className="bg-success text-white hover:bg-success/90">
                {pending ? <Loader2 className="animate-spin" /> : <BadgeCheck />}
                Review found — keep bonus
              </Button>
              <ConfirmDialog
                trigger={
                  <Button size="sm" variant="outline" className="text-destructive hover:text-destructive" disabled={pending}>
                    <XCircle /> No review — remove bonus
                  </Button>
                }
                title="Remove the review bonus?"
                description={`${formatCents(customer.pendingBonusCents)} will be deducted from ${customer.accessCode}'s bonus, and they'll see it was removed because no review was found.`}
                confirmLabel="Remove bonus"
                destructive
                onConfirm={async () => {
                  const result = await revokeReviewBonusAction(customer.id);
                  if (result.ok) {
                    toast.success("Bonus removed", { description: "The customer can see why on their dashboard." });
                    router.refresh();
                  } else toast.error(result.error);
                }}
              />
            </div>
          </>
        ) : null}

        {status === "VERIFIED" ? (
          <p className="flex items-center gap-2 text-sm text-success">
            <BadgeCheck className="size-4" /> Review verified — bonus kept.
          </p>
        ) : null}

        {status === "REVOKED" ? (
          <p className="flex items-center gap-2 text-sm text-destructive">
            <XCircle className="size-4" /> Bonus removed — no review was found.
          </p>
        ) : null}
      </CardContent>
    </Card>
  );
}
