"use client";

import { useTransition } from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { ArchiveRestore, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { ConfirmDialog } from "@/components/shared/confirm-dialog";

import { formatCents } from "@/lib/money";
import type { CustomerRow } from "@/lib/types";
import { permanentDeleteCustomerAction, restoreCustomerAction } from "@/app/admin/(dashboard)/customers/actions";
import { LocalTime } from "@/components/shared/local-time";

export function DeletedCustomers({ customers }: { customers: CustomerRow[] }) {
  const [pending, startTransition] = useTransition();
  const router = useRouter();

  if (customers.length === 0) return null;

  const restore = (customer: CustomerRow) => {
    startTransition(async () => {
      const result = await restoreCustomerAction(customer.id);
      if (result.ok) {
        toast.success("Customer restored", { description: customer.accessCode });
        router.refresh();
      } else toast.error(result.error);
    });
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle>Deleted customers</CardTitle>
        <CardDescription>
          Soft-deleted customers are kept with all their history. Restore them, or remove them permanently.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <div className="overflow-x-auto">
          <Table>
            <TableHeader>
              <TableRow className="hover:bg-transparent">
                <TableHead>Access Code</TableHead>
                <TableHead>Order</TableHead>
                <TableHead>Balance</TableHead>
                <TableHead>Deleted</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {customers.map((c) => (
                <TableRow key={c.id}>
                  <TableCell className="font-mono text-[13px] font-medium">{c.accessCode}</TableCell>
                  <TableCell className="font-mono text-[13px] text-muted-foreground">{c.orderNumber}</TableCell>
                  <TableCell className="tabular-nums">{formatCents(c.remainingBalanceCents)} left</TableCell>
                  <TableCell className="text-muted-foreground"><LocalTime date={c.deletedAt} variant="date" /></TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-1.5">
                      <Button variant="outline" size="sm" disabled={pending} onClick={() => restore(c)}>
                        <ArchiveRestore /> Restore
                      </Button>
                      <ConfirmDialog
                        trigger={
                          <Button variant="ghost" size="sm" className="text-destructive hover:text-destructive" disabled={pending}>
                            <Trash2 /> Delete forever
                          </Button>
                        }
                        title="Permanently delete customer?"
                        description={`${c.accessCode} and all of its history will be removed forever. This cannot be undone.`}
                        confirmLabel="Delete forever"
                        destructive
                        onConfirm={async () => {
                          const result = await permanentDeleteCustomerAction(c.id);
                          if (result.ok) {
                            toast.success("Customer permanently deleted");
                            router.refresh();
                          } else toast.error(result.error);
                        }}
                      />
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </div>
      </CardContent>
    </Card>
  );
}
