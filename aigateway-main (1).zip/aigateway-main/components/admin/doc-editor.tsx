"use client";

import { useMemo, useState, useTransition } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { toast } from "sonner";
import { BookOpen, Eye, FileCode2, History, Info, Loader2, Pencil, RotateCcw, Save } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Textarea } from "@/components/ui/textarea";
import { Markdown } from "@/components/shared/markdown";
import { ConfirmDialog } from "@/components/shared/confirm-dialog";
import { EmptyState } from "@/components/shared/empty-state";

import { DOC_CATEGORIES, DOC_CATEGORY_LABELS, DOC_OS_LABELS, type DocCategory, type DocOS } from "@/lib/constants";
import { updateDocAction, rollbackDocAction } from "@/app/admin/(dashboard)/documentation/actions";
import { cn } from "@/lib/utils";
import { LocalTime } from "@/components/shared/local-time";

export interface DocItem {
  id: string;
  slug: string;
  category: string;
  os: string;
  title: string;
  content: string;
  updatedAt: string;
}

export interface DocVersion {
  id: string;
  savedBy: string;
  createdAt: string;
  content: string;
}

interface DocEditorProps {
  docs: DocItem[];
  versions: Record<string, DocVersion[]>;
}

export function DocEditor({ docs, versions }: DocEditorProps) {
  const searchParams = useSearchParams();
  const router = useRouter();
  const initialSlug = searchParams.get("doc") ?? docs[0]?.slug;
  const [activeSlug, setActiveSlug] = useState(initialSlug);
  const active = docs.find((d) => d.slug === activeSlug) ?? docs[0];
  const [draft, setDraft] = useState(active?.content ?? "");
  const [pending, startTransition] = useTransition();

  // Reset the draft whenever a different document (or a freshly saved
  // version of it) becomes active — done during render, not in an effect.
  const activeKey = `${active?.id ?? ""}:${active?.content ?? ""}`;
  const [draftKey, setDraftKey] = useState(activeKey);
  if (draftKey !== activeKey) {
    setDraftKey(activeKey);
    setDraft(active?.content ?? "");
  }

  const dirty = active && draft !== active.content;

  const grouped = useMemo(() => {
    const map = new Map<string, DocItem[]>();
    for (const doc of docs) {
      const list = map.get(doc.category) ?? [];
      list.push(doc);
      map.set(doc.category, list);
    }
    // Canonical order from DOC_CATEGORIES, then anything else.
    const order: string[] = [...DOC_CATEGORIES];
    return new Map(
      [...map.entries()].sort(
        (a, b) =>
          (order.indexOf(a[0]) === -1 ? 99 : order.indexOf(a[0])) -
          (order.indexOf(b[0]) === -1 ? 99 : order.indexOf(b[0]))
      )
    );
  }, [docs]);

  const save = () => {
    if (!active || !dirty) return;
    startTransition(async () => {
      const result = await updateDocAction(active.id, draft);
      if (result.ok) {
        toast.success("Documentation saved", { description: `${active.title} · previous version kept in history` });
        router.refresh();
      } else toast.error(result.error);
    });
  };

  const rollback = async (versionId: string) => {
    const result = await rollbackDocAction(versionId);
    if (result.ok) {
      toast.success("Version restored");
      router.refresh();
    } else toast.error(result.error);
  };

  if (!active) {
    return (
      <EmptyState
        icon={BookOpen}
        title="No documentation yet"
        description="Run the database seed to load the setup guides, or check back after they are published."
      />
    );
  }
  const activeVersions = versions[active.id] ?? [];

  return (
    <div className="grid gap-6 lg:grid-cols-[260px_1fr]">
      {/* Guide list */}
      <div className="space-y-5">
        {Array.from(grouped.entries()).map(([category, items]) => (
          <div key={category}>
            <p className="mb-2 px-1 text-xs font-semibold tracking-wide text-muted-foreground uppercase">
              {DOC_CATEGORY_LABELS[category as DocCategory] ?? category}
            </p>
            <div className="space-y-1">
              {items.map((doc) => (
                <button
                  key={doc.slug}
                  type="button"
                  onClick={() => {
                    if (dirty && !confirm("Discard unsaved changes?")) return;
                    setActiveSlug(doc.slug);
                    router.replace(`/admin/documentation?doc=${doc.slug}`, { scroll: false });
                  }}
                  className={cn(
                    "flex w-full items-center justify-between rounded-lg px-3 py-2 text-left text-sm transition-colors",
                    doc.slug === active.slug
                      ? "bg-primary/12 font-medium text-foreground ring-1 ring-primary/25"
                      : "text-muted-foreground hover:bg-accent/60 hover:text-foreground"
                  )}
                >
                  <span className="flex items-center gap-2">
                    <FileCode2 className={cn("size-4", doc.slug === active.slug && "text-primary")} />
                    {DOC_OS_LABELS[doc.os as DocOS] ?? doc.os}
                  </span>
                </button>
              ))}
            </div>
          </div>
        ))}

        <div className="rounded-xl border border-warning/25 bg-warning/8 p-3.5 text-xs leading-relaxed text-muted-foreground">
          <p className="mb-1 flex items-center gap-1.5 font-medium text-warning">
            <Info className="size-3.5" /> Content rule
          </p>
          <code className="rounded bg-muted px-1 py-0.5 font-mono text-[11px]">{"{{BASE_URL}}"}</code> and{" "}
          <code className="rounded bg-muted px-1 py-0.5 font-mono text-[11px]">{"{{MODEL}}"}</code> are filled in for
          each customer;{" "}
          <code className="rounded bg-muted px-1 py-0.5 font-mono text-[11px]">YOUR_AEROLINK_API_KEY</code> stays as
          written so customers paste their own token. Once you save a guide here, deploys stop refreshing it from{" "}
          <code className="rounded bg-muted px-1 py-0.5 font-mono text-[11px]">prisma/docs</code>.
        </div>
      </div>

      {/* Editor */}
      <Card className="gap-0 overflow-hidden p-0">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b px-5 py-3.5">
          <div className="min-w-0">
            <h2 className="truncate text-sm font-semibold">{active.title}</h2>
            <p className="text-xs text-muted-foreground">Updated <LocalTime date={active.updatedAt} variant="datetime" /></p>
          </div>
          <div className="flex items-center gap-2">
            {dirty ? (
              <Badge variant="secondary" className="bg-warning/15 text-warning">
                Unsaved changes
              </Badge>
            ) : null}
            <Dialog>
              <DialogTrigger asChild>
                <Button variant="outline" size="sm">
                  <History /> History ({activeVersions.length})
                </Button>
              </DialogTrigger>
              <DialogContent className="sm:max-w-lg">
                <DialogHeader>
                  <DialogTitle>Version history</DialogTitle>
                  <DialogDescription>
                    Previous versions of “{active.title}”. Restoring keeps the current content as a new version.
                  </DialogDescription>
                </DialogHeader>
                {activeVersions.length === 0 ? (
                  <p className="py-6 text-center text-sm text-muted-foreground">No versions yet — saving creates one.</p>
                ) : (
                  <ScrollArea className="max-h-80 pr-3">
                    <ul className="space-y-2">
                      {activeVersions.map((v) => (
                        <li key={v.id} className="flex items-center justify-between gap-3 rounded-lg border px-3.5 py-2.5">
                          <div className="min-w-0">
                            <p className="text-sm font-medium"><LocalTime date={v.createdAt} variant="datetime" /></p>
                            <p className="text-xs text-muted-foreground">
                              Saved by {v.savedBy} · {v.content.length.toLocaleString()} chars
                            </p>
                          </div>
                          <ConfirmDialog
                            trigger={
                              <Button variant="outline" size="sm">
                                <RotateCcw /> Restore
                              </Button>
                            }
                            title="Restore this version?"
                            description="The current content will be preserved in history before restoring."
                            confirmLabel="Restore"
                            onConfirm={() => rollback(v.id)}
                          />
                        </li>
                      ))}
                    </ul>
                  </ScrollArea>
                )}
              </DialogContent>
            </Dialog>
            <Button size="sm" onClick={save} disabled={!dirty || pending}>
              {pending ? <Loader2 className="animate-spin" /> : <Save />}
              Save
            </Button>
          </div>
        </div>

        <Tabs defaultValue="write" className="gap-0">
          <div className="border-b px-5 py-2">
            <TabsList className="h-8">
              <TabsTrigger value="write" className="gap-1.5 text-xs">
                <Pencil className="size-3.5" /> Write
              </TabsTrigger>
              <TabsTrigger value="preview" className="gap-1.5 text-xs">
                <Eye className="size-3.5" /> Preview
              </TabsTrigger>
            </TabsList>
          </div>
          <TabsContent value="write" className="m-0">
            <Textarea
              value={draft}
              onChange={(e) => setDraft(e.target.value)}
              spellCheck={false}
              className="min-h-[560px] resize-y rounded-none border-0 bg-transparent px-5 py-4 font-mono text-[13px] leading-relaxed shadow-none focus-visible:ring-0"
              aria-label={`Markdown source for ${active.title}`}
            />
          </TabsContent>
          <TabsContent value="preview" className="m-0">
            <ScrollArea className="h-[560px]">
              <div className="px-6 py-5">
                <Markdown content={draft} />
              </div>
            </ScrollArea>
          </TabsContent>
        </Tabs>
      </Card>
    </div>
  );
}
