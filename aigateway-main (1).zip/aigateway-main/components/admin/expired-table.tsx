"use client";

import { useMemo, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { Hourglass, Search, ThumbsDown, ThumbsUp, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { CopyButton } from "@/components/shared/copy-button";
import { EmptyState } from "@/components/shared/empty-state";
import { formatCents } from "@/lib/money";

import type { CustomerRow } from "@/lib/types";
import { setPurchasedAgainAction } from "@/app/admin/(dashboard)/customers/actions";
import { cn } from "@/lib/utils";
import { LocalTime } from "@/components/shared/local-time";
import { maskApiKey } from "@/lib/format";

interface ExpiredTableProps {
  customers: CustomerRow[];
  /** Controlled repurchase filter (ALL | YES | NO | UNKNOWN). */
  repurchaseFilter: string;
  onRepurchaseFilterChange: (value: string) => void;
}

export function ExpiredTable({ customers, repurchaseFilter, onRepurchaseFilterChange }: ExpiredTableProps) {
  const [query, setQuery] = useState("");
  const setRepurchaseFilter = onRepurchaseFilterChange;
  const [pending, startTransition] = useTransition();
  const router = useRouter();

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    let list = customers;
    if (repurchaseFilter !== "ALL") list = list.filter((c) => c.purchasedAgain === repurchaseFilter);
    if (q) {
      list = list.filter((c) => [c.accessCode, c.orderNumber, c.apiKey].join(" ").toLowerCase().includes(q));
    }
    return list;
  }, [customers, query, repurchaseFilter]);

  const mark = (customer: CustomerRow, value: "YES" | "NO") => {
    startTransition(async () => {
      const result = await setPurchasedAgainAction(customer.id, value);
      if (result.ok) {
        toast.success(
          value === "YES"
            ? `${customer.accessCode} marked as purchased again`
            : `${customer.accessCode} marked as did not purchase`
        );
        router.refresh();
      } else toast.error(result.error);
    });
  };

  return (
    <div className="space-y-4">
      <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
        <div className="relative flex-1 sm:max-w-md">
          <Search className="absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            placeholder="Search access code, order or API key…"
            className="pl-9"
            aria-label="Search expired customers"
          />
          {query ? (
            <button
              type="button"
              onClick={() => setQuery("")}
              className="absolute top-1/2 right-3 -translate-y-1/2 text-muted-foreground hover:text-foreground"
              aria-label="Clear search"
            >
              <X className="size-4" />
            </button>
          ) : null}
        </div>
        <Select value={repurchaseFilter} onValueChange={setRepurchaseFilter}>
          <SelectTrigger className="w-[190px]" aria-label="Filter by repurchase">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="ALL">All repurchase states</SelectItem>
            <SelectItem value="YES">Purchased again</SelectItem>
            <SelectItem value="NO">Did not purchase</SelectItem>
            <SelectItem value="UNKNOWN">Unknown</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <Card className="overflow-hidden p-0">
        {filtered.length === 0 ? (
          <EmptyState
            icon={Hourglass}
            title={customers.length === 0 ? "No expired balances" : "No matching customers"}
            description={
              customers.length === 0
                ? "Customers whose balance is fully consumed appear here automatically — nothing is ever deleted."
                : "Try adjusting your search or filter."
            }
            className="border-0"
          />
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="hover:bg-transparent">
                  <TableHead className="pl-4">Access Code</TableHead>
                  <TableHead>Order</TableHead>
                  <TableHead>API Key</TableHead>
                  <TableHead>Total Balance</TableHead>
                  <TableHead>Used</TableHead>
                  <TableHead>Bonus</TableHead>
                  <TableHead>Profit</TableHead>
                  <TableHead>Finished</TableHead>
                  <TableHead className="pr-4">Purchased Again?</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filtered.map((c) => (
                  <TableRow
                    key={c.id}
                    className="group cursor-pointer"
                    onClick={() => router.push(`/admin/customers/${c.id}`)}
                  >
                    <TableCell className="pl-4">
                      <div className="flex items-center gap-1">
                        <span className="font-mono text-[13px] font-medium">{c.accessCode}</span>
                        <span onClick={(e) => e.stopPropagation()}>
                          <CopyButton value={c.accessCode} label="Access code" size="icon-xs" className="opacity-0 transition-opacity group-hover:opacity-100" />
                        </span>
                      </div>
                    </TableCell>
                    <TableCell className="font-mono text-[13px] text-muted-foreground">{c.orderNumber}</TableCell>
                    <TableCell className="font-mono text-xs text-muted-foreground">{c.apiKeyEditable ? maskApiKey(c.apiKey) : c.apiKey || "—"}</TableCell>
                    <TableCell className="tabular-nums">{formatCents(c.initialBalanceCents)}</TableCell>
                    <TableCell className="tabular-nums">{formatCents(c.usedBalanceCents)}</TableCell>
                    <TableCell className="tabular-nums">{formatCents(c.initialBonusCents)}</TableCell>
                    <TableCell className="text-success tabular-nums">{formatCents(c.profitCents)}</TableCell>
                    <TableCell className="whitespace-nowrap text-muted-foreground"><LocalTime date={c.finishedAt} variant="date" /></TableCell>
                    <TableCell className="pr-4" onClick={(e) => e.stopPropagation()}>
                      <div className="flex items-center gap-1.5">
                        <Button
                          size="xs"
                          variant={c.purchasedAgain === "YES" ? "default" : "outline"}
                          className={cn(
                            c.purchasedAgain === "YES" && "bg-success text-white hover:bg-success/90"
                          )}
                          disabled={pending}
                          onClick={() => mark(c, "YES")}
                          aria-label={`Mark ${c.accessCode} as purchased again`}
                        >
                          <ThumbsUp /> Yes
                        </Button>
                        <Button
                          size="xs"
                          variant={c.purchasedAgain === "NO" ? "destructive" : "outline"}
                          disabled={pending}
                          onClick={() => mark(c, "NO")}
                          aria-label={`Mark ${c.accessCode} as did not purchase`}
                        >
                          <ThumbsDown /> No
                        </Button>
                        {c.purchasedAgainAt ? (
                          <span className="ml-1 hidden text-xs whitespace-nowrap text-muted-foreground xl:inline">
                            <LocalTime date={c.purchasedAgainAt} variant="date" />
                          </span>
                        ) : null}
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </Card>
    </div>
  );
}
