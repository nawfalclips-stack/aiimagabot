"use client";

import { useState } from "react";
import { Hourglass, RefreshCcw, ThumbsDown, ThumbsUp, type LucideIcon } from "lucide-react";
import { ExpiredTable } from "@/components/admin/expired-table";
import { AnimatedCounter } from "@/components/shared/animated-counter";
import type { CustomerRow } from "@/lib/types";
import { cn } from "@/lib/utils";

interface FilterCard {
  key: string; // ALL | YES | NO | UNKNOWN
  title: string;
  icon: LucideIcon;
  tone: string;
  iconTone: string;
}

const CARDS: FilterCard[] = [
  { key: "ALL", title: "Expired Customers", icon: Hourglass, tone: "hover:border-destructive/40", iconTone: "bg-destructive/12 text-destructive" },
  { key: "YES", title: "Purchased Again", icon: ThumbsUp, tone: "hover:border-success/40", iconTone: "bg-success/12 text-success" },
  { key: "NO", title: "Did Not Purchase", icon: ThumbsDown, tone: "hover:border-warning/40", iconTone: "bg-warning/12 text-warning" },
  { key: "UNKNOWN", title: "Awaiting Decision", icon: RefreshCcw, tone: "hover:border-primary/40", iconTone: "bg-muted text-muted-foreground" },
];

/** Stat cards double as filters — click one to filter the table below. */
export function ExpiredView({ customers }: { customers: CustomerRow[] }) {
  const [filter, setFilter] = useState("ALL");

  const counts: Record<string, number> = {
    ALL: customers.length,
    YES: customers.filter((c) => c.purchasedAgain === "YES").length,
    NO: customers.filter((c) => c.purchasedAgain === "NO").length,
    UNKNOWN: customers.filter((c) => c.purchasedAgain === "UNKNOWN").length,
  };

  return (
    <div className="space-y-6">
      <section aria-label="Repurchase filters" className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        {CARDS.map((card) => {
          const active = filter === card.key;
          return (
            <button
              key={card.key}
              type="button"
              onClick={() => setFilter(card.key)}
              aria-pressed={active}
              className={cn(
                "group rounded-xl border bg-card p-5 text-left transition-all duration-200",
                card.tone,
                active && "border-primary/50 ring-2 ring-primary/25"
              )}
            >
              <div className="flex items-start justify-between">
                <p className="text-sm font-medium text-muted-foreground">{card.title}</p>
                <span
                  className={cn(
                    "flex size-9 shrink-0 items-center justify-center rounded-lg transition-transform duration-200 group-hover:scale-110",
                    card.iconTone
                  )}
                >
                  <card.icon className="size-4.5" />
                </span>
              </div>
              <AnimatedCounter value={counts[card.key]} className="mt-2 block text-2xl font-semibold tracking-tight tabular-nums" />
              <p className="mt-1 text-xs text-muted-foreground">{active ? "Showing below" : "Click to filter"}</p>
            </button>
          );
        })}
      </section>

      <ExpiredTable customers={customers} repurchaseFilter={filter} onRepurchaseFilterChange={setFilter} />
    </div>
  );
}
