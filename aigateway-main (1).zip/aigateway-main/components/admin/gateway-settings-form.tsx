"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { Loader2, Save } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { saveGatewaySettingsAction, type GatewaySettingsInput } from "@/app/admin/(dashboard)/settings/actions";

export interface GatewaySettingsValues {
  holdMarginPct: number;
  minHoldUsd: number;
  defaultMaxTokens: number;
  defaultRpm: number;
  defaultMaxConcurrent: number;
  storeMaxConcurrent: number;
  partialChargePolicy: "CHARGE_DELIVERED" | "WAIVE_ON_UPSTREAM_ERROR";
  voucherAutoApprove: boolean;
  voucherMaxRedemptionsPerIpDay: number;
  voucherExpiryMonths: number;
  voucherLowStockCount: number;
  voucherLowStockDays: number;
  voucherTurnstileAfterFailures: number;
}

function Field({ id, label, hint, children }: { id: string; label: string; hint?: string; children: React.ReactNode }) {
  return (
    <div className="space-y-1.5">
      <Label htmlFor={id}>{label}</Label>
      {children}
      {hint && <p className="text-xs text-muted-foreground">{hint}</p>}
    </div>
  );
}

export function GatewaySettingsForm({ initial }: { initial: GatewaySettingsValues }) {
  const router = useRouter();
  const [pending, startTransition] = useTransition();
  const [form, setForm] = useState(initial);
  const set = <K extends keyof typeof form>(k: K) => (v: (typeof form)[K]) => setForm((f) => ({ ...f, [k]: v }));
  const num = (k: keyof GatewaySettingsValues) => (e: React.ChangeEvent<HTMLInputElement>) => setForm((f) => ({ ...f, [k]: Number(e.target.value) }));

  const save = (e: React.FormEvent) => {
    e.preventDefault();
    startTransition(async () => {
      const r = await saveGatewaySettingsAction(form as GatewaySettingsInput);
      if (r.ok) {
        toast.success("Gateway & voucher settings saved");
        router.refresh();
      } else toast.error(r.error);
    });
  };

  return (
    <form onSubmit={save} className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>API gateway</CardTitle>
          <CardDescription>Holds, default limits and what a cut-off answer costs. Plans can override the limits per customer.</CardDescription>
        </CardHeader>
        <CardContent className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          <Field id="holdMarginPct" label="Hold safety margin (%)" hint="Added on top of the worst-case estimate reserved before each request.">
            <Input id="holdMarginPct" type="number" min={0} max={100} value={form.holdMarginPct} onChange={num("holdMarginPct")} />
          </Field>
          <Field id="minHoldUsd" label="Minimum hold (USD)" hint="Smallest amount reserved per request.">
            <Input id="minHoldUsd" type="number" min={0} step="0.001" value={form.minHoldUsd} onChange={num("minHoldUsd")} />
          </Field>
          <Field id="defaultMaxTokens" label="Default max_tokens" hint="Used for the estimate when the client sends none and the model has no cap.">
            <Input id="defaultMaxTokens" type="number" min={1} value={form.defaultMaxTokens} onChange={num("defaultMaxTokens")} />
          </Field>
          <Field id="defaultRpm" label="Default requests / minute" hint="For customers whose plan sets no RPM.">
            <Input id="defaultRpm" type="number" min={1} value={form.defaultRpm} onChange={num("defaultRpm")} />
          </Field>
          <Field id="defaultMaxConcurrent" label="Default concurrent requests" hint="For customers whose plan sets no concurrency.">
            <Input id="defaultMaxConcurrent" type="number" min={1} value={form.defaultMaxConcurrent} onChange={num("defaultMaxConcurrent")} />
          </Field>
          <Field id="storeMaxConcurrent" label="Store-wide concurrency ceiling" hint="Across all customers of this store.">
            <Input id="storeMaxConcurrent" type="number" min={1} value={form.storeMaxConcurrent} onChange={num("storeMaxConcurrent")} />
          </Field>
          <Field id="partialChargePolicy" label="Cut-off streams" hint="Client disconnects are always charged for what was delivered.">
            <Select value={form.partialChargePolicy} onValueChange={(v) => set("partialChargePolicy")(v as GatewaySettingsValues["partialChargePolicy"])}>
              <SelectTrigger id="partialChargePolicy" className="w-full">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="WAIVE_ON_UPSTREAM_ERROR">Waive when the provider fails or times out</SelectItem>
                <SelectItem value="CHARGE_DELIVERED">Charge what was delivered, whatever the cause</SelectItem>
              </SelectContent>
            </Select>
          </Field>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Vouchers (GamsGo automatic delivery)</CardTitle>
          <CardDescription>How redeemed codes are credited and when you are warned about stock.</CardDescription>
        </CardHeader>
        <CardContent className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
          <div className="flex items-center justify-between gap-3 rounded-lg border px-3 py-2.5 sm:col-span-2 lg:col-span-3">
            <div>
              <Label htmlFor="voucherAutoApprove">Auto-approve redemptions</Label>
              <p className="text-xs text-muted-foreground">
                On: a valid code credits the buyer instantly. Off: every redemption waits in Activations / Recharges for your approval (the code is still consumed).
              </p>
            </div>
            <Switch id="voucherAutoApprove" checked={form.voucherAutoApprove} onCheckedChange={set("voucherAutoApprove")} />
          </div>
          <Field id="voucherMaxRedemptionsPerIpDay" label="Redemptions per IP per day" hint="Above this, a redemption goes to review even with auto-approve on. 0 = review everything.">
            <Input id="voucherMaxRedemptionsPerIpDay" type="number" min={0} value={form.voucherMaxRedemptionsPerIpDay} onChange={num("voucherMaxRedemptionsPerIpDay")} />
          </Field>
          <Field id="voucherExpiryMonths" label="Default code expiry (months)" hint="Pre-filled when generating a batch; editable per batch. 0 = never.">
            <Input id="voucherExpiryMonths" type="number" min={0} value={form.voucherExpiryMonths} onChange={num("voucherExpiryMonths")} />
          </Field>
          <Field id="voucherTurnstileAfterFailures" label="Captcha after N failed attempts / hour" hint="Needs TURNSTILE_* keys. 0 = never.">
            <Input id="voucherTurnstileAfterFailures" type="number" min={0} value={form.voucherTurnstileAfterFailures} onChange={num("voucherTurnstileAfterFailures")} />
          </Field>
          <Field id="voucherLowStockCount" label="Low stock below (codes)" hint="Uploaded, unredeemed codes per pack.">
            <Input id="voucherLowStockCount" type="number" min={0} value={form.voucherLowStockCount} onChange={num("voucherLowStockCount")} />
          </Field>
          <Field id="voucherLowStockDays" label="Low stock below (days left)" hint="At the last-7-day redemption rate.">
            <Input id="voucherLowStockDays" type="number" min={0} value={form.voucherLowStockDays} onChange={num("voucherLowStockDays")} />
          </Field>
        </CardContent>
      </Card>

      <div className="flex justify-end">
        <Button type="submit" disabled={pending}>
          {pending ? <Loader2 className="animate-spin" /> : <Save />}
          Save gateway & voucher settings
        </Button>
      </div>
    </form>
  );
}
