"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { Boxes, ChevronDown, ChevronRight, EyeOff, Link2, Loader2, Pencil, Plus, Trash2, TriangleAlert } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { ConfirmDialog } from "@/components/shared/confirm-dialog";
import { EmptyState } from "@/components/shared/empty-state";
import { cn } from "@/lib/utils";
import { PriceSyncButton } from "@/components/admin/gateway/price-sync-dialog";
import { aliasWarnings, publicModelId, publicModelName } from "@/lib/model-alias";
import {
  deleteMappingAction,
  deleteModelAction,
  saveMappingAction,
  saveModelAction,
  setModelEnabledAction,
  type MappingInput,
  type ModelInput,
} from "@/app/admin/(dashboard)/models/actions";

export interface MappingRow {
  id: string;
  providerId: string;
  providerName: string;
  providerSlug: string;
  providerEnabled: boolean;
  providerHealth: string;
  upstreamModelId: string;
  priority: number;
  enabled: boolean;
}

export interface ModelRow {
  id: string;
  slug: string;
  displayName: string;
  /** Public alias ("" = none). */
  aliasSlug: string;
  aliasName: string;
  /** Why the alias would reveal the real model (empty = fine). */
  aliasWarnings: string[];
  enabled: boolean;
  inputPriceUsd: number;
  outputPriceUsd: number;
  contextWindow: number | null;
  maxOutputTokens: number | null;
  enabledStoreIds: string[];
  mappings: MappingRow[];
}

export interface ProviderOption {
  id: string;
  name: string;
  slug: string;
  enabled: boolean;
}

const usd = (n: number) => `$${n.toFixed(n < 1 ? 3 : 2)}`;

export function ModelsView({
  models,
  providers,
  stores,
}: {
  models: ModelRow[];
  providers: ProviderOption[];
  stores: Array<{ id: string; name: string }>;
}) {
  const router = useRouter();
  const [editing, setEditing] = useState<ModelRow | null | "new">(null);
  const [mapping, setMapping] = useState<{ model: ModelRow; row: MappingRow | null } | null>(null);
  const [expanded, setExpanded] = useState<Set<string>>(new Set());
  const [pending, startTransition] = useTransition();

  const toggleExpanded = (id: string) =>
    setExpanded((s) => {
      const n = new Set(s);
      if (n.has(id)) n.delete(id);
      else n.add(id);
      return n;
    });

  const setEnabled = (m: ModelRow, enabled: boolean) =>
    startTransition(async () => {
      const r = await setModelEnabledAction(m.id, enabled);
      if (!r.ok) toast.error(r.error);
      router.refresh();
    });

  return (
    <div className="space-y-4">
      <div className="flex justify-end gap-2">
        <PriceSyncButton />
        <Button onClick={() => setEditing("new")} disabled={providers.length === 0} title={providers.length === 0 ? "Add a provider first" : undefined}>
          <Plus /> Add model
        </Button>
      </div>

      <Card className="overflow-hidden p-0">
        {models.length === 0 ? (
          <EmptyState
            icon={Boxes}
            title="No models in the catalog"
            description="Import models from a provider (Providers → ⬇) or add one by hand."
            className="border-0"
          />
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="hover:bg-transparent">
                  <TableHead className="w-8" />
                  <TableHead>Model</TableHead>
                  <TableHead className="text-right" title="Saved price — also shown to customers as-is on API Access">Price / 1M</TableHead>
                  <TableHead>Stores</TableHead>
                  <TableHead>Providers</TableHead>
                  <TableHead>Enabled</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {models.map((m) => {
                  const open = expanded.has(m.id);
                  const live = m.mappings.filter((x) => x.enabled && x.providerEnabled).length;
                  return (
                    <ModelRows
                      key={m.id}
                      model={m}
                      open={open}
                      live={live}
                      stores={stores}
                      pending={pending}
                      onToggleOpen={() => toggleExpanded(m.id)}
                      onEnabled={(v) => setEnabled(m, v)}
                      onEdit={() => setEditing(m)}
                      onAddMapping={() => setMapping({ model: m, row: null })}
                      onEditMapping={(row) => setMapping({ model: m, row })}
                      onDeleted={() => router.refresh()}
                    />
                  );
                })}
              </TableBody>
            </Table>
          </div>
        )}
      </Card>

      <ModelDialog
        key={editing === "new" ? "new" : (editing?.id ?? "closed")}
        model={editing === "new" ? null : editing}
        open={editing !== null}
        stores={stores}
        onClose={() => setEditing(null)}
        onSaved={() => {
          setEditing(null);
          router.refresh();
        }}
      />

      <MappingDialog
        key={mapping ? `${mapping.model.id}:${mapping.row?.id ?? "new"}` : "closed"}
        target={mapping}
        providers={providers}
        onClose={() => setMapping(null)}
        onSaved={() => {
          setMapping(null);
          router.refresh();
        }}
      />
    </div>
  );
}

function ModelRows({
  model: m,
  open,
  live,
  stores,
  pending,
  onToggleOpen,
  onEnabled,
  onEdit,
  onAddMapping,
  onEditMapping,
  onDeleted,
}: {
  model: ModelRow;
  open: boolean;
  live: number;
  stores: Array<{ id: string; name: string }>;
  pending: boolean;
  onToggleOpen: () => void;
  onEnabled: (v: boolean) => void;
  onEdit: () => void;
  onAddMapping: () => void;
  onEditMapping: (row: MappingRow) => void;
  onDeleted: () => void;
}) {
  const storeLabel =
    m.enabledStoreIds.length === 0 ? "All" : stores.filter((s) => m.enabledStoreIds.includes(s.id)).map((s) => s.name).join(", ") || "None";

  return (
    <>
      <TableRow className={cn(!m.enabled && "opacity-60")}>
        <TableCell className="pr-0">
          <Button variant="ghost" size="icon-xs" onClick={onToggleOpen} aria-label={open ? "Collapse" : "Expand"}>
            {open ? <ChevronDown /> : <ChevronRight />}
          </Button>
        </TableCell>
        <TableCell>
          <div className="font-medium">{m.displayName}</div>
          <div className="font-mono text-xs text-muted-foreground">{m.slug}</div>
          <div className="mt-1 flex items-center gap-1 text-xs" title="What customers see">
            <EyeOff className="size-3 text-muted-foreground" />
            <span className="text-muted-foreground">Customers see</span>
            <span className="font-medium">{publicModelName(m)}</span>
            <span className="font-mono text-muted-foreground">({publicModelId(m)})</span>
          </div>
          {m.aliasWarnings.length > 0 ? (
            <div className="mt-0.5 flex items-start gap-1 text-xs text-warning">
              <TriangleAlert className="mt-px size-3 shrink-0" />
              <span>{m.aliasWarnings.join(" ")}</span>
            </div>
          ) : null}
        </TableCell>
        <TableCell className="text-right text-xs tabular-nums">
          <div>in {usd(m.inputPriceUsd)}</div>
          <div className="text-muted-foreground">out {usd(m.outputPriceUsd)}</div>
        </TableCell>
        <TableCell className="text-xs">{storeLabel}</TableCell>
        <TableCell className="text-xs">
          <span className={cn("font-medium", live === 0 && "text-destructive")}>{live} live</span>
          <span className="text-muted-foreground"> / {m.mappings.length}</span>
        </TableCell>
        <TableCell>
          <Switch checked={m.enabled} disabled={pending} onCheckedChange={onEnabled} aria-label={`Enable ${m.slug}`} />
        </TableCell>
        <TableCell>
          <div className="flex justify-end gap-1">
            <Button variant="ghost" size="icon-sm" onClick={onAddMapping} aria-label="Add provider mapping" title="Add provider mapping">
              <Link2 />
            </Button>
            <Button variant="ghost" size="icon-sm" onClick={onEdit} aria-label="Edit" title="Edit">
              <Pencil />
            </Button>
            <ConfirmDialog
              trigger={
                <Button variant="ghost" size="icon-sm" aria-label="Delete" title="Delete" className="text-destructive hover:text-destructive">
                  <Trash2 />
                </Button>
              }
              title={`Remove ${m.slug}?`}
              description="Customers using this model id will start receiving 'model not found' errors."
              confirmLabel="Remove model"
              destructive
              onConfirm={async () => {
                const r = await deleteModelAction(m.id);
                if (r.ok) {
                  toast.success("Model removed");
                  onDeleted();
                } else toast.error(r.error);
              }}
            />
          </div>
        </TableCell>
      </TableRow>

      {open ? (
        <TableRow className="bg-muted/30 hover:bg-muted/30">
          <TableCell />
          <TableCell colSpan={7} className="py-3">
            {m.mappings.length === 0 ? (
              <p className="text-sm text-muted-foreground">
                No provider serves this model yet.{" "}
                <Button variant="link" size="sm" className="h-auto p-0" onClick={onAddMapping}>Add a mapping</Button>
              </p>
            ) : (
              <div className="space-y-1.5">
                {m.mappings.map((x) => (
                  <div key={x.id} className={cn("flex flex-wrap items-center gap-x-4 gap-y-1 text-sm", (!x.enabled || !x.providerEnabled) && "opacity-60")}>
                    <span className="w-6 text-right font-mono text-xs text-muted-foreground">#{x.priority}</span>
                    <span className="font-medium">{x.providerName}</span>
                    <span
                      className={cn(
                        "size-2 rounded-full",
                        x.providerHealth === "UP" ? "bg-success" : x.providerHealth === "DOWN" ? "bg-destructive" : "bg-muted-foreground/50"
                      )}
                      title={x.providerHealth}
                    />
                    <span className="font-mono text-xs text-muted-foreground">{x.upstreamModelId}</span>
                    {!x.providerEnabled ? <span className="text-xs text-warning">provider disabled</span> : null}
                    {!x.enabled ? <span className="text-xs text-muted-foreground">mapping off</span> : null}
                    <span className="ml-auto flex gap-1">
                      <Button variant="ghost" size="icon-xs" onClick={() => onEditMapping(x)} aria-label="Edit mapping"><Pencil /></Button>
                      <ConfirmDialog
                        trigger={<Button variant="ghost" size="icon-xs" aria-label="Remove mapping" className="text-destructive hover:text-destructive"><Trash2 /></Button>}
                        title="Remove this provider from the model?"
                        description={`${x.providerName} will no longer serve ${m.slug}.`}
                        confirmLabel="Remove"
                        destructive
                        onConfirm={async () => {
                          const r = await deleteMappingAction(x.id);
                          if (r.ok) onDeleted();
                          else toast.error(r.error);
                        }}
                      />
                    </span>
                  </div>
                ))}
              </div>
            )}
          </TableCell>
        </TableRow>
      ) : null}
    </>
  );
}

// ─── Model add/edit dialog ───────────────────────────────────────────────────

function ModelDialog({
  model,
  open,
  stores,
  onClose,
  onSaved,
}: {
  model: ModelRow | null;
  open: boolean;
  stores: Array<{ id: string; name: string }>;
  onClose: () => void;
  onSaved: () => void;
}) {
  const [form, setForm] = useState<ModelInput>({
    slug: model?.slug ?? "",
    displayName: model?.displayName ?? "",
    aliasSlug: model?.aliasSlug ?? "",
    aliasName: model?.aliasName ?? "",
    enabled: model?.enabled ?? true,
    inputPriceUsd: model?.inputPriceUsd ?? 0,
    outputPriceUsd: model?.outputPriceUsd ?? 0,
    contextWindow: model?.contextWindow ?? null,
    maxOutputTokens: model?.maxOutputTokens ?? null,
    enabledStoreIds: (model?.enabledStoreIds ?? []) as ModelInput["enabledStoreIds"],
  });
  const [pending, startTransition] = useTransition();
  const set = <K extends keyof ModelInput>(k: K, v: ModelInput[K]) => setForm((f) => ({ ...f, [k]: v }));

  const submit = () =>
    startTransition(async () => {
      const r = await saveModelAction(model?.id ?? null, form);
      if (r.ok) {
        toast.success(model ? "Model updated" : "Model added");
        onSaved();
      } else toast.error(r.error);
    });

  const inUsd = Number(form.inputPriceUsd) || 0;
  const outUsd = Number(form.outputPriceUsd) || 0;
  const storeIds = form.enabledStoreIds ?? [];

  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>{model ? `Edit ${model.slug}` : "Add model"}</DialogTitle>
          <DialogDescription>
            Slug and display name are internal. Customers only see the <strong>public alias</strong> — in the portal, usage history,
            /v1/models, API responses and notifications. The provider&apos;s model id never reaches them. The internal slug keeps working
            on requests, so adding an alias does not break existing tool configs.
          </DialogDescription>
        </DialogHeader>

        <div className="grid gap-4 sm:grid-cols-2">
          <div className="space-y-1.5">
            <Label htmlFor="model-name">Display name (internal)</Label>
            <Input id="model-name" value={form.displayName} onChange={(e) => set("displayName", e.target.value)} placeholder="DeepSeek V3" />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="model-slug">Slug (internal id)</Label>
            <Input id="model-slug" value={form.slug} onChange={(e) => set("slug", e.target.value)} placeholder="deepseek-v3" className="font-mono" />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="model-alias-name">Public alias name</Label>
            <Input id="model-alias-name" value={form.aliasName ?? ""} onChange={(e) => set("aliasName", e.target.value)} placeholder="Aero Pro" />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="model-alias-slug">Public model id</Label>
            <Input id="model-alias-slug" value={form.aliasSlug ?? ""} onChange={(e) => set("aliasSlug", e.target.value)} placeholder="aero-pro" className="font-mono" />
          </div>
          {(() => {
            const warnings = aliasWarnings(
              { slug: form.slug, displayName: form.displayName, aliasSlug: form.aliasSlug, aliasName: form.aliasName },
              model?.mappings.map((x) => x.upstreamModelId) ?? []
            );
            return warnings.length > 0 ? (
              <p className="flex items-start gap-1.5 text-xs text-warning sm:col-span-2">
                <TriangleAlert className="mt-px size-3.5 shrink-0" /> {warnings.join(" ")}
              </p>
            ) : (
              <p className="text-xs text-muted-foreground sm:col-span-2">
                Customers will see <strong>{publicModelName({ slug: form.slug, displayName: form.displayName, aliasSlug: form.aliasSlug, aliasName: form.aliasName })}</strong> (
                <code>{publicModelId({ slug: form.slug, displayName: form.displayName, aliasSlug: form.aliasSlug })}</code>).
              </p>
            );
          })()}
          <div className="space-y-1.5">
            <Label htmlFor="model-in">Input cost, $ per 1M tokens</Label>
            <Input id="model-in" type="number" min={0} step="0.001" value={Number(form.inputPriceUsd ?? 0)} onChange={(e) => set("inputPriceUsd", Number(e.target.value))} />
            <p className="text-xs text-muted-foreground">Shown to customers as {usd(inUsd)}</p>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="model-out">Output cost, $ per 1M tokens</Label>
            <Input id="model-out" type="number" min={0} step="0.001" value={Number(form.outputPriceUsd ?? 0)} onChange={(e) => set("outputPriceUsd", Number(e.target.value))} />
            <p className="text-xs text-muted-foreground">Shown to customers as {usd(outUsd)}</p>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="model-ctx">Context window (tokens)</Label>
            <Input id="model-ctx" type="number" min={0} value={form.contextWindow == null ? "" : Number(form.contextWindow)} onChange={(e) => set("contextWindow", e.target.value ? Number(e.target.value) : null)} placeholder="optional" />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="model-maxout">Max output tokens</Label>
            <Input id="model-maxout" type="number" min={0} value={form.maxOutputTokens == null ? "" : Number(form.maxOutputTokens)} onChange={(e) => set("maxOutputTokens", e.target.value ? Number(e.target.value) : null)} placeholder="optional cap" />
          </div>
          <div className="space-y-2 sm:col-span-2">
            <Label>Available in stores</Label>
            <div className="flex flex-wrap gap-4">
              {stores.map((s) => {
                const checked = storeIds.length === 0 || storeIds.includes(s.id as never);
                return (
                  <label key={s.id} className="flex items-center gap-2 text-sm">
                    <Checkbox
                      checked={checked}
                      onCheckedChange={(v) => {
                        // Empty list means "all"; materialise it before editing.
                        const current = storeIds.length === 0 ? stores.map((x) => x.id) : [...storeIds];
                        const next = v ? [...new Set([...current, s.id])] : current.filter((x) => x !== s.id);
                        set("enabledStoreIds", (next.length === stores.length ? [] : next) as ModelInput["enabledStoreIds"]);
                      }}
                    />
                    {s.name}
                  </label>
                );
              })}
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Switch id="model-enabled" checked={!!form.enabled} onCheckedChange={(v) => set("enabled", v)} />
            <Label htmlFor="model-enabled">Enabled</Label>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={pending}>Cancel</Button>
          <Button onClick={submit} disabled={pending}>
            {pending ? <Loader2 className="animate-spin" /> : null}
            {model ? "Save changes" : "Add model"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ─── Provider mapping dialog ─────────────────────────────────────────────────

function MappingDialog({
  target,
  providers,
  onClose,
  onSaved,
}: {
  target: { model: ModelRow; row: MappingRow | null } | null;
  providers: ProviderOption[];
  onClose: () => void;
  onSaved: () => void;
}) {
  const row = target?.row ?? null;
  const [form, setForm] = useState<MappingInput>({
    providerId: row?.providerId ?? providers[0]?.id ?? "",
    upstreamModelId: row?.upstreamModelId ?? "",
    priority: row?.priority ?? (target ? target.model.mappings.length + 1 : 1),
    enabled: row?.enabled ?? true,
  });
  const [pending, startTransition] = useTransition();
  const set = <K extends keyof MappingInput>(k: K, v: MappingInput[K]) => setForm((f) => ({ ...f, [k]: v }));

  const submit = () => {
    if (!target) return;
    startTransition(async () => {
      const r = await saveMappingAction(target.model.id, form);
      if (r.ok) {
        toast.success("Provider mapping saved");
        onSaved();
      } else toast.error(r.error);
    });
  };

  return (
    <Dialog open={target !== null} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>{row ? "Edit provider mapping" : "Add provider"} — {target?.model.slug}</DialogTitle>
          <DialogDescription>Which provider serves this model, and what it calls it.</DialogDescription>
        </DialogHeader>
        <div className="grid gap-4">
          <div className="space-y-1.5">
            <Label>Provider</Label>
            <Select value={form.providerId} onValueChange={(v) => set("providerId", v)} disabled={!!row}>
              <SelectTrigger><SelectValue placeholder="Choose a provider" /></SelectTrigger>
              <SelectContent>
                {providers.map((p) => (
                  <SelectItem key={p.id} value={p.id}>{p.name}{!p.enabled ? " (disabled)" : ""}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="map-upstream">Upstream model id</Label>
            <Input id="map-upstream" value={form.upstreamModelId} onChange={(e) => set("upstreamModelId", e.target.value)} placeholder="deepseek-ai/DeepSeek-V3" className="font-mono" />
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1.5">
              <Label htmlFor="map-priority">Priority</Label>
              <Input id="map-priority" type="number" min={1} max={1000} value={Number(form.priority ?? 1)} onChange={(e) => set("priority", Number(e.target.value))} />
            </div>
            <div className="flex items-center gap-3 pt-6">
              <Switch id="map-enabled" checked={!!form.enabled} onCheckedChange={(v) => set("enabled", v)} />
              <Label htmlFor="map-enabled">Enabled</Label>
            </div>
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={pending}>Cancel</Button>
          <Button onClick={submit} disabled={pending || !form.providerId}>
            {pending ? <Loader2 className="animate-spin" /> : null}
            Save
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
