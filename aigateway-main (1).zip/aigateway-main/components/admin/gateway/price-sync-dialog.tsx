"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { ArrowRight, Loader2, RefreshCcw } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { syncModelPricesAction } from "@/app/admin/(dashboard)/models/actions";
import type { PriceSnapshot, PriceSyncReport } from "@/lib/services/model-prices";
import { cn } from "@/lib/utils";

/** µ$ per 1M tokens → "$3.00" / "$0.075" (null → "—"). */
function perM(micro: number | null): string {
  if (micro === null) return "—";
  const usd = micro / 1_000_000;
  return `$${usd.toFixed(usd > 0 && usd < 1 ? 3 : 2)}`;
}

function PriceCell({ before, after, k }: { before: PriceSnapshot; after: PriceSnapshot | null; k: keyof PriceSnapshot }) {
  const changed = after !== null && before[k] !== after[k];
  if (!changed) return <span className="tabular-nums text-muted-foreground">{perM(before[k])}</span>;
  return (
    <span className="inline-flex items-center gap-1 tabular-nums">
      <span className="text-muted-foreground line-through">{perM(before[k])}</span>
      <ArrowRight className="size-3 text-muted-foreground" />
      <span className="font-medium">{perM(after![k])}</span>
    </span>
  );
}

/**
 * "Sync prices" on the Models page: fetch OpenRouter / DeepInfra list prices,
 * show what would change, apply on confirmation. A daily cron does the same
 * unattended (/api/cron/model-prices).
 */
export function PriceSyncButton() {
  const router = useRouter();
  const [open, setOpen] = useState(false);
  const [report, setReport] = useState<PriceSyncReport | null>(null);
  const [pending, startTransition] = useTransition();

  const check = () => {
    setOpen(true);
    setReport(null);
    startTransition(async () => {
      const r = await syncModelPricesAction(false);
      if (!r.ok) {
        toast.error(r.error);
        setOpen(false);
        return;
      }
      setReport(r.data!);
    });
  };

  const apply = () =>
    startTransition(async () => {
      const r = await syncModelPricesAction(true);
      if (!r.ok) {
        toast.error(r.error);
        return;
      }
      toast.success(`${r.data!.changed} model price${r.data!.changed === 1 ? "" : "s"} updated`);
      setOpen(false);
      router.refresh();
    });

  const rows = report?.rows ?? [];

  return (
    <>
      <Button variant="outline" onClick={check}>
        <RefreshCcw /> Sync prices
      </Button>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="sm:max-w-3xl">
          <DialogHeader>
            <DialogTitle>Sync prices from providers</DialogTitle>
            <DialogDescription>
              Live list prices from OpenRouter and DeepInfra for each model&apos;s primary provider, per 1M tokens. OpenRouter requests are
              still billed from the real cost OpenRouter reports on each response; these prices drive balance holds, the prices customers
              see, and the fallback when no cost is reported.
            </DialogDescription>
          </DialogHeader>

          {pending && !report ? (
            <div className="flex items-center justify-center gap-2 py-10 text-sm text-muted-foreground">
              <Loader2 className="size-4 animate-spin" /> Fetching provider catalogs…
            </div>
          ) : rows.length === 0 ? (
            <p className="py-6 text-center text-sm text-muted-foreground">
              No model is served by a provider that publishes prices. Map a model to OpenRouter or DeepInfra first.
            </p>
          ) : (
            <div className="max-h-[55vh] overflow-auto rounded-lg border">
              <Table>
                <TableHeader>
                  <TableRow className="hover:bg-transparent">
                    <TableHead>Model</TableHead>
                    <TableHead>Input</TableHead>
                    <TableHead>Output</TableHead>
                    <TableHead>Cached input</TableHead>
                    <TableHead>Cache write</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {rows.map((r) => (
                    <TableRow key={r.modelId} className={cn(r.changed && "bg-primary/5")}>
                      <TableCell>
                        <p className="font-mono text-xs">{r.slug}</p>
                        <p className="text-[11px] text-muted-foreground">
                          {r.providerName} · {r.upstreamModelId}
                          {!r.after ? <span className="ml-1 text-destructive">— not in catalog</span> : null}
                        </p>
                      </TableCell>
                      <TableCell><PriceCell before={r.before} after={r.after} k="input" /></TableCell>
                      <TableCell><PriceCell before={r.before} after={r.after} k="output" /></TableCell>
                      <TableCell><PriceCell before={r.before} after={r.after} k="cachedInput" /></TableCell>
                      <TableCell><PriceCell before={r.before} after={r.after} k="cacheWrite" /></TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}

          {report ? (
            <p className="text-xs text-muted-foreground">
              {report.changed} to update · {report.unchanged} already current{report.missing > 0 ? ` · ${report.missing} not found in the provider catalog` : ""}
            </p>
          ) : null}

          <DialogFooter>
            <Button variant="ghost" onClick={() => setOpen(false)}>
              Close
            </Button>
            <Button onClick={apply} disabled={pending || !report || report.changed === 0}>
              {pending && report ? <Loader2 className="animate-spin" /> : null}
              Apply {report?.changed ?? 0} update{report?.changed === 1 ? "" : "s"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </>
  );
}
