"use client";

import { useEffect, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { Activity, Download, Loader2, Pencil, Plus, Server, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Switch } from "@/components/ui/switch";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { ConfirmDialog } from "@/components/shared/confirm-dialog";
import { EmptyState } from "@/components/shared/empty-state";
import { LocalTime } from "@/components/shared/local-time";
import { cn } from "@/lib/utils";
import {
  deleteProviderAction,
  fetchProviderModelsAction,
  importProviderModelsAction,
  saveProviderAction,
  setProviderEnabledAction,
  testProviderAction,
  type ProviderInput,
  type UpstreamModelOption,
} from "@/app/admin/(dashboard)/providers/actions";

export interface ProviderRow {
  id: string;
  slug: string;
  name: string;
  baseUrl: string;
  apiKeyMasked: string;
  enabled: boolean;
  priority: number;
  healthStatus: string;
  lastCheckedAt: string | null;
  lastError: string;
  modelCount: number;
}

const PRESETS: Array<{ label: string; slug: string; name: string; baseUrl: string }> = [
  { label: "DeepInfra", slug: "deepinfra", name: "DeepInfra", baseUrl: "https://api.deepinfra.com/v1/openai" },
  { label: "OpenRouter", slug: "openrouter", name: "OpenRouter", baseUrl: "https://openrouter.ai/api/v1" },
  { label: "Together", slug: "together", name: "Together AI", baseUrl: "https://api.together.xyz/v1" },
  { label: "Groq", slug: "groq", name: "Groq", baseUrl: "https://api.groq.com/openai/v1" },
  { label: "OpenAI", slug: "openai", name: "OpenAI", baseUrl: "https://api.openai.com/v1" },
];

function HealthDot({ status }: { status: string }) {
  const tone =
    status === "UP" ? "bg-success" : status === "DOWN" ? "bg-destructive" : "bg-muted-foreground/50";
  const label = status === "UP" ? "Healthy" : status === "DOWN" ? "Down" : "Unknown";
  return (
    <span className="inline-flex items-center gap-1.5 text-xs font-medium">
      <span className={cn("size-2 rounded-full", tone)} />
      {label}
    </span>
  );
}

export function ProvidersView({ providers }: { providers: ProviderRow[] }) {
  const router = useRouter();
  const [editing, setEditing] = useState<ProviderRow | null | "new">(null);
  const [importing, setImporting] = useState<ProviderRow | null>(null);
  const [pending, startTransition] = useTransition();
  const [busyId, setBusyId] = useState<string | null>(null);

  const toggle = (row: ProviderRow, enabled: boolean) => {
    setBusyId(row.id);
    startTransition(async () => {
      const r = await setProviderEnabledAction(row.id, enabled);
      if (r.ok) toast.success(`${row.name} ${enabled ? "enabled" : "disabled"}`);
      else toast.error(r.error);
      setBusyId(null);
      router.refresh();
    });
  };

  const test = (row: ProviderRow) => {
    setBusyId(row.id);
    startTransition(async () => {
      const r = await testProviderAction(row.id);
      if (r.ok && r.data) {
        if (r.data.ok) toast.success(`${row.name}: ${r.data.message} (${r.data.ms} ms)`);
        else toast.error(`${row.name}: ${r.data.message}`);
      } else if (!r.ok) toast.error(r.error);
      setBusyId(null);
      router.refresh();
    });
  };

  return (
    <div className="space-y-4">
      <div className="flex justify-end">
        <Button onClick={() => setEditing("new")}>
          <Plus /> Add provider
        </Button>
      </div>

      <Card className="overflow-hidden p-0">
        {providers.length === 0 ? (
          <EmptyState
            icon={Server}
            title="No providers yet"
            description="Add DeepInfra (or any OpenAI-compatible API) to start routing customer requests."
            className="border-0"
          />
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="hover:bg-transparent">
                  <TableHead>Provider</TableHead>
                  <TableHead>Base URL</TableHead>
                  <TableHead>Key</TableHead>
                  <TableHead className="text-right">Priority</TableHead>
                  <TableHead className="text-right">Models</TableHead>
                  <TableHead>Health</TableHead>
                  <TableHead>Enabled</TableHead>
                  <TableHead className="text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {providers.map((p) => (
                  <TableRow key={p.id} className={cn(!p.enabled && "opacity-60")}>
                    <TableCell>
                      <div className="font-medium">{p.name}</div>
                      <div className="font-mono text-xs text-muted-foreground">{p.slug}</div>
                    </TableCell>
                    <TableCell className="max-w-[260px] truncate font-mono text-xs">{p.baseUrl}</TableCell>
                    <TableCell className="font-mono text-xs">{p.apiKeyMasked || <span className="text-destructive">missing</span>}</TableCell>
                    <TableCell className="text-right tabular-nums">{p.priority}</TableCell>
                    <TableCell className="text-right tabular-nums">{p.modelCount}</TableCell>
                    <TableCell>
                      <HealthDot status={p.healthStatus} />
                      {p.lastCheckedAt ? (
                        <div className="text-[11px] text-muted-foreground">
                          <LocalTime date={new Date(p.lastCheckedAt)} variant="datetime" />
                        </div>
                      ) : null}
                      {p.lastError ? (
                        <div className="mt-0.5 max-w-[220px] truncate text-[11px] text-destructive" title={p.lastError}>
                          {p.lastError}
                        </div>
                      ) : null}
                    </TableCell>
                    <TableCell>
                      <Switch checked={p.enabled} disabled={pending && busyId === p.id} onCheckedChange={(v) => toggle(p, v)} aria-label={`Enable ${p.name}`} />
                    </TableCell>
                    <TableCell>
                      <div className="flex justify-end gap-1">
                        <Button variant="ghost" size="icon-sm" onClick={() => test(p)} disabled={pending && busyId === p.id} aria-label="Test connection" title="Test connection">
                          {pending && busyId === p.id ? <Loader2 className="animate-spin" /> : <Activity />}
                        </Button>
                        <Button variant="ghost" size="icon-sm" onClick={() => setImporting(p)} aria-label="Import models" title="Import models">
                          <Download />
                        </Button>
                        <Button variant="ghost" size="icon-sm" onClick={() => setEditing(p)} aria-label="Edit" title="Edit">
                          <Pencil />
                        </Button>
                        <ConfirmDialog
                          trigger={
                            <Button variant="ghost" size="icon-sm" aria-label="Delete" title="Delete" className="text-destructive hover:text-destructive">
                              <Trash2 />
                            </Button>
                          }
                          title={`Remove ${p.name}?`}
                          description="Its model mappings are removed too. Customers using models only served by this provider will get errors until another provider is mapped."
                          confirmLabel="Remove provider"
                          destructive
                          onConfirm={async () => {
                            const r = await deleteProviderAction(p.id);
                            if (r.ok) {
                              toast.success("Provider removed");
                              router.refresh();
                            } else toast.error(r.error);
                          }}
                        />
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </Card>

      <ProviderDialog
        key={editing === "new" ? "edit-new" : `edit-${editing?.id ?? "closed"}`}
        provider={editing === "new" ? null : editing}
        open={editing !== null}
        onClose={() => setEditing(null)}
        onSaved={() => {
          setEditing(null);
          router.refresh();
        }}
      />

      <ImportModelsDialog
        key={`import-${importing?.id ?? "closed"}`}
        provider={importing}
        onClose={() => setImporting(null)}
        onImported={() => {
          setImporting(null);
          router.refresh();
        }}
      />
    </div>
  );
}

// ─── Add / edit dialog ───────────────────────────────────────────────────────

function ProviderDialog({
  provider,
  open,
  onClose,
  onSaved,
}: {
  provider: ProviderRow | null;
  open: boolean;
  onClose: () => void;
  onSaved: () => void;
}) {
  const [form, setForm] = useState<ProviderInput>({
    slug: provider?.slug ?? "",
    name: provider?.name ?? "",
    baseUrl: provider?.baseUrl ?? "",
    apiKey: "",
    priority: provider?.priority ?? 100,
    enabled: provider?.enabled ?? true,
  });
  const [pending, startTransition] = useTransition();

  const set = <K extends keyof ProviderInput>(k: K, v: ProviderInput[K]) => setForm((f) => ({ ...f, [k]: v }));

  const submit = () => {
    startTransition(async () => {
      const r = await saveProviderAction(provider?.id ?? null, form);
      if (r.ok) {
        toast.success(provider ? "Provider updated" : "Provider added");
        onSaved();
      } else toast.error(r.error);
    });
  };

  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="sm:max-w-lg">
        <DialogHeader>
          <DialogTitle>{provider ? `Edit ${provider.name}` : "Add provider"}</DialogTitle>
          <DialogDescription>Any API that speaks OpenAI Chat Completions works.</DialogDescription>
        </DialogHeader>

        {!provider ? (
          <div className="flex flex-wrap gap-2">
            {PRESETS.map((p) => (
              <Button
                key={p.slug}
                type="button"
                variant="outline"
                size="sm"
                onClick={() => setForm((f) => ({ ...f, slug: p.slug, name: p.name, baseUrl: p.baseUrl }))}
              >
                {p.label}
              </Button>
            ))}
          </div>
        ) : null}

        <div className="grid gap-4 sm:grid-cols-2">
          <div className="space-y-1.5">
            <Label htmlFor="prov-name">Name</Label>
            <Input id="prov-name" value={form.name} onChange={(e) => set("name", e.target.value)} placeholder="DeepInfra" />
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="prov-slug">Slug</Label>
            <Input id="prov-slug" value={form.slug} onChange={(e) => set("slug", e.target.value)} placeholder="deepinfra" className="font-mono" />
          </div>
          <div className="space-y-1.5 sm:col-span-2">
            <Label htmlFor="prov-url">Base URL</Label>
            <Input id="prov-url" value={form.baseUrl} onChange={(e) => set("baseUrl", e.target.value)} placeholder="https://api.deepinfra.com/v1/openai" className="font-mono" />
            <p className="text-xs text-muted-foreground">The gateway appends <code>/chat/completions</code> and <code>/models</code>.</p>
          </div>
          <div className="space-y-1.5 sm:col-span-2">
            <Label htmlFor="prov-key">API key</Label>
            <Input
              id="prov-key"
              type="password"
              autoComplete="off"
              value={form.apiKey ?? ""}
              onChange={(e) => set("apiKey", e.target.value)}
              placeholder={provider ? `Leave blank to keep ${provider.apiKeyMasked || "current key"}` : "Paste the provider API key"}
              className="font-mono"
            />
            <p className="text-xs text-muted-foreground">Stored encrypted. Never shown again in full.</p>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="prov-priority">Priority</Label>
            <Input id="prov-priority" type="number" min={1} max={1000} value={Number(form.priority ?? 100)} onChange={(e) => set("priority", Number(e.target.value))} />
            <p className="text-xs text-muted-foreground">Lower is tried first.</p>
          </div>
          <div className="flex items-center gap-3 pt-6">
            <Switch id="prov-enabled" checked={!!form.enabled} onCheckedChange={(v) => set("enabled", v)} />
            <Label htmlFor="prov-enabled">Enabled</Label>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={pending}>Cancel</Button>
          <Button onClick={submit} disabled={pending}>
            {pending ? <Loader2 className="animate-spin" /> : null}
            {provider ? "Save changes" : "Add provider"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ─── Import models dialog ────────────────────────────────────────────────────

function ImportModelsDialog({
  provider,
  onClose,
  onImported,
}: {
  provider: ProviderRow | null;
  onClose: () => void;
  onImported: () => void;
}) {
  const [options, setOptions] = useState<UpstreamModelOption[] | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [selected, setSelected] = useState<Set<string>>(new Set());
  const [filter, setFilter] = useState("");
  const [, startLoad] = useTransition();
  const [importing, startImport] = useTransition();

  const fetchOptions = (id: string) =>
    startLoad(async () => {
      const r = await fetchProviderModelsAction(id);
      if (r.ok && r.data) setOptions(r.data);
      else if (!r.ok) setError(r.error);
    });

  const load = () => {
    if (!provider) return;
    setError(null);
    fetchOptions(provider.id);
  };

  // Load once the dialog opens (the component is re-keyed per provider).
  const providerId = provider?.id;
  useEffect(() => {
    if (providerId) fetchOptions(providerId);
  }, [providerId]);

  const visible = (options ?? []).filter((o) => o.id.toLowerCase().includes(filter.toLowerCase()));

  const submit = () => {
    if (!provider) return;
    startImport(async () => {
      const r = await importProviderModelsAction(provider.id, [...selected]);
      if (r.ok && r.data) {
        toast.success(`Imported ${r.data.mapped} models (${r.data.created} new). Check their prices on the Models page.`);
        onImported();
      } else if (!r.ok) toast.error(r.error);
    });
  };

  return (
    <Dialog open={provider !== null} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="sm:max-w-xl">
        <DialogHeader>
          <DialogTitle>Import models from {provider?.name}</DialogTitle>
          <DialogDescription>
            Pick the models to expose to customers. Each becomes a catalog entry you can price and enable per store.
          </DialogDescription>
        </DialogHeader>

        {error ? (
          <div className="rounded-lg border border-destructive/30 bg-destructive/10 px-4 py-3 text-sm text-destructive">
            {error}
            <Button variant="link" size="sm" className="ml-2 h-auto p-0" onClick={load}>Retry</Button>
          </div>
        ) : options === null ? (
          <div className="flex items-center gap-2 py-8 text-sm text-muted-foreground">
            <Loader2 className="size-4 animate-spin" /> Fetching model list…
          </div>
        ) : (
          <>
            <Input placeholder="Filter…" value={filter} onChange={(e) => setFilter(e.target.value)} />
            <div className="max-h-80 overflow-y-auto rounded-lg border">
              {visible.length === 0 ? (
                <p className="p-4 text-sm text-muted-foreground">No models match.</p>
              ) : (
                visible.map((o) => {
                  const checked = selected.has(o.id);
                  return (
                    <label
                      key={o.id}
                      className={cn(
                        "flex cursor-pointer items-center gap-3 border-b px-3 py-2 text-sm last:border-0 hover:bg-muted/50",
                        o.mappedTo && "opacity-60"
                      )}
                    >
                      <Checkbox
                        checked={checked}
                        disabled={!!o.mappedTo}
                        onCheckedChange={(v) =>
                          setSelected((s) => {
                            const n = new Set(s);
                            if (v) n.add(o.id);
                            else n.delete(o.id);
                            return n;
                          })
                        }
                      />
                      <span className="min-w-0 flex-1 truncate font-mono text-xs">
                        {o.id}
                        {o.deprecated ? <span className="ml-2 rounded bg-warning/15 px-1.5 py-0.5 font-sans text-[10px] font-medium text-warning">deprecated</span> : null}
                      </span>
                      {o.mappedTo ? (
                        <span className="shrink-0 text-[11px] text-muted-foreground">already mapped → {o.mappedTo}</span>
                      ) : o.inputUsdPerMTok !== undefined ? (
                        <span className="shrink-0 text-[11px] tabular-nums text-muted-foreground">
                          ${o.inputUsdPerMTok.toFixed(2)} / ${(o.outputUsdPerMTok ?? 0).toFixed(2)} per 1M
                          {o.contextWindow ? ` · ${Math.round(o.contextWindow / 1000)}k` : ""}
                        </span>
                      ) : null}
                    </label>
                  );
                })
              )}
            </div>
            <p className="text-xs text-muted-foreground">{selected.size} selected</p>
          </>
        )}

        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={importing}>Cancel</Button>
          <Button onClick={submit} disabled={importing || selected.size === 0}>
            {importing ? <Loader2 className="animate-spin" /> : <Download />}
            Import {selected.size > 0 ? selected.size : ""}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
