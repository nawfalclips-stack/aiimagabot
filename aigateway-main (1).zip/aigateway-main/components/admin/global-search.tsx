"use client";

import { useCallback, useEffect, useRef, useState } from "react";
import { useRouter } from "next/navigation";
import { BookOpen, Search, User } from "lucide-react";
import {
  CommandDialog,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command";
import { StatusBadge } from "@/components/shared/status-badge";
import { globalSearch, type SearchResult } from "@/app/admin/(dashboard)/search-actions";

export function GlobalSearch() {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  // Results are tagged with the query that produced them, so "loading" and the
  // visible list are derived from state instead of set synchronously in an effect.
  const [found, setFound] = useState<{ query: string; results: SearchResult[] }>({ query: "", results: [] });
  const router = useRouter();
  const requestId = useRef(0);
  const active = query.trim().length >= 2;
  const results = active && found.query === query ? found.results : [];
  const loading = active && found.query !== query;

  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      if (e.key === "k" && (e.metaKey || e.ctrlKey)) {
        e.preventDefault();
        setOpen((v) => !v);
      }
    };
    document.addEventListener("keydown", down);
    return () => document.removeEventListener("keydown", down);
  }, []);

  useEffect(() => {
    if (!active) return;
    const id = ++requestId.current;
    const timer = setTimeout(async () => {
      const results = await globalSearch(query);
      if (id === requestId.current) setFound({ query, results });
    }, 180);
    return () => clearTimeout(timer);
  }, [query, active]);

  const go = useCallback(
    (href: string) => {
      setOpen(false);
      setQuery("");
      router.push(href);
    },
    [router]
  );

  const customers = results.filter((r) => r.type === "customer");
  const docs = results.filter((r) => r.type === "documentation");

  return (
    <>
      <button
        type="button"
        onClick={() => setOpen(true)}
        className="flex h-9 w-full items-center gap-2 rounded-lg border bg-muted/40 px-3 text-sm text-muted-foreground transition-colors hover:border-primary/40 hover:bg-muted/70"
        aria-label="Open global search"
      >
        <Search className="size-4" />
        <span className="flex-1 truncate text-left">Search customers, orders…</span>
        <kbd className="pointer-events-none hidden rounded border bg-background px-1.5 py-0.5 font-mono text-[10px] font-medium sm:inline">
          Ctrl K
        </kbd>
      </button>

      <CommandDialog open={open} onOpenChange={setOpen} shouldFilter={false} title="Global search" description="Search customers, orders, API keys and documentation">
        <CommandInput
          placeholder="Search access codes, orders, API keys, notes…"
          value={query}
          onValueChange={setQuery}
        />
        <CommandList>
          <CommandEmpty>
            {loading ? "Searching…" : query.trim().length < 2 ? "Type at least 2 characters" : "No results found."}
          </CommandEmpty>
          {customers.length > 0 ? (
            <CommandGroup heading="Customers">
              {customers.map((r) => (
                <CommandItem key={r.id} value={r.id} onSelect={() => go(r.href)}>
                  <User className="text-muted-foreground" />
                  <div className="flex min-w-0 flex-1 items-center justify-between gap-3">
                    <div className="min-w-0">
                      <p className="truncate font-mono text-[13px] font-medium">{r.title}</p>
                      <p className="truncate text-xs text-muted-foreground">{r.subtitle}</p>
                    </div>
                    {r.status ? <StatusBadge status={r.status} /> : null}
                  </div>
                </CommandItem>
              ))}
            </CommandGroup>
          ) : null}
          {docs.length > 0 ? (
            <CommandGroup heading="Documentation">
              {docs.map((r) => (
                <CommandItem key={r.id} value={r.id} onSelect={() => go(r.href)}>
                  <BookOpen className="text-muted-foreground" />
                  <span className="truncate">{r.title}</span>
                </CommandItem>
              ))}
            </CommandGroup>
          ) : null}
        </CommandList>
      </CommandDialog>
    </>
  );
}
