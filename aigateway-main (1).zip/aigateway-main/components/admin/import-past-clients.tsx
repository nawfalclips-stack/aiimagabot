"use client";

import { useMemo, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { ClipboardPaste, History, Loader2, Upload } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Textarea } from "@/components/ui/textarea";
import { formatCents } from "@/lib/money";
import { parsePastClients } from "@/lib/past-clients-parser";
import { importPastClientsAction } from "@/app/admin/(dashboard)/expired/actions";
import { cn } from "@/lib/utils";

export function ImportPastClients() {
  const [open, setOpen] = useState(false);
  const [raw, setRaw] = useState("");
  const [pending, startTransition] = useTransition();
  const router = useRouter();

  const preview = useMemo(() => (raw.trim() ? parsePastClients(raw) : null), [raw]);

  const runImport = () => {
    if (!preview || preview.clients.length === 0 || pending) return;
    startTransition(async () => {
      const result = await importPastClientsAction(raw);
      if (result.ok && result.data) {
        const skipCount = result.data.skipped.length;
        const skipReasons = result.data.skipped
          .map((s) => s.reason)
          .filter(Boolean)
          .slice(0, 3)
          .join(" · ");
        toast.success(`${result.data.imported} clients imported`, {
          description:
            skipCount > 0
              ? `${skipCount} skipped: ${skipReasons}${skipCount > 3 ? " …" : ""}`
              : "All clients are now in Customers — expired ones show in Expired Balance with Purchased Again buttons.",
        });
        setOpen(false);
        setRaw("");
        router.refresh();
      } else if (!result.ok) {
        toast.error(result.error);
      }
    });
  };

  const cancelled = preview?.clients.filter((c) => c.sourceStatus === "cancelled").length ?? 0;
  const toImport = (preview?.clients.length ?? 0) - cancelled;

  return (
    <Dialog open={open} onOpenChange={(v) => { setOpen(v); if (!v) setRaw(""); }}>
      <DialogTrigger asChild>
        <Button variant="outline">
          <History /> Import past clients
        </Button>
      </DialogTrigger>
      <DialogContent className="sm:max-w-3xl">
        <DialogHeader>
          <DialogTitle>Import past clients</DialogTitle>
          <DialogDescription>
            Paste the full list copied from the other website. Each client block (Access Code → API Key → Order # →
            Balance) is parsed automatically. Cancelled entries are skipped; all others are imported with their
            exact balances, profit and status.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-3">
          <Textarea
            value={raw}
            onChange={(e) => setRaw(e.target.value)}
            placeholder={"L2WJ-WNRP-X44Q\nAPI Key:\nfe_oa_a15e6c21f0...\n\nOrder #: 874007375756005376\nProfit:\n$7.00\n\nBalance: $125.00 remaining ($0.00 used of $125)"}
            rows={8}
            spellCheck={false}
            className="font-mono text-[12px]"
            aria-label="Paste past clients"
          />

          {preview && preview.clients.length > 0 ? (
            <div className="overflow-hidden rounded-lg border">
              <div className="flex flex-wrap items-center justify-between gap-2 border-b bg-muted/40 px-4 py-2 text-sm">
                <span className="flex items-center gap-2 font-medium">
                  <ClipboardPaste className="size-4 text-primary" />
                  {toImport} clients will be imported
                  {cancelled > 0 ? <span className="text-xs text-muted-foreground">({cancelled} Cancelled skipped)</span> : null}
                </span>
                {preview.skipped.length > 0 ? (
                  <span className="text-xs text-warning">{preview.skipped.length} blocks skipped</span>
                ) : null}
              </div>
              <ScrollArea className="max-h-64">
                <Table>
                  <TableHeader>
                    <TableRow className="hover:bg-transparent">
                      <TableHead className="pl-4">Access Code</TableHead>
                      <TableHead>Order #</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Balance</TableHead>
                      <TableHead>Used</TableHead>
                      <TableHead>Bonus</TableHead>
                      <TableHead className="pr-4">Profit</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {preview.clients.map((c) => {
                      const remaining = c.initialBalanceCents - c.usedBalanceCents;
                      return (
                        <TableRow key={c.accessCode} className={cn("hover:bg-transparent", c.sourceStatus === "cancelled" && "opacity-40")}>
                          <TableCell className="pl-4 font-mono text-[13px] font-medium">{c.accessCode}</TableCell>
                          <TableCell className="font-mono text-xs text-muted-foreground truncate max-w-36">{c.orderId}</TableCell>
                          <TableCell>
                            <span className={cn("text-xs font-medium",
                              c.sourceStatus === "cancelled" ? "text-muted-foreground" :
                              c.sourceStatus === "inactive" ? "text-warning" :
                              remaining <= 0 ? "text-destructive" : "text-success"
                            )}>
                              {c.sourceStatus === "cancelled" ? "Cancelled" :
                               c.sourceStatus === "inactive" ? "Inactive" :
                               remaining <= 0 ? "Expired" : "Active"}
                            </span>
                          </TableCell>
                          <TableCell className="tabular-nums text-xs">{formatCents(c.initialBalanceCents)}</TableCell>
                          <TableCell className="tabular-nums text-xs text-muted-foreground">{formatCents(c.usedBalanceCents)}</TableCell>
                          <TableCell className="tabular-nums text-xs">{formatCents(c.initialBonusCents)}</TableCell>
                          <TableCell className="pr-4 tabular-nums text-xs text-success">{formatCents(c.profitCents)}</TableCell>
                        </TableRow>
                      );
                    })}
                  </TableBody>
                </Table>
              </ScrollArea>
            </div>
          ) : raw.trim() ? (
            <p className="text-sm text-destructive">No clients recognized — paste the full block including Access Code lines like XXXX-XXXX-XXXX.</p>
          ) : null}
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => setOpen(false)} disabled={pending}>Cancel</Button>
          <Button onClick={runImport} disabled={!preview || toImport === 0 || pending}>
            {pending ? <Loader2 className="animate-spin" /> : <Upload />}
            Import {toImport > 0 ? `${toImport} clients` : ""}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
