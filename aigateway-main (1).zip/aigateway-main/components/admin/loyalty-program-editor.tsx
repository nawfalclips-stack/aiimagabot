"use client";

import { useMemo, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { Loader2, Plus, RotateCcw, Save, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ConfirmDialog } from "@/components/shared/confirm-dialog";
import {
  MAX_LOYALTY_BRACKETS,
  MAX_LOYALTY_TIERS,
  getTierForPoints,
  pointsForPurchase,
  tierIdFromName,
  type LoyaltyProgram,
} from "@/lib/loyalty";
import { resetLoyaltyProgramAction, saveLoyaltyProgramAction } from "@/app/admin/(dashboard)/loyalty/program/actions";

interface TierDraft {
  id: string;
  name: string;
  minPoints: string;
  rewardUsd: string;
  colorHex: string;
}
interface BracketDraft {
  key: string;
  minUsd: string;
  points: string;
}

const PALETTE = ["#8d6e63", "#94a3b8", "#f59e0b", "#a855f7", "#0ea5e9", "#10b981", "#ef4444", "#64748b"];
const num = (v: string) => (v.trim() === "" ? NaN : Number(v));
const cents = (usd: string) => Math.round(num(usd) * 100);

function toDrafts(p: LoyaltyProgram) {
  return {
    basePoints: String(p.basePoints),
    overflowPercent: String(p.overflowPercent),
    brackets: [...p.brackets]
      .sort((a, b) => a.minCents - b.minCents)
      .map((b, i) => ({ key: `b${i}-${b.minCents}`, minUsd: String(b.minCents / 100), points: String(b.points) })),
    tiers: [...p.tiers]
      .sort((a, b) => a.minPoints - b.minPoints)
      .map((t) => ({ id: t.id, name: t.name, minPoints: String(t.minPoints), rewardUsd: t.rewardAmountCents ? String(t.rewardAmountCents / 100) : "0", colorHex: t.colorHex })),
  };
}

/** Editable loyalty program: levels, rewards, points brackets, with a live preview. */
export function LoyaltyProgramEditor({ program, isCustom, customerPoints }: { program: LoyaltyProgram; isCustom: boolean; customerPoints: number[] }) {
  const router = useRouter();
  const [pending, startTransition] = useTransition();
  const initial = useMemo(() => toDrafts(program), [program]);
  const [basePoints, setBasePoints] = useState(initial.basePoints);
  const [overflowPercent, setOverflowPercent] = useState(initial.overflowPercent);
  const [brackets, setBrackets] = useState<BracketDraft[]>(initial.brackets);
  const [tiers, setTiers] = useState<TierDraft[]>(initial.tiers);
  const [sampleUsd, setSampleUsd] = useState("250");

  /** The draft as a program (NaN fields make the server reject it with a clear message). */
  const draft: LoyaltyProgram = {
    basePoints: num(basePoints),
    overflowPercent: num(overflowPercent),
    brackets: brackets.map((b) => ({ minCents: cents(b.minUsd), points: num(b.points) })),
    tiers: tiers.map((t) => ({ id: t.id, name: t.name, minPoints: num(t.minPoints), rewardAmountCents: cents(t.rewardUsd || "0"), colorHex: t.colorHex })),
  };
  const valid = (n: number) => Number.isFinite(n) && n >= 0;
  const previewable =
    valid(draft.basePoints) &&
    valid(draft.overflowPercent) &&
    draft.brackets.every((b) => valid(b.minCents) && b.minCents > 0 && valid(b.points)) &&
    draft.tiers.length > 0 &&
    draft.tiers.every((t) => valid(t.minPoints));

  const counts = useMemo(() => {
    const map = new Map<string, number>();
    if (!previewable) return map;
    for (const p of customerPoints) {
      const t = getTierForPoints(p, draft.tiers);
      map.set(t.id, (map.get(t.id) ?? 0) + 1);
    }
    return map;
    // draft.tiers is rebuilt every render; recompute from the raw inputs instead.
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [customerPoints, tiers, previewable]);

  const sample = previewable && Number(sampleUsd) > 0 ? pointsForPurchase(Math.round(Number(sampleUsd) * 100), draft) : null;

  const setTier = (i: number, patch: Partial<TierDraft>) => setTiers((list) => list.map((t, j) => (j === i ? { ...t, ...patch } : t)));
  const setBracket = (i: number, patch: Partial<BracketDraft>) => setBrackets((list) => list.map((b, j) => (j === i ? { ...b, ...patch } : b)));

  const addTier = () =>
    setTiers((list) => {
      const top = Math.max(0, ...list.map((t) => num(t.minPoints)).filter(Number.isFinite));
      const name = `Level ${list.length + 1}`;
      return [...list, { id: tierIdFromName(name, list.map((t) => t.id)), name, minPoints: String(top + 500), rewardUsd: "0", colorHex: PALETTE[list.length % PALETTE.length] }];
    });
  const addBracket = () =>
    setBrackets((list) => {
      const top = Math.max(0, ...list.map((b) => num(b.minUsd)).filter(Number.isFinite));
      return [...list, { key: `new-${Date.now()}`, minUsd: String(top ? top * 2 : 100), points: "0" }];
    });

  const save = () =>
    startTransition(async () => {
      const r = await saveLoyaltyProgramAction(draft);
      if (!r.ok) {
        toast.error(r.error);
        return;
      }
      toast.success("Loyalty program saved");
      const next = toDrafts(r.data!);
      setBasePoints(next.basePoints);
      setOverflowPercent(next.overflowPercent);
      setBrackets(next.brackets);
      setTiers(next.tiers);
      router.refresh();
    });

  const reset = async () => {
    const r = await resetLoyaltyProgramAction();
    if (!r.ok) {
      toast.error(r.error);
      return;
    }
    toast.success("Back to the default program");
    router.refresh();
  };

  return (
    <div className="grid gap-6 xl:grid-cols-[1fr_20rem]">
      <div className="space-y-6">
        {/* Levels */}
        <Card>
          <CardHeader>
            <CardTitle>Levels and cash rewards</CardTitle>
            <CardDescription>
              A customer reaches a level with its number of points. Levels with a reward above $0 let the customer request that reward, which you
              approve on the Loyalty page. The first level must start at 0 points. Each colour tints the customer&apos;s dashboard.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="hidden grid-cols-[2.5rem_1fr_7rem_7rem_5rem_2.25rem] gap-2 px-1 text-xs text-muted-foreground sm:grid">
              <span>Colour</span>
              <span>Name</span>
              <span>Points needed</span>
              <span>Cash reward ($)</span>
              <span className="text-right">Customers</span>
              <span />
            </div>
            {tiers.map((t, i) => (
              <div key={t.id} className="grid grid-cols-[2.5rem_1fr_2.25rem] items-center gap-2 rounded-lg border p-2 sm:grid-cols-[2.5rem_1fr_7rem_7rem_5rem_2.25rem] sm:border-0 sm:p-0">
                <input
                  type="color"
                  aria-label={`Colour of ${t.name || "level"}`}
                  value={t.colorHex}
                  onChange={(e) => setTier(i, { colorHex: e.target.value })}
                  className="h-9 w-10 cursor-pointer rounded-md border bg-transparent p-1"
                />
                <Input aria-label="Level name" value={t.name} maxLength={40} onChange={(e) => setTier(i, { name: e.target.value })} />
                <Button
                  type="button"
                  variant="ghost"
                  size="icon-sm"
                  aria-label={`Remove ${t.name || "level"}`}
                  className="text-destructive hover:text-destructive sm:order-last"
                  disabled={tiers.length <= 1}
                  onClick={() => setTiers((list) => list.filter((_, j) => j !== i))}
                >
                  <Trash2 />
                </Button>
                <div className="col-span-3 grid grid-cols-3 gap-2 sm:col-span-1 sm:contents">
                  <Input aria-label="Points needed" type="number" min={0} step={1} inputMode="numeric" value={t.minPoints} onChange={(e) => setTier(i, { minPoints: e.target.value })} />
                  <Input aria-label="Cash reward in dollars" type="number" min={0} step="0.01" inputMode="decimal" value={t.rewardUsd} onChange={(e) => setTier(i, { rewardUsd: e.target.value })} />
                  <p className="self-center text-right text-sm tabular-nums text-muted-foreground" title="Customers at this level with these settings">
                    {previewable ? (counts.get(t.id) ?? 0) : "—"}
                  </p>
                </div>
              </div>
            ))}
            <Button type="button" variant="outline" size="sm" onClick={addTier} disabled={tiers.length >= MAX_LOYALTY_TIERS}>
              <Plus /> Add level
            </Button>
          </CardContent>
        </Card>

        {/* Points */}
        <Card>
          <CardHeader>
            <CardTitle>Points per purchase</CardTitle>
            <CardDescription>
              Points are added on every approved activation and recharge. A purchase earns the points of the highest bracket it reaches, plus a share for the
              dollars above that bracket. A purchase below the smallest bracket earns the base points.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-5">
            <div className="grid gap-4 sm:grid-cols-2">
              <div className="grid gap-1.5">
                <Label htmlFor="lp-base">Points below the smallest bracket</Label>
                <Input id="lp-base" type="number" min={0} step={1} inputMode="numeric" value={basePoints} onChange={(e) => setBasePoints(e.target.value)} />
              </div>
              <div className="grid gap-1.5">
                <Label htmlFor="lp-overflow">Extra points per dollar above a bracket (%)</Label>
                <Input id="lp-overflow" type="number" min={0} step="0.5" inputMode="decimal" value={overflowPercent} onChange={(e) => setOverflowPercent(e.target.value)} />
                <p className="text-xs text-muted-foreground">
                  {valid(num(overflowPercent)) ? `${Number((num(overflowPercent) / 100).toFixed(3))} points per extra dollar` : "Enter a percentage"}
                </p>
              </div>
            </div>

            <div className="space-y-2">
              <div className="grid grid-cols-[1fr_1fr_2.25rem] gap-2 px-1 text-xs text-muted-foreground">
                <span>Purchase from ($)</span>
                <span>Points</span>
                <span />
              </div>
              {brackets.map((b, i) => (
                <div key={b.key} className="grid grid-cols-[1fr_1fr_2.25rem] items-center gap-2">
                  <Input aria-label="Purchase from, in dollars" type="number" min={0.01} step="0.01" inputMode="decimal" value={b.minUsd} onChange={(e) => setBracket(i, { minUsd: e.target.value })} />
                  <Input aria-label="Points for this bracket" type="number" min={0} step={1} inputMode="numeric" value={b.points} onChange={(e) => setBracket(i, { points: e.target.value })} />
                  <Button type="button" variant="ghost" size="icon-sm" aria-label="Remove bracket" className="text-destructive hover:text-destructive" onClick={() => setBrackets((list) => list.filter((_, j) => j !== i))}>
                    <Trash2 />
                  </Button>
                </div>
              ))}
              <Button type="button" variant="outline" size="sm" onClick={addBracket} disabled={brackets.length >= MAX_LOYALTY_BRACKETS}>
                <Plus /> Add bracket
              </Button>
            </div>
          </CardContent>
        </Card>

        <div className="flex flex-wrap items-center gap-2">
          <Button onClick={save} disabled={pending}>
            {pending ? <Loader2 className="animate-spin" /> : <Save />} Save program
          </Button>
          {isCustom ? (
            <ConfirmDialog
              trigger={
                <Button variant="ghost" disabled={pending}>
                  <RotateCcw /> Reset to default
                </Button>
              }
              title="Reset the loyalty program?"
              description="The store goes back to the default levels, rewards and points brackets. Customers keep their points."
              confirmLabel="Reset"
              onConfirm={reset}
            />
          ) : null}
        </div>
      </div>

      {/* Preview */}
      <aside className="space-y-6 xl:sticky xl:top-24 xl:self-start">
        <Card>
          <CardHeader>
            <CardTitle>Try a purchase</CardTitle>
            <CardDescription>Points a purchase would earn with these settings.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-3">
            <div className="grid gap-1.5">
              <Label htmlFor="lp-sample">Purchase amount ($)</Label>
              <Input id="lp-sample" type="number" min={0} step="0.01" inputMode="decimal" value={sampleUsd} onChange={(e) => setSampleUsd(e.target.value)} />
            </div>
            {sample ? (
              <p className="text-sm">
                <span className="font-display text-2xl font-semibold tabular-nums">{sample.totalPoints}</span> points
                <span className="block text-xs text-muted-foreground">
                  {sample.basePoints} base{sample.extraPoints > 0 ? ` + ${sample.extraPoints} for the amount above the bracket` : ""}
                </span>
              </p>
            ) : (
              <p className="text-sm text-muted-foreground">Fill in the fields to see the result.</p>
            )}
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Levels at a glance</CardTitle>
          </CardHeader>
          <CardContent>
            <ol className="space-y-2">
              {[...draft.tiers]
                .filter((t) => valid(t.minPoints))
                .sort((a, b) => a.minPoints - b.minPoints)
                .map((t) => (
                  <li key={t.id} className="flex items-center gap-2.5 text-sm">
                    <span aria-hidden className="size-2.5 rounded-full" style={{ backgroundColor: t.colorHex }} />
                    <span className="font-medium">{t.name || "Unnamed"}</span>
                    <span className="ml-auto text-xs text-muted-foreground tabular-nums">
                      {t.minPoints} pts{t.rewardAmountCents > 0 ? ` · $${(t.rewardAmountCents / 100).toFixed(2)}` : ""}
                    </span>
                  </li>
                ))}
            </ol>
          </CardContent>
        </Card>
      </aside>
    </div>
  );
}
