"use client";

import { useState } from "react";
import { Bell, Check, CheckCheck, Gift, ShieldCheck, RefreshCw } from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { ScrollArea } from "@/components/ui/scroll-area";
import { formatDistanceToNow } from "date-fns";
import { markNotificationAsReadAction, markAllNotificationsAsReadAction } from "@/app/admin/actions";
import { useRouter } from "next/navigation";

interface Notification {
  id: string;
  type: string;
  title: string;
  message: string;
  customerId: string | null;
  relatedId: string | null;
  isRead: boolean;
  createdAt: Date;
}

interface NotificationBellProps {
  notifications: Notification[];
  unreadCount: number;
}

export function NotificationBell({ notifications, unreadCount }: NotificationBellProps) {
  const [open, setOpen] = useState(false);
  const router = useRouter();

  const handleMarkAsRead = async (notificationId: string) => {
    await markNotificationAsReadAction(notificationId);
    router.refresh();
  };

  const handleMarkAllAsRead = async () => {
    await markAllNotificationsAsReadAction();
    router.refresh();
  };

  const getIcon = (type: string) => {
    switch (type) {
      case "REVIEW_CLAIMED":
        return <Gift className="size-4 text-success" />;
      case "ACTIVATION_PENDING":
        return <ShieldCheck className="size-4 text-warning" />;
      case "RECHARGE_REQUESTED":
        return <RefreshCw className="size-4 text-primary" />;
      case "VOUCHER_LOW_STOCK":
      case "PROVIDER_BREAKER_OPEN":
      case "RESERVATIONS_SWEPT":
      case "MODEL_PRICES_SYNCED":
        return <Bell className="size-4 text-warning" />;
      case "VOUCHER_REVIEW":
        return <ShieldCheck className="size-4 text-warning" />;
      default:
        return <Bell className="size-4" />;
    }
  };

  const getLink = (notification: Notification) => {
    switch (notification.type) {
      case "REVIEW_CLAIMED":
        return `/admin/customers`;
      case "ACTIVATION_PENDING":
        return `/admin/activations`;
      case "RECHARGE_REQUESTED":
        return `/admin/recharges`;
      case "VOUCHER_LOW_STOCK":
        return `/admin/vouchers`;
      case "VOUCHER_REVIEW":
        return notification.message.includes("recharge") ? `/admin/recharges` : `/admin/activations`;
      case "PROVIDER_BREAKER_OPEN":
        return `/admin/providers`;
      case "MODEL_PRICES_SYNCED":
        return `/admin/models`;
      default:
        return "/admin";
    }
  };

  return (
    <DropdownMenu open={open} onOpenChange={setOpen}>
      <DropdownMenuTrigger asChild>
        <Button variant="ghost" size="icon-sm" className="relative" aria-label="Notifications">
          <Bell className="size-5" />
          {unreadCount > 0 && (
            <span className="absolute -right-1 -top-1 flex h-5 min-w-[1.25rem] items-center justify-center rounded-full bg-destructive px-1 text-[10px] font-bold text-white">
              {unreadCount > 99 ? "99+" : unreadCount}
            </span>
          )}
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-80">
        <DropdownMenuLabel className="flex items-center justify-between">
          <span>Notifications</span>
          {unreadCount > 0 && (
            <Button
              variant="ghost"
              size="sm"
              className="h-7 text-xs"
              onClick={handleMarkAllAsRead}
            >
              <CheckCheck className="size-3.5" /> Mark all read
            </Button>
          )}
        </DropdownMenuLabel>
        <DropdownMenuSeparator />
        <ScrollArea className="max-h-[400px]">
          {notifications.length === 0 ? (
            <div className="py-8 text-center text-sm text-muted-foreground">
              No notifications yet
            </div>
          ) : (
            notifications.map((notification) => (
              <DropdownMenuItem
                key={notification.id}
                className={`flex cursor-pointer flex-col items-start gap-1.5 p-3 ${
                  !notification.isRead ? "bg-muted/50" : ""
                }`}
                onClick={() => {
                  if (!notification.isRead) {
                    handleMarkAsRead(notification.id);
                  }
                  router.push(getLink(notification));
                  setOpen(false);
                }}
              >
                <div className="flex w-full items-start gap-2">
                  <span className="mt-0.5">{getIcon(notification.type)}</span>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium">{notification.title}</p>
                    <p className="text-xs text-muted-foreground">{notification.message}</p>
                  </div>
                  {!notification.isRead && (
                    <span className="size-2 shrink-0 rounded-full bg-primary" />
                  )}
                </div>
                <p className="text-xs text-muted-foreground">
                  {formatDistanceToNow(new Date(notification.createdAt), { addSuffix: true })}
                </p>
              </DropdownMenuItem>
            ))
          )}
        </ScrollArea>
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
