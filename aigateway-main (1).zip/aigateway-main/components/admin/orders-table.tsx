"use client";

import { useMemo, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { Check, Loader2, Pencil, Search, ShoppingCart, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { StatusBadge } from "@/components/shared/status-badge";
import { CopyButton } from "@/components/shared/copy-button";
import { EmptyState } from "@/components/shared/empty-state";
import { formatCents } from "@/lib/money";

import { setProfitAction } from "@/app/admin/(dashboard)/customers/actions";
import { LocalTime } from "@/components/shared/local-time";

export interface OrderRow {
  id: string;
  orderNumber: string;
  customerId: string;
  accessCode: string;
  status: string;
  initialBalanceCents: number;
  profitCents: number;
  createdAt: string;
}

/**
 * Inline profit editor — OPTIMISTIC: the new value shows instantly and the
 * popover closes right away; the save runs in the background and reverts
 * (with an error toast) only if it fails. Dashboard/analytics recalculate
 * from profit history automatically.
 */
function ProfitEditor({ order }: { order: OrderRow }) {
  const [open, setOpen] = useState(false);
  const [value, setValue] = useState(String(order.profitCents / 100));
  // Optimistic display value — null means "show the server value".
  const [optimisticCents, setOptimisticCents] = useState<number | null>(null);
  const router = useRouter();

  const shownCents = optimisticCents ?? order.profitCents;
  const parsed = parseFloat(value);
  const valid = Number.isFinite(parsed) && parsed >= 0;

  const save = () => {
    if (!valid) return;
    const newCents = Math.round(parsed * 100);
    const previousCents = shownCents;

    // Instant feedback: show the new value and close immediately.
    setOptimisticCents(newCents);
    setOpen(false);
    toast.success("Profit updated", { description: `${order.orderNumber} → ${formatCents(newCents)}` });

    // Persist in the background; revert if it fails.
    void setProfitAction(order.customerId, parsed).then((result) => {
      if (result.ok) {
        router.refresh();
      } else {
        setOptimisticCents(previousCents === order.profitCents ? null : previousCents);
        toast.error(result.error);
      }
    });
  };

  return (
    <Popover
      open={open}
      onOpenChange={(v) => {
        setOpen(v);
        if (v) setValue(String(shownCents / 100));
      }}
    >
      <PopoverTrigger asChild>
        <button
          type="button"
          onClick={(e) => e.stopPropagation()}
          className="group/profit inline-flex items-center gap-1.5 rounded-md px-1.5 py-0.5 text-success tabular-nums transition-colors hover:bg-success/10"
          aria-label={`Edit profit for ${order.orderNumber}`}
          title="Edit profit"
        >
          {formatCents(shownCents)}
          <Pencil className="size-3 opacity-0 transition-opacity group-hover/profit:opacity-60" />
        </button>
      </PopoverTrigger>
      <PopoverContent className="w-56 p-3" align="start" onClick={(e) => e.stopPropagation()}>
        <p className="mb-2 text-xs font-medium text-muted-foreground">Profit for {order.orderNumber} (USD)</p>
        <div className="flex gap-1.5">
          <Input
            type="number"
            inputMode="decimal"
            min="0"
            step="0.01"
            value={value}
            onChange={(e) => setValue(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && save()}
            autoFocus
            className="h-8"
          />
          <Button size="icon-sm" onClick={save} disabled={!valid} aria-label="Save profit">
            <Check />
          </Button>
        </div>
      </PopoverContent>
    </Popover>
  );
}

export function OrdersTable({ orders }: { orders: OrderRow[] }) {
  const [query, setQuery] = useState("");
  const router = useRouter();

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (!q) return orders;
    return orders.filter((o) => [o.orderNumber, o.accessCode, o.status].join(" ").toLowerCase().includes(q));
  }, [orders, query]);

  return (
    <div className="space-y-4">
      <div className="relative max-w-md">
        <Search className="absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search order number or access code…"
          className="pl-9"
          aria-label="Search orders"
        />
        {query ? (
          <button
            type="button"
            onClick={() => setQuery("")}
            className="absolute top-1/2 right-3 -translate-y-1/2 text-muted-foreground hover:text-foreground"
            aria-label="Clear search"
          >
            <X className="size-4" />
          </button>
        ) : null}
      </div>

      <Card className="overflow-hidden p-0">
        {filtered.length === 0 ? (
          <EmptyState
            icon={ShoppingCart}
            title={orders.length === 0 ? "No orders yet" : "No matching orders"}
            description={
              orders.length === 0
                ? "Orders are created automatically with each customer."
                : "Try a different search term."
            }
            className="border-0"
          />
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="hover:bg-transparent">
                  <TableHead className="pl-4">Order Number</TableHead>
                  <TableHead>Access Code</TableHead>
                  <TableHead>Order Value</TableHead>
                  <TableHead>Profit</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="pr-4">Created</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {filtered.map((o) => (
                  <TableRow
                    key={o.id}
                    className="group cursor-pointer"
                    onClick={() => router.push(`/admin/customers/${o.customerId}`)}
                  >
                    <TableCell className="pl-4">
                      <div className="flex items-center gap-1">
                        <span className="font-mono text-[13px] font-medium">{o.orderNumber}</span>
                        <span onClick={(e) => e.stopPropagation()}>
                          <CopyButton value={o.orderNumber} label="Order number" size="icon-xs" className="opacity-0 transition-opacity group-hover:opacity-100" />
                        </span>
                      </div>
                    </TableCell>
                    <TableCell>
                      <div className="flex items-center gap-1">
                        <span className="font-mono text-[13px] text-muted-foreground">{o.accessCode}</span>
                        <span onClick={(e) => e.stopPropagation()}>
                          <CopyButton value={o.accessCode} label="Access code" size="icon-xs" className="opacity-0 transition-opacity group-hover:opacity-100" />
                        </span>
                      </div>
                    </TableCell>
                    <TableCell className="tabular-nums">{formatCents(o.initialBalanceCents)}</TableCell>
                    <TableCell onClick={(e) => e.stopPropagation()}>
                      <ProfitEditor order={o} />
                    </TableCell>
                    <TableCell>
                      <StatusBadge status={o.status} />
                    </TableCell>
                    <TableCell className="pr-4 text-muted-foreground"><LocalTime date={o.createdAt} variant="date" /></TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </Card>
    </div>
  );
}
