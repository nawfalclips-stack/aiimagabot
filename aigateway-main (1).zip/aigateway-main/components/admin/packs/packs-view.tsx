"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { Loader2, Package, Pencil, Plus, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { ConfirmDialog } from "@/components/shared/confirm-dialog";
import { EmptyState } from "@/components/shared/empty-state";
import { cn } from "@/lib/utils";
import { formatCents } from "@/lib/money";
import { deletePackAction, savePackAction, setPackActiveAction, type PackInput } from "@/app/admin/(dashboard)/packs/actions";

export interface PackRow {
  id: string;
  name: string;
  planId: string;
  planName: string;
  balanceGrantCents: number;
  bonusGrantCents: number;
  listingPriceLabel: string;
  gamsgoOfferRef: string;
  active: boolean;
  sortOrder: number;
  customers: number;
  vouchersIssued: number;
}

export interface PlanChoice {
  id: string;
  name: string;
  priceCents: number;
  isActive: boolean;
}

export function PacksView({ packs, plans }: { packs: PackRow[]; plans: PlanChoice[] }) {
  const router = useRouter();
  const [editing, setEditing] = useState<PackRow | "new" | null>(null);

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <p className="text-sm text-muted-foreground">
          A pack is what you sell on GamsGo: it grants credit and puts the buyer on exactly one plan. Approvals and vouchers always name a pack.
        </p>
        <Button size="sm" onClick={() => setEditing("new")} disabled={plans.length === 0}>
          <Plus /> New pack
        </Button>
      </div>

      <Card className="overflow-hidden py-0">
        {packs.length === 0 ? (
          <EmptyState icon={Package} title="No packs yet" description={plans.length ? "Create one pack per GamsGo offer and bind it to a plan." : "Create a plan first (Plans page), then add packs."} />
        ) : (
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Pack</TableHead>
                <TableHead>Grants</TableHead>
                <TableHead>Plan</TableHead>
                <TableHead>Listing</TableHead>
                <TableHead className="text-right">Customers</TableHead>
                <TableHead className="text-right">Codes live</TableHead>
                <TableHead>Active</TableHead>
                <TableHead className="w-[90px]" />
              </TableRow>
            </TableHeader>
            <TableBody>
              {packs.map((p) => (
                <PackRowItem key={p.id} pack={p} onEdit={() => setEditing(p)} />
              ))}
            </TableBody>
          </Table>
        )}
      </Card>

      {editing !== null && (
        <PackDialog
          pack={editing === "new" ? null : editing}
          plans={plans}
          open
          onClose={() => setEditing(null)}
          onSaved={() => {
            setEditing(null);
            router.refresh();
          }}
        />
      )}
    </div>
  );
}

function PackRowItem({ pack, onEdit }: { pack: PackRow; onEdit: () => void }) {
  const router = useRouter();
  const [pending, startTransition] = useTransition();
  return (
    <TableRow className={cn(!pack.active && "opacity-60")}>
      <TableCell className="font-medium">{pack.name}</TableCell>
      <TableCell className="text-sm">
        {formatCents(pack.balanceGrantCents)}
        {pack.bonusGrantCents > 0 && <span className="text-success"> + {formatCents(pack.bonusGrantCents)} bonus</span>}
      </TableCell>
      <TableCell className="text-sm text-muted-foreground">{pack.planName}</TableCell>
      <TableCell className="text-sm text-muted-foreground">
        {pack.listingPriceLabel || "—"}
        {pack.gamsgoOfferRef && <span className="block truncate font-mono text-[11px]">{pack.gamsgoOfferRef}</span>}
      </TableCell>
      <TableCell className="text-right tabular-nums">{pack.customers}</TableCell>
      <TableCell className="text-right tabular-nums">{pack.vouchersIssued}</TableCell>
      <TableCell>
        <Switch
          checked={pack.active}
          disabled={pending}
          onCheckedChange={(v) =>
            startTransition(async () => {
              const r = await setPackActiveAction(pack.id, v);
              if (r.ok) router.refresh();
              else toast.error(r.error);
            })
          }
          aria-label={`${pack.active ? "Deactivate" : "Activate"} ${pack.name}`}
        />
      </TableCell>
      <TableCell>
        <div className="flex items-center justify-end gap-1">
          <Button variant="ghost" size="icon-sm" onClick={onEdit} aria-label="Edit pack">
            <Pencil />
          </Button>
          <ConfirmDialog
            trigger={
              <Button variant="ghost" size="icon-sm" className="text-destructive hover:text-destructive" aria-label="Delete pack">
                <Trash2 />
              </Button>
            }
            title={`Delete pack "${pack.name}"?`}
            description="Customers and redeemed vouchers keep their history; the pack disappears from pickers. Packs with unredeemed codes cannot be deleted."
            confirmLabel="Delete pack"
            destructive
            onConfirm={async () => {
              const r = await deletePackAction(pack.id);
              if (r.ok) {
                toast.success("Pack deleted");
                router.refresh();
              } else toast.error(r.error);
            }}
          />
        </div>
      </TableCell>
    </TableRow>
  );
}

function PackDialog({ pack, plans, open, onClose, onSaved }: { pack: PackRow | null; plans: PlanChoice[]; open: boolean; onClose: () => void; onSaved: () => void }) {
  const [pending, startTransition] = useTransition();
  const [form, setForm] = useState({
    name: pack?.name ?? "",
    planId: pack?.planId ?? "",
    balanceGrantUsd: pack ? String(pack.balanceGrantCents / 100) : "",
    bonusGrantUsd: pack && pack.bonusGrantCents > 0 ? String(pack.bonusGrantCents / 100) : "",
    listingPriceLabel: pack?.listingPriceLabel ?? "",
    gamsgoOfferRef: pack?.gamsgoOfferRef ?? "",
    active: pack?.active ?? true,
    sortOrder: String(pack?.sortOrder ?? 0),
  });
  const set = <K extends keyof typeof form>(k: K) => (v: (typeof form)[K]) => setForm((f) => ({ ...f, [k]: v }));

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    startTransition(async () => {
      const input: PackInput = {
        name: form.name,
        planId: form.planId,
        balanceGrantUsd: Number(form.balanceGrantUsd) || 0,
        bonusGrantUsd: Number(form.bonusGrantUsd) || 0,
        listingPriceLabel: form.listingPriceLabel,
        gamsgoOfferRef: form.gamsgoOfferRef,
        active: form.active,
        sortOrder: Number(form.sortOrder) || 0,
      };
      const r = await savePackAction(pack?.id ?? null, input);
      if (r.ok) {
        toast.success(pack ? "Pack updated" : "Pack created");
        onSaved();
      } else toast.error(r.error);
    });
  };

  return (
    <Dialog open={open} onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="sm:max-w-lg">
        <form onSubmit={submit} className="space-y-4">
          <DialogHeader>
            <DialogTitle>{pack ? "Edit pack" : "New pack"}</DialogTitle>
            <DialogDescription>One pack per GamsGo offer. The plan decides the billing rate and limits; the grants are what the buyer receives.</DialogDescription>
          </DialogHeader>
          <div className="grid gap-3 sm:grid-cols-2">
            <div className="space-y-1.5 sm:col-span-2">
              <Label htmlFor="pack-name">Name</Label>
              <Input id="pack-name" value={form.name} onChange={(e) => set("name")(e.target.value)} placeholder="Starter $100" required />
            </div>
            <div className="space-y-1.5 sm:col-span-2">
              <Label htmlFor="pack-plan">Plan</Label>
              <Select value={form.planId} onValueChange={set("planId")}>
                <SelectTrigger id="pack-plan" className="w-full">
                  <SelectValue placeholder="Choose a plan" />
                </SelectTrigger>
                <SelectContent>
                  {plans.map((p) => (
                    <SelectItem key={p.id} value={p.id}>
                      {p.name} (${(p.priceCents / 100).toFixed(0)}){p.isActive ? "" : " — inactive"}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="pack-balance">Balance granted (USD)</Label>
              <Input id="pack-balance" type="number" min={0} step="0.01" value={form.balanceGrantUsd} onChange={(e) => set("balanceGrantUsd")(e.target.value)} placeholder="100" />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="pack-bonus">Bonus granted (USD)</Label>
              <Input id="pack-bonus" type="number" min={0} step="0.01" value={form.bonusGrantUsd} onChange={(e) => set("bonusGrantUsd")(e.target.value)} placeholder="0" />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="pack-label">Listing price (display)</Label>
              <Input id="pack-label" value={form.listingPriceLabel} onChange={(e) => set("listingPriceLabel")(e.target.value)} placeholder="$100 on GamsGo" />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="pack-ref">GamsGo offer reference</Label>
              <Input id="pack-ref" value={form.gamsgoOfferRef} onChange={(e) => set("gamsgoOfferRef")(e.target.value)} placeholder="offer URL or id (optional)" />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="pack-sort">Sort order</Label>
              <Input id="pack-sort" type="number" min={0} value={form.sortOrder} onChange={(e) => set("sortOrder")(e.target.value)} />
            </div>
            <div className="flex items-center gap-2 pt-6">
              <Switch id="pack-active" checked={form.active} onCheckedChange={set("active")} />
              <Label htmlFor="pack-active">Active</Label>
            </div>
          </div>
          <DialogFooter>
            <Button type="button" variant="outline" onClick={onClose} disabled={pending}>
              Cancel
            </Button>
            <Button type="submit" disabled={pending || !form.planId}>
              {pending && <Loader2 className="animate-spin" />}
              {pack ? "Save" : "Create pack"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}
