"use client";

import { useEffect } from "react";
import { useRouter } from "next/navigation";
import { PERIODS, type PeriodKey } from "@/lib/periods";
import { cn } from "@/lib/utils";

/**
 * Segmented period control for Analytics. "Live" auto-refreshes the page
 * every 15 seconds so the numbers keep moving without a manual reload.
 */
export function PeriodSwitcher({ active }: { active: PeriodKey }) {
  const router = useRouter();

  useEffect(() => {
    if (active !== "live") return;
    const interval = setInterval(() => router.refresh(), 15_000);
    return () => clearInterval(interval);
  }, [active, router]);

  return (
    <div className="inline-flex items-center gap-1 rounded-xl border bg-muted/40 p-1" role="tablist" aria-label="Analytics period">
      {PERIODS.map((period) => {
        const isActive = active === period.key;
        return (
          <button
            key={period.key}
            type="button"
            role="tab"
            aria-selected={isActive}
            onClick={() => router.replace(`/admin/analytics?period=${period.key}`, { scroll: false })}
            className={cn(
              "flex items-center gap-1.5 rounded-lg px-3.5 py-1.5 text-sm font-medium transition-colors",
              isActive ? "bg-primary/15 text-primary ring-1 ring-primary/30" : "text-muted-foreground hover:text-foreground"
            )}
          >
            {period.key === "live" ? (
              <span className={cn("size-1.5 rounded-full", isActive ? "animate-pulse bg-success" : "bg-muted-foreground/50")} />
            ) : null}
            {period.label}
          </button>
        );
      })}
    </div>
  );
}
