"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { CreditCard, Loader2, Pencil, Plus, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Textarea } from "@/components/ui/textarea";
import { ConfirmDialog } from "@/components/shared/confirm-dialog";
import { EmptyState } from "@/components/shared/empty-state";
import { cn } from "@/lib/utils";
import { describeBonusWorth, describePlanLimit, describePlanRate, planRate, type PlanLike, type PlanLimitType } from "@/lib/plan-usage";
import { rateToNumber } from "@/lib/billing/pricing-engine";
import { deletePlanAction, savePlanAction, setDefaultPlanAction, setPlanActiveAction, type PlanInput } from "@/app/admin/(dashboard)/plans/actions";

export interface PlanRow {
  id: string;
  name: string;
  description: string;
  priceCents: number;
  /** Profit recorded for every purchase of this plan. */
  profitCents: number;
  /** Net plan profit recorded so far (reversals included). */
  profitRecordedCents: number;
  /** Purchases that recorded a profit. */
  purchases: number;
  limitType: PlanLimitType;
  limitUsageCents: number;
  limitMTokens: number;
  /** Bonus credited on every purchase, and the real usage it is worth (0 = same rate as the balance). */
  bonusCents: number;
  bonusLimitUsageCents: number;
  bonusLimitMTokens: number;
  isActive: boolean;
  sortOrder: number;
  rpm: number | null;
  maxConcurrent: number | null;
  customers: number;
}

const usd = (cents: number) => `$${(cents / 100).toFixed(cents % 100 === 0 ? 0 : 2)}`;

const NO_DEFAULT = "__none__";

export function PlansView({
  plans,
  globalMultiplier,
  defaultPlanId,
  customersWithoutPlan,
}: {
  plans: PlanRow[];
  globalMultiplier: number;
  /** "" = customers without a plan pay provider cost × globalMultiplier. */
  defaultPlanId: string;
  customersWithoutPlan: number;
}) {
  const router = useRouter();
  const [editing, setEditing] = useState<PlanRow | "new" | null>(null);
  const [savingDefault, startDefault] = useTransition();
  const activePlans = plans.filter((p) => p.isActive && planRate(p) !== null);
  const currentDefault = activePlans.some((p) => p.id === defaultPlanId) ? defaultPlanId : "";

  const changeDefault = (v: string) =>
    startDefault(async () => {
      const r = await setDefaultPlanAction(v === NO_DEFAULT ? "" : v);
      if (r.ok) {
        toast.success("Default plan updated");
        router.refresh();
      } else toast.error(r.error);
    });

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-end justify-between gap-3">
        <div className="grid gap-1.5">
          <Label>Default plan for customers without one ({customersWithoutPlan})</Label>
          <div className="flex items-center gap-2">
            <Select value={currentDefault || NO_DEFAULT} onValueChange={changeDefault} disabled={savingDefault}>
              <SelectTrigger className="w-72">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value={NO_DEFAULT}>None — provider cost ×{globalMultiplier}</SelectItem>
                {activePlans.map((p) => (
                  <SelectItem key={p.id} value={p.id}>
                    {p.name} — {describePlanRate(p).split(" — ")[0]}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {savingDefault ? <Loader2 className="size-4 animate-spin text-muted-foreground" /> : null}
          </div>
          <p className="text-xs text-muted-foreground">
            Example: a $100 plan that includes $2 of real usage bills ×50 — a request that costs $0.50 upstream is charged $25 and the balance goes
            from $100 to $75.
          </p>
        </div>
        <Button size="sm" onClick={() => setEditing("new")}>
          <Plus /> New plan
        </Button>
      </div>

      <Card className="overflow-hidden py-0">
        {plans.length === 0 ? (
          <EmptyState
            icon={CreditCard}
            title="No plans yet"
            description="Create your $100, $200 … $1000 plans here and say how much real API usage each one buys."
            className="py-12"
          />
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="hover:bg-transparent">
                  <TableHead>Plan</TableHead>
                  <TableHead className="text-right">Price</TableHead>
                  <TableHead className="text-right" title="Profit recorded for every purchase of the plan">Profit / purchase</TableHead>
                  <TableHead className="text-right" title="Plan profit recorded so far (after clawbacks)">Profit recorded</TableHead>
                  <TableHead>Includes</TableHead>
                  <TableHead>Effective rate</TableHead>
                  <TableHead title="Bonus credited on every purchase, and what it is worth in real API usage">Bonus</TableHead>
                  <TableHead className="text-right">Customers</TableHead>
                  <TableHead>Active</TableHead>
                  <TableHead className="text-right" />
                </TableRow>
              </TableHeader>
              <TableBody>
                {plans.map((p) => (
                  <PlanTableRow key={p.id} plan={p} isDefault={p.id === currentDefault} onEdit={() => setEditing(p)} />
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </Card>

      <PlanDialog
        key={editing === "new" ? "plan-new" : `plan-${editing?.id ?? "closed"}`}
        plan={editing === "new" ? null : editing}
        open={editing !== null}
        onClose={() => setEditing(null)}
        onSaved={() => {
          setEditing(null);
          router.refresh();
        }}
      />
    </div>
  );
}

function PlanTableRow({ plan, isDefault, onEdit }: { plan: PlanRow; isDefault: boolean; onEdit: () => void }) {
  const router = useRouter();
  const [pending, startTransition] = useTransition();
  const misconfigured = planRate(plan) === null;

  const toggle = (v: boolean) =>
    startTransition(async () => {
      const r = await setPlanActiveAction(plan.id, v);
      if (r.ok) router.refresh();
      else toast.error(r.error);
    });

  return (
    <TableRow className={cn(!plan.isActive && "opacity-60")}>
      <TableCell>
        <p className="flex items-center gap-2 font-medium">
          {plan.name}
          {isDefault ? <span className="rounded-full bg-primary/12 px-2 py-0.5 text-[10px] font-semibold text-primary uppercase">Default</span> : null}
        </p>
        {plan.description ? <p className="text-xs text-muted-foreground">{plan.description}</p> : null}
      </TableCell>
      <TableCell className="text-right font-medium tabular-nums">{usd(plan.priceCents)}</TableCell>
      <TableCell className="text-right tabular-nums">
        {plan.profitCents > 0 ? <span className="font-medium text-success">{usd(plan.profitCents)}</span> : <span className="text-muted-foreground">—</span>}
        {plan.profitCents > 0 ? <p className="text-[11px] text-muted-foreground">{Math.round((plan.profitCents / plan.priceCents) * 100)}% of price</p> : null}
      </TableCell>
      <TableCell className="text-right tabular-nums">
        <span className="font-medium">{usd(plan.profitRecordedCents)}</span>
        <p className="text-[11px] text-muted-foreground">{plan.purchases} purchase{plan.purchases === 1 ? "" : "s"}</p>
      </TableCell>
      <TableCell className="tabular-nums">{describePlanLimit(plan)}</TableCell>
      <TableCell className={cn("text-sm", misconfigured ? "text-destructive" : "text-muted-foreground")}>{describePlanRate(plan)}</TableCell>
      <TableCell className="text-sm tabular-nums">
        {plan.bonusCents > 0 ? (
          <>
            <span className="font-medium">{usd(plan.bonusCents)}</span>
            <p className="max-w-56 text-[11px] text-muted-foreground">= {describeBonusWorth(plan)}</p>
          </>
        ) : (
          <span className="text-muted-foreground">—</span>
        )}
      </TableCell>
      <TableCell className="text-right tabular-nums">{plan.customers}</TableCell>
      <TableCell>
        <Switch checked={plan.isActive} disabled={pending} onCheckedChange={toggle} aria-label={`Activate ${plan.name}`} />
      </TableCell>
      <TableCell className="text-right">
        <div className="flex justify-end gap-1">
          <Button variant="ghost" size="icon-sm" aria-label="Edit" onClick={onEdit}>
            <Pencil />
          </Button>
          <ConfirmDialog
            trigger={
              <Button variant="ghost" size="icon-sm" aria-label="Delete" className="text-destructive hover:text-destructive">
                <Trash2 />
              </Button>
            }
            title={`Delete "${plan.name}"?`}
            description={
              plan.customers > 0
                ? `${plan.customers} customer(s) are on this plan. They will be billed at the default plan (or the global multiplier) until you assign another plan.`
                : "This cannot be undone."
            }
            confirmLabel="Delete plan"
            destructive
            onConfirm={async () => {
              const r = await deletePlanAction(plan.id);
              if (r.ok) {
                toast.success("Plan deleted");
                router.refresh();
              } else toast.error(r.error);
            }}
          />
        </div>
      </TableCell>
    </TableRow>
  );
}

function PlanDialog({ plan, open, onClose, onSaved }: { plan: PlanRow | null; open: boolean; onClose: () => void; onSaved: () => void }) {
  const [pending, startTransition] = useTransition();
  const [form, setForm] = useState({
    name: plan?.name ?? "",
    description: plan?.description ?? "",
    priceUsd: plan ? String(plan.priceCents / 100) : "",
    profitUsd: plan && plan.profitCents > 0 ? String(plan.profitCents / 100) : "",
    limitType: (plan?.limitType ?? "USD") as PlanLimitType,
    limitUsageUsd: plan && plan.limitUsageCents > 0 ? String(plan.limitUsageCents / 100) : "",
    limitMTokens: plan && plan.limitMTokens > 0 ? String(plan.limitMTokens) : "",
    bonusUsd: plan && plan.bonusCents > 0 ? String(plan.bonusCents / 100) : "",
    bonusLimitUsageUsd: plan && plan.bonusLimitUsageCents > 0 ? String(plan.bonusLimitUsageCents / 100) : "",
    bonusLimitMTokens: plan && plan.bonusLimitMTokens > 0 ? String(plan.bonusLimitMTokens) : "",
    isActive: plan?.isActive ?? true,
    sortOrder: String(plan?.sortOrder ?? 0),
    rpm: plan?.rpm ? String(plan.rpm) : "",
    maxConcurrent: plan?.maxConcurrent ? String(plan.maxConcurrent) : "",
  });
  const set = <K extends keyof typeof form>(k: K) => (v: (typeof form)[K]) => setForm((f) => ({ ...f, [k]: v }));

  const draft: PlanLike = {
    priceCents: Math.round(Number(form.priceUsd) * 100) || 0,
    limitType: form.limitType,
    limitUsageCents: Math.round(Number(form.limitUsageUsd) * 100) || 0,
    limitMTokens: Number(form.limitMTokens) || 0,
    bonusCents: Math.round(Number(form.bonusUsd) * 100) || 0,
    bonusLimitUsageCents: Math.round(Number(form.bonusLimitUsageUsd) * 100) || 0,
    bonusLimitMTokens: Number(form.bonusLimitMTokens) || 0,
  };
  const preview = planRate(draft);
  const bonusWorth = describeBonusWorth(draft);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    startTransition(async () => {
      const input: PlanInput = {
        name: form.name,
        description: form.description,
        priceUsd: Number(form.priceUsd),
        profitUsd: form.profitUsd === "" ? 0 : Number(form.profitUsd),
        limitType: form.limitType,
        limitUsageUsd: form.limitUsageUsd === "" ? 0 : Number(form.limitUsageUsd),
        limitMTokens: form.limitMTokens === "" ? 0 : Number(form.limitMTokens),
        bonusUsd: form.bonusUsd === "" ? 0 : Number(form.bonusUsd),
        bonusLimitUsageUsd: form.bonusLimitUsageUsd === "" ? 0 : Number(form.bonusLimitUsageUsd),
        bonusLimitMTokens: form.bonusLimitMTokens === "" ? 0 : Number(form.bonusLimitMTokens),
        isActive: form.isActive,
        sortOrder: Number(form.sortOrder) || 0,
        rpm: Number(form.rpm) || 0,
        maxConcurrent: Number(form.maxConcurrent) || 0,
      };
      const r = await savePlanAction(plan?.id ?? null, input);
      if (r.ok) {
        toast.success(plan ? "Plan updated" : "Plan created");
        onSaved();
      } else toast.error(r.error);
    });
  };

  return (
    <Dialog open={open} onOpenChange={(v) => !v && onClose()}>
      <DialogContent className="flex max-h-[calc(100dvh-2rem)] flex-col gap-0 overflow-hidden p-0 sm:max-w-3xl">
        <form onSubmit={submit} className="flex min-h-0 flex-1 flex-col">
          <DialogHeader className="border-b px-6 pt-6 pr-12 pb-4">
            <DialogTitle>{plan ? `Edit ${plan.name}` : "New plan"}</DialogTitle>
            <DialogDescription>The price is what the customer pays; the limit is what that money buys through the API.</DialogDescription>
          </DialogHeader>

          {/* Only the fields scroll: the header and the Save button stay on screen. */}
          <div className="min-h-0 flex-1 space-y-7 overflow-y-auto overscroll-contain px-6 py-5">
            <FormSection title="Basics">
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-1.5">
                  <Label htmlFor="plan-name">Name</Label>
                  <Input id="plan-name" value={form.name} onChange={(e) => set("name")(e.target.value)} placeholder="Starter" maxLength={60} required autoFocus />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1.5">
                    <Label htmlFor="plan-price">Price (USD)</Label>
                    <Input id="plan-price" type="number" inputMode="decimal" min="0.01" step="0.01" value={form.priceUsd} onChange={(e) => set("priceUsd")(e.target.value)} placeholder="100" required />
                  </div>
                  <div className="space-y-1.5">
                    <Label htmlFor="plan-profit">Profit (USD)</Label>
                    <Input id="plan-profit" type="number" inputMode="decimal" min="0" step="0.01" value={form.profitUsd} onChange={(e) => set("profitUsd")(e.target.value)} placeholder="0" />
                  </div>
                </div>
                <div className="space-y-1.5 sm:col-span-2">
                  <Label htmlFor="plan-desc">Description (shown to the customer)</Label>
                  <Textarea id="plan-desc" value={form.description} onChange={(e) => set("description")(e.target.value)} maxLength={200} rows={2} placeholder="Best for daily coding with Claude Code" className="min-h-16" />
                </div>
                <div className="grid grid-cols-[7rem_1fr] items-end gap-4 sm:col-span-2">
                  <div className="space-y-1.5">
                    <Label htmlFor="plan-order">Sort order</Label>
                    <Input id="plan-order" type="number" inputMode="numeric" min="0" step="1" value={form.sortOrder} onChange={(e) => set("sortOrder")(e.target.value)} />
                  </div>
                  <div className="flex h-9 items-center gap-3">
                    <Switch id="plan-active" checked={form.isActive} onCheckedChange={set("isActive")} />
                    <Label htmlFor="plan-active">Active (can be assigned)</Label>
                  </div>
                </div>
              </div>
              <p className="mt-2 text-xs text-muted-foreground">
                Profit is recorded on every approved activation, recharge or voucher
                {Number(form.priceUsd) > 0 && Number(form.profitUsd) > 0 ? ` (${Math.round((Number(form.profitUsd) / Number(form.priceUsd)) * 100)}% of the price)` : ""}; changes apply to future purchases only.
              </p>
            </FormSection>

            <FormSection title="Usage limit">
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-1.5">
                  <Label>Limit measured in</Label>
                  <Select value={form.limitType} onValueChange={(v) => set("limitType")(v as PlanLimitType)}>
                    <SelectTrigger className="w-full"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="USD">Dollars of real API usage</SelectItem>
                      <SelectItem value="TOKENS">Million tokens</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                {form.limitType === "USD" ? (
                  <div className="space-y-1.5">
                    <Label htmlFor="plan-usage">Real API usage the plan buys (USD)</Label>
                    <Input id="plan-usage" type="number" inputMode="decimal" min="0.01" step="0.01" value={form.limitUsageUsd} onChange={(e) => set("limitUsageUsd")(e.target.value)} placeholder="5" required />
                  </div>
                ) : (
                  <div className="space-y-1.5">
                    <Label htmlFor="plan-tokens">Tokens included (millions)</Label>
                    <Input id="plan-tokens" type="number" inputMode="numeric" min="1" step="1" value={form.limitMTokens} onChange={(e) => set("limitMTokens")(e.target.value)} placeholder="50" required />
                  </div>
                )}
              </div>
              <p className="mt-2 text-xs text-muted-foreground">
                {form.limitType === "USD"
                  ? "What the provider (DeepInfra…) will actually bill you for this customer before their balance runs out."
                  : "Input and output tokens count the same, whatever the model. The balance reaches zero exactly at this limit."}
              </p>
              <div className="mt-3 rounded-lg border bg-muted/40 px-4 py-2.5 text-sm">
                {preview ? (
                  preview.kind === "perToken" ? (
                    <>Each token deducts <span className="font-medium">${(rateToNumber(preview) / 1_000_000).toFixed(8)}</span> — <span className="font-medium">${rateToNumber(preview).toFixed(2)} per 1M tokens</span> for every model.</>
                  ) : (
                    <>Rate <span className="font-medium">×{rateToNumber(preview).toFixed(2)}</span> — every $1 the provider charges deducts <span className="font-medium">${rateToNumber(preview).toFixed(2)}</span> from the customer&apos;s balance.</>
                  )
                ) : (
                  <span className="text-muted-foreground">Fill in the price and the limit to see the effective rate.</span>
                )}
              </div>
            </FormSection>

            <FormSection title="Bonus">
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-1.5">
                  <Label htmlFor="plan-bonus">Bonus per purchase (USD)</Label>
                  <Input id="plan-bonus" type="number" inputMode="decimal" min="0" step="0.01" value={form.bonusUsd} onChange={(e) => set("bonusUsd")(e.target.value)} placeholder="0" />
                </div>
                {form.limitType === "USD" ? (
                  <div className="space-y-1.5">
                    <Label htmlFor="plan-bonus-usage">Bonus real API usage (USD)</Label>
                    <Input id="plan-bonus-usage" type="number" inputMode="decimal" min="0" step="0.01" value={form.bonusLimitUsageUsd} onChange={(e) => set("bonusLimitUsageUsd")(e.target.value)} placeholder="0 = same rate as the balance" disabled={!(Number(form.bonusUsd) > 0)} />
                  </div>
                ) : (
                  <div className="space-y-1.5">
                    <Label htmlFor="plan-bonus-tokens">Bonus tokens (millions)</Label>
                    <Input id="plan-bonus-tokens" type="number" inputMode="numeric" min="0" step="1" value={form.bonusLimitMTokens} onChange={(e) => set("bonusLimitMTokens")(e.target.value)} placeholder="0 = same rate as the balance" disabled={!(Number(form.bonusUsd) > 0)} />
                  </div>
                )}
              </div>
              <p className="mt-2 text-xs text-muted-foreground">
                Added to the customer&apos;s bonus on every approved activation, recharge or voucher (0 = no bonus). The bonus real usage sets the rate the whole
                bonus balance is billed at; 0 = same rate as the balance.
              </p>
              {bonusWorth ? (
                <div className="mt-3 rounded-lg border bg-muted/40 px-4 py-2.5 text-sm">
                  Bonus <span className="font-medium">{usd(draft.bonusCents ?? 0)}</span> is worth <span className="font-medium">{bonusWorth}</span>.
                </div>
              ) : null}
            </FormSection>

            <FormSection title="Gateway limits">
              <div className="grid gap-4 sm:grid-cols-2">
                <div className="space-y-1.5">
                  <Label htmlFor="plan-rpm">Requests per minute</Label>
                  <Input id="plan-rpm" type="number" inputMode="numeric" min="0" step="1" value={form.rpm} onChange={(e) => set("rpm")(e.target.value)} placeholder="store default" />
                </div>
                <div className="space-y-1.5">
                  <Label htmlFor="plan-conc">Parallel requests</Label>
                  <Input id="plan-conc" type="number" inputMode="numeric" min="0" step="1" value={form.maxConcurrent} onChange={(e) => set("maxConcurrent")(e.target.value)} placeholder="store default" />
                </div>
              </div>
              <p className="mt-2 text-xs text-muted-foreground">
                Requests per minute count per token and per customer; parallel requests are streams open at once (extras get 429 and retry). Empty = the
                store default in Settings.
              </p>
            </FormSection>
          </div>

          <DialogFooter className="border-t bg-muted/30 px-6 py-4">
            <Button type="button" variant="outline" onClick={onClose} disabled={pending}>Cancel</Button>
            <Button type="submit" disabled={pending}>
              {pending ? <Loader2 className="animate-spin" /> : null} {plan ? "Save changes" : "Create plan"}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
}

/** A titled group of fields in the plan dialog. */
function FormSection({ title, children }: { title: string; children: React.ReactNode }) {
  return (
    <section>
      <h3 className="mb-3 flex items-center gap-3 text-xs font-semibold tracking-wide text-muted-foreground uppercase">
        {title}
        <span aria-hidden className="h-px flex-1 bg-border" />
      </h3>
      {children}
    </section>
  );
}
