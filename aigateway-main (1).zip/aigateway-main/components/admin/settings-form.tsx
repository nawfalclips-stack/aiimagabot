"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { ExternalLink, Loader2, Plus, Save, ShieldCheck, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { createGamsGoAdminAction, saveSettingsAction, type SettingsInput } from "@/app/admin/(dashboard)/settings/actions";
import { SOCIAL_PRESETS, detectSocialKind, type SocialLink } from "@/lib/social-links";
import { SocialIcon } from "@/components/shared/social-links";



interface SettingsFormProps {
  initial: {
    siteName: string;
    logoText: string;
    supportEmail: string;
    brandColor: string;
    footerText: string;
    lowBalanceThreshold: number;
    defaultCurrency: string;
    timezone: string;
    usageCostMultiplier: number;
    signupBalance: number;
    signupBonus: number;
    storeUrl: string;
    socialLinks: SocialLink[];
  };
}

export function SettingsForm({ initial }: SettingsFormProps) {
  const router = useRouter();
  const [pending, startTransition] = useTransition();
  const [gamsGoPending, startGamsGoTransition] = useTransition();
  const [form, setForm] = useState(initial);
  const set = <K extends keyof typeof form>(k: K) => (v: (typeof form)[K]) =>
    setForm((f) => ({ ...f, [k]: v }));

  const updateLink = (i: number, patch: Partial<SocialLink>) =>
    set("socialLinks")(form.socialLinks.map((l, idx) => (idx === i ? { ...l, ...patch } : l)));
  const removeLink = (i: number) => set("socialLinks")(form.socialLinks.filter((_, idx) => idx !== i));
  const addLink = (label = "", url = "") => set("socialLinks")([...form.socialLinks, { label, url }]);

  const save = (e: React.FormEvent) => {
    e.preventDefault();
    startTransition(async () => {
      const result = await saveSettingsAction(form as SettingsInput);
      if (result.ok) {
        toast.success("Settings saved");
        router.refresh();
      } else {
        toast.error(result.error);
      }
    });
  };

  const createGamsGoAdmin = () => {
    startGamsGoTransition(async () => {
      const result = await createGamsGoAdminAction();
      if (result.ok) {
        toast.success("GamsGo inspector account ready", {
          description: "Email: sellerjoin@gamsgo.com · Password: aerolink2026",
        });
      } else {
        toast.error(result.error);
      }
    });
  };

  return (
    <form onSubmit={save} className="space-y-6">
      {/* Branding */}
      <Card>
        <CardHeader>
          <CardTitle>Branding</CardTitle>
          <CardDescription>Customise how the platform looks to customers.</CardDescription>
        </CardHeader>
        <CardContent className="grid gap-4 sm:grid-cols-2">
          <div className="space-y-2">
            <Label htmlFor="siteName">Website name</Label>
            <Input id="siteName" value={form.siteName} onChange={(e) => set("siteName")(e.target.value)} required />
          </div>
          <div className="space-y-2">
            <Label htmlFor="logoText">Logo text</Label>
            <Input id="logoText" value={form.logoText} onChange={(e) => set("logoText")(e.target.value)} required />
          </div>
          <div className="space-y-2">
            <Label htmlFor="brandColor">Brand colour (hex)</Label>
            <div className="flex gap-2">
              <Input id="brandColor" value={form.brandColor} onChange={(e) => set("brandColor")(e.target.value)} required />
              <input type="color" value={form.brandColor} onChange={(e) => set("brandColor")(e.target.value)} className="h-9 w-12 cursor-pointer rounded-md border" />
            </div>
          </div>
          <div className="space-y-2">
            <Label htmlFor="footerText">Footer text</Label>
            <Input id="footerText" value={form.footerText} onChange={(e) => set("footerText")(e.target.value)} />
          </div>
          <div className="space-y-2 sm:col-span-2">
            <Label htmlFor="storeUrl">Store URL (GamsGo link)</Label>
            <div className="flex gap-2">
              <Input id="storeUrl" type="url" value={form.storeUrl} onChange={(e) => set("storeUrl")(e.target.value)} required />
              <Button asChild type="button" variant="outline" disabled={!form.storeUrl}>
                <a href={form.storeUrl || undefined} target="_blank" rel="noopener noreferrer">
                  <ExternalLink /> Open
                </a>
              </Button>
            </div>
            <p className="text-xs text-muted-foreground">
              Every &quot;Buy&quot;, &quot;Renew&quot;, &quot;Recharge&quot; and &quot;Contact us&quot; link in the customer portal, the landing, login and
              redeem pages, and the support bot replies points here. Saved per store — the public pages use the AeroLink store&apos;s link.
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Business rules */}
      <Card>
        <CardHeader>
          <CardTitle>Business rules</CardTitle>
          <CardDescription>Billing, thresholds, and new-customer defaults.</CardDescription>
        </CardHeader>
        <CardContent className="grid gap-4 sm:grid-cols-2">
          <div className="space-y-2">
            <Label htmlFor="supportEmail">Support email</Label>
            <Input id="supportEmail" type="email" value={form.supportEmail} onChange={(e) => set("supportEmail")(e.target.value)} required />
          </div>
          <div className="space-y-2">
            <Label htmlFor="usageCostMultiplier">Usage cost multiplier (customers without a plan)</Label>
            <Input id="usageCostMultiplier" type="number" inputMode="decimal" min="0.1" step="0.01"
              value={form.usageCostMultiplier} onChange={(e) => set("usageCostMultiplier")(Number(e.target.value))} required />
          </div>
          <div className="space-y-2">
            <Label htmlFor="lowBalanceThreshold">Low-balance threshold (USD)</Label>
            <Input id="lowBalanceThreshold" type="number" inputMode="decimal" min="0" step="0.01"
              value={form.lowBalanceThreshold} onChange={(e) => set("lowBalanceThreshold")(Number(e.target.value))} required />
          </div>
          <div className="space-y-2">
            <Label htmlFor="defaultCurrency">Currency code</Label>
            <Input id="defaultCurrency" value={form.defaultCurrency} onChange={(e) => set("defaultCurrency")(e.target.value.toUpperCase())} maxLength={3} required />
          </div>
          <div className="space-y-2">
            <Label htmlFor="signupBalance">Default signup balance (USD)</Label>
            <Input id="signupBalance" type="number" inputMode="decimal" min="0" step="0.01"
              value={form.signupBalance} onChange={(e) => set("signupBalance")(Number(e.target.value))} required />
          </div>
          <div className="space-y-2">
            <Label htmlFor="signupBonus">Default signup bonus (USD)</Label>
            <Input id="signupBonus" type="number" inputMode="decimal" min="0" step="0.01"
              value={form.signupBonus} onChange={(e) => set("signupBonus")(Number(e.target.value))} required />
          </div>
        </CardContent>
      </Card>

      {/* Social links */}
      <Card>
        <CardHeader>
          <CardTitle>Social links</CardTitle>
          <CardDescription>
            Shown in the footer of the public pages and the customer portal. Leave the list empty and nothing is shown.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex flex-wrap gap-2">
            {SOCIAL_PRESETS.map((p) => (
              <Button
                key={p.kind}
                type="button"
                variant="outline"
                size="sm"
                disabled={form.socialLinks.length >= 12}
                onClick={() => addLink(p.label, p.placeholder)}
              >
                <SocialIcon kind={p.kind} className="size-3.5" /> {p.label}
              </Button>
            ))}
            <Button type="button" variant="ghost" size="sm" disabled={form.socialLinks.length >= 12} onClick={() => addLink()}>
              <Plus /> Custom
            </Button>
          </div>
          {form.socialLinks.length === 0 ? (
            <p className="text-sm text-muted-foreground">No links yet — pick a network above to add one.</p>
          ) : (
            <div className="space-y-2">
              {form.socialLinks.map((link, i) => (
                <div key={i} className="grid gap-2 sm:grid-cols-[auto_minmax(0,1fr)_minmax(0,2fr)_auto] sm:items-center">
                  <span className="hidden text-muted-foreground sm:block">
                    <SocialIcon kind={detectSocialKind(link)} className="size-4" />
                  </span>
                  <Input
                    aria-label="Label"
                    placeholder="Label (e.g. Telegram)"
                    value={link.label}
                    maxLength={40}
                    onChange={(e) => updateLink(i, { label: e.target.value })}
                  />
                  <Input
                    aria-label="Link"
                    placeholder="https://…"
                    value={link.url}
                    maxLength={500}
                    onChange={(e) => updateLink(i, { url: e.target.value })}
                  />
                  <Button type="button" variant="ghost" size="icon-sm" aria-label="Remove link" className="text-destructive hover:text-destructive" onClick={() => removeLink(i)}>
                    <Trash2 />
                  </Button>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>


      {/* GamsGo inspector account */}
      <Card>
        <CardHeader>
          <CardTitle>GamsGo Inspector Account</CardTitle>
          <CardDescription>
            GamsGo requires a read-only admin account for periodic inspections. Click once to create it.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="rounded-lg border bg-muted/40 px-4 py-3 text-sm space-y-1">
            <p><span className="text-muted-foreground">Email:</span> <span className="font-mono">sellerjoin@gamsgo.com</span></p>
            <p><span className="text-muted-foreground">Password:</span> <span className="font-mono">aerolink2026</span></p>
          </div>
          <Button type="button" variant="outline" onClick={createGamsGoAdmin} disabled={gamsGoPending}>
            {gamsGoPending ? <Loader2 className="animate-spin" /> : <ShieldCheck />}
            Create / Reset GamsGo account
          </Button>
        </CardContent>
      </Card>

      <div className="flex justify-end">
        <Button type="submit" disabled={pending}>
          {pending ? <Loader2 className="animate-spin" /> : <Save />}
          Save settings
        </Button>
      </div>
    </form>
  );
}
