"use client";

import { Store } from "lucide-react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import type { StoreId } from "@/lib/store";
import { switchStoreAction } from "@/app/admin/actions";
import { useTransition } from "react";

interface StoreSwitcherProps {
  stores: Array<{ id: string; name: string; logoText: string }>;
  currentStoreId: string;
}

export function StoreSwitcher({ stores, currentStoreId }: StoreSwitcherProps) {
  const [isPending, startTransition] = useTransition();
  const currentStore = stores.find((s) => s.id === currentStoreId);

  if (stores.length <= 1) {
    return null; // Don't show switcher if only one store
  }

  const handleSwitch = (storeId: string) => {
    if (storeId === currentStoreId) return;

    startTransition(async () => {
      await switchStoreAction(storeId as StoreId);
    });
  };

  return (
    <DropdownMenu>
      <DropdownMenuTrigger asChild>
        <Button variant="outline" className="gap-2" disabled={isPending}>
          <Store className="size-4" />
          <span className="hidden sm:inline">{currentStore?.logoText || "Store"}</span>
        </Button>
      </DropdownMenuTrigger>
      <DropdownMenuContent align="end" className="w-56">
        <DropdownMenuLabel>Switch Store</DropdownMenuLabel>
        <DropdownMenuSeparator />
        {stores.map((store) => (
          <DropdownMenuItem
            key={store.id}
            onSelect={() => handleSwitch(store.id)}
            className={store.id === currentStoreId ? "bg-accent" : ""}
          >
            <div className="flex flex-1 items-center justify-between">
              <span>{store.name}</span>
              {store.id === currentStoreId && (
                <span className="text-xs text-muted-foreground">Current</span>
              )}
            </div>
          </DropdownMenuItem>
        ))}
      </DropdownMenuContent>
    </DropdownMenu>
  );
}
