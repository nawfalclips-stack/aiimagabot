"use client";

import { useMemo, useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { Check, ChevronsUpDown, ClipboardPaste, Loader2, ScrollText, Trash2, Upload } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Textarea } from "@/components/ui/textarea";
import { EmptyState } from "@/components/shared/empty-state";
import { ConfirmDialog } from "@/components/shared/confirm-dialog";
import { StatusBadge } from "@/components/shared/status-badge";
import { formatCents } from "@/lib/money";
import { parseUsageLogs, customerCostCents } from "@/lib/usage-parser";
import { addUsageLogsAction, deleteUsageLogAction } from "@/app/admin/(dashboard)/usage-logs/actions";
import { cn } from "@/lib/utils";
import { LocalTime } from "@/components/shared/local-time";

export interface UsageCustomerOption {
  id: string;
  accessCode: string;
  orderNumber: string;
  apiKey: string;
  status: string;
  remainingBalanceCents: number;
}

export interface UsageLogRow {
  id: string;
  happenedAt: string;
  keyLabel: string;
  model: string;
  tokens: string;
  costMicroUsd: number;
  latency: string;
  status: string;
}

interface UsageLogsViewProps {
  customers: UsageCustomerOption[];
  selected: UsageCustomerOption | null;
  logs: UsageLogRow[];
  multiplier: number;
}

export function UsageLogsView({ customers, selected, logs, multiplier }: UsageLogsViewProps) {
  const [pickerOpen, setPickerOpen] = useState(false);
  const [raw, setRaw] = useState("");
  const [pending, startTransition] = useTransition();
  const [customMultiplier, setCustomMultiplier] = useState<number>(multiplier);
  const router = useRouter();

  const preview = useMemo(() => (raw.trim() ? parseUsageLogs(raw) : []), [raw]);
  const previewTotalMicro = preview.reduce((sum, r) => sum + Math.round(r.costUsd * 1_000_000), 0);
  const previewDeductCents = customerCostCents(previewTotalMicro, customMultiplier);

  const submit = () => {
    if (!selected || preview.length === 0 || pending) return;
    startTransition(async () => {
      const result = await addUsageLogsAction(selected.id, raw, customMultiplier);
      if (result.ok && result.data) {
        toast.success(`${result.data.added} usage rows added`, {
          description: `${formatCents(result.data.deductedCents)} deducted from ${selected.accessCode}.`,
        });
        setRaw("");
        router.refresh();
      } else if (!result.ok) {
        toast.error(result.error);
      }
    });
  };

  return (
    <div className="space-y-6">
      {/* Customer picker + paste area */}
      <Card>
        <CardHeader>
          <CardTitle>Import usage</CardTitle>
          <CardDescription>
            Select a customer and paste their usage rows to import. Add at most 1000 rows at a time.
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex flex-col gap-3 sm:flex-row sm:items-center">
            <Popover open={pickerOpen} onOpenChange={setPickerOpen}>
              <PopoverTrigger asChild>
                <Button variant="outline" role="combobox" aria-expanded={pickerOpen} className="w-full justify-between sm:w-80">
                  {selected ? (
                    <span className="flex items-center gap-2 truncate">
                      <span className="font-mono text-[13px]">{selected.accessCode}</span>
                      <span className="truncate text-xs text-muted-foreground">{selected.orderNumber}</span>
                    </span>
                  ) : (
                    "Select a customer…"
                  )}
                  <ChevronsUpDown className="ml-2 size-4 shrink-0 opacity-50" />
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-80 p-0" align="start">
                <Command>
                  <CommandInput placeholder="Search access code or order…" />
                  <CommandList>
                    <CommandEmpty>No customers found.</CommandEmpty>
                    <CommandGroup>
                      {customers.map((c) => (
                        <CommandItem
                          key={c.id}
                          value={`${c.accessCode} ${c.orderNumber} ${c.apiKey}`}
                          onSelect={() => {
                            setPickerOpen(false);
                            router.push(`/admin/usage-logs?customer=${c.id}`);
                          }}
                        >
                          <Check className={cn("size-4", selected?.id === c.id ? "opacity-100" : "opacity-0")} />
                          <div className="flex min-w-0 flex-1 items-center justify-between gap-2">
                            <div className="min-w-0">
                              <p className="truncate font-mono text-[13px]">{c.accessCode}</p>
                              <p className="truncate text-xs text-muted-foreground">{c.orderNumber || c.apiKey.slice(0, 20) || "—"}</p>
                            </div>
                            <span className={cn("text-xs tabular-nums", c.remainingBalanceCents < 0 ? "text-destructive" : "text-muted-foreground")}>
                              {formatCents(c.remainingBalanceCents)}
                            </span>
                          </div>
                        </CommandItem>
                      ))}
                    </CommandGroup>
                  </CommandList>
                </Command>
              </PopoverContent>
            </Popover>
            {selected ? (
              <div className="flex items-center gap-3 text-sm">
                <StatusBadge status={selected.status} />
                <span className={cn("tabular-nums", selected.remainingBalanceCents < 0 ? "text-destructive" : "text-muted-foreground")}>
                  Remaining: {formatCents(selected.remainingBalanceCents)}
                </span>
              </div>
            ) : null}
          </div>

          {/* Multiplier selector */}
          <div className="flex flex-wrap items-center gap-2">
            <span className="text-xs font-medium text-muted-foreground">Cost rate:</span>
            {[1.8, 2.2, 3, 4].map((m) => (
              <button
                key={m}
                type="button"
                onClick={() => setCustomMultiplier(m)}
                className={`rounded-md border px-3 py-1 text-xs font-semibold transition-colors ${
                  customMultiplier === m
                    ? "border-primary bg-primary/12 text-primary"
                    : "border-border bg-muted/40 text-muted-foreground hover:border-primary/40 hover:text-foreground"
                }`}
              >
                ×{m}
              </button>
            ))}
          </div>

          <Textarea
            value={raw}
            onChange={(e) => setRaw(e.target.value)}
            placeholder={"01:07:46 AM\nme\tclaude-fable-5\tin2 out1 540 read0 w5m410 687 w1h0\t$5.2200\t35.9s\t200"}
            rows={6}
            spellCheck={false}
            className="font-mono text-[12.5px]"
            aria-label="Paste usage rows"
            disabled={!selected}
          />

          {/* Live preview */}
          {preview.length > 0 ? (
            <div className="rounded-lg border">
              <div className="flex flex-wrap items-center justify-between gap-2 border-b bg-muted/40 px-4 py-2.5 text-sm">
                <span className="flex items-center gap-2 font-medium">
                  <ClipboardPaste className="size-4 text-primary" />
                  {preview.length} {preview.length === 1 ? "row" : "rows"} recognized
                </span>
                <span className="text-muted-foreground">
                  {preview.length} rows · total deducted{" "}
                  <span className="font-semibold text-destructive">{formatCents(previewDeductCents)}</span>
                </span>
              </div>
              <div className="max-h-48 overflow-auto">
                <Table>
                  <TableBody>
                    {preview.map((row, i) => (
                      <TableRow key={i} className="hover:bg-transparent">
                        <TableCell className="pl-4 whitespace-nowrap text-xs text-muted-foreground">
                          {new Date(row.happenedAt).toLocaleTimeString()}
                        </TableCell>
                        <TableCell className="text-xs">{row.keyLabel}</TableCell>
                        <TableCell className="font-mono text-xs">{row.model}</TableCell>
                        <TableCell className="max-w-56 truncate font-mono text-xs text-muted-foreground">{row.tokens}</TableCell>
                        <TableCell className="text-xs tabular-nums">{formatCents(customerCostCents(Math.round(row.costUsd * 1_000_000), multiplier))}</TableCell>
                        <TableCell className="text-xs text-muted-foreground">{row.latency}</TableCell>
                        <TableCell className="pr-4 text-xs">{row.status}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </div>
            </div>
          ) : raw.trim() ? (
            <p className="text-sm text-destructive">No rows recognized yet — paste the rows exactly as copied.</p>
          ) : null}

          <div className="flex justify-end">
            <Button onClick={submit} disabled={!selected || preview.length === 0 || pending}>
              {pending ? <Loader2 className="animate-spin" /> : <Upload />}
              Save {preview.length > 0 ? `${preview.length} rows` : ""} & deduct{" "}
              {preview.length > 0 ? formatCents(previewDeductCents) : ""}
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Existing logs for the selected customer */}
      <Card className="overflow-hidden p-0">
        <div className="border-b px-5 py-4">
          <h2 className="text-sm font-semibold">
            {selected ? `Usage logs — ${selected.accessCode}` : "Usage logs"}
          </h2>
          <p className="text-xs text-muted-foreground">
            {selected
              ? `Logs for ${selected.accessCode}. Deleting a row refunds its cost.`
              : "Select a customer to view their logs."}
          </p>
        </div>
        {!selected || logs.length === 0 ? (
          <EmptyState
            icon={ScrollText}
            title={selected ? "No usage logs yet" : "No customer selected"}
            description={selected ? "Rows you import above will appear here and in the customer's portal." : undefined}
            className="border-0"
          />
        ) : (
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow className="hover:bg-transparent">
                  <TableHead className="pl-4">Time</TableHead>
                  <TableHead>Key</TableHead>
                  <TableHead>Model</TableHead>
                  <TableHead>Tokens</TableHead>
                  <TableHead>Cost</TableHead>
                  <TableHead>Latency</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="pr-4 text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {logs.map((log) => (
                  <TableRow key={log.id}>
                    <TableCell className="pl-4 whitespace-nowrap text-muted-foreground">
                      <LocalTime date={log.happenedAt} variant="log" />
                    </TableCell>
                    <TableCell>{log.keyLabel || "—"}</TableCell>
                    <TableCell className="font-mono text-[13px]">{log.model || "—"}</TableCell>
                    <TableCell className="max-w-64 truncate font-mono text-xs text-muted-foreground">{log.tokens || "—"}</TableCell>
                    <TableCell className="tabular-nums font-medium">
                      {formatCents(customerCostCents(log.costMicroUsd, multiplier))}
                    </TableCell>
                    <TableCell className="text-muted-foreground">{log.latency || "—"}</TableCell>
                    <TableCell>{log.status || "—"}</TableCell>
                    <TableCell className="pr-4 text-right">
                      <ConfirmDialog
                        trigger={
                          <Button variant="ghost" size="icon-sm" className="text-muted-foreground hover:text-destructive" aria-label="Delete usage log">
                            <Trash2 />
                          </Button>
                        }
                        title="Delete this usage row?"
                        description={`Its cost (${formatCents(customerCostCents(log.costMicroUsd, multiplier))}) will be refunded to the customer's balance.`}
                        confirmLabel="Delete & refund"
                        destructive
                        onConfirm={async () => {
                          const result = await deleteUsageLogAction(log.id);
                          if (result.ok) {
                            toast.success("Usage log removed and refunded");
                            router.refresh();
                          } else toast.error(result.error);
                        }}
                      />
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        )}
      </Card>
    </div>
  );
}
