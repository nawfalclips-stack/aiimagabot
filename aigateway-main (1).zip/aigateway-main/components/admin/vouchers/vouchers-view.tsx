"use client";

import { useState, useTransition } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { AlertTriangle, Copy, Download, FileText, Loader2, Plus, Search, Ticket, Upload } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Switch } from "@/components/ui/switch";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Textarea } from "@/components/ui/textarea";
import { EmptyState } from "@/components/shared/empty-state";
import { LocalTime } from "@/components/shared/local-time";
import { useCopy } from "@/hooks/use-copy";
import { cn } from "@/lib/utils";
import {
  clawbackVoucherAction,
  generateBatchAction,
  listingTextAction,
  lookupVouchersAction,
  markUploadedAction,
  revokeBatchAction,
  revokeVoucherAction,
  updateBatchExpiryAction,
  type GeneratedBatch,
  type VoucherLookupResult,
} from "@/app/admin/(dashboard)/vouchers/actions";

export interface StockRow {
  packId: string;
  packName: string;
  active: boolean;
  uploadedUnredeemed: number;
  generatedNotUploaded: number;
  redeemedLast7Days: number;
  daysOfStockLeft: number | null;
  low: boolean;
}

export interface BatchRow {
  id: string;
  packName: string;
  quantity: number;
  issued: number;
  redeemed: number;
  revoked: number;
  expired: number;
  createdAt: string;
  createdBy: string;
  markedUploadedAt: string | null;
  expiresAt: string | null;
  compromisedAt: string | null;
  note: string;
}

export interface PackChoice {
  id: string;
  name: string;
  active: boolean;
}

interface Props {
  stock: StockRow[];
  batches: BatchRow[];
  packs: PackChoice[];
  defaultExpiryMonths: number;
  pepperConfigured: boolean;
  canWrite: boolean;
}

export function VouchersView({ stock, batches, packs, defaultExpiryMonths, pepperConfigured, canWrite }: Props) {
  const [generateOpen, setGenerateOpen] = useState(false);
  const [generated, setGenerated] = useState<GeneratedBatch | null>(null);

  return (
    <div className="space-y-6">
      {!pepperConfigured && (
        <div className="flex items-start gap-2 rounded-xl border border-destructive/30 bg-destructive/10 px-4 py-3 text-sm text-destructive">
          <AlertTriangle className="mt-0.5 size-4 shrink-0" />
          <span>
            <strong>VOUCHER_PEPPER is not set on the server.</strong> Codes cannot be generated or redeemed until it is (see docs/vouchers.md).
          </span>
        </div>
      )}

      {/* Stock */}
      <section className="space-y-3">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <h2 className="text-base font-semibold">Stock per pack</h2>
          {canWrite && (
            <Button size="sm" onClick={() => setGenerateOpen(true)} disabled={!pepperConfigured || packs.filter((p) => p.active).length === 0}>
              <Plus /> Generate codes
            </Button>
          )}
        </div>
        {stock.length === 0 ? (
          <Card>
            <EmptyState icon={Ticket} title="No packs yet" description="Create a pack first (Packs page), then generate voucher codes for it." />
          </Card>
        ) : (
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {stock.map((s) => (
              <Card key={s.packId} className={cn("gap-2 py-4", s.low && "border-warning/40 bg-warning/5", !s.active && "opacity-60")}>
                <CardHeader className="pb-0">
                  <CardTitle className="flex items-center justify-between text-sm">
                    <span className="truncate">{s.packName}</span>
                    {s.low && (
                      <span className="inline-flex items-center gap-1 rounded-full border border-warning/30 bg-warning/12 px-2 py-0.5 text-[10px] font-semibold uppercase text-warning">
                        <AlertTriangle className="size-3" /> Low stock
                      </span>
                    )}
                  </CardTitle>
                </CardHeader>
                <CardContent className="grid grid-cols-2 gap-x-3 gap-y-1 text-xs">
                  <span className="text-muted-foreground">On GamsGo, unredeemed</span>
                  <span className="text-right text-base font-semibold tabular-nums">{s.uploadedUnredeemed}</span>
                  <span className="text-muted-foreground">Generated, not uploaded</span>
                  <span className="text-right tabular-nums">{s.generatedNotUploaded}</span>
                  <span className="text-muted-foreground">Redeemed, last 7 days</span>
                  <span className="text-right tabular-nums">{s.redeemedLast7Days}</span>
                  <span className="text-muted-foreground">Days of stock left</span>
                  <span className="text-right tabular-nums">{s.daysOfStockLeft === null ? "—" : `~${s.daysOfStockLeft}`}</span>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </section>

      {/* Batches */}
      <section className="space-y-3">
        <h2 className="text-base font-semibold">Batches</h2>
        <Card className="overflow-hidden py-0">
          {batches.length === 0 ? (
            <EmptyState icon={Ticket} title="No batches yet" description="Generate a batch, download the codes once, paste them into the GamsGo offer's Automatic Delivery inventory, then mark the batch as uploaded." />
          ) : (
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Batch</TableHead>
                  <TableHead>Pack</TableHead>
                  <TableHead className="text-right">Codes</TableHead>
                  <TableHead className="text-right">Unredeemed</TableHead>
                  <TableHead className="text-right">Redeemed</TableHead>
                  <TableHead>Uploaded</TableHead>
                  <TableHead>Expires</TableHead>
                  <TableHead className="w-[200px]" />
                </TableRow>
              </TableHeader>
              <TableBody>
                {batches.map((b) => (
                  <BatchRowItem key={b.id} batch={b} canWrite={canWrite} />
                ))}
              </TableBody>
            </Table>
          )}
        </Card>
      </section>

      <div className="grid gap-6 lg:grid-cols-2">
        <Lookup canWrite={canWrite} />
        <ListingHelper packs={packs} />
      </div>

      {generateOpen && (
        <GenerateDialog
          packs={packs.filter((p) => p.active)}
          defaultExpiryMonths={defaultExpiryMonths}
          onClose={() => setGenerateOpen(false)}
          onGenerated={(g) => {
            setGenerateOpen(false);
            setGenerated(g);
          }}
        />
      )}
      {generated && <CodesDialog batch={generated} onClose={() => setGenerated(null)} />}
    </div>
  );
}

// ─── Batch row ──────────────────────────────────────────────────────────────

function BatchRowItem({ batch, canWrite }: { batch: BatchRow; canWrite: boolean }) {
  const router = useRouter();
  const [pending, startTransition] = useTransition();
  const [revokeOpen, setRevokeOpen] = useState(false);
  const [expiryOpen, setExpiryOpen] = useState(false);
  const [reason, setReason] = useState("");
  const [expiry, setExpiry] = useState(batch.expiresAt ? batch.expiresAt.slice(0, 10) : "");
  const compromised = !!batch.compromisedAt;

  return (
    <TableRow className={cn(compromised && "opacity-60")}>
      <TableCell>
        <span className="font-mono text-xs">…{batch.id.slice(-6)}</span>
        <span className="block text-[11px] text-muted-foreground">
          <LocalTime date={batch.createdAt} variant="date" /> · {batch.createdBy}
        </span>
        {batch.note && <span className="block truncate text-[11px] text-muted-foreground">{batch.note}</span>}
        {compromised && <span className="mt-0.5 inline-flex rounded-full border border-destructive/30 bg-destructive/10 px-1.5 text-[10px] font-semibold uppercase text-destructive">revoked</span>}
      </TableCell>
      <TableCell className="text-sm">{batch.packName}</TableCell>
      <TableCell className="text-right tabular-nums">{batch.quantity}</TableCell>
      <TableCell className="text-right tabular-nums">{batch.issued}</TableCell>
      <TableCell className="text-right tabular-nums">
        {batch.redeemed}
        {(batch.revoked > 0 || batch.expired > 0) && (
          <span className="block text-[11px] text-muted-foreground">
            {batch.revoked > 0 ? `${batch.revoked} revoked` : ""}
            {batch.revoked > 0 && batch.expired > 0 ? " · " : ""}
            {batch.expired > 0 ? `${batch.expired} expired` : ""}
          </span>
        )}
      </TableCell>
      <TableCell className="text-xs">
        {batch.markedUploadedAt ? (
          <LocalTime date={batch.markedUploadedAt} variant="date" />
        ) : canWrite && !compromised ? (
          <Button
            size="sm"
            variant="outline"
            disabled={pending}
            onClick={() =>
              startTransition(async () => {
                const r = await markUploadedAction(batch.id);
                if (r.ok) {
                  toast.success("Batch marked as uploaded to GamsGo");
                  router.refresh();
                } else toast.error(r.error);
              })
            }
          >
            <Upload className="size-3.5" /> Mark uploaded
          </Button>
        ) : (
          <span className="text-muted-foreground">not yet</span>
        )}
      </TableCell>
      <TableCell className="text-xs">
        {batch.expiresAt ? <LocalTime date={batch.expiresAt} variant="date" /> : <span className="text-muted-foreground">never</span>}
        {canWrite && !compromised && (
          <button type="button" className="ml-1 text-[11px] text-primary hover:underline" onClick={() => setExpiryOpen(true)}>
            edit
          </button>
        )}
      </TableCell>
      <TableCell>
        {canWrite && !compromised && batch.issued > 0 && (
          <Button size="sm" variant="ghost" className="text-destructive hover:text-destructive" onClick={() => setRevokeOpen(true)}>
            Revoke unredeemed
          </Button>
        )}
      </TableCell>

      <Dialog open={revokeOpen} onOpenChange={setRevokeOpen}>
        <DialogContent className="sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Revoke all unredeemed codes in this batch?</DialogTitle>
            <DialogDescription>
              Use this when the batch may have leaked (compromise). {batch.issued} code(s) will stop working at once; already redeemed codes are untouched.
            </DialogDescription>
          </DialogHeader>
          <Input value={reason} onChange={(e) => setReason(e.target.value)} placeholder="Reason (required) — e.g. inventory file leaked" />
          <DialogFooter>
            <Button variant="outline" onClick={() => setRevokeOpen(false)} disabled={pending}>
              Cancel
            </Button>
            <Button
              variant="destructive"
              disabled={pending || !reason.trim()}
              onClick={() =>
                startTransition(async () => {
                  const r = await revokeBatchAction(batch.id, reason);
                  if (r.ok) {
                    toast.success(`Revoked ${r.data?.revoked ?? 0} code(s)`);
                    setRevokeOpen(false);
                    router.refresh();
                  } else toast.error(r.error);
                })
              }
            >
              {pending && <Loader2 className="animate-spin" />} Revoke batch
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={expiryOpen} onOpenChange={setExpiryOpen}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle>Batch expiry</DialogTitle>
            <DialogDescription>Unredeemed codes past this date are marked expired by the daily cron. Leave empty for never.</DialogDescription>
          </DialogHeader>
          <Input type="date" value={expiry} onChange={(e) => setExpiry(e.target.value)} />
          <DialogFooter>
            <Button variant="outline" onClick={() => setExpiryOpen(false)} disabled={pending}>
              Cancel
            </Button>
            <Button
              disabled={pending}
              onClick={() =>
                startTransition(async () => {
                  const r = await updateBatchExpiryAction(batch.id, expiry ? `${expiry}T23:59:59.000Z` : null);
                  if (r.ok) {
                    toast.success("Expiry updated");
                    setExpiryOpen(false);
                    router.refresh();
                  } else toast.error(r.error);
                })
              }
            >
              Save
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </TableRow>
  );
}

// ─── Generate ───────────────────────────────────────────────────────────────

function GenerateDialog({ packs, defaultExpiryMonths, onClose, onGenerated }: { packs: PackChoice[]; defaultExpiryMonths: number; onClose: () => void; onGenerated: (g: GeneratedBatch) => void }) {
  const [pending, startTransition] = useTransition();
  const [packId, setPackId] = useState(packs[0]?.id ?? "");
  const [quantity, setQuantity] = useState("100");
  const [expiryMonths, setExpiryMonths] = useState(String(defaultExpiryMonths));
  const [note, setNote] = useState("");

  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>Generate voucher codes</DialogTitle>
          <DialogDescription>One batch per pack. The codes are shown once, on the next screen — download them before closing it.</DialogDescription>
        </DialogHeader>
        <div className="space-y-3">
          <div className="space-y-1.5">
            <Label>Pack</Label>
            <Select value={packId} onValueChange={setPackId}>
              <SelectTrigger className="w-full">
                <SelectValue placeholder="Choose a pack" />
              </SelectTrigger>
              <SelectContent>
                {packs.map((p) => (
                  <SelectItem key={p.id} value={p.id}>
                    {p.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-1.5">
              <Label htmlFor="qty">Quantity (max 1000)</Label>
              <Input id="qty" type="number" min={1} max={1000} value={quantity} onChange={(e) => setQuantity(e.target.value)} />
            </div>
            <div className="space-y-1.5">
              <Label htmlFor="exp">Expire after (months, 0 = never)</Label>
              <Input id="exp" type="number" min={0} max={120} value={expiryMonths} onChange={(e) => setExpiryMonths(e.target.value)} />
            </div>
          </div>
          <div className="space-y-1.5">
            <Label htmlFor="note">Note (optional)</Label>
            <Input id="note" value={note} onChange={(e) => setNote(e.target.value)} placeholder="e.g. September upload, offer #123" />
          </div>
        </div>
        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={pending}>
            Cancel
          </Button>
          <Button
            disabled={pending || !packId}
            onClick={() =>
              startTransition(async () => {
                const r = await generateBatchAction({ packId, quantity: Number(quantity), expiryMonths: Number(expiryMonths), note });
                if (!r.ok) toast.error(r.error);
                else if (r.data) onGenerated(r.data);
              })
            }
          >
            {pending && <Loader2 className="animate-spin" />} Generate
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

type Column = "code" | "url" | "pack" | "blank";
const COLUMN_LABELS: Record<Column, string> = { code: "Voucher code", url: "Redeem URL", pack: "Pack name", blank: "(empty)" };

function download(name: string, content: string, type: string) {
  const blob = new Blob([content], { type });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = name;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 1000);
}

function CodesDialog({ batch, onClose }: { batch: GeneratedBatch; onClose: () => void }) {
  const { copy } = useCopy();
  const router = useRouter();
  const [colA, setColA] = useState<Column>("code");
  const [colB, setColB] = useState<Column>("url");
  const [header, setHeader] = useState(true);
  const [downloaded, setDownloaded] = useState(false);
  const cell = (c: Column, code: string) => (c === "code" ? code : c === "url" ? batch.redeemUrl : c === "pack" ? batch.packName : "");
  const csv = () => {
    const rows = batch.codes.map((code) => `${cell(colA, code)},${cell(colB, code)}`);
    return (header ? ["username,password", ...rows] : rows).join("\r\n") + "\r\n";
  };
  const stamp = new Date().toISOString().slice(0, 10);

  return (
    <Dialog
      open
      onOpenChange={(o) => {
        if (!o) {
          if (!downloaded && !confirm("You have not downloaded the codes. They cannot be shown again. Close anyway?")) return;
          onClose();
          router.refresh();
        }
      }}
    >
      <DialogContent className="sm:max-w-2xl">
        <DialogHeader>
          <DialogTitle>{batch.codes.length} codes for {batch.packName} — save them now</DialogTitle>
          <DialogDescription>
            This is the only time the codes are shown. Download the CSV (GamsGo inventory format) or TXT, paste them into the offer&apos;s Automatic Delivery inventory, then mark the batch as uploaded.
          </DialogDescription>
        </DialogHeader>
        <div className="grid gap-3 sm:grid-cols-3">
          <div className="space-y-1.5">
            <Label>Column A (username)</Label>
            <Select value={colA} onValueChange={(v) => setColA(v as Column)}>
              <SelectTrigger className="w-full">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {(Object.keys(COLUMN_LABELS) as Column[]).map((c) => (
                  <SelectItem key={c} value={c}>
                    {COLUMN_LABELS[c]}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="space-y-1.5">
            <Label>Column B (password)</Label>
            <Select value={colB} onValueChange={(v) => setColB(v as Column)}>
              <SelectTrigger className="w-full">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {(Object.keys(COLUMN_LABELS) as Column[]).map((c) => (
                  <SelectItem key={c} value={c}>
                    {COLUMN_LABELS[c]}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
          <div className="flex items-center gap-2 pt-6">
            <Switch id="hdr" checked={header} onCheckedChange={setHeader} />
            <Label htmlFor="hdr">Header row</Label>
          </div>
        </div>
        <Textarea readOnly value={batch.codes.join("\n")} className="h-40 font-mono text-xs" />
        <DialogFooter className="flex-wrap gap-2">
          <Button
            variant="outline"
            onClick={() => {
              download(`vouchers-${batch.packName.replace(/[^a-z0-9]+/gi, "-")}-${stamp}.csv`, csv(), "text/csv");
              setDownloaded(true);
            }}
          >
            <Download /> CSV
          </Button>
          <Button
            variant="outline"
            onClick={() => {
              download(`vouchers-${batch.packName.replace(/[^a-z0-9]+/gi, "-")}-${stamp}.txt`, batch.codes.join("\r\n") + "\r\n", "text/plain");
              setDownloaded(true);
            }}
          >
            <FileText /> TXT
          </Button>
          <Button
            variant="outline"
            onClick={() => {
              copy(batch.codes.join("\n"), "Codes");
              setDownloaded(true);
            }}
          >
            <Copy /> Copy all
          </Button>
          <Button
            onClick={() => {
              if (!downloaded && !confirm("You have not downloaded the codes. They cannot be shown again. Close anyway?")) return;
              onClose();
              router.refresh();
            }}
          >
            Done
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ─── Lookup ─────────────────────────────────────────────────────────────────

const STATUS_STYLE: Record<string, string> = {
  ISSUED: "bg-primary/10 text-primary border-primary/25",
  REDEEMED: "bg-success/12 text-success border-success/25",
  REVOKED: "bg-destructive/12 text-destructive border-destructive/25",
  EXPIRED: "bg-muted text-muted-foreground border-border",
};

function Lookup({ canWrite }: { canWrite: boolean }) {
  const [query, setQuery] = useState("");
  const [rows, setRows] = useState<VoucherLookupResult[] | null>(null);
  const [pending, startTransition] = useTransition();
  const [action, setAction] = useState<{ kind: "revoke" | "clawback"; row: VoucherLookupResult } | null>(null);

  const run = () =>
    startTransition(async () => {
      const r = await lookupVouchersAction(query);
      if (r.ok) setRows(r.data ?? []);
      else toast.error(r.error);
    });

  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base">Look up a voucher</CardTitle>
        <CardDescription>Full code, last 4 characters, GamsGo order ID, or a customer&apos;s access code.</CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        <form
          className="flex gap-2"
          onSubmit={(e) => {
            e.preventDefault();
            run();
          }}
        >
          <Input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="ALK-… / 7Q3W / GamsGo order / AERO-…" />
          <Button type="submit" disabled={pending || !query.trim()}>
            {pending ? <Loader2 className="animate-spin" /> : <Search />}
          </Button>
        </form>
        {rows && rows.length === 0 && <p className="text-sm text-muted-foreground">Nothing matches.</p>}
        {rows && rows.length > 0 && (
          <div className="space-y-2">
            {rows.map((v) => (
              <div key={v.id} className="rounded-lg border px-3 py-2 text-xs">
                <div className="flex flex-wrap items-center justify-between gap-2">
                  <div className="flex items-center gap-2">
                    <span className="font-mono">…{v.last4}</span>
                    <span className={cn("inline-flex rounded-full border px-2 py-0.5 text-[10px] font-semibold uppercase", STATUS_STYLE[v.status])}>{v.status.toLowerCase()}</span>
                    <span className="text-muted-foreground">{v.packName}</span>
                    {!v.uploaded && v.status === "ISSUED" && <span className="text-muted-foreground">(not uploaded)</span>}
                  </div>
                  {canWrite && v.status === "ISSUED" && (
                    <Button size="sm" variant="ghost" className="text-destructive hover:text-destructive" onClick={() => setAction({ kind: "revoke", row: v })}>
                      Revoke
                    </Button>
                  )}
                  {canWrite && v.status === "REDEEMED" && !v.clawedBackAt && (
                    <Button size="sm" variant="ghost" className="text-destructive hover:text-destructive" onClick={() => setAction({ kind: "clawback", row: v })}>
                      Claw back
                    </Button>
                  )}
                </div>
                <div className="mt-1 flex flex-wrap gap-x-3 gap-y-0.5 text-muted-foreground">
                  <span>
                    batch …{v.batchId.slice(-6)} · <LocalTime date={v.createdAt} variant="date" />
                  </span>
                  {v.redeemedAt && (
                    <span>
                      redeemed <LocalTime date={v.redeemedAt} variant="datetime" />
                      {v.customerAccessCode && (
                        <>
                          {" by "}
                          <Link href={`/admin/customers/${v.customerId}`} className="font-mono text-primary hover:underline">
                            {v.customerAccessCode}
                          </Link>
                        </>
                      )}
                    </span>
                  )}
                  {v.gamsgoOrderId && <span>GamsGo order {v.gamsgoOrderId}</span>}
                  {v.expiresAt && (
                    <span>
                      expires <LocalTime date={v.expiresAt} variant="date" />
                    </span>
                  )}
                  {v.clawedBackAt && <span className="text-destructive">clawed back</span>}
                  {v.revokedReason && <span className="text-destructive">{v.revokedReason}</span>}
                </div>
              </div>
            ))}
          </div>
        )}
      </CardContent>
      {action && (
        <VoucherActionDialog
          action={action}
          onClose={() => setAction(null)}
          onDone={() => {
            setAction(null);
            run();
          }}
        />
      )}
    </Card>
  );
}

function VoucherActionDialog({ action, onClose, onDone }: { action: { kind: "revoke" | "clawback"; row: VoucherLookupResult }; onClose: () => void; onDone: () => void }) {
  const [reason, setReason] = useState("");
  const [suspend, setSuspend] = useState(false);
  const [pending, startTransition] = useTransition();
  const router = useRouter();
  const isClawback = action.kind === "clawback";
  return (
    <Dialog open onOpenChange={(o) => !o && onClose()}>
      <DialogContent className="sm:max-w-md">
        <DialogHeader>
          <DialogTitle>{isClawback ? `Claw back voucher …${action.row.last4}` : `Revoke voucher …${action.row.last4}`}</DialogTitle>
          <DialogDescription>
            {isClawback
              ? "For refunds and disputes: the pack's grant is taken back from what remains of the customer's balance and bonus, through the ledger. Never below zero."
              : "The code stops working. Use this for a refunded, unredeemed purchase."}
          </DialogDescription>
        </DialogHeader>
        <Input value={reason} onChange={(e) => setReason(e.target.value)} placeholder="Reason (required) — e.g. GamsGo refund #1234" />
        {isClawback && (
          <div className="flex items-center gap-2">
            <Switch id="suspend" checked={suspend} onCheckedChange={setSuspend} />
            <Label htmlFor="suspend">Also suspend the customer</Label>
          </div>
        )}
        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={pending}>
            Cancel
          </Button>
          <Button
            variant="destructive"
            disabled={pending || !reason.trim()}
            onClick={() =>
              startTransition(async () => {
                const r = isClawback ? await clawbackVoucherAction(action.row.id, reason, suspend) : await revokeVoucherAction(action.row.id, reason);
                if (r.ok) {
                  toast.success(isClawback ? "Voucher clawed back" : "Voucher revoked");
                  onDone();
                  router.refresh();
                } else toast.error(r.error);
              })
            }
          >
            {pending && <Loader2 className="animate-spin" />} {isClawback ? "Claw back" : "Revoke"}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

// ─── Listing helper ─────────────────────────────────────────────────────────

function ListingHelper({ packs }: { packs: PackChoice[] }) {
  const { copy } = useCopy();
  const [packId, setPackId] = useState(packs[0]?.id ?? "");
  const [text, setText] = useState<{ title: string; description: string } | null>(null);
  const [pending, startTransition] = useTransition();
  return (
    <Card>
      <CardHeader>
        <CardTitle className="text-base">GamsGo listing text</CardTitle>
        <CardDescription>A truthful title and description built from the pack: what the buyer gets, which models, how to redeem. Follows GamsGo&apos;s title rules.</CardDescription>
      </CardHeader>
      <CardContent className="space-y-3">
        <div className="flex gap-2">
          <Select value={packId} onValueChange={setPackId}>
            <SelectTrigger className="w-full">
              <SelectValue placeholder="Choose a pack" />
            </SelectTrigger>
            <SelectContent>
              {packs.map((p) => (
                <SelectItem key={p.id} value={p.id}>
                  {p.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <Button
            variant="outline"
            disabled={pending || !packId}
            onClick={() =>
              startTransition(async () => {
                const r = await listingTextAction(packId);
                if (!r.ok) toast.error(r.error);
                else if (r.data) setText(r.data);
              })
            }
          >
            {pending ? <Loader2 className="animate-spin" /> : "Generate"}
          </Button>
        </div>
        {text && (
          <div className="space-y-3">
            <div className="space-y-1">
              <div className="flex items-center justify-between">
                <Label>Title</Label>
                <Button size="sm" variant="ghost" onClick={() => copy(text.title, "Title")}>
                  <Copy /> Copy
                </Button>
              </div>
              <Input readOnly value={text.title} />
            </div>
            <div className="space-y-1">
              <div className="flex items-center justify-between">
                <Label>Description</Label>
                <Button size="sm" variant="ghost" onClick={() => copy(text.description, "Description")}>
                  <Copy /> Copy
                </Button>
              </div>
              <Textarea readOnly value={text.description} className="h-44 text-xs" />
            </div>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
