import { Plane } from "lucide-react";
import { cn } from "@/lib/utils";
import { BrandMark } from "@/components/shared/brand-mark";

// Deterministic "barcode" bar widths (no randomness: identical on server and client).
const BAR_UNITS = [3, 1, 2, 1, 1, 3, 1, 2, 2, 1, 3, 1, 1, 2, 1, 3, 2, 1, 1, 2, 3, 1, 2, 1, 2, 1, 3, 1];

const STOPS = [
  { n: "01", label: "Order ID", hint: "From your store receipt" },
  { n: "02", label: "Access code", hint: "Created on the spot" },
  { n: "03", label: "Your agent", hint: "Point it at /v1" },
];

const FIELDS = [
  { label: "Passenger", value: "You" },
  { label: "Class", value: "Prepaid" },
  { label: "Gate", value: "/v1", mono: true },
  { label: "Works with", value: "Claude Code · Codex · any SDK", wide: true },
];

/**
 * Hero illustration for the activation page: a full-width AeroLink access
 * pass, styled like a boarding pass — from your store order to your coding
 * agent, through the three activation steps. Theme colours only (light and
 * dark); the route motion stops for reduced motion (globals.css).
 * No prices, models or promises about timing.
 */
export function AccessPass({ className }: { className?: string }) {
  return (
    <figure
      className={cn("group relative", className)}
      aria-label="Your AeroLink access pass: from your store order to your coding agent, in three steps"
    >
      <div className="relative flex flex-col overflow-hidden rounded-3xl border bg-card shadow-[0_1px_2px_oklch(0_0_0/0.04),0_12px_40px_-12px_oklch(0.4_0.1_264/0.18)] transition-transform duration-500 ease-[cubic-bezier(0.25,1,0.5,1)] group-hover:-translate-y-0.5 md:flex-row">
        <div aria-hidden className="absolute inset-x-0 top-0 z-10 h-1 bg-primary" />

        {/* Main body */}
        <div className="relative flex-1 p-6 sm:p-8 lg:p-10">
          {/* Faint technical grid, fading out to the right */}
          <div
            aria-hidden
            className="pointer-events-none absolute inset-0 opacity-60 [background-image:linear-gradient(to_right,var(--border)_1px,transparent_1px),linear-gradient(to_bottom,var(--border)_1px,transparent_1px)] [background-size:28px_28px] [mask-image:linear-gradient(to_right,black,transparent_70%)]"
          />
          <div className="relative">
            {/* Header */}
            <div className="flex items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <BrandMark className="size-8" />
                <span className="text-sm font-semibold tracking-[0.2em]">AEROLINK</span>
              </div>
              <span className="rounded-full border px-3 py-1 text-[11px] font-medium tracking-[0.18em] text-muted-foreground uppercase">
                Access pass
              </span>
            </div>

            {/* Route */}
            <div className="mt-8 grid grid-cols-[auto_1fr_auto] items-end gap-4 sm:gap-8">
              <div>
                <p className="text-[11px] font-medium tracking-[0.18em] text-muted-foreground uppercase">From</p>
                <p className="mt-1 font-display text-4xl leading-none font-semibold tracking-tight sm:text-5xl lg:text-6xl">ORDER</p>
                <p className="mt-2 text-sm text-muted-foreground">Your store purchase</p>
              </div>

              {/* Flight path */}
              <div className="relative mb-9 hidden sm:block" aria-hidden>
                <div className="h-px w-full border-t-2 border-dashed border-border" />
                <div className="absolute inset-x-0 -top-px h-[2px] overflow-hidden">
                  <div className="pass-route h-full w-1/3 rounded-full bg-gradient-to-r from-transparent to-primary" />
                </div>
                <span className="absolute top-1/2 left-1/2 flex size-9 -translate-x-1/2 -translate-y-1/2 items-center justify-center rounded-full border bg-card text-primary shadow-sm">
                  <Plane className="size-4" />
                </span>
              </div>

              <div className="text-right">
                <p className="text-[11px] font-medium tracking-[0.18em] text-muted-foreground uppercase">To</p>
                <p className="mt-1 font-display text-4xl leading-none font-semibold tracking-tight text-primary sm:text-5xl lg:text-6xl">AGENT</p>
                <p className="mt-2 text-sm text-muted-foreground">Your coding tool</p>
              </div>
            </div>

            {/* The three steps as stops on the route */}
            <ol className="mt-8 grid gap-3 sm:grid-cols-3 md:grid-cols-1 lg:grid-cols-3">
              {STOPS.map((s) => (
                <li key={s.n} className="flex items-start gap-3 rounded-2xl border bg-background/60 px-4 py-3 backdrop-blur-sm">
                  <span className="font-mono text-xs font-semibold text-primary tabular-nums">{s.n}</span>
                  <span>
                    <span className="block text-sm font-semibold">{s.label}</span>
                    <span className="block text-xs text-muted-foreground">{s.hint}</span>
                  </span>
                </li>
              ))}
            </ol>

            {/* Fields */}
            <dl className="mt-8 grid grid-cols-2 gap-x-6 gap-y-5 border-t pt-6 lg:grid-cols-[repeat(3,auto)_1fr]">
              {FIELDS.map((f) => (
                <div key={f.label} className={cn("min-w-0 lg:pr-10", f.wide && "col-span-2 lg:col-span-1")}>
                  <dt className="text-[11px] font-medium tracking-[0.18em] text-muted-foreground uppercase">{f.label}</dt>
                  <dd className={cn("mt-1 text-base font-semibold", f.mono && "font-mono")}>{f.value}</dd>
                </div>
              ))}
            </dl>
          </div>
        </div>

        {/* Perforation: notches + dashed tear line (vertical on md+, horizontal when stacked) */}
        <div aria-hidden className="relative h-px md:h-auto md:w-px">
          <div className="absolute inset-x-8 top-0 border-t-2 border-dashed border-border md:inset-x-auto md:inset-y-8 md:left-0 md:border-t-0 md:border-l-2" />
          <span className="absolute top-1/2 -left-4 z-20 size-8 -translate-y-1/2 rounded-full border bg-background md:top-0 md:left-1/2 md:-translate-x-1/2 md:-translate-y-1/2" />
          <span className="absolute top-1/2 -right-4 z-20 size-8 -translate-y-1/2 rounded-full border bg-background md:top-auto md:right-auto md:bottom-0 md:left-1/2 md:-translate-x-1/2 md:translate-y-1/2" />
        </div>

        {/* Stub */}
        <div className="flex flex-col justify-between gap-6 bg-muted/40 p-6 sm:p-8 md:w-64 lg:w-72 lg:p-10">
          <div className="grid grid-cols-2 gap-6 md:grid-cols-1">
            <div>
              <p className="text-[11px] font-medium tracking-[0.18em] text-muted-foreground uppercase">Access code</p>
              <p className="mt-1 font-mono text-lg font-semibold tracking-wider">
                AERO-<span className="text-primary">••••</span>
              </p>
            </div>
            <div>
              <p className="text-[11px] font-medium tracking-[0.18em] text-muted-foreground uppercase">Valid</p>
              <p className="mt-1 text-base font-semibold">Until used</p>
            </div>
          </div>
          <div aria-hidden>
            <div className="flex h-16 items-stretch gap-[3px]">
              {BAR_UNITS.map((u, i) => (
                <span key={i} className="bg-foreground/85" style={{ width: `${u * 1.5}px` }} />
              ))}
            </div>
            <p className="mt-2 font-mono text-[10px] tracking-[0.3em] text-muted-foreground">AL · PREPAID · V1</p>
          </div>
        </div>
      </div>
    </figure>
  );
}
