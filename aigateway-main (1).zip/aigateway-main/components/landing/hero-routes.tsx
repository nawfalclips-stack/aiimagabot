import { cn } from "@/lib/utils";
import { MARK_BAR, MARK_LETTER } from "@/components/shared/brand-mark";

const TOOLS = ["Claude Code", "Claude Desktop", "Codex CLI", "OpenCode", "Cline", "Your own code"];

// Geometry (viewBox 0 0 560 400): tool labels on the left converge into the
// mark at the centre; one route leaves it on the right.
const NODE = { x: 330, y: 200, size: 72 };
const LABEL_X = 150;
const top = 45;
const step = (400 - top * 2) / (TOOLS.length - 1);
const routeIn = (y: number) => `M${LABEL_X + 12} ${y} C ${LABEL_X + 95} ${y}, ${NODE.x - 110} ${NODE.y}, ${NODE.x - NODE.size / 2 - 6} ${NODE.y}`;
const OUT_START = NODE.x + NODE.size / 2 + 6;
const OUT_END = 540;

/**
 * Hero visual: every coding tool routes through one gateway — the idea behind
 * the mark. Pure SVG in theme colours (works in light and dark); pulses travel
 * along the routes and stop when the visitor prefers reduced motion.
 */
export function HeroRoutes({ className }: { className?: string }) {
  return (
    <figure className={cn("relative", className)}>
      <svg viewBox="0 0 560 400" className="h-auto w-full" role="img" aria-labelledby="hero-routes-title">
        <title id="hero-routes-title">Claude Code, Claude Desktop, Codex CLI, OpenCode, Cline and your own code all connect through one AeroLink key</title>

        {/* Routes in */}
        {TOOLS.map((tool, i) => {
          const y = top + i * step;
          const d = routeIn(y);
          return (
            <g key={tool}>
              <text x={LABEL_X} y={y} dy="0.35em" textAnchor="end" className="fill-foreground text-[15px] font-medium">
                {tool}
              </text>
              <circle cx={LABEL_X + 12} cy={y} r="3" className="fill-background stroke-muted-foreground" strokeWidth="1.25" />
              <path d={d} fill="none" className="stroke-border" strokeWidth="1.25" />
              <path d={d} fill="none" pathLength={100} className="route-pulse stroke-primary" strokeWidth="1.75" strokeLinecap="round" style={{ animationDelay: `${(i * 0.55).toFixed(2)}s` }} />
            </g>
          );
        })}

        {/* Route out */}
        <path d={`M${OUT_START} ${NODE.y} H${OUT_END}`} fill="none" className="stroke-foreground" strokeWidth="1.75" />
        <path d={`M${OUT_START} ${NODE.y} H${OUT_END}`} fill="none" pathLength={100} className="route-pulse route-pulse-out stroke-primary" strokeWidth="2.5" strokeLinecap="round" />
        <circle cx={OUT_END} cy={NODE.y} r="4" className="fill-foreground" />
        <text x={OUT_END} y={NODE.y - 18} textAnchor="end" className="fill-foreground text-[15px] font-semibold">
          one key
        </text>
        <text x={OUT_END} y={NODE.y + 30} textAnchor="end" className="fill-muted-foreground text-[13px]">
          one balance
        </text>

        {/* The gateway — the AeroLink mark */}
        <g transform={`translate(${NODE.x - NODE.size / 2} ${NODE.y - NODE.size / 2})`}>
          <rect width={NODE.size} height={NODE.size} rx={NODE.size / 4} className="fill-background" />
          <g transform={`scale(${NODE.size / 32})`}>
            <rect width="32" height="32" rx="8" className="fill-primary" />
            <path d={MARK_LETTER} fillRule="evenodd" className="fill-primary-foreground" />
            <path d={MARK_BAR} className="fill-primary-foreground" />
          </g>
        </g>
      </svg>
    </figure>
  );
}
