"use client";

import { useEffect, useState } from "react";
import Link from "next/link";
import { Menu, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { cn } from "@/lib/utils";
import { ThemeToggle } from "@/components/theme/theme-toggle";
import { BrandMark } from "@/components/shared/brand-mark";

export interface NavLink {
  href: string;
  label: string;
}

const LINKS: NavLink[] = [
  { href: "#features", label: "Features" },
  { href: "#how", label: "How it works" },
  { href: "#plans", label: "Plans" },
  { href: "#tools", label: "Tools" },
  { href: "#faq", label: "FAQ" },
  { href: "/docs", label: "Docs" },
];

/** Sticky top bar: transparent over the hero, frosted once the page scrolls. */
export function LandingNav({
  logoText,
  links = LINKS,
  cta = { href: "/", label: "Activate" },
}: {
  logoText: string;
  /** Section links (defaults to the /new page anchors). */
  links?: NavLink[];
  /** The primary button on the right. */
  cta?: NavLink;
}) {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 12);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={cn(
        "sticky top-0 z-40 transition-colors",
        scrolled || open ? "border-b border-border bg-background/80 backdrop-blur-xl" : "border-b border-transparent"
      )}
    >
      <div className="mx-auto flex w-full max-w-6xl items-center justify-between gap-4 px-6 py-4">
        <Link href="/new" className="flex items-center gap-2.5">
          <BrandMark className="size-8" />
          <span className="text-lg font-semibold tracking-tight">{logoText}</span>
        </Link>

        <nav aria-label="Sections" className="hidden items-center gap-1 lg:flex">
          {links.map((l) => (
            <a key={l.href} href={l.href} className="rounded-lg px-3 py-2 text-sm text-muted-foreground transition-colors hover:bg-foreground/5 hover:text-foreground">
              {l.label}
            </a>
          ))}
        </nav>

        <div className="hidden items-center gap-2 lg:flex">
          <ThemeToggle />
          <Button asChild variant="ghost" size="sm">
            <Link href="/login">Sign in</Link>
          </Button>
          <Button asChild size="sm">
            <Link href={cta.href}>{cta.label}</Link>
          </Button>
        </div>

        <div className="flex items-center gap-1 lg:hidden">
        <ThemeToggle />
        <button
          type="button"
          className="rounded-lg border p-2 text-muted-foreground hover:text-foreground"
          aria-expanded={open}
          aria-label={open ? "Close menu" : "Open menu"}
          onClick={() => setOpen((o) => !o)}
        >
          {open ? <X className="size-5" /> : <Menu className="size-5" />}
        </button>
        </div>
      </div>

      {open ? (
        <div className="border-t border-border px-6 pb-5 pt-2 lg:hidden">
          <nav aria-label="Sections" className="grid gap-1">
            {links.map((l) => (
              <a key={l.href} href={l.href} onClick={() => setOpen(false)} className="rounded-lg px-3 py-2.5 text-sm text-muted-foreground hover:bg-foreground/5 hover:text-foreground">
                {l.label}
              </a>
            ))}
          </nav>
          <div className="mt-3 grid grid-cols-2 gap-2">
            <Button asChild variant="outline"><Link href="/login">Sign in</Link></Button>
            <Button asChild><Link href={cta.href}>{cta.label}</Link></Button>
          </div>
        </div>
      ) : null}
    </header>
  );
}
