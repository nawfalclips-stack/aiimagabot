import Link from "next/link";
import { ArrowUpRight } from "lucide-react";
import { prisma } from "@/lib/prisma";
import { getSettings } from "@/lib/services/settings";
import { SETTING_KEYS } from "@/lib/constants";
import type { StoreId } from "@/lib/store";
import { parseSocialLinks } from "@/lib/social-links";
import { listModelsForStore } from "@/lib/gateway/registry";
import { resolveBaseUrl } from "@/lib/base-url";
import { AFFILIATE_MILESTONES } from "@/lib/affiliate";
import { getLoyaltyProgram } from "@/lib/services/loyalty-program";
import { Button } from "@/components/ui/button";
import { SocialLinks } from "@/components/shared/social-links";
import { Reveal, Section } from "@/components/landing/reveal";
import { ToolsTabs } from "@/components/landing/tools-tabs";
import { Faq, type FaqItem } from "@/components/landing/faq";
import { cn } from "@/lib/utils";

const usd = (cents: number) => `$${(cents / 100).toFixed(cents % 100 === 0 ? 0 : 2)}`;
const pad = (n: number) => String(n).padStart(2, "0");

/** Links to the shared sections, for a page that renders them itself (anchors) or points at /new. */
export function landingSectionLinks(base = "") {
  return [
    { href: `${base}#features`, label: "Features" },
    { href: `${base}#how`, label: "How it works" },
    { href: `${base}#plans`, label: "Plans" },
    { href: `${base}#tools`, label: "Tools" },
    { href: `${base}#faq`, label: "FAQ" },
    { href: "/docs", label: "Docs" },
  ];
}

/**
 * Everything below the hero on the marketing pages ("/" and "/new"): what you
 * get, how it works, plans, tool configs, rewards, FAQ and the closing call to
 * action. One component so both pages always stay identical.
 */
export async function LandingSections({ storeId, activateHref = "/" }: { storeId: StoreId; activateHref?: string }) {
  const [settings, plans, models, baseUrl, loyalty] = await Promise.all([
    getSettings(storeId),
    prisma.plan.findMany({ where: { storeId, isActive: true }, orderBy: [{ sortOrder: "asc" }, { priceCents: "asc" }] }),
    listModelsForStore(storeId),
    resolveBaseUrl(),
    getLoyaltyProgram(storeId),
  ]);
  const storeUrl = settings[SETTING_KEYS.storeUrl];
  const logoText = settings[SETTING_KEYS.logoText];
  // Customers only ever see public aliases — never the upstream model names.
  const defaultModel = models[0]?.publicSlug ?? "your-model";

  const features = [
    { title: "The cost of every request", body: "Model, input and output tokens, latency and the exact amount deducted — listed per request, the moment it finishes. Nothing is averaged or delayed to the end of the month." },
    { title: "Tokens you control", body: "Up to five named tokens per account, one per machine or tool. Revoke a leaked one instantly without touching the others; all of them draw from the same balance." },
    { title: "Every price before you use it", body: "Your dashboard lists each model, its context window and its price per million tokens — before you send a single request." },
    { title: "Recharge without a ticket", body: "Buy again on the store, enter the new Order ID or voucher, and the balance is added. Your tokens and settings stay exactly as they were." },
    { title: "Guides for every tool", body: "Step-by-step setup for Claude Code, Claude Desktop, Codex, OpenCode and more, on Windows, macOS and Linux — with this site's address already filled in." },
    { title: "Rewards that add up", body: "Loyalty points on every purchase, cash rewards at the higher levels, and a referral programme that pays on every order your friends place." },
  ];

  const steps = [
    { title: "Buy a pack", body: "Choose a pack on our GamsGo store. You receive an Order ID — or a voucher code — right away." },
    { title: "Activate", body: "Enter it on the activation page. Your access code and balance are created on the spot." },
    { title: "Paste one config", body: "Create a token in API Access and copy the ready-made settings for your tool." },
    { title: "Code", body: "Every request shows its model, tokens and cost. Recharge in two clicks when you need to." },
  ];

  const included = ["Every model in the catalog", "Claude Code, Codex & any SDK", "Live usage and cost per request", "Loyalty points on every purchase"];

  const faq: FaqItem[] = [
    { q: "What exactly am I buying?", a: <>A prepaid balance for the {logoText} API. Your tools send requests to this site with your token; each request is deducted from the balance at the rate of your plan. Nothing is charged per seat or per month.</> },
    { q: "Which tools work with it?", a: <>Anything that speaks the OpenAI Chat Completions API or the Anthropic Messages API: Claude Code, Claude Desktop, Codex CLI, OpenCode, editors with a custom base URL, and the official OpenAI and Anthropic SDKs in any language. The <Link href="/docs" className="font-medium text-foreground underline underline-offset-4">documentation</Link> has a guide for each.</> },
    { q: "How is the price of a request calculated?", a: <>Your plan sets the rate, and the exact deduction is shown next to every request in your Activity Logs — to the fraction of a cent.</> },
    { q: "How do I get my access code?", a: <>Buy on our GamsGo store, then enter the Order ID (or voucher code) on the activation page. Your access code is generated immediately; an Order ID account becomes usable once we confirm the order, usually within a few hours.</> },
    { q: "Can I use one account on several machines?", a: <>Yes — create a separate token for each machine or tool (up to five active at a time) so you can revoke one without touching the others. All of them draw from the same balance.</> },
    { q: "What if my balance runs out mid-task?", a: <>Requests are refused with a clear <code className="rounded bg-muted px-1 font-mono text-xs">402</code> error once the balance is finished. Recharge from the store, enter the new Order ID, and you are back within minutes — your tokens and settings stay the same.</> },
    { q: "Is my data stored?", a: <>Only what is needed to bill: model, token counts, latency and cost per request. Prompts and completions are streamed through and not kept. Tokens are stored hashed.</> },
    { q: "Where do I get help?", a: <>Open a ticket from your dashboard, read the <Link href="/docs" className="font-medium text-foreground underline underline-offset-4">documentation</Link> for your tool and OS, or contact us through the store.</> },
  ];

  return (
    <>
        {/* ── What you get ─────────────────────────────────────────────────── */}
        <Section id="features" eyebrow="What you get" title="Built for people who code with agents all day" lede="No seats, no subscription, no guessing. A balance you control and a record of where every cent went.">
          <ol className="grid gap-x-12 sm:grid-cols-2">
            {features.map((f, i) => (
              <Reveal key={f.title} delay={Math.min(i % 2, 1) * 0.05}>
                <li className="grid grid-cols-[2.5rem_1fr] gap-x-4 border-t border-border py-7">
                  <span className="pt-0.5 text-sm text-muted-foreground tabular-nums">{pad(i + 1)}</span>
                  <div>
                    <h3 className="text-[17px] font-semibold tracking-tight">{f.title}</h3>
                    <p className="mt-2 text-[15px] leading-relaxed text-muted-foreground">{f.body}</p>
                  </div>
                </li>
              </Reveal>
            ))}
          </ol>
        </Section>

        {/* ── How it works ─────────────────────────────────────────────────── */}
        <Section id="how" eyebrow="How it works" title="From order to first completion in ten minutes" lede="No sign-up form and no card on file. The Order ID from the store is your account.">
          <ol className="grid gap-10 sm:grid-cols-2 lg:grid-cols-4 lg:gap-0">
            {steps.map((s, i) => (
              <Reveal key={s.title} delay={i * 0.06}>
                <li className={cn("relative lg:pr-8", i > 0 && "lg:border-l lg:border-border lg:pl-8")}>
                  <span className="font-display text-5xl leading-none font-semibold tracking-tight text-primary tabular-nums">{i + 1}</span>
                  <h3 className="mt-6 text-[17px] font-semibold tracking-tight">{s.title}</h3>
                  <p className="mt-2 text-[15px] leading-relaxed text-muted-foreground">{s.body}</p>
                </li>
              </Reveal>
            ))}
          </ol>
        </Section>

        {/* ── Plans ────────────────────────────────────────────────────────── */}
        <Section id="plans" eyebrow="Plans" title="Prepaid. No subscription. Choose a pack." lede="Every pack is a balance you spend at your own pace. Purchases are made on our GamsGo store; activate here with the Order ID you receive.">
          {plans.length === 0 ? (
            <p className="border-t border-border py-8 text-sm text-muted-foreground">Plans are being set up — see the offers on our store meanwhile.</p>
          ) : (
            <div className={cn("grid border-t border-border", plans.length >= 4 ? "sm:grid-cols-2 lg:grid-cols-4" : plans.length === 3 ? "sm:grid-cols-3" : "sm:grid-cols-2")}>
              {plans.map((p, i) => {
                const featured = plans.length > 2 && i === Math.floor((plans.length - 1) / 2);
                return (
                  <Reveal key={p.id} delay={i * 0.05} className="h-full">
                    <div
                      className={cn(
                        "relative flex h-full flex-col py-8 sm:px-6",
                        i > 0 && "border-t border-border sm:border-t-0 sm:border-l",
                        featured && "bg-primary/[0.045] sm:rounded-none"
                      )}
                    >
                      {featured ? <span aria-hidden className="absolute inset-x-0 top-0 h-0.5 bg-primary" /> : null}
                      <div className="flex items-baseline justify-between gap-3">
                        <h3 className="text-[17px] font-semibold tracking-tight">{p.name}</h3>
                        {featured ? <span className="text-xs font-medium text-primary">Most chosen</span> : null}
                      </div>
                      <p className="mt-4 flex items-baseline gap-1.5">
                        <span className="font-display text-[2.75rem] leading-none font-semibold tracking-tight tabular-nums">{usd(p.priceCents)}</span>
                        <span className="text-sm text-muted-foreground">once</span>
                      </p>
                      <p className="mt-3 min-h-10 text-sm leading-relaxed text-muted-foreground">
                        {p.description || (p.limitType === "TOKENS" ? `${p.limitMTokens}M tokens, any model.` : `${usd(p.priceCents)} of balance to spend on any model.`)}
                      </p>
                      <ul className="mt-6 space-y-2.5 text-sm">
                        <li className="flex gap-3">
                          <span aria-hidden className="text-primary">—</span>
                          <span>{p.limitType === "TOKENS" ? <><strong className="font-semibold">{p.limitMTokens}M tokens</strong> included</> : <><strong className="font-semibold">{usd(p.priceCents)}</strong> balance credited</>}</span>
                        </li>
                        {included.map((f) => (
                          <li key={f} className="flex gap-3 text-muted-foreground">
                            <span aria-hidden className="text-border">—</span>
                            {f}
                          </li>
                        ))}
                      </ul>
                      <div className="mt-auto pt-8">
                        <Button asChild className="w-full" variant={featured ? "default" : "outline"}>
                          <a href={storeUrl} target="_blank" rel="noopener noreferrer">
                            Buy {p.name} <ArrowUpRight />
                          </a>
                        </Button>
                      </div>
                    </div>
                  </Reveal>
                );
              })}
            </div>
          )}
        </Section>

        {/* ── Tools ────────────────────────────────────────────────────────── */}
        <Section id="tools" eyebrow="Connect your tool" title="Copy, paste, code" lede="Ready-made configs with this site's address already filled in. Your dashboard generates the same snippets with your token inside.">
          <Reveal>
            <ToolsTabs baseUrl={baseUrl} model={defaultModel} />
          </Reveal>
        </Section>

        {/* ── Rewards ──────────────────────────────────────────────────────── */}
        <Section id="rewards" eyebrow="Rewards" title="Loyal customers and their friends earn more" lede="Points on every purchase, cash rewards at the higher levels, and a referral programme that pays on every order.">
          <div className="grid border-t border-border lg:grid-cols-2">
            <Reveal className="py-8 lg:pr-10">
              <h3 className="text-[17px] font-semibold tracking-tight">Loyalty levels</h3>
              <dl className="mt-5 divide-y divide-border">
                {loyalty.tiers.map((t) => (
                  <div key={t.id} className="flex items-center gap-3 py-3 text-[15px]">
                    <span aria-hidden className="size-2 rounded-full" style={{ backgroundColor: t.colorHex }} />
                    <dt className="font-medium">{t.name}</dt>
                    <dd className="ml-auto text-right text-sm text-muted-foreground tabular-nums">
                      {t.minPoints === 0 ? "from the first purchase" : `${t.minPoints.toLocaleString()} points`}
                      {t.rewardAmountCents > 0 ? <span className="ml-3 font-medium text-foreground">{usd(t.rewardAmountCents)} reward</span> : null}
                    </dd>
                  </div>
                ))}
              </dl>
              {loyalty.tiers.some((t) => t.rewardAmountCents > 0) ? (
                <p className="mt-5 text-sm leading-relaxed text-muted-foreground">
                  Levels with a cash reward can claim it from the dashboard; it is credited to your balance after a quick check.
                </p>
              ) : null}
            </Reveal>
            <Reveal className="border-t border-border py-8 lg:border-t-0 lg:border-l lg:pl-10" delay={0.06}>
              <h3 className="text-[17px] font-semibold tracking-tight">Referral programme</h3>
              <p className="mt-3 text-[15px] leading-relaxed text-muted-foreground">
                Share your personal link. Every time a friend you invited buys — the first activation and every recharge — you earn{" "}
                <strong className="font-semibold text-foreground">$5 and 15 points</strong>. Then the milestones:
              </p>
              <dl className="mt-5 divide-y divide-border">
                {AFFILIATE_MILESTONES.map((m) => (
                  <div key={m.id} className="flex items-center justify-between gap-4 py-3 text-[15px]">
                    <dt>{m.label}</dt>
                    <dd className="font-semibold tabular-nums">{usd(m.rewardCents)}</dd>
                  </div>
                ))}
              </dl>
            </Reveal>
          </div>
        </Section>

        {/* ── FAQ ──────────────────────────────────────────────────────────── */}
        <Section id="faq" eyebrow="FAQ" title="Questions people ask before they buy">
          <Reveal>
            <Faq items={faq} />
          </Reveal>
        </Section>

        {/* ── Closing ──────────────────────────────────────────────────────── */}
        <section className="border-t border-border/70">
          <div className="mx-auto grid w-full max-w-6xl gap-8 px-6 py-20 sm:py-24 lg:grid-cols-12 lg:items-end">
            <Reveal className="lg:col-span-7">
              <h2 className="font-display text-4xl leading-[1.05] font-semibold tracking-[-0.02em] text-balance sm:text-5xl">Your agent is waiting for a key.</h2>
              <p className="mt-5 max-w-lg text-[17px] leading-relaxed text-muted-foreground">Choose a pack, activate with the Order ID, paste one config. That is the whole onboarding.</p>
            </Reveal>
            <Reveal className="flex flex-wrap items-center gap-x-6 gap-y-4 lg:col-span-5 lg:justify-end" delay={0.06}>
              <Button asChild size="lg" className="h-11 px-5">
                <a href={storeUrl} target="_blank" rel="noopener noreferrer">
                  Choose a pack <ArrowUpRight />
                </a>
              </Button>
              <Link href={activateHref} className="text-sm font-medium underline-offset-4 hover:underline">
                Activate now
              </Link>
            </Reveal>
          </div>
        </section>
    </>
  );
}

/** Footer shared by the marketing pages. */
export async function LandingFooter({ storeId }: { storeId: StoreId }) {
  const settings = await getSettings(storeId);
  const storeUrl = settings[SETTING_KEYS.storeUrl];
  const socialLinks = parseSocialLinks(settings[SETTING_KEYS.socialLinks]);
  return (
    <footer className="border-t border-border">
      <div className="mx-auto flex w-full max-w-6xl flex-col gap-4 px-6 py-8 text-sm text-muted-foreground sm:flex-row sm:items-center sm:justify-between">
        <p>{settings[SETTING_KEYS.footerText]}</p>
        <SocialLinks links={socialLinks} />
        <nav aria-label="Footer" className="flex flex-wrap items-center gap-x-5 gap-y-2">
          <Link href="/docs" className="transition-colors hover:text-foreground">Documentation</Link>
          <Link href="/portal/rules" className="transition-colors hover:text-foreground">Rules &amp; terms</Link>
          <a href={storeUrl} target="_blank" rel="noopener noreferrer" className="transition-colors hover:text-foreground">Store &amp; support</a>
        </nav>
      </div>
    </footer>
  );
}
