"use client";

import { motion, useReducedMotion } from "framer-motion";
import { cn } from "@/lib/utils";

/** Fades a block up as it scrolls into view. Renders at rest when motion is reduced. */
export function Reveal({ children, className, delay = 0 }: { children: React.ReactNode; className?: string; delay?: number }) {
  const reduce = useReducedMotion();
  if (reduce) return <div className={className}>{children}</div>;
  return (
    <motion.div
      className={className}
      initial={{ opacity: 0, y: 18 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-60px" }}
      transition={{ duration: 0.5, ease: "easeOut", delay }}
    >
      {children}
    </motion.div>
  );
}

/**
 * Section wrapper: editorial header — eyebrow and title on the left, lede
 * aligned to the right on wide screens — separated from the previous section
 * by a hairline rule rather than a card.
 */
export function Section({
  id,
  eyebrow,
  title,
  lede,
  children,
  className,
}: {
  id: string;
  eyebrow?: string;
  title: string;
  lede?: string;
  children: React.ReactNode;
  className?: string;
}) {
  return (
    <section id={id} className={cn("relative scroll-mt-24 border-t border-border/70 py-20 sm:py-28", className)}>
      <div className="mx-auto w-full max-w-6xl px-6">
        <Reveal className="grid gap-5 lg:grid-cols-12 lg:items-end lg:gap-10">
          <div className="lg:col-span-6">
            {eyebrow ? (
              <p className="flex items-center gap-3 text-sm font-medium text-muted-foreground">
                <span aria-hidden className="h-px w-6 bg-primary" />
                {eyebrow}
              </p>
            ) : null}
            <h2 className="mt-4 font-display text-3xl leading-[1.08] font-semibold tracking-tight text-balance sm:text-[2.55rem]">{title}</h2>
          </div>
          {lede ? <p className="text-base leading-relaxed text-muted-foreground text-pretty lg:col-span-5 lg:col-start-8 sm:text-[17px]">{lede}</p> : null}
        </Reveal>
        <div className="mt-12 sm:mt-16">{children}</div>
      </div>
    </section>
  );
}
