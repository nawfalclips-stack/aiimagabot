"use client";

import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { CodeBlock } from "@/components/shared/code-block";

/** The three ways to connect, with the deployment's real base URL filled in. */
export function ToolsTabs({ baseUrl, model }: { baseUrl: string; model: string }) {
  const claude = `{
  "env": {
    "ANTHROPIC_API_KEY": "YOUR_TOKEN",
    "ANTHROPIC_BASE_URL": "${baseUrl}",
    "ANTHROPIC_MODEL": "${model}",
    "ANTHROPIC_DEFAULT_SONNET_MODEL": "${model}",
    "ANTHROPIC_DEFAULT_OPUS_MODEL": "${model}",
    "ANTHROPIC_DEFAULT_HAIKU_MODEL": "${model}"
  }
}`;
  const codex = `model_provider = "aerolink"
model = "${model}"
preferred_auth_method = "apikey"

[model_providers.aerolink]
name = "aerolink"
base_url = "${baseUrl}/v1"
wire_api = "chat"
env_key = "AEROLINK_API_KEY"`;
  const curl = `curl ${baseUrl}/v1/chat/completions \\
  -H "Authorization: Bearer YOUR_TOKEN" \\
  -H "Content-Type: application/json" \\
  -d '{"model":"${model}","messages":[{"role":"user","content":"Hello!"}],"stream":true}'`;

  return (
    <Tabs defaultValue="claude" className="max-w-3xl">
      <TabsList>
        <TabsTrigger value="claude">Claude Code</TabsTrigger>
        <TabsTrigger value="codex">Codex CLI</TabsTrigger>
        <TabsTrigger value="curl">Any SDK</TabsTrigger>
      </TabsList>
      <TabsContent value="claude" className="space-y-3 pt-4">
        <p className="text-sm text-muted-foreground">
          Save as <code className="rounded bg-muted px-1 py-0.5 font-mono text-xs">~/.claude/settings.json</code>, replace <code className="rounded bg-muted px-1 py-0.5 font-mono text-xs">YOUR_TOKEN</code> with a token from your dashboard, run <code className="rounded bg-muted px-1 py-0.5 font-mono text-xs">claude</code>.
        </p>
        <CodeBlock code={claude} language="json" />
      </TabsContent>
      <TabsContent value="codex" className="space-y-3 pt-4">
        <p className="text-sm text-muted-foreground">
          Save as <code className="rounded bg-muted px-1 py-0.5 font-mono text-xs">~/.codex/config.toml</code>, export <code className="rounded bg-muted px-1 py-0.5 font-mono text-xs">AEROLINK_API_KEY=YOUR_TOKEN</code>, run <code className="rounded bg-muted px-1 py-0.5 font-mono text-xs">codex</code>.
        </p>
        <CodeBlock code={codex} language="toml" />
      </TabsContent>
      <TabsContent value="curl" className="space-y-3 pt-4">
        <p className="text-sm text-muted-foreground">
          OpenAI-compatible: set <code className="rounded bg-muted px-1 py-0.5 font-mono text-xs">base_url</code> to <code className="rounded bg-muted px-1 py-0.5 font-mono text-xs">{baseUrl}/v1</code>. Anthropic SDKs: <code className="rounded bg-muted px-1 py-0.5 font-mono text-xs">ANTHROPIC_BASE_URL={baseUrl}</code>.
        </p>
        <CodeBlock code={curl} language="bash" />
      </TabsContent>
    </Tabs>
  );
}
