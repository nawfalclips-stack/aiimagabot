"use client";

import { useActionState, useEffect, useRef } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { ArrowRight, Loader2, TriangleAlert } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { customerLogin, type CustomerLoginState } from "@/app/actions";

export function AccessForm() {
  const [state, formAction, pending] = useActionState<CustomerLoginState, FormData>(customerLogin, {});
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (state.error) inputRef.current?.focus();
  }, [state.error]);

  return (
    <form action={formAction} className="w-full">
      <div className="flex flex-col gap-3 sm:flex-row">
        <Input
          ref={inputRef}
          name="accessCode"
          placeholder="AERO-XXXX-XXXX-XXXX"
          autoFocus
          autoComplete="off"
          autoCapitalize="characters"
          spellCheck={false}
          required
          minLength={6}
          disabled={pending}
          aria-label="Access code"
          className="h-12 flex-1 border-border bg-foreground/[0.04] font-mono text-base tracking-wider uppercase placeholder:font-sans placeholder:normal-case placeholder:tracking-normal sm:text-[15px]"
          onChange={(e) => {
            e.target.value = e.target.value.toUpperCase();
          }}
        />
        <Button type="submit" size="lg" className="h-12 px-6 shadow-lg shadow-primary/25" disabled={pending}>
          {pending ? (
            <>
              <Loader2 className="animate-spin" /> Checking…
            </>
          ) : (
            <>
              Continue <ArrowRight />
            </>
          )}
        </Button>
      </div>

      <AnimatePresence>
        {state.error ? (
          <motion.div
            initial={{ opacity: 0, y: -6, height: 0 }}
            animate={{ opacity: 1, y: 0, height: "auto" }}
            exit={{ opacity: 0, y: -6, height: 0 }}
            transition={{ duration: 0.25, ease: [0.16, 1, 0.3, 1] }}
            className="overflow-hidden"
          >
            <motion.div
              initial={{ x: 0 }}
              animate={{ x: [0, -6, 6, -4, 4, 0] }}
              transition={{ duration: 0.4 }}
              className="mt-3 flex items-center gap-2 rounded-lg border border-destructive/30 bg-destructive/10 px-3.5 py-2.5 text-sm text-destructive"
              role="alert"
            >
              <TriangleAlert className="size-4 shrink-0" />
              {state.error}
            </motion.div>
          </motion.div>
        ) : null}
      </AnimatePresence>

      <p className="mt-4 text-xs text-muted-foreground">
        Your access code was provided with your purchase. Press Enter to continue.
      </p>
    </form>
  );
}
