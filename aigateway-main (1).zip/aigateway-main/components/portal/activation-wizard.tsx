"use client";

import { useActionState, useMemo, useState } from "react";
import { useRouter } from "next/navigation";
import { AnimatePresence, motion } from "framer-motion";
import { ArrowLeft, ArrowRight, ArrowUpRight, Check, Loader2, TriangleAlert } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { CopyButton } from "@/components/shared/copy-button";
import { parseOfferTitle } from "@/lib/offer-parser";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import type { PackChoice } from "@/lib/services/packs";
import { activateOrder, type ActivateState } from "@/app/activate/actions";
import { cn } from "@/lib/utils";

const RULES = [
  {
    title: "Never share your API tokens",
    description: "Your API tokens are personal. Anyone who has one can spend your balance — and sharing can get your access suspended.",
  },
  {
    title: "If you have any problem, we'll help",
    description: "Something not working or unclear? Reach out and we'll sort it out with you.",
  },
  {
    title: "A token leaked? Revoke it yourself",
    description: "On the API Access page you can revoke any token and create a new one in seconds.",
  },
] as const;

const STEPS = ["Welcome", "Rules", "Your order"] as const;
const STEP_TRANSITION = { duration: 0.3, ease: [0.16, 1, 0.3, 1] as const };

interface ActivationWizardProps {
  siteName: string;
  storeUrl: string;
  /** Referral code pre-filled from a ?ref= link. */
  initialRef?: string;
  /** Plans (packs) on sale; empty = fall back to typing the offer title. */
  packs?: PackChoice[];
}

const usd = (cents: number) => `$${(cents / 100).toFixed(cents % 100 === 0 ? 0 : 2)}`;

/** Motion wrapper shared by every step. */
function StepPanel({ id, children }: { id: string; children: React.ReactNode }) {
  return (
    <motion.div key={id} initial={{ opacity: 0, y: 14 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -14 }} transition={STEP_TRANSITION}>
      {children}
    </motion.div>
  );
}

export function ActivationWizard({ siteName, storeUrl, initialRef, packs = [] }: ActivationWizardProps) {
  const [step, setStep] = useState(0);
  const [offerTitle, setOfferTitle] = useState("");
  const [packId, setPackId] = useState("");
  const pickPack = packs.length > 0;
  const chosenPack = packs.find((p) => p.id === packId) ?? null;
  const [state, formAction, pending] = useActionState<ActivateState, FormData>(activateOrder, {});
  const router = useRouter();

  // The referral-code field only appears on the affiliate-invite flow
  // (arrived via /affiliate/CODE). The main landing page never shows it.
  const showReferral = !!initialRef;

  // Smart live detection of balance/bonus from the pasted offer title.
  const detected = useMemo(() => (!pickPack && offerTitle.trim().length >= 3 ? parseOfferTitle(offerTitle) : null), [offerTitle, pickPack]);

  // Jump to the success screen once the account is created (state adjusted
  // during render — React's sanctioned pattern instead of a setState effect).
  const [shownAccessCode, setShownAccessCode] = useState<string | null>(null);
  if (state.accessCode && state.accessCode !== shownAccessCode) {
    setShownAccessCode(state.accessCode);
    setStep(3);
  }

  return (
    <div className="w-full max-w-lg">
      {/* Progress */}
      {step < 3 ? (
        <div className="mb-5" aria-label={`Step ${step + 1} of 3: ${STEPS[step]}`}>
          <div className="flex items-baseline justify-between text-xs">
            <span className="font-medium text-foreground">{STEPS[step]}</span>
            <span className="text-muted-foreground tabular-nums">Step {step + 1} of 3</span>
          </div>
          <div className="mt-2 grid grid-cols-3 gap-1.5" aria-hidden>
            {[0, 1, 2].map((i) => (
              <span key={i} className={cn("h-0.5 rounded-full transition-colors duration-300", i <= step ? "bg-primary" : "bg-border")} />
            ))}
          </div>
        </div>
      ) : null}

      <AnimatePresence mode="wait">
        {/* Step 1 — Welcome */}
        {step === 0 ? (
          <StepPanel key="welcome" id="welcome">
            <Card className="gap-0 p-7 sm:p-8">
              <h2 className="font-display text-2xl leading-tight font-semibold tracking-tight">Welcome to {siteName}</h2>
              <p className="mt-3 text-[15px] leading-relaxed text-muted-foreground">
                Thank you for your purchase and for trusting us. Your API access is moments away — three short steps and we set everything up
                for you.
              </p>
              <Button size="lg" className="mt-7 h-11 w-full" onClick={() => setStep(1)}>
                Get started <ArrowRight />
              </Button>
            </Card>
          </StepPanel>
        ) : null}

        {/* Step 2 — Rules */}
        {step === 1 ? (
          <StepPanel key="rules" id="rules">
            <Card className="gap-0 p-7 sm:p-8">
              <h2 className="font-display text-xl font-semibold tracking-tight">A few quick rules</h2>
              <p className="mt-1.5 text-sm text-muted-foreground">Please read these before using your API.</p>

              <ol className="mt-6 divide-y divide-border border-y border-border">
                {RULES.map((rule, i) => (
                  <li key={rule.title} className="grid grid-cols-[2rem_1fr] gap-x-3 py-4">
                    <span className="pt-0.5 text-sm text-muted-foreground tabular-nums">{String(i + 1).padStart(2, "0")}</span>
                    <div>
                      <p className="text-sm font-semibold">{rule.title}</p>
                      <p className="mt-1 text-[13px] leading-relaxed text-muted-foreground">{rule.description}</p>
                    </div>
                  </li>
                ))}
              </ol>

              <a
                href={storeUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="group mt-5 flex items-center justify-between gap-3 text-sm font-medium text-foreground"
              >
                <span className="underline-offset-4 group-hover:underline">Need to reach us? Contact us on our store</span>
                <ArrowUpRight className="size-4 text-muted-foreground transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
              </a>

              <div className="mt-7 flex gap-2">
                <Button variant="outline" className="h-11" onClick={() => setStep(0)}>
                  <ArrowLeft /> Back
                </Button>
                <Button className="h-11 flex-1" onClick={() => setStep(2)}>
                  I understand <ArrowRight />
                </Button>
              </div>
            </Card>
          </StepPanel>
        ) : null}

        {/* Step 3 — Order ID + plan bought */}
        {step === 2 ? (
          <StepPanel key="order" id="order">
            <Card className="gap-0 p-7 sm:p-8">
              <h2 className="font-display text-xl font-semibold tracking-tight">Enter your order details</h2>
              <p className="mt-1.5 text-sm leading-relaxed text-muted-foreground">
                {pickPack ? (
                  <>
                    Your Order ID is in <span className="font-medium text-foreground">Order Details</span> in your store account. Then choose the
                    plan you bought — we&apos;ll verify it and create your access automatically.
                  </>
                ) : (
                  <>
                    You&apos;ll find both in <span className="font-medium text-foreground">Order Details</span> in your store account. We&apos;ll
                    verify them and create your access automatically.
                  </>
                )}
              </p>

              <form action={formAction} className="mt-6 space-y-5">
                <div className="space-y-2">
                  <Label htmlFor="orderId">Order ID</Label>
                  <Input
                    id="orderId"
                    name="orderId"
                    placeholder="e.g. 2026080212345678"
                    autoFocus
                    autoComplete="off"
                    spellCheck={false}
                    required
                    minLength={4}
                    disabled={pending}
                    className="h-11 font-mono"
                  />
                </div>

                {pickPack ? (
                  <div className="space-y-2">
                    <Label htmlFor="packId">Plan you bought</Label>
                    <Select name="packId" value={packId} onValueChange={setPackId} disabled={pending} required>
                      <SelectTrigger id="packId" className="h-11 w-full">
                        <SelectValue placeholder="Choose your plan" />
                      </SelectTrigger>
                      <SelectContent>
                        {packs.map((p) => (
                          <SelectItem key={p.id} value={p.id}>
                            {p.name} — {usd(p.priceCents)}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                    <p className="text-xs text-muted-foreground">
                      {chosenPack ? (
                        <>
                          Balance: <span className="font-semibold text-foreground">{usd(chosenPack.priceCents)}</span> — confirmed once we verify your
                          order.
                        </>
                      ) : (
                        "Pick the same plan as on your order — we check it against your Order ID."
                      )}
                    </p>
                  </div>
                ) : (
                  <div className="space-y-2">
                    <Label htmlFor="offerTitle">Offer Title</Label>
                    <Input
                      id="offerTitle"
                      name="offerTitle"
                      placeholder="e.g. Codex API 300$ + 50$ Bonus"
                      autoComplete="off"
                      required
                      minLength={3}
                      disabled={pending}
                      value={offerTitle}
                      onChange={(e) => setOfferTitle(e.target.value)}
                      className="h-11"
                    />
                    <p className="text-xs text-muted-foreground">Copy it exactly as shown on your order — we detect your balance and bonus from it.</p>
                  </div>
                )}

                {/* Referral code — ONLY on the affiliate-invite flow, never on the main landing page. */}
                {showReferral ? (
                  <div className="space-y-2">
                    <Label htmlFor="affiliateCode">Friend&apos;s referral code</Label>
                    <Input
                      id="affiliateCode"
                      name="affiliateCode"
                      placeholder="e.g. AERO-4K7QX2"
                      autoComplete="off"
                      spellCheck={false}
                      disabled={pending}
                      defaultValue={initialRef ?? ""}
                      readOnly={!!initialRef}
                      className="h-11 font-mono uppercase"
                    />
                    <p className="text-xs text-muted-foreground">You were invited by a friend — their code is applied automatically.</p>
                  </div>
                ) : null}

                {/* Live detection (offer-title fallback only) */}
                <AnimatePresence>
                  {detected ? (
                    <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }} className="overflow-hidden">
                      <dl className="grid grid-cols-2 gap-x-6 border-y border-border py-3 text-sm">
                        <div>
                          <dt className="text-xs text-muted-foreground">Balance</dt>
                          <dd className="mt-0.5 font-semibold tabular-nums">
                            {detected.balanceCents !== null ? `$${(detected.balanceCents / 100).toFixed(2)}` : "Standard plan"}
                          </dd>
                        </div>
                        {detected.bonusCents > 0 ? (
                          <div>
                            <dt className="text-xs text-muted-foreground">Bonus · after your review</dt>
                            <dd className="mt-0.5 font-semibold text-success tabular-nums">${(detected.bonusCents / 100).toFixed(2)}</dd>
                          </div>
                        ) : null}
                      </dl>
                    </motion.div>
                  ) : null}
                </AnimatePresence>

                <AnimatePresence>
                  {state.error ? (
                    <motion.div initial={{ opacity: 0, height: 0 }} animate={{ opacity: 1, height: "auto" }} exit={{ opacity: 0, height: 0 }} className="overflow-hidden">
                      <p className="flex items-start gap-2 rounded-md border border-destructive/30 bg-destructive/8 px-3.5 py-2.5 text-sm text-destructive" role="alert">
                        <TriangleAlert className="mt-0.5 size-4 shrink-0" />
                        {state.error}
                      </p>
                    </motion.div>
                  ) : null}
                </AnimatePresence>

                <div className="flex gap-2 pt-1">
                  <Button type="button" variant="outline" className="h-11" onClick={() => setStep(1)} disabled={pending}>
                    <ArrowLeft /> Back
                  </Button>
                  <Button type="submit" className="h-11 flex-1" disabled={pending || (pickPack && !packId)}>
                    {pending ? (
                      <>
                        <Loader2 className="animate-spin" /> Activating…
                      </>
                    ) : (
                      <>
                        Activate my access <ArrowRight />
                      </>
                    )}
                  </Button>
                </div>
              </form>
            </Card>
          </StepPanel>
        ) : null}

        {/* Success */}
        {step === 3 && state.accessCode ? (
          <motion.div key="success" initial={{ opacity: 0, y: 10 }} animate={{ opacity: 1, y: 0 }} transition={STEP_TRANSITION}>
            <Card className="gap-0 p-7 sm:p-8">
              <p className="flex items-center gap-2 text-sm font-medium text-success">
                <Check className="size-4" /> Account created
              </p>
              <h2 className="mt-3 font-display text-2xl leading-tight font-semibold tracking-tight">You&apos;re all set.</h2>
              <p className="mt-2 text-[15px] leading-relaxed text-muted-foreground">
                Next, create your API token on the <span className="font-medium text-foreground">API Access</span> page.
              </p>

              <div className="mt-6 border-y border-border py-5">
                <p className="text-xs text-muted-foreground">Your access code — save it somewhere safe</p>
                <div className="mt-2 flex items-center gap-2">
                  <code className="font-mono text-xl font-semibold tracking-wider text-foreground">{state.accessCode}</code>
                  <CopyButton value={state.accessCode} label="Access code" />
                </div>
                <p className="mt-2 flex items-center gap-1.5 text-xs text-warning">
                  <TriangleAlert className="size-3.5" />
                  This code is the only way to sign in to your dashboard.
                </p>
              </div>

              <dl className="divide-y divide-border text-sm">
                {typeof state.balanceCents === "number" ? (
                  <div className="flex items-center justify-between py-3">
                    <dt className="text-muted-foreground">Balance credited</dt>
                    <dd className="font-semibold tabular-nums">${(state.balanceCents / 100).toFixed(2)}</dd>
                  </div>
                ) : null}
                {state.pendingBonusCents && state.pendingBonusCents > 0 ? (
                  <div className="py-3">
                    <div className="flex items-center justify-between">
                      <dt className="text-muted-foreground">Bonus waiting for you</dt>
                      <dd className="font-semibold text-success tabular-nums">${(state.pendingBonusCents / 100).toFixed(2)}</dd>
                    </div>
                    <p className="mt-1 text-xs text-muted-foreground">Write us a review on the store, then confirm it from your dashboard to unlock it.</p>
                  </div>
                ) : null}
              </dl>

              <Button size="lg" className="mt-6 h-11 w-full" onClick={() => router.push("/portal")}>
                Go to my dashboard <ArrowRight />
              </Button>
            </Card>
          </motion.div>
        ) : null}
      </AnimatePresence>
    </div>
  );
}
