"use client";

import { useEffect, useRef, useTransition } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { ArrowRight, Boxes, Info, Sparkles, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { LocalTime } from "@/components/shared/local-time";
import { cn } from "@/lib/utils";
import { markAnnouncementsReadAction } from "@/app/portal/actions";

/** What the portal shows of an announcement (dates as ISO strings). */
export interface PortalAnnouncement {
  id: string;
  kind: string;
  title: string;
  message: string;
  rechargeBonusPct: number;
  startsAt: string;
  endsAt: string | null;
  read: boolean;
}

const KIND_META: Record<string, { icon: typeof Info; tone: string; cta?: { href: string; label: string } }> = {
  PROMO: { icon: Sparkles, tone: "bg-success/12 text-success", cta: { href: "/portal/recharge", label: "Recharge now" } },
  NEW_MODEL: { icon: Boxes, tone: "bg-primary/12 text-primary", cta: { href: "/portal/api-access", label: "See models & prices" } },
  INFO: { icon: Info, tone: "bg-muted text-foreground" },
};

export function AnnouncementItem({ a, compact = false, onDismiss }: { a: PortalAnnouncement; compact?: boolean; onDismiss?: () => void }) {
  const meta = KIND_META[a.kind] ?? KIND_META.INFO;
  const Icon = meta.icon;
  return (
    <div className={cn("relative flex gap-3 rounded-xl border bg-card p-4", !a.read && "border-primary/30 bg-primary/[0.03]")}>
      <span className={cn("flex size-9 shrink-0 items-center justify-center rounded-lg", meta.tone)}>
        <Icon className="size-[18px]" />
      </span>
      <div className="min-w-0 flex-1 space-y-1 pr-6">
        <p className="flex flex-wrap items-center gap-2 font-medium">
          {a.title}
          {!a.read ? <span className="rounded-full bg-primary px-1.5 py-px text-[10px] font-semibold text-primary-foreground uppercase">New</span> : null}
        </p>
        <p className={cn("text-sm whitespace-pre-line text-muted-foreground", compact && "line-clamp-2")}>{a.message}</p>
        <div className="flex flex-wrap items-center gap-x-3 gap-y-1 pt-1 text-xs text-muted-foreground">
          <LocalTime date={a.startsAt} variant="date" />
          {a.endsAt ? (
            <span>
              Ends <LocalTime date={a.endsAt} />
            </span>
          ) : null}
          {meta.cta ? (
            <Link href={meta.cta.href} className="inline-flex items-center gap-1 font-medium text-primary underline-offset-4 hover:underline">
              {meta.cta.label} <ArrowRight className="size-3" />
            </Link>
          ) : null}
        </div>
      </div>
      {onDismiss ? (
        <Button variant="ghost" size="icon-sm" className="absolute top-2 right-2 text-muted-foreground" aria-label="Dismiss" onClick={onDismiss}>
          <X />
        </Button>
      ) : null}
    </div>
  );
}

/** Marks everything read once the inbox has been shown, then refreshes the unread badge. */
export function MarkAnnouncementsRead({ ids }: { ids: string[] }) {
  const router = useRouter();
  const done = useRef(false);
  useEffect(() => {
    if (done.current || ids.length === 0) return;
    done.current = true;
    void markAnnouncementsReadAction(ids).then(() => router.refresh());
  }, [ids, router]);
  return null;
}

/** Dashboard: unread announcements (promotions first), each dismissible. */
export function AnnouncementBanner({ items }: { items: PortalAnnouncement[] }) {
  const router = useRouter();
  const [, startTransition] = useTransition();
  if (items.length === 0) return null;
  const dismiss = (id: string) =>
    startTransition(async () => {
      await markAnnouncementsReadAction([id]);
      router.refresh();
    });
  return (
    <div className="space-y-2">
      {items.map((a) => (
        <AnnouncementItem key={a.id} a={a} compact onDismiss={() => dismiss(a.id)} />
      ))}
    </div>
  );
}
