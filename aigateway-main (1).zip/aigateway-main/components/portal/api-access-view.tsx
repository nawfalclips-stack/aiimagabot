"use client";

import { useState, useTransition } from "react";
import Link from "next/link";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { Check, Eye, EyeOff, KeyRound, Loader2, Plus, ShieldAlert, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { CodeBlock } from "@/components/shared/code-block";
import { CopyButton } from "@/components/shared/copy-button";
import { ConfirmDialog } from "@/components/shared/confirm-dialog";
import { EmptyState } from "@/components/shared/empty-state";
import { PageHeader } from "@/components/shared/page-header";
import { LocalTime } from "@/components/shared/local-time";
import { cn } from "@/lib/utils";
import { createTokenAction, revealTokenAction, revokeTokenAction } from "@/app/portal/api-access/actions";

export interface TokenRow {
  id: string;
  name: string;
  prefix: string;
  createdAt: string;
  lastUsedAt: string | null;
  revokedAt: string | null;
  /** False for tokens created before the portal stored a copy — they can't be shown again. */
  canReveal: boolean;
}

export interface ModelInfo {
  slug: string;
  displayName: string;
  inputCentsPerMTok: number;
  /** Price of cached (prompt-cache hit) input tokens; equals input when the plan gives no discount. */
  cachedInputCentsPerMTok: number;
  outputCentsPerMTok: number;
  contextWindow: number | null;
}

export interface PlanSummary {
  name: string;
  description: string;
  priceCents: number;
  limitType: "USD" | "TOKENS";
  limitMTokens: number;
  tokensUsed: number;
}

/** "$3.00" / "$0.075" — small prices keep their significant digits. */
const perM = (cents: number) => {
  const usd = cents / 100;
  return `$${usd > 0 && usd < 1 ? Number(usd.toFixed(4)).toString() : usd.toFixed(2)}`;
};
const fmtTokens = (n: number) => (n >= 1_000_000 ? `${(n / 1_000_000).toFixed(n >= 10_000_000 ? 0 : 1)}M` : n >= 1000 ? `${Math.round(n / 1000)}k` : String(n));

export function ApiAccessView({
  baseUrl,
  tokens,
  models,
  plan = null,
}: {
  baseUrl: string;
  tokens: TokenRow[];
  models: ModelInfo[];
  plan?: PlanSummary | null;
}) {
  const router = useRouter();
  const [creating, setCreating] = useState(false);
  const [name, setName] = useState("");
  const [pending, startTransition] = useTransition();
  const [selectedModel, setSelectedModel] = useState(models[0]?.slug ?? "");
  // Selecting a token in the table shows its full text at the top and fills
  // the snippets. Full tokens are fetched on demand and cached per id.
  const [selectedId, setSelectedId] = useState<string | null>(null);
  const [revealed, setRevealed] = useState<Record<string, string>>({});
  const [hidden, setHidden] = useState(false);
  const [revealing, setRevealing] = useState(false);
  const [justCreated, setJustCreated] = useState<string | null>(null);

  const active = tokens.filter((t) => !t.revokedAt);
  const selected = tokens.find((t) => t.id === selectedId && !t.revokedAt) ?? null;
  const selectedToken = selected ? revealed[selected.id] ?? null : null;
  const tokenForSnippet = selectedToken ?? "YOUR_TOKEN";
  const model = selectedModel || models[0]?.slug || "MODEL_ID";

  const selectToken = (t: TokenRow) => {
    if (t.revokedAt) return;
    setSelectedId(t.id);
    setHidden(false);
    if (revealed[t.id] || !t.canReveal) return;
    setRevealing(true);
    void revealTokenAction(t.id).then((r) => {
      setRevealing(false);
      if (r.ok && r.data) {
        const token = r.data.token;
        setRevealed((m) => ({ ...m, [t.id]: token }));
      } else if (!r.ok) toast.error(r.error);
    });
  };

  const create = () =>
    startTransition(async () => {
      const r = await createTokenAction(name);
      if (r.ok && r.data) {
        const { id, token } = r.data;
        setRevealed((m) => ({ ...m, [id]: token }));
        setSelectedId(id);
        setJustCreated(id);
        setHidden(false);
        setCreating(false);
        setName("");
        router.refresh();
      } else if (!r.ok) toast.error(r.error);
    });

  const codexToml = `model_provider = "aerolink"
model = "${model}"
disable_response_storage = true
preferred_auth_method = "apikey"

[model_providers.aerolink]
name = "aerolink"
base_url = "${baseUrl}/v1"
wire_api = "chat"
env_key = "AEROLINK_API_KEY"`;

  const opencodeJson = `{
  "$schema": "https://opencode.ai/config.json",
  "provider": {
    "aerolink": {
      "npm": "@ai-sdk/openai-compatible",
      "name": "AeroLink",
      "options": {
        "baseURL": "${baseUrl}/v1",
        "apiKey": "{env:AEROLINK_API_KEY}"
      },
      "models": {
        "${model}": {
          "name": "${model}",
          "limit": { "context": 128000, "output": 8192 }
        }
      }
    }
  },
  "model": "aerolink/${model}",
  "small_model": "aerolink/${model}"
}`;

  const envSnippet = `# PowerShell (Windows) — then open a new window
setx AEROLINK_API_KEY "${tokenForSnippet}"

# bash / zsh (macOS, Linux)
echo 'export AEROLINK_API_KEY="${tokenForSnippet}"' >> ~/.bashrc`;

  const claudeSettings = `{
  "env": {
    "ANTHROPIC_API_KEY": "${tokenForSnippet}",
    "ANTHROPIC_BASE_URL": "${baseUrl}",
    "ANTHROPIC_MODEL": "${model}",
    "ANTHROPIC_DEFAULT_SONNET_MODEL": "${model}",
    "ANTHROPIC_DEFAULT_OPUS_MODEL": "${model}",
    "ANTHROPIC_DEFAULT_HAIKU_MODEL": "${model}",
    "CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC": "1"
  },
  "apiKeyHelper": "echo '${tokenForSnippet}'"
}`;

  const curlExample = `curl ${baseUrl}/v1/chat/completions \\
  -H "Authorization: Bearer ${tokenForSnippet}" \\
  -H "Content-Type: application/json" \\
  -d '{"model":"${model}","messages":[{"role":"user","content":"Hello!"}]}'`;

  return (
    <div className="space-y-6">
      <PageHeader
        eyebrow="Account"
        title="API Access"
        description={
          <>
            Create a token, point your tool at{" "}
            <code className="rounded-md bg-muted px-1.5 py-0.5 font-mono text-[12.5px] text-foreground">{baseUrl}</code>, pick a
            model. Every request is billed to your balance and listed under Activity Logs.
          </>
        }
      />

      {/* Plan */}
      {plan ? (
        <div className="rounded-2xl border bg-card px-5 py-4 shadow-card">
          <div className="flex flex-wrap items-baseline justify-between gap-2">
            <p className="text-sm">
              <span className="eyebrow mr-2">Your plan</span> <span className="font-display text-base font-semibold">{plan.name}</span>
              <span className="ml-2 text-muted-foreground">${(plan.priceCents / 100).toFixed(0)}</span>
              {plan.limitType === "TOKENS" ? <span className="ml-2 text-muted-foreground">· {plan.limitMTokens}M tokens included</span> : null}
            </p>
            {plan.limitType === "TOKENS" ? (
              <p className="text-xs tabular-nums text-muted-foreground">
                {fmtTokens(plan.tokensUsed)} of {plan.limitMTokens}M tokens used
              </p>
            ) : null}
          </div>
          {plan.limitType === "TOKENS" ? (
            <div className="mt-2 h-1.5 w-full overflow-hidden rounded-full bg-muted">
              <div
                className="h-full rounded-full bg-primary"
                style={{ width: `${Math.min(100, (plan.tokensUsed / (plan.limitMTokens * 1_000_000)) * 100)}%` }}
              />
            </div>
          ) : null}
          {plan.description ? <p className="mt-1 text-xs text-muted-foreground">{plan.description}</p> : null}
        </div>
      ) : null}

      {/* Selected token — full text + copy. A freshly created token is selected automatically. */}
      {selected ? (
        <div
          role="status"
          className={cn(
            "rounded-2xl border px-5 py-4",
            justCreated === selected.id ? "border-success/30 bg-success/10" : "border-primary/30 bg-primary/5"
          )}
        >
          <div className="flex flex-wrap items-center justify-between gap-2">
            <p className={cn("text-sm font-semibold", justCreated === selected.id ? "text-success" : "text-foreground")}>
              {justCreated === selected.id ? "Your new token is ready" : `Token “${selected.name}”`}
            </p>
            <p className="text-xs text-muted-foreground">
              {selected.prefix}… · created <LocalTime date={new Date(selected.createdAt)} variant="date" />
            </p>
          </div>
          <p className="mt-0.5 text-sm text-muted-foreground">
            {selectedToken
              ? "Copy it into your tool — the snippets below already include it."
              : selected.canReveal
                ? "Loading the full token…"
                : "This token was created before copying was supported. Create a new token to get one you can copy."}
          </p>
          {selectedToken ? (
            <div className="mt-3 flex items-center gap-2 rounded-xl border bg-card px-4 py-2.5 shadow-card">
              <code className="flex-1 font-mono text-[13px] break-all">
                {hidden ? `${selected.prefix}${"•".repeat(Math.max(8, selectedToken.length - selected.prefix.length))}` : selectedToken}
              </code>
              <Button variant="ghost" size="icon-sm" aria-label={hidden ? "Show token" : "Hide token"} onClick={() => setHidden((h) => !h)}>
                {hidden ? <Eye /> : <EyeOff />}
              </Button>
              <CopyButton value={selectedToken} label="Token" />
            </div>
          ) : revealing ? (
            <div className="mt-3 flex items-center gap-2 text-sm text-muted-foreground"><Loader2 className="size-4 animate-spin" /> Loading…</div>
          ) : null}
        </div>
      ) : null}

      {/* Tokens */}
      <Card>
        <CardHeader className="flex flex-row items-start justify-between gap-4">
          <div>
            <CardTitle>Your tokens</CardTitle>
            <CardDescription>Up to 5 active tokens. Click a token to see and copy it. Revoke any that leaks — it stops working immediately.</CardDescription>
          </div>
          <Button size="sm" onClick={() => setCreating(true)} disabled={active.length >= 5}>
            <Plus /> New token
          </Button>
        </CardHeader>
        <CardContent>
          {tokens.length === 0 ? (
            <EmptyState icon={KeyRound} title="No tokens yet" description="Create one to start using the API from Codex, Claude Code or any SDK." className="py-8" />
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="hover:bg-transparent">
                    <TableHead className="w-8" />
                    <TableHead>Name</TableHead>
                    <TableHead>Token</TableHead>
                    <TableHead>Created</TableHead>
                    <TableHead>Last used</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead className="text-right" />
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {tokens.map((t) => (
                    <TableRow
                      key={t.id}
                      onClick={() => selectToken(t)}
                      aria-selected={selectedId === t.id}
                      className={cn(t.revokedAt ? "opacity-50" : "cursor-pointer", selectedId === t.id && "bg-primary/5")}
                    >
                      <TableCell>
                        <span
                          className={cn(
                            "flex size-5 items-center justify-center rounded-full border",
                            selectedId === t.id ? "border-primary bg-primary text-primary-foreground" : "border-muted-foreground/30"
                          )}
                        >
                          {selectedId === t.id ? <Check className="size-3" /> : null}
                        </span>
                      </TableCell>
                      <TableCell className="font-medium">{t.name}</TableCell>
                      <TableCell className="font-mono text-xs">{t.prefix}…</TableCell>
                      <TableCell className="text-muted-foreground"><LocalTime date={new Date(t.createdAt)} variant="date" /></TableCell>
                      <TableCell className="text-muted-foreground">{t.lastUsedAt ? <LocalTime date={new Date(t.lastUsedAt)} variant="datetime" /> : "never"}</TableCell>
                      <TableCell>
                        {t.revokedAt ? (
                          <span className="inline-flex rounded-full bg-muted px-2.5 py-0.5 text-xs font-medium text-muted-foreground">Revoked</span>
                        ) : (
                          <span className="inline-flex rounded-full bg-success/12 px-2.5 py-0.5 text-xs font-medium text-success">Active</span>
                        )}
                      </TableCell>
                      <TableCell className="text-right" onClick={(e) => e.stopPropagation()}>
                        {!t.revokedAt ? (
                          <ConfirmDialog
                            trigger={<Button variant="ghost" size="icon-sm" aria-label="Revoke" className="text-destructive hover:text-destructive"><Trash2 /></Button>}
                            title={`Revoke "${t.name}"?`}
                            description="Any tool still using this token will get authentication errors."
                            confirmLabel="Revoke token"
                            destructive
                            onConfirm={async () => {
                              const r = await revokeTokenAction(t.id);
                              if (r.ok) {
                                toast.success("Token revoked");
                                router.refresh();
                              } else toast.error(r.error);
                            }}
                          />
                        ) : null}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Models */}
      <Card>
        <CardHeader>
          <CardTitle>Available models</CardTitle>
          <CardDescription>Model prices per 1 million tokens. What each of your requests cost is listed in Activity Logs.</CardDescription>
        </CardHeader>
        <CardContent>
          {models.length === 0 ? (
            <EmptyState icon={ShieldAlert} title="No models available yet" description="The administrator hasn&apos;t enabled any models for your store." className="py-8" />
          ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="hover:bg-transparent">
                    <TableHead>Model id</TableHead>
                    <TableHead>Name</TableHead>
                    <TableHead className="text-right">Input / 1M</TableHead>
                    <TableHead className="text-right" title="Input tokens served from the provider's prompt cache (Claude Code reuses context heavily)">Cached in / 1M</TableHead>
                    <TableHead className="text-right">Output / 1M</TableHead>
                    <TableHead className="text-right">Context</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {models.map((m) => (
                    <TableRow key={m.slug}>
                      <TableCell>
                        <span className="inline-flex items-center gap-1 font-mono text-xs">
                          {m.slug} <CopyButton value={m.slug} label="Model id" size="icon-xs" />
                        </span>
                      </TableCell>
                      <TableCell>{m.displayName}</TableCell>
                      <TableCell className="text-right tabular-nums">{perM(m.inputCentsPerMTok)}</TableCell>
                      <TableCell className={"text-right tabular-nums " + (m.cachedInputCentsPerMTok < m.inputCentsPerMTok ? "text-success" : "text-muted-foreground")}>{perM(m.cachedInputCentsPerMTok)}</TableCell>
                      <TableCell className="text-right tabular-nums">{perM(m.outputCentsPerMTok)}</TableCell>
                      <TableCell className="text-right tabular-nums text-muted-foreground">{m.contextWindow ? `${Math.round(m.contextWindow / 1000)}k` : "—"}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Setup */}
      <Card>
        <CardHeader className="flex flex-row flex-wrap items-start justify-between gap-4">
          <div>
            <CardTitle>Connect your tool</CardTitle>
            <CardDescription>
              {selectedToken ? `Snippets include the token “${selected?.name}”.` : "Select a token above (or create one) and the snippets will fill in automatically."}
            </CardDescription>
          </div>
          {models.length > 0 ? (
            <div className="w-56 space-y-1">
              <Label className="text-xs text-muted-foreground">Model for the snippets</Label>
              <Select value={model} onValueChange={setSelectedModel}>
                <SelectTrigger><SelectValue /></SelectTrigger>
                <SelectContent>
                  {models.map((m) => <SelectItem key={m.slug} value={m.slug}>{m.displayName}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
          ) : null}
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="claude">
            <TabsList>
              <TabsTrigger value="claude">Claude Code</TabsTrigger>
              <TabsTrigger value="codex">Codex CLI</TabsTrigger>
              <TabsTrigger value="opencode">OpenCode</TabsTrigger>
              <TabsTrigger value="curl">cURL / SDKs</TabsTrigger>
            </TabsList>
            <TabsContent value="claude" className="space-y-3 pt-3">
              <p className="text-sm text-muted-foreground">
                Save as <code className="rounded bg-muted px-1 py-0.5 font-mono text-xs">~/.claude/settings.json</code> (Windows: <code className="rounded bg-muted px-1 py-0.5 font-mono text-xs">C:\Users\YOU\.claude\settings.json</code>), then run <code className="rounded bg-muted px-1 py-0.5 font-mono text-xs">claude</code>.
              </p>
              <CodeBlock code={claudeSettings} language="json" />
            </TabsContent>
            <TabsContent value="codex" className="space-y-3 pt-3">
              <p className="text-sm text-muted-foreground">
                Save as <code className="rounded bg-muted px-1 py-0.5 font-mono text-xs">~/.codex/config.toml</code>, then set the environment variable{" "}
                <code className="rounded bg-muted px-1 py-0.5 font-mono text-xs">AEROLINK_API_KEY={tokenForSnippet}</code> and run <code className="rounded bg-muted px-1 py-0.5 font-mono text-xs">codex</code>.
              </p>
              <p className="rounded-xl border border-warning/25 bg-warning/7 px-3.5 py-2.5 text-xs leading-relaxed text-muted-foreground">
                <span className="font-semibold text-warning">Use Codex 0.80.0:</span>{" "}
                <code className="rounded bg-muted px-1 py-0.5 font-mono">npm install -g @openai/codex@0.80.0</code>. Newer releases only
                support OpenAI&apos;s Responses API and fail with{" "}
                <code className="font-mono">wire_api = &quot;chat&quot; is no longer supported</code>.
              </p>
              <CodeBlock code={codexToml} language="toml" />
              <CodeBlock code={envSnippet} language="bash" />
            </TabsContent>
            <TabsContent value="opencode" className="space-y-3 pt-3">
              <p className="text-sm text-muted-foreground">
                Save as <code className="rounded bg-muted px-1 py-0.5 font-mono text-xs">~/.config/opencode/opencode.json</code> (Windows:{" "}
                <code className="rounded bg-muted px-1 py-0.5 font-mono text-xs">C:\Users\YOU\.config\opencode\opencode.json</code>), set{" "}
                <code className="rounded bg-muted px-1 py-0.5 font-mono text-xs">AEROLINK_API_KEY</code>, then run{" "}
                <code className="rounded bg-muted px-1 py-0.5 font-mono text-xs">opencode</code> and pick the model with{" "}
                <code className="rounded bg-muted px-1 py-0.5 font-mono text-xs">/models</code>. Already have an opencode.json? Add only
                the <code className="font-mono text-xs">&quot;aerolink&quot;</code> block inside your <code className="font-mono text-xs">&quot;provider&quot;</code> object.
              </p>
              <CodeBlock code={opencodeJson} language="json" />
              <CodeBlock code={envSnippet} language="bash" />
            </TabsContent>
            <TabsContent value="curl" className="space-y-3 pt-3">
              <p className="text-sm text-muted-foreground">
                Any OpenAI-compatible SDK works: set <code className="rounded bg-muted px-1 py-0.5 font-mono text-xs">base_url</code> to <code className="rounded bg-muted px-1 py-0.5 font-mono text-xs">{baseUrl}/v1</code> and the API key to your token. Anthropic SDKs: <code className="rounded bg-muted px-1 py-0.5 font-mono text-xs">ANTHROPIC_BASE_URL={baseUrl}</code>.
              </p>
              <CodeBlock code={curlExample} language="bash" />
            </TabsContent>
          </Tabs>
          <p className="mt-4 text-sm text-muted-foreground">
            Using Cline, Roo Code, Kilo Code, Continue, Aider, Qwen Code, Crush or Zed? Step-by-step setup is in{" "}
            <Link href="/portal/documentation" className="font-medium text-primary underline-offset-4 hover:underline">
              Documentation → More agents
            </Link>
            .
          </p>
        </CardContent>
      </Card>

      <Dialog open={creating} onOpenChange={(v) => !v && setCreating(false)}>
        <DialogContent className="sm:max-w-sm">
          <DialogHeader>
            <DialogTitle>New API token</DialogTitle>
            <DialogDescription>Give it a name so you remember where it&apos;s used.</DialogDescription>
          </DialogHeader>
          <div className="space-y-1.5">
            <Label htmlFor="token-name">Name</Label>
            <Input id="token-name" value={name} onChange={(e) => setName(e.target.value)} placeholder="Laptop · Claude Code" maxLength={40} autoFocus onKeyDown={(e) => e.key === "Enter" && create()} />
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setCreating(false)} disabled={pending}>Cancel</Button>
            <Button onClick={create} disabled={pending}>
              {pending ? <Loader2 className="animate-spin" /> : <KeyRound />} Create token
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
