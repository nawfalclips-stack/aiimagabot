"use client";

import { useState } from "react";
import { motion } from "framer-motion";
import { Eye, EyeOff, KeyRound } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { CopyButton } from "@/components/shared/copy-button";
import { maskApiKey } from "@/lib/format";

/**
 * Displays the API key assigned by the administrator. Customers can only
 * view and copy it — never edit, replace or regenerate it.
 */
export function ApiKeyCard({ apiKey }: { apiKey: string }) {
  const [visible, setVisible] = useState(false);

  return (
    <Card className="relative gap-0 overflow-hidden p-6">
      <div aria-hidden className="pointer-events-none absolute -top-16 -right-16 size-48 rounded-full bg-primary/10 blur-3xl" />
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <KeyRound className="size-[18px] text-primary" />
          <div>
            <h2 className="text-sm font-semibold">Your API Key</h2>
            <p className="text-xs text-muted-foreground">Assigned to your account — keep it secret</p>
          </div>
        </div>
        <div className="flex items-center gap-1">
          <Button
            variant="ghost"
            size="icon-sm"
            onClick={() => setVisible((v) => !v)}
            aria-label={visible ? "Hide API key" : "Show API key"}
          >
            {visible ? <EyeOff /> : <Eye />}
          </Button>
          <CopyButton value={apiKey} label="API key" />
        </div>
      </div>

      <motion.div
        key={visible ? "visible" : "hidden"}
        initial={{ opacity: 0, y: 4 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.2 }}
        className="mt-4 overflow-x-auto rounded-xl border bg-muted/40 px-4 py-3"
      >
        <code className="font-mono text-[13px] break-all text-foreground">
          {visible ? apiKey : maskApiKey(apiKey)}
        </code>
      </motion.div>
    </Card>
  );
}
