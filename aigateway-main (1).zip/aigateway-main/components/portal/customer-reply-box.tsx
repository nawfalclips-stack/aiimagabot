"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { Loader2, Send } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { customerReplyAction } from "@/app/portal/support/actions";

export function CustomerReplyBox({ ticketId }: { ticketId: string }) {
  const [body, setBody] = useState("");
  const [pending, startTransition] = useTransition();
  const router = useRouter();

  const send = () => {
    if (!body.trim()) return;
    startTransition(async () => {
      const result = await customerReplyAction(ticketId, body);
      if (result.ok) { setBody(""); router.refresh(); }
      else toast.error(result.error);
    });
  };

  return (
    <div className="flex gap-2">
      <Textarea
        value={body}
        onChange={(e) => setBody(e.target.value)}
        placeholder="Type your reply…"
        rows={2}
        onKeyDown={(e) => {
          if (e.key === "Enter" && (e.ctrlKey || e.metaKey)) send();
        }}
        className="flex-1 resize-none"
      />
      <Button onClick={send} disabled={!body.trim() || pending} size="icon" className="h-full aspect-square">
        {pending ? <Loader2 className="animate-spin" /> : <Send />}
      </Button>
    </div>
  );
}
