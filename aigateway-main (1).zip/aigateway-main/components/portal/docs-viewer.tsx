"use client";

import { useMemo, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { BookOpen, FileSearch, Search, X } from "lucide-react";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Markdown } from "@/components/shared/markdown";
import { EmptyState } from "@/components/shared/empty-state";
import { CopyButton } from "@/components/shared/copy-button";
import { AgentsLogo, ClaudeLogo, CodexLogo, OpenCodeLogo, SdkLogo } from "@/components/shared/agent-logos";
import { DOC_CATEGORIES, DOC_OS_LABELS, type DocOS } from "@/lib/constants";
import { cn } from "@/lib/utils";

export interface PortalDoc {
  slug: string;
  category: string;
  os: string;
  title: string;
  content: string; // {{BASE_URL}} / {{MODEL}} already filled in (WS7)
}

const CATEGORY_META: Record<
  string,
  { name: string; badge: string; description: string; Logo: typeof CodexLogo }
> = {
  CODEX: {
    name: "Codex CLI",
    badge: "OPENAI-COMPATIBLE",
    description: "Codex CLI through the AeroLink gateway (Chat Completions).",
    Logo: CodexLogo,
  },
  CLAUDE: {
    name: "Claude Code",
    badge: "ANTHROPIC-COMPATIBLE",
    description: "Anthropic's coding agent through the AeroLink gateway.",
    Logo: ClaudeLogo,
  },
  DESKTOP: {
    name: "Claude Desktop",
    badge: "ANTHROPIC-COMPATIBLE",
    description: "The Claude app for Windows and macOS — chat, Cowork and Code — on your AeroLink balance.",
    Logo: ClaudeLogo,
  },
  OPENCODE: {
    name: "OpenCode",
    badge: "OPENAI-COMPATIBLE",
    description: "Open-source terminal agent with AeroLink as a custom provider.",
    Logo: OpenCodeLogo,
  },
  AGENTS: {
    name: "More agents",
    badge: "ANY TOOL",
    description: "Cline, Roo Code, Kilo Code, Continue, Aider, Qwen Code, Crush, Zed…",
    Logo: AgentsLogo,
  },
  SKILLS: {
    name: "Skills",
    badge: "CLAUDE CODE · CODEX · OPENCODE",
    description: "Reusable SKILL.md instructions that make your agent better at design, testing, documents and more.",
    Logo: AgentsLogo,
  },
  SDK: {
    name: "API & SDKs",
    badge: "PYTHON · NODE · CURL",
    description: "Call AeroLink from your own code with the OpenAI or Anthropic SDK.",
    Logo: SdkLogo,
  },
};

export function DocsViewer({ docs, baseUrl }: { docs: PortalDoc[]; baseUrl: string }) {
  const codexBaseUrl = `${baseUrl}/v1`;
  const claudeBaseUrl = baseUrl;
  const categories = useMemo(() => {
    const present = new Set(docs.map((d) => d.category));
    // Show categories in the canonical order from DOC_CATEGORIES.
    const ordered: string[] = DOC_CATEGORIES.filter((c) => present.has(c));
    for (const c of present) if (!ordered.includes(c)) ordered.push(c);
    return ordered;
  }, [docs]);
  const [category, setCategory] = useState<string>(categories[0] ?? "CLAUDE");
  const [os, setOs] = useState<string>("WINDOWS");
  const [query, setQuery] = useState("");

  const activeDoc = docs.find((d) => d.category === category && d.os === os);
  const activeMeta = CATEGORY_META[category];

  const results = useMemo(() => {
    const q = query.trim().toLowerCase();
    if (q.length < 2) return null;
    return docs
      .map((doc) => {
        const haystack = `${doc.title}\n${doc.content}`.toLowerCase();
        const index = haystack.indexOf(q);
        if (index === -1) return null;
        const snippetSource = doc.content.toLowerCase();
        const snippetIndex = snippetSource.indexOf(q);
        const start = Math.max(0, (snippetIndex === -1 ? 0 : snippetIndex) - 60);
        const snippet = doc.content
          .slice(start, start + 160)
          .replace(/[#`>*]/g, "")
          .trim();
        return { doc, snippet };
      })
      .filter((r): r is { doc: PortalDoc; snippet: string } => r !== null);
  }, [docs, query]);

  if (docs.length === 0) {
    return (
      <EmptyState
        icon={BookOpen}
        title="No documentation available yet"
        description="Setup guides will appear here as soon as they are published."
      />
    );
  }

  return (
    <div className="space-y-6">
      {/* Hero */}
      <div>
        <p className="eyebrow text-primary">Help · Documentation</p>
        <h1 className="mt-1.5 text-[1.65rem] leading-tight font-semibold tracking-tight text-balance sm:text-3xl">
          Set Up Aerolink With Coding Agents
        </h1>
        <p className="mt-1.5 max-w-2xl text-sm leading-relaxed text-muted-foreground">
          Choose Codex CLI or Claude Code, install the client, connect it with an API token from the API Access
          page, then run it inside a real project folder.
        </p>
      </div>

      {/* Search */}
      <div className="relative max-w-md">
        <Search className="absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground" />
        <Input
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          placeholder="Search commands, titles, operating systems…"
          className="h-10 bg-card pl-9 shadow-card"
          aria-label="Search documentation"
        />
        {query ? (
          <button
            type="button"
            onClick={() => setQuery("")}
            className="absolute top-1/2 right-3 -translate-y-1/2 text-muted-foreground hover:text-foreground"
            aria-label="Clear search"
          >
            <X className="size-4" />
          </button>
        ) : null}
      </div>

      {results !== null ? (
        // Search results
        <div className="space-y-2">
          {results.length === 0 ? (
            <EmptyState
              icon={FileSearch}
              title="No matches found"
              description={`Nothing in the guides matches “${query}”.`}
            />
          ) : (
            results.map(({ doc, snippet }) => (
              <button
                key={doc.slug}
                type="button"
                onClick={() => {
                  setCategory(doc.category);
                  setOs(doc.os);
                  setQuery("");
                }}
                className="block w-full rounded-xl border bg-card px-5 py-4 text-left transition-colors hover:border-primary/40 hover:bg-accent/40"
              >
                <p className="text-sm font-semibold">{doc.title}</p>
                <p className="mt-1 line-clamp-2 text-xs text-muted-foreground">…{snippet}…</p>
              </button>
            ))
          )}
        </div>
      ) : (
        <>
          {/* Selected agent hero card */}
          {activeMeta ? (
            <AnimatePresence mode="wait">
              <motion.div
                key={category}
                initial={{ opacity: 0, y: 6 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -6 }}
                transition={{ duration: 0.2 }}
              >
                <Card className="flex-row items-center gap-5 p-6 sm:p-7">
                  <activeMeta.Logo className="size-16 sm:size-20" />
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-2.5">
                      <h2 className="text-xl font-bold tracking-tight sm:text-2xl">{activeMeta.name}</h2>
                      <span className="rounded-full border px-2.5 py-0.5 text-[10px] font-semibold tracking-wider text-muted-foreground">
                        {activeMeta.badge}
                      </span>
                    </div>
                    <p className="mt-1 text-sm text-muted-foreground sm:text-[15px]">{activeMeta.description}</p>
                  </div>
                </Card>
              </motion.div>
            </AnimatePresence>
          ) : null}

          {/* Agent selector cards */}
          <div className="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
            {categories.map((c) => {
              const meta = CATEGORY_META[c];
              if (!meta) return null;
              const active = category === c;
              return (
                <button
                  key={c}
                  type="button"
                  onClick={() => setCategory(c)}
                  aria-pressed={active}
                  className={cn(
                    "flex items-center gap-3.5 rounded-2xl border p-4 text-left transition-all duration-200",
                    active
                      ? "border-primary/50 bg-primary/8 shadow-card ring-1 ring-primary/20"
                      : "bg-card shadow-card hover:border-primary/30 hover:bg-accent/30"
                  )}
                >
                  <meta.Logo className="size-11" />
                  <div className="min-w-0">
                    <p className={cn("text-base font-semibold", !active && "text-muted-foreground")}>{meta.name}</p>
                    <p className="mt-0.5 text-[13px] leading-snug text-muted-foreground">{meta.description}</p>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Base URLs */}
          <div className="grid gap-3 sm:grid-cols-2">
            <div className="flex items-center justify-between gap-3 rounded-xl border bg-card py-2.5 pr-1.5 pl-4 shadow-card">
              <div className="min-w-0">
                <p className="text-[11px] font-medium tracking-wide text-muted-foreground uppercase">OpenAI-compatible base URL</p>
                <code className="block truncate font-mono text-[13px] text-foreground">{codexBaseUrl}</code>
              </div>
              <CopyButton value={codexBaseUrl} label="OpenAI-compatible base URL" />
            </div>
            <div className="flex items-center justify-between gap-3 rounded-xl border bg-card py-2.5 pr-1.5 pl-4 shadow-card">
              <div className="min-w-0">
                <p className="text-[11px] font-medium tracking-wide text-muted-foreground uppercase">Anthropic-compatible base URL</p>
                <code className="block truncate font-mono text-[13px] text-foreground">{claudeBaseUrl}</code>
              </div>
              <CopyButton value={claudeBaseUrl} label="Anthropic-compatible base URL" />
            </div>
          </div>

          {/* OS tabs */}
          <Tabs value={os} onValueChange={setOs}>
            <TabsList>
              {(["WINDOWS", "MACOS", "LINUX"] as const).map((o) => (
                <TabsTrigger key={o} value={o}>
                  {DOC_OS_LABELS[o as DocOS]}
                </TabsTrigger>
              ))}
            </TabsList>
          </Tabs>

          {/* Guide content */}
          <AnimatePresence mode="wait">
            <motion.div
              key={`${category}-${os}`}
              initial={{ opacity: 0, y: 8 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
            >
              {activeDoc ? (
                <Card className="px-6 py-2 sm:px-8">
                  <Markdown content={activeDoc.content} />
                </Card>
              ) : (
                <EmptyState
                  icon={BookOpen}
                  title="Guide not available"
                  description="This guide hasn't been published yet. Check back soon."
                />
              )}
            </motion.div>
          </AnimatePresence>
        </>
      )}
    </div>
  );
}
