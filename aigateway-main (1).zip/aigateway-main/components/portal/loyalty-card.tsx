"use client";

import { useTransition } from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { motion } from "framer-motion";
import { Award, Clock, Gift, Loader2, ShoppingBag } from "lucide-react";
import { Button } from "@/components/ui/button";
import { formatCents } from "@/lib/money";
import { canRequestReward, firstRewardTier, getNextTier, getTierForPoints, type LoyaltyTier } from "@/lib/loyalty";

interface LoyaltyCardProps {
  points: number;
  purchaseCount: number;
  rewardRequestStatus: string;
  /** The store's loyalty levels (admin → Loyalty → Program settings). */
  tiers: LoyaltyTier[];
  onRequestReward: () => Promise<{ ok: boolean; error?: string }>;
}

/**
 * The customer's loyalty section on their dashboard: level badge with its own
 * accent color, progress toward the next tier, purchase count and — at VIP —
 * the button that ASKS the admin for the cash reward (never instant credit).
 */
export function LoyaltyCard({ points, purchaseCount, rewardRequestStatus, tiers, onRequestReward }: LoyaltyCardProps) {
  const [pending, startTransition] = useTransition();
  const router = useRouter();

  const tier = getTierForPoints(points, tiers);
  const next = getNextTier(points, tiers);
  const unlock = firstRewardTier(tiers);
  // Top level reached: the claim button moves up next to the level badge.
  const isVip = next === null && tier.rewardAmountCents > 0;
  const progressPct = next
    ? Math.min(100, Math.round(((points - tier.minPoints) / (next.minPoints - tier.minPoints)) * 100))
    : 100;

  const request = () => {
    startTransition(async () => {
      const result = await onRequestReward();
      if (result.ok) {
        toast.success("Reward request sent!", {
          description: "An administrator will review it shortly. You'll be notified once approved.",
        });
        router.refresh();
      } else if (result.error) {
        toast.error(result.error);
      }
    });
  };

  return (
    <motion.section
      initial={{ opacity: 0, y: 8 }}
      animate={{ opacity: 1, y: 0 }}
      className="relative overflow-hidden rounded-2xl border bg-card p-5 shadow-card sm:p-6"
      aria-label="Loyalty program"
    >
      {/* Tier-colored glow — the loyalty level tints this card */}
      <span
        aria-hidden
        className="pointer-events-none absolute -top-24 -left-16 size-72 rounded-full opacity-[0.12] blur-3xl"
        style={{ backgroundColor: tier.colorHex }}
      />
      <span
        aria-hidden
        className="pointer-events-none absolute inset-x-0 top-0 h-px"
        style={{ background: `linear-gradient(90deg, transparent, ${tier.colorHex}, transparent)` }}
      />
      <div className="relative flex flex-wrap items-start justify-between gap-4">
        <div className="flex items-start gap-3">
          <span
            className="flex size-10 shrink-0 items-center justify-center rounded-lg"
            style={{ backgroundColor: `${tier.colorHex}22`, color: tier.colorHex }}
          >
            <Award className="size-5" />
          </span>
          <div>
            <p className="text-sm font-semibold">
              {tier.name}
              {!isVip && next ? <span className="ml-2 font-normal text-muted-foreground">— next: {next.name}</span> : null}
            </p>
            <p className="mt-0.5 flex flex-wrap items-center gap-x-3 gap-y-0.5 text-sm text-muted-foreground">
              <span className="font-display text-xl font-semibold text-foreground tabular-nums">{points}</span> points
              <span className="inline-flex items-center gap-1">
                <ShoppingBag className="size-3.5" /> {purchaseCount} purchase{purchaseCount === 1 ? "" : "s"}
              </span>
            </p>
          </div>
        </div>

        {isVip ? (
          rewardRequestStatus === "NONE" || rewardRequestStatus === "REJECTED" ? (
            <Button onClick={request} disabled={pending} className="gap-2">
              {pending ? <Loader2 className="size-4 animate-spin" /> : <Gift className="size-4" />}
              Request my {formatCents(tier.rewardAmountCents)} reward
            </Button>
          ) : rewardRequestStatus === "PENDING" ? (
            <span className="inline-flex items-center gap-2 rounded-lg border border-warning/40 bg-warning/10 px-3 py-2 text-sm font-medium text-warning">
              <Clock className="size-4" /> Member reward pending approval
            </span>
          ) : (
            <span className="inline-flex items-center gap-2 rounded-lg border border-success/40 bg-success/10 px-3 py-2 text-sm font-medium text-success">
              <Gift className="size-4" /> Member reward approved &amp; credited
            </span>
          )
        ) : null}
      </div>

      {/* Member reward section — visible at EVERY level with its unlock condition. */}
      <div className="relative mt-5 w-full rounded-xl border border-primary/20 bg-primary/6 px-4 py-3">
        {rewardRequestStatus === "PENDING" ? (
          <p className="flex items-center gap-2 text-sm font-medium text-warning">
            <Clock className="size-4 shrink-0" /> Member reward request is waiting for admin approval
          </p>
        ) : rewardRequestStatus === "APPROVED" ? (
          <p className="flex items-center gap-2 text-sm font-medium text-success">
            <Gift className="size-4 shrink-0" /> Member reward approved — credited to your bonus balance
          </p>
        ) : canRequestReward(points, tiers) ? (
          <div className="flex flex-wrap items-center justify-between gap-3">
            <p className="text-sm font-semibold">
              💎 Your member reward of <strong>{formatCents(tier.rewardAmountCents)}</strong> is ready to claim!
            </p>
            <Button onClick={request} disabled={pending} size="sm" className="gap-2">
              {pending ? <Loader2 className="size-4 animate-spin" /> : <Gift className="size-4" />}
              Request my member reward
            </Button>
          </div>
        ) : (
          unlock ? (
            <>
              <p className="text-sm font-semibold">
                💎 Member reward unlocks at {unlock.name} ({unlock.minPoints} pts) — worth {formatCents(unlock.rewardAmountCents)}
              </p>
              <p className="mt-1 text-xs text-muted-foreground">
                Collect {Math.max(0, unlock.minPoints - points)} more points (every purchase earns points, friends&apos;
                purchases earn you points too) then claim your cash reward here for admin approval.
              </p>
            </>
          ) : (
            <p className="text-sm text-muted-foreground">Earn points with every purchase to move up the levels.</p>
          )
        )}
      </div>
      <div className="relative mt-5">
        <div className="h-2 overflow-hidden rounded-full bg-muted">
          <div
            className="h-full rounded-full transition-all"
            style={{ width: `${progressPct}%`, backgroundColor: tier.colorHex }}
          />
        </div>
        {next ? (
          <p className="mt-1.5 text-xs text-muted-foreground">
            {Math.max(0, next.minPoints - points)} more points to reach{" "}
            <span className="font-medium text-foreground">{next.name}</span>
          </p>
        ) : (
          <p className="mt-1.5 text-xs font-medium" style={{ color: tier.colorHex }}>
            🎉 Max level reached — enjoy your perks!
          </p>
        )}
      </div>

      {/* Level ladder */}
      <div className="relative mt-5 grid grid-cols-2 gap-2 sm:grid-cols-[repeat(auto-fit,minmax(8rem,1fr))]">
        {tiers.map((t) => (
          <div
            key={t.id}
            className={`rounded-xl border px-3 py-2 text-xs transition-colors ${t.id === tier.id ? "font-semibold" : "text-muted-foreground"}`}
            style={
              t.id === tier.id
                ? { borderColor: t.colorHex, color: t.colorHex, backgroundColor: `${t.colorHex}14` }
                : undefined
            }
          >
            {t.name}
            <span className="block text-[11px] opacity-80">{t.minPoints}+ pts</span>
          </div>
        ))}
      </div>
    </motion.section>
  );
}
