"use client";

import { useState, useTransition } from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { ArrowLeft, Loader2, Send, Ticket } from "lucide-react";
import Link from "next/link";
import { Button } from "@/components/ui/button";
import { PageHeader } from "@/components/shared/page-header";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Textarea } from "@/components/ui/textarea";
import { TICKET_TYPES, TICKET_TYPE_LABELS } from "@/lib/constants";
import { createTicketAction } from "@/app/portal/support/actions";

export function NewTicketForm({ orderNumber }: { orderNumber: string }) {
  const router = useRouter();
  const [pending, startTransition] = useTransition();
  const [form, setForm] = useState({
    type: "API_ISSUE",
    title: "",
    description: "",
    screenshotUrl: "",
    orderNumber,
  });
  const set = (k: keyof typeof form) => (v: string) => setForm((f) => ({ ...f, [k]: v }));

  const submit = () => {
    startTransition(async () => {
      const result = await createTicketAction({
        type: form.type,
        title: form.title,
        // Prepend order number to description so admin can look it up on GamsGo.
        description: form.orderNumber.trim()
          ? `Order: ${form.orderNumber.trim()}\n\n${form.description}`
          : form.description,
        screenshotUrl: form.screenshotUrl,
      });
      if (result.ok && result.ticketId) {
        toast.success("Ticket submitted", { description: "We received your issue — contact us on GamsGo for faster support." });
        router.push(`/portal/support/${result.ticketId}`);
      } else if (!result.ok) {
        toast.error(result.error);
      }
    });
  };

  return (
    <div className="max-w-xl space-y-6">
      <Button asChild variant="ghost" size="sm" className="-ml-2 text-muted-foreground">
        <Link href="/portal/support"><ArrowLeft /> Back to support</Link>
      </Button>

      <PageHeader
        eyebrow="Help"
        title="Open a support ticket"
        description="Describe your issue below. Include the x-request-id from the failed response if you have it."
      />

      <Card>
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Ticket className="size-4 text-primary" /> Describe your issue
          </CardTitle>
          <CardDescription>Include as much detail as possible so we can help you quickly.</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Order number — pre-filled, editable */}
          <div className="space-y-2">
            <Label htmlFor="order">Your Order Number</Label>
            <Input
              id="order"
              value={form.orderNumber}
              onChange={(e) => set("orderNumber")(e.target.value)}
              placeholder="e.g. 874133419448209408"
              className="font-mono"
            />
            <p className="text-xs text-muted-foreground">Your GamsGo order number — helps us find your account faster.</p>
          </div>

          <div className="space-y-2">
            <Label>Issue type</Label>
            <Select value={form.type} onValueChange={set("type")}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {TICKET_TYPES.map((t) => (
                  <SelectItem key={t} value={t}>{TICKET_TYPE_LABELS[t]}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            {form.type === "API_ISSUE" ? (
              <p className="text-xs text-muted-foreground">Quick check: your tool must use your AeroLink token and the base URL shown on the API Access page.</p>
            ) : null}
          </div>

          <div className="space-y-2">
            <Label htmlFor="title">Short title</Label>
            <Input
              id="title"
              value={form.title}
              onChange={(e) => set("title")(e.target.value)}
              placeholder="e.g. API key returns 401 error"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="desc">Describe the problem</Label>
            <Textarea
              id="desc"
              rows={4}
              value={form.description}
              onChange={(e) => set("description")(e.target.value)}
              placeholder="What happened? Paste any error messages here."
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="screenshot">Screenshot URL <span className="text-muted-foreground">(optional)</span></Label>
            <Input
              id="screenshot"
              type="url"
              value={form.screenshotUrl}
              onChange={(e) => set("screenshotUrl")(e.target.value)}
              placeholder="https://..."
            />
          </div>

          <Button onClick={submit} disabled={!form.title || !form.description || pending} className="w-full">
            {pending ? <Loader2 className="animate-spin" /> : <Send />}
            Submit ticket
          </Button>
        </CardContent>
      </Card>
    </div>
  );
}
