"use client";

import Link from "next/link";
import { Clock, ExternalLink, XCircle, Zap } from "lucide-react";
import { Button } from "@/components/ui/button";
import { CopyButton } from "@/components/shared/copy-button";
import type { SocialLink } from "@/lib/social-links";
import { SocialLinks } from "@/components/shared/social-links";

interface PendingActivationScreenProps {
  storeUrl: string;
  accessCode: string;
  isRejected: boolean;
  rejectionReason: string;
  logoText: string;
  footerText: string;
  socialLinks?: SocialLink[];
}

export function PendingActivationScreen({
  storeUrl,
  accessCode,
  isRejected,
  rejectionReason,
  logoText,
  footerText,
  socialLinks = [],
}: PendingActivationScreenProps) {
  return (
    <div className="flex min-h-screen flex-col overflow-hidden">
      {/* Ambient background */}
      <div aria-hidden className="pointer-events-none fixed inset-0">
        <div className="absolute top-[-20%] left-1/2 h-[480px] w-[720px] -translate-x-1/2 rounded-full bg-primary/10 blur-[140px]" />
      </div>

      {/* Header */}
      <header className="relative z-10 mx-auto flex w-full max-w-5xl items-center px-6 py-6">
        <div className="flex items-center gap-2.5">
          <span className="flex size-8 items-center justify-center rounded-lg bg-primary shadow-lg shadow-primary/25">
            <Zap className="size-4.5 text-white" />
          </span>
          <span className="text-[15px] font-semibold tracking-tight">{logoText}</span>
        </div>
      </header>

      {/* Main */}
      <main className="relative z-10 mx-auto flex w-full max-w-lg flex-1 flex-col items-center justify-center gap-8 px-6 pb-16">
        {isRejected ? (
          /* Rejected state */
          <div className="w-full space-y-6 text-center">
            <div className="mx-auto flex size-16 items-center justify-center rounded-2xl bg-destructive/15 ring-1 ring-destructive/30">
              <XCircle className="size-8 text-destructive" />
            </div>
            <div>
              <h1 className="text-2xl font-semibold tracking-tight">Activation not approved</h1>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                {rejectionReason ||
                  "Your offer title does not match the order. Please verify your details and contact us."}
              </p>
            </div>
            <div className="rounded-xl border bg-muted/30 px-5 py-4 text-sm text-muted-foreground">
              <p>Your access code (saved for when you are approved):</p>
              <div className="mt-2 flex items-center justify-center gap-2">
                <code className="font-mono font-semibold text-foreground">{accessCode}</code>
                <CopyButton value={accessCode} label="Access code" />
              </div>
            </div>
            <a
              href={storeUrl}
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2 rounded-xl bg-primary px-6 py-3 text-sm font-semibold text-white shadow-lg shadow-primary/25 transition-all hover:bg-primary/90"
            >
              <ExternalLink className="size-4" /> Contact us on GamsGo
            </a>
          </div>
        ) : (
          /* Pending state */
          <div className="w-full space-y-6 text-center">
            <div className="mx-auto flex size-16 items-center justify-center rounded-2xl bg-warning/15 ring-1 ring-warning/30">
              <Clock className="size-8 text-warning" />
            </div>
            <div>
              <h1 className="text-2xl font-semibold tracking-tight">Your account is being verified</h1>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
                We are reviewing your order details to make sure everything is correct and protect the platform from
                fraudulent entries. This usually takes just a few minutes.
              </p>
            </div>

            {/* Access code */}
            <div className="rounded-xl border border-primary/25 bg-primary/8 px-5 py-4">
              <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">
                Your access code — save it
              </p>
              <div className="mt-2 flex items-center justify-center gap-2">
                <code className="font-mono text-lg font-semibold tracking-wider">{accessCode}</code>
                <CopyButton value={accessCode} label="Access code" />
              </div>
              <p className="mt-1 text-xs text-muted-foreground">
                This code is the only way to sign in. Keep it safe.
              </p>
            </div>

            {/* Why this exists */}
            <div className="rounded-xl border bg-muted/30 px-5 py-4 text-left text-sm text-muted-foreground space-y-2">
              <p className="font-medium text-foreground">Why do we verify activations?</p>
              <p>
                Some customers enter offer titles that do not match what they purchased — for example, claiming a $200
                balance when they bought $100. This verification step protects the platform and ensures everyone
                receives exactly what they paid for.
              </p>
            </div>

            {/* 10-minute message */}
            <div className="rounded-xl border border-warning/25 bg-warning/8 px-5 py-4 text-sm text-warning">
              <p className="font-medium">If it has been more than 10 minutes:</p>
              <p className="mt-1 text-xs opacity-80">
                Please send us a message on our store and we will handle it right away.
              </p>
              <a
                href={storeUrl}
                target="_blank"
                rel="noopener noreferrer"
                className="mt-3 inline-flex items-center gap-2 rounded-lg border border-warning/30 bg-background px-4 py-2 text-xs font-semibold text-warning transition-colors hover:bg-warning/10"
              >
                <ExternalLink className="size-3.5" /> Open our GamsGo store
              </a>
            </div>
          </div>
        )}
      </main>

      <footer className="relative z-10 border-t border-border">
        <div className="mx-auto flex w-full max-w-5xl flex-col items-center justify-between gap-2 px-6 py-6 text-xs text-muted-foreground sm:flex-row">
          <p>{footerText}</p>
          <SocialLinks links={socialLinks} />
          <a href={storeUrl} target="_blank" rel="noopener noreferrer" className="transition-colors hover:text-foreground">
            Our store — contact &amp; support
          </a>
        </div>
      </footer>
    </div>
  );
}
