"use client";

import { useState } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { motion } from "framer-motion";
import {
  Award,
  Bell,
  BookOpen,
  KeyRound,
  LayoutDashboard,
  LogOut,
  Menu,
  RefreshCw,
  ScrollText,
  Share2,
  ShieldCheck,
  Ticket,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet";
import { customerLogout } from "@/app/actions";
import { cn } from "@/lib/utils";
import type { SocialLink } from "@/lib/social-links";
import { SocialLinks } from "@/components/shared/social-links";
import { ThemeToggle } from "@/components/theme/theme-toggle";
import { BrandMark } from "@/components/shared/brand-mark";

type NavItem = { href: string; label: string; icon: typeof LayoutDashboard; exact?: boolean };

const NAV_GROUPS: Array<{ label: string; items: NavItem[] }> = [
  {
    label: "Account",
    items: [
      { href: "/portal", label: "Dashboard", icon: LayoutDashboard, exact: true },
      { href: "/portal/api-access", label: "API Access", icon: KeyRound },
      { href: "/portal/recharge", label: "Recharge", icon: RefreshCw },
      { href: "/portal/activity", label: "Activity Logs", icon: ScrollText },
      { href: "/portal/notifications", label: "Notifications", icon: Bell },
    ],
  },
  {
    label: "Rewards",
    items: [
      { href: "/portal/loyalty", label: "Loyalty", icon: Award },
      { href: "/portal/affiliate", label: "Affiliate", icon: Share2 },
    ],
  },
  {
    label: "Help",
    items: [
      { href: "/portal/documentation", label: "Documentation", icon: BookOpen },
      { href: "/portal/support", label: "Report an Issue", icon: Ticket },
      { href: "/portal/rules", label: "Rules & Terms", icon: ShieldCheck },
    ],
  },
];

interface PortalShellProps {
  logoText: string;
  footerText: string;
  storeUrl: string;
  socialLinks?: SocialLink[];
  /** Unread announcements, shown as a badge on Notifications. */
  unreadNotifications?: number;
  children: React.ReactNode;
}

/**
 * Customer portal shell — the section navigation lives in a RIGHT-side
 * sidebar on desktop (per the owner's preference), with a slim top bar and a
 * slide-over menu on mobile.
 */
export function PortalShell({ logoText, footerText, storeUrl, socialLinks = [], unreadNotifications = 0, children }: PortalShellProps) {
  const pathname = usePathname();
  const [menuOpen, setMenuOpen] = useState(false);
  const isActive = (item: NavItem) => (item.exact ? pathname === item.href : pathname.startsWith(item.href));

  const brand = (
    <Link href="/portal" className="flex items-center gap-2.5">
      <span className="flex size-8 shrink-0 items-center justify-center overflow-hidden rounded-lg">
        <BrandMark className="size-8" />
      </span>
      <span className="flex min-w-0 flex-col leading-tight">
        <span className="truncate font-display text-[15px] font-semibold tracking-tight">{logoText}</span>
        <span className="text-[10px] font-medium tracking-wider text-muted-foreground uppercase">Customer portal</span>
      </span>
    </Link>
  );

  const navList = (layoutId: string, onNavigate?: () => void) => (
    <nav className="flex flex-col gap-5" aria-label="Portal navigation">
      {NAV_GROUPS.map((group) => (
        <div key={group.label} className="flex flex-col gap-0.5">
          <p className="eyebrow mb-1 px-3 text-[10px]">{group.label}</p>
          {group.items.map((item) => {
            const active = isActive(item);
            return (
              <Link
                key={item.href}
                href={item.href}
                onClick={onNavigate}
                aria-current={active ? "page" : undefined}
                className={cn(
                  "group/nav relative flex h-9 items-center gap-3 rounded-lg px-3 text-[13.5px] font-medium transition-colors",
                  active ? "text-foreground" : "text-muted-foreground hover:bg-accent/70 hover:text-foreground"
                )}
              >
                {active ? (
                  <motion.span
                    layoutId={layoutId}
                    className="absolute inset-0 rounded-lg bg-primary/10 ring-1 ring-primary/20"
                    transition={{ type: "spring", stiffness: 420, damping: 36 }}
                  />
                ) : null}
                <item.icon
                  className={cn(
                    "relative z-10 size-[18px] transition-transform duration-200 group-hover/nav:scale-105",
                    active && "text-primary"
                  )}
                />
                <span className="relative z-10">{item.label}</span>
                {item.href === "/portal/notifications" && unreadNotifications > 0 ? (
                  <span className="relative z-10 ml-auto flex h-5 min-w-5 items-center justify-center rounded-full bg-primary px-1.5 text-[10px] font-semibold text-primary-foreground tabular-nums">
                    {unreadNotifications > 99 ? "99+" : unreadNotifications}
                  </span>
                ) : null}
              </Link>
            );
          })}
        </div>
      ))}
    </nav>
  );

  return (
    <div className="app-canvas flex min-h-screen flex-1 flex-col">
      {/* Mobile top bar */}
      <header className="glass sticky top-0 z-40 border-b lg:hidden">
        <div className="flex h-14 items-center justify-between gap-3 px-4">
          {brand}
          <div className="flex items-center gap-1">
            <ThemeToggle />
            <Sheet open={menuOpen} onOpenChange={setMenuOpen}>
              <SheetTrigger asChild>
                <Button variant="ghost" size="icon-sm" className="relative" aria-label={unreadNotifications > 0 ? `Open navigation (${unreadNotifications} unread notifications)` : "Open navigation"}>
                  <Menu />
                  {unreadNotifications > 0 ? <span className="absolute top-1 right-1 size-2 rounded-full bg-primary" /> : null}
                </Button>
              </SheetTrigger>
              <SheetContent side="right" className="w-72 gap-0 bg-sidebar p-0">
                <SheetHeader className="h-14 justify-center border-b px-4">
                  <SheetTitle className="text-[15px]">Menu</SheetTitle>
                </SheetHeader>
                <div className="flex flex-1 flex-col overflow-y-auto p-3">{navList("portal-nav-active-mobile", () => setMenuOpen(false))}</div>
                <div className="border-t p-3">
                  <Button
                    variant="ghost"
                    size="sm"
                    className="w-full justify-start gap-3 text-muted-foreground hover:text-foreground"
                    onClick={() => customerLogout()}
                  >
                    <LogOut className="size-[18px]" /> Sign out
                  </Button>
                </div>
              </SheetContent>
            </Sheet>
          </div>
        </div>
      </header>

      <div className="mx-auto flex w-full max-w-6xl flex-1 gap-8 px-4 py-8 sm:px-6 lg:gap-10 lg:py-10">
        {/* Content (left) */}
        <main className="min-w-0 flex-1">{children}</main>

        {/* Right sidebar (desktop) */}
        <aside className="hidden w-60 shrink-0 lg:block" aria-label="Portal sections">
          <div className="sticky top-8 flex flex-col gap-5 rounded-2xl border bg-card/70 p-3 shadow-card backdrop-blur-sm">
            <div className="px-2 pt-1">{brand}</div>
            <div className="h-px bg-border" />
            {navList("portal-nav-active")}
            <div className="flex items-center gap-1 border-t pt-3">
              <Button
                variant="ghost"
                size="sm"
                className="flex-1 justify-start gap-3 text-muted-foreground hover:text-foreground"
                onClick={() => customerLogout()}
              >
                <LogOut className="size-[18px]" /> Sign out
              </Button>
              <ThemeToggle />
            </div>
          </div>
        </aside>
      </div>

      <footer className="border-t border-border">
        <div className="mx-auto flex w-full max-w-6xl flex-col items-center justify-between gap-3 px-6 py-6 text-xs text-muted-foreground sm:flex-row">
          <p>{footerText}</p>
          <SocialLinks links={socialLinks} />
          <a href={storeUrl} target="_blank" rel="noopener noreferrer" className="transition-colors hover:text-foreground">
            Our store — contact & support
          </a>
        </div>
      </footer>
    </div>
  );
}
