"use client";

import { useActionState, useMemo, useState } from "react";
import Link from "next/link";
import Script from "next/script";
import { ArrowRight, CheckCircle2, Loader2, PartyPopper, Ticket, TriangleAlert } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { CopyButton } from "@/components/shared/copy-button";
import { formatCents } from "@/lib/money";
import { normaliseVoucherCode } from "@/lib/vouchers/format";
import { redeemCodeAction, type RedeemState } from "@/app/redeem/actions";
import { customerLogout } from "@/app/actions";

interface RedeemFormProps {
  initialCode?: string;
  signedInAs: string | null;
  turnstileSiteKey: string | null;
}

/**
 * Voucher redemption form (WS9). The check character catches typos before a
 * round-trip; the server answers every failure with the same message.
 */
export function RedeemForm({ initialCode = "", signedInAs, turnstileSiteKey }: RedeemFormProps) {
  const [state, formAction, pending] = useActionState<RedeemState, FormData>(redeemCodeAction, {});
  const [code, setCode] = useState(initialCode);
  const [orderId, setOrderId] = useState("");
  // Once the server asks for the captcha it stays on for the rest of the session.
  const [captchaSeen, setCaptchaSeen] = useState(false);
  if (state.requiresCaptcha && !captchaSeen) setCaptchaSeen(true);
  const showCaptcha = captchaSeen && !!turnstileSiteKey;

  const looksValid = useMemo(() => normaliseVoucherCode(code) !== null, [code]);
  const typed = code.replace(/[^A-Za-z0-9]/g, "").length;

  if (state.accessCode || state.toppedUp) {
    return (
      <div className="rounded-2xl border border-success/25 bg-success/8 p-6 text-center">
        <div className="mx-auto flex size-14 items-center justify-center rounded-2xl bg-success/15 ring-1 ring-success/30">
          <PartyPopper className="size-7 text-success" />
        </div>
        <h2 className="mt-4 text-xl font-semibold">{state.accessCode ? "Your account is ready" : "Code redeemed"}</h2>
        <p className="mt-1 text-sm text-muted-foreground">
          {state.credited
            ? `${formatCents(state.balanceCents ?? 0)} of API credit${state.bonusCents ? ` plus ${formatCents(state.bonusCents)} bonus` : ""} on the ${state.planName} plan.`
            : `Your ${formatCents(state.balanceCents ?? 0)} ${state.planName} credit is being verified and will be added shortly — we'll review it as fast as we can.`}
        </p>
        {state.accessCode && (
          <div className="mt-5 rounded-xl border bg-background p-4 text-left">
            <p className="text-xs font-medium uppercase tracking-wide text-muted-foreground">Your access code — save it, it is your login</p>
            <div className="mt-1 flex items-center justify-between gap-2">
              <span className="font-mono text-lg font-semibold">{state.accessCode}</span>
              <CopyButton value={state.accessCode} label="Access code" />
            </div>
          </div>
        )}
        <Button asChild className="mt-5">
          <Link href="/portal/api-access">
            Create your API token <ArrowRight />
          </Link>
        </Button>
      </div>
    );
  }

  return (
    <form action={formAction} className="space-y-4">
      {signedInAs ? (
        <p className="rounded-lg border border-primary/25 bg-primary/8 px-3 py-2 text-xs">
          Signed in as <span className="font-mono font-medium">{signedInAs}</span> — the credit will be added to this account.{" "}
          <button type="button" formAction={undefined} onClick={() => customerLogout()} className="text-primary hover:underline">
            Not you? Sign out
          </button>
        </p>
      ) : null}
      <div className="space-y-1.5">
        <Label htmlFor="code">Voucher code from your GamsGo order</Label>
        <Input
          id="code"
          name="code"
          value={code}
          onChange={(e) => setCode(e.target.value)}
          placeholder="ALK-XXXXX-XXXXX-XXXXX-XXXXX-X"
          autoComplete="off"
          spellCheck={false}
          className="font-mono uppercase"
          required
        />
        {typed >= 21 && !looksValid && (
          <p className="flex items-center gap-1.5 text-xs text-warning">
            <TriangleAlert className="size-3.5" /> That doesn&apos;t look like a valid code — check for a typo (0/O and 1/I/L are interchangeable).
          </p>
        )}
        {looksValid && (
          <p className="flex items-center gap-1.5 text-xs text-success">
            <CheckCircle2 className="size-3.5" /> Looks good
          </p>
        )}
      </div>
      <div className="space-y-1.5">
        <Label htmlFor="gamsgoOrderId">
          GamsGo order ID <span className="text-muted-foreground">(optional, helps support)</span>
        </Label>
        <Input id="gamsgoOrderId" name="gamsgoOrderId" value={orderId} onChange={(e) => setOrderId(e.target.value)} autoComplete="off" />
      </div>
      {!signedInAs && <input type="hidden" name="affiliateCode" value="" />}
      {showCaptcha && turnstileSiteKey && (
        <>
          <Script src="https://challenges.cloudflare.com/turnstile/v0/api.js" strategy="afterInteractive" />
          <div className="cf-turnstile" data-sitekey={turnstileSiteKey} />
        </>
      )}
      {state.error && <p className="rounded-lg border border-destructive/30 bg-destructive/10 px-3 py-2 text-sm text-destructive">{state.error}</p>}
      <Button type="submit" className="w-full" disabled={pending || !looksValid}>
        {pending ? <Loader2 className="animate-spin" /> : <Ticket />}
        {signedInAs ? "Add credit to my account" : "Redeem and create my account"}
      </Button>
    </form>
  );
}
