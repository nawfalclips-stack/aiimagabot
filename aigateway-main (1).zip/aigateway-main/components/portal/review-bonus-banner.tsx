"use client";

import { useTransition, useState } from "react";
import { useRouter } from "next/navigation";
import { toast } from "sonner";
import { motion } from "framer-motion";
import {
  AlertTriangle,
  CheckCircle2,
  ExternalLink,
  Gift,
  Info,
  Loader2,
  PenLine,
  XCircle,
} from "lucide-react";
import { Button } from "@/components/ui/button";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { formatCents } from "@/lib/money";
import { claimReviewBonusAction } from "@/app/portal/actions";

interface ReviewBonusBannerProps {
  status: string; // OFFERED | CLAIMED | VERIFIED | REVOKED
  pendingBonusCents: number;
  storeUrl: string;
  /** Order number this bonus came from — the one the review must mention. */
  orderNumber?: string | null;
  /** Percent of the offer (e.g. 10 or 15) for the conditions text. */
  bonusPercentLabel?: string;
}

/**
 * Review-gated bonus states on the customer dashboard:
 *  OFFERED            → conditions + "Open store" + confirm dialog
 *  CLAIMED / VERIFIED → thank-you note (bonus credited)
 *  REVOKED            → the administrator removed the bonus (no review found)
 *
 * Confirm dialog: pressing "Yes, I wrote a review" opens a warning first —
 * claiming without actually reviewing gets the bonus revoked by an admin.
 */
export function ReviewBonusBanner({
  status,
  pendingBonusCents,
  storeUrl,
  orderNumber,
  bonusPercentLabel = "10",
}: ReviewBonusBannerProps) {
  const [pending, startTransition] = useTransition();
  const [confirmOpen, setConfirmOpen] = useState(false);
  const router = useRouter();

  if (pendingBonusCents <= 0 || status === "NONE") return null;

  const claim = () => {
    startTransition(async () => {
      const result = await claimReviewBonusAction();
      if (result.ok) {
        setConfirmOpen(false);
        toast.success("Review confirmed — thank you!", {
          description: `Keep an eye on your ${formatCents(pendingBonusCents)} bonus; it stays yours after verification.`,
        });
        router.refresh();
      } else {
        toast.error(result.error);
      }
    });
  };

  if (status === "OFFERED" || status === "CLAIMED" || status === "VERIFIED") {
    // Bonus is credited AUTOMATICALLY at activation/recharge — the banner
    // shows it as available money plus the review conditions. The confirm
    // dialog lets the customer attest the review (admin verifies after).
    return (
      <>
        <motion.section
          initial={{ opacity: 0, y: 8 }}
          animate={{ opacity: 1, y: 0 }}
          className="rounded-2xl border border-success/30 bg-success/8 p-5"
          role="region"
          aria-label="Review bonus"
          style={{ borderTop: "3px solid var(--color-success)" }}
        >
          <div className="flex items-start gap-3">
            <span className="flex size-10 shrink-0 items-center justify-center rounded-lg bg-success/15 text-success">
              <Gift className="size-5" />
            </span>
            <div className="flex-1">
              <p className="text-base font-semibold text-success">
                🎁 {status === "OFFERED"
                  ? `A ${formatCents(pendingBonusCents)} bonus was added to your account!`
                  : `${formatCents(pendingBonusCents)} bonus is active on your account`}
              </p>

              {/* Conditions */}
              <div className="mt-3 rounded-lg border border-success/20 bg-background/40 p-3.5">
                <p className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">
                  Conditions to keep this bonus
                </p>
                <ol className="mt-2 space-y-1.5 text-sm">
                  <li className="flex items-start gap-2">
                    <CheckCircle2 className="mt-0.5 size-4 shrink-0 text-success" />
                    <span>
                      Your order{" "}
                      {orderNumber ? (
                        <code className="rounded bg-muted px-1.5 py-0.5 font-mono text-xs font-bold">{orderNumber}</code>
                      ) : (
                        "on file"
                      )}{" "}
                      must be completed.
                    </span>
                  </li>
                  <li className="flex items-start gap-2">
                    <PenLine className="mt-0.5 size-4 shrink-0 text-success" />
                    <span>
                      Write a <strong>positive review</strong> on our GamsGo store for order{" "}
                      <code className="rounded bg-muted px-1.5 py-0.5 font-mono text-xs font-bold">{orderNumber ?? "—"}</code>.
                    </span>
                  </li>
                </ol>
                <a
                  href="/portal/review-bonus"
                  className="mt-2 inline-flex items-center gap-1 text-xs font-medium text-primary underline-offset-4 hover:underline"
                >
                  <Info className="size-3" /> Read the full conditions
                </a>
              </div>

              {/* Actions — hidden once already attested */}
              {status === "OFFERED" ? (
                <div className="mt-4 flex flex-wrap items-center gap-2">
                  <a
                    href={storeUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex h-9 items-center gap-2 rounded-lg bg-success px-4 text-sm font-semibold text-white shadow-lg shadow-success/25 transition-colors hover:bg-success/90"
                  >
                    <ExternalLink className="size-4" /> Open store &amp; write review
                  </a>
                  <Button
                    size="sm"
                    variant="outline"
                    className="h-9 border-success/40 text-success hover:bg-success/10"
                    onClick={() => setConfirmOpen(true)}
                    disabled={pending}
                  >
                    {pending ? <Loader2 className="size-4 animate-spin" /> : <CheckCircle2 className="size-4" />}
                    Yes, I wrote my review
                  </Button>
                </div>
              ) : (
                <p className="mt-3 flex items-center gap-2 text-xs text-muted-foreground">
                  <CheckCircle2 className="size-3.5 text-success" /> Review confirmed — an administrator may still
                  verify it on the store.
                </p>
              )}
            </div>
          </div>
        </motion.section>

        {/* Confirmation dialog — warns before attesting */}
        <Dialog open={confirmOpen} onOpenChange={setConfirmOpen}>
          <DialogContent>
            <DialogHeader>
              <DialogTitle className="flex items-center gap-2">
                <AlertTriangle className="size-5 text-warning" /> Did you really write the review?
              </DialogTitle>
              <DialogDescription asChild>
                <div className="space-y-2 pt-1 text-sm">
                  <p>
                    You are confirming the review for order{" "}
                    <code className="rounded bg-muted px-1.5 py-0.5 font-mono text-xs">{orderNumber ?? "—"}</code> and
                    your <strong>{formatCents(pendingBonusCents)}</strong> bonus.
                  </p>
                  <p className="rounded-lg border border-warning/30 bg-warning/10 px-3 py-2 text-warning">
                    ⚠️ We verify every claim on our store. If your review is not found, the bonus is
                    <strong> removed from your account</strong>.
                  </p>
                  <p>Only continue if your review for this order is already posted.</p>
                </div>
              </DialogDescription>
            </DialogHeader>
            <DialogFooter className="gap-2 sm:gap-0">
              <Button variant="outline" size="sm" onClick={() => setConfirmOpen(false)}>
                Not yet — I&apos;ll write it first
              </Button>
              <Button
                size="sm"
                className="bg-success text-white hover:bg-success/90"
                onClick={claim}
                disabled={pending}
              >
                {pending ? <Loader2 className="size-4 animate-spin" /> : <CheckCircle2 className="size-4" />}
                Yes, my review is posted
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </>
    );
  }

  if (status === "CLAIMED" || status === "VERIFIED") {
    return (
      <div className="flex items-center gap-3 rounded-2xl border border-success/25 bg-success/8 px-5 py-3.5" role="status">
        <CheckCircle2 className="size-5 shrink-0 text-success" />
        <p className="text-sm text-muted-foreground">
          <span className="font-semibold text-success">{formatCents(pendingBonusCents)} review bonus added.</span>{" "}
          Thank you for your review{orderNumber ? ` of order ${orderNumber}` : ""}!
        </p>
      </div>
    );
  }

  // REVOKED
  return (
    <div className="flex items-center gap-3 rounded-2xl border border-destructive/30 bg-destructive/10 px-5 py-3.5" role="alert">
      <XCircle className="size-5 shrink-0 text-destructive" />
      <p className="text-sm text-muted-foreground">
        <span className="font-semibold text-destructive">Your review bonus was removed.</span> We couldn&apos;t find
        your review on the store — the {formatCents(pendingBonusCents)} bonus was taken back.
      </p>
    </div>
  );
}
