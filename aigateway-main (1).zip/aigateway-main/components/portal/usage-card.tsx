"use client";

import { motion } from "framer-motion";
import { CircleDollarSign, Gift } from "lucide-react";
import { Card } from "@/components/ui/card";
import { AnimatedCounter } from "@/components/shared/animated-counter";
import { formatCents, percentUsed } from "@/lib/money";
import { cn } from "@/lib/utils";

// Icons resolved locally so server components can render this card.
const ICONS = { dollar: CircleDollarSign, gift: Gift } as const;

interface UsageCardProps {
  title: string;
  icon: keyof typeof ICONS;
  initialCents: number;
  usedCents: number;
  remainingCents: number;
  tone: "primary" | "success";
}

/** Large premium card showing initial / used / remaining with an animated progress bar. */
export function UsageCard({ title, icon, initialCents, usedCents, remainingCents, tone }: UsageCardProps) {
  const Icon = ICONS[icon];
  const pct = percentUsed(usedCents, initialCents);
  const barClass = tone === "primary" ? "bg-primary" : "bg-success";
  const iconClass = tone === "primary" ? "text-primary" : "text-success";
  const wash = tone === "primary" ? "var(--primary)" : "var(--success)";
  const remainingClass =
    remainingCents < 0 ? "text-destructive" : tone === "primary" ? "text-primary" : "text-success";

  return (
    <Card className="group relative gap-0 overflow-hidden p-6 transition-shadow duration-300 hover:shadow-raised">
      {/* Soft tone wash anchored top-right */}
      <span
        aria-hidden
        className="pointer-events-none absolute -top-24 -right-20 size-64 rounded-full opacity-[0.08] blur-3xl transition-opacity duration-500 group-hover:opacity-[0.14]"
        style={{ background: wash }}
      />

      <div className="relative flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Icon className={cn("size-[18px]", iconClass)} />
          <h2 className="text-sm font-semibold">{title}</h2>
        </div>
        <span className="rounded-full border bg-background/60 px-2.5 py-0.5 text-xs font-medium text-muted-foreground tabular-nums">
          {pct}% used
        </span>
      </div>

      <div className="relative mt-6">
        <p className="eyebrow">Remaining</p>
        <AnimatedCounter
          value={remainingCents / 100}
          format="money"
          className={cn(
            "mt-1 block font-display text-4xl leading-none font-semibold tracking-tight tabular-nums",
            remainingCents < 0 && "text-destructive"
          )}
        />
      </div>

      {/* Animated progress bar */}
      <div
        className="relative mt-5 h-2 overflow-hidden rounded-full bg-muted"
        role="progressbar"
        aria-valuenow={pct}
        aria-valuemin={0}
        aria-valuemax={100}
        aria-label={`${title} used`}
      >
        <motion.div
          className={cn("h-full rounded-full", barClass)}
          initial={{ width: 0 }}
          animate={{ width: `${pct}%` }}
          transition={{ duration: 1, ease: [0.16, 1, 0.3, 1], delay: 0.2 }}
        />
      </div>

      <dl className="relative mt-5 grid grid-cols-3 divide-x rounded-xl border bg-muted/30">
        <div className="px-3 py-2.5">
          <dt className="text-[11px] tracking-wide text-muted-foreground uppercase">Initial</dt>
          <dd className="mt-0.5 text-sm font-semibold tabular-nums">{formatCents(initialCents)}</dd>
        </div>
        <div className="px-3 py-2.5">
          <dt className="text-[11px] tracking-wide text-muted-foreground uppercase">Used</dt>
          <dd className="mt-0.5 text-sm font-semibold tabular-nums">{formatCents(usedCents)}</dd>
        </div>
        <div className="px-3 py-2.5">
          <dt className="text-[11px] tracking-wide text-muted-foreground uppercase">Remaining</dt>
          <dd className={cn("mt-0.5 text-sm font-semibold tabular-nums", remainingClass)}>{formatCents(remainingCents)}</dd>
        </div>
      </dl>
    </Card>
  );
}
