import { cn } from "@/lib/utils";

/** Codex CLI mark — blue terminal glyph. */
export function CodexLogo({ className }: { className?: string }) {
  return (
    <span
      className={cn(
        "flex shrink-0 items-center justify-center rounded-xl bg-[#1a2340] ring-1 ring-blue-400/25",
        className
      )}
      aria-hidden
    >
      <svg viewBox="0 0 24 24" fill="none" className="size-[55%]">
        <circle cx="12" cy="12" r="10" fill="#3b82f6" opacity="0.18" />
        <path d="M7 8.5 10.5 12 7 15.5" stroke="#60a5fa" strokeWidth="2.1" strokeLinecap="round" strokeLinejoin="round" />
        <path d="M12.5 15.5H17" stroke="#60a5fa" strokeWidth="2.1" strokeLinecap="round" />
      </svg>
    </span>
  );
}

/** Claude Code mark — orange asterisk. */
export function ClaudeLogo({ className }: { className?: string }) {
  return (
    <span
      className={cn(
        "flex shrink-0 items-center justify-center rounded-xl bg-[#2b1c14] ring-1 ring-orange-400/25",
        className
      )}
      aria-hidden
    >
      <svg viewBox="0 0 24 24" fill="none" className="size-[55%]">
        <g stroke="#e8794a" strokeWidth="2.2" strokeLinecap="round">
          <path d="M12 4v16" />
          <path d="M5.1 8l13.8 8" />
          <path d="M18.9 8 5.1 16" />
        </g>
      </svg>
    </span>
  );
}

/** OpenCode mark — stacked terminal brackets. */
export function OpenCodeLogo({ className }: { className?: string }) {
  return (
    <span
      className={cn("flex shrink-0 items-center justify-center rounded-xl bg-[#18181b] ring-1 ring-zinc-400/25", className)}
      aria-hidden
    >
      <svg viewBox="0 0 24 24" fill="none" className="size-[55%]">
        <rect x="4" y="4" width="16" height="16" rx="3" stroke="#e4e4e7" strokeWidth="1.8" />
        <path d="M9 9.5 6.8 12 9 14.5M15 9.5l2.2 2.5-2.2 2.5" stroke="#e4e4e7" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round" />
      </svg>
    </span>
  );
}

/** "More agents" mark — plug. */
export function AgentsLogo({ className }: { className?: string }) {
  return (
    <span
      className={cn("flex shrink-0 items-center justify-center rounded-xl bg-[#14281f] ring-1 ring-emerald-400/25", className)}
      aria-hidden
    >
      <svg viewBox="0 0 24 24" fill="none" className="size-[55%]">
        <g stroke="#34d399" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M9 3v5M15 3v5" />
          <path d="M6 8h12v3a6 6 0 0 1-12 0V8Z" />
          <path d="M12 17v4" />
        </g>
      </svg>
    </span>
  );
}

/** API & SDKs mark — braces. */
export function SdkLogo({ className }: { className?: string }) {
  return (
    <span
      className={cn("flex shrink-0 items-center justify-center rounded-xl bg-[#241a36] ring-1 ring-violet-400/25", className)}
      aria-hidden
    >
      <svg viewBox="0 0 24 24" fill="none" className="size-[55%]">
        <g stroke="#a78bfa" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
          <path d="M8 4c-2 0-2.5 1-2.5 2.5v2c0 1.5-.8 2.5-2 3.5 1.2 1 2 2 2 3.5v2C5.5 19 6 20 8 20" />
          <path d="M16 4c2 0 2.5 1 2.5 2.5v2c0 1.5.8 2.5 2 3.5-1.2 1-2 2-2 3.5v2c0 1.5-.5 2.5-2.5 2.5" />
        </g>
      </svg>
    </span>
  );
}
