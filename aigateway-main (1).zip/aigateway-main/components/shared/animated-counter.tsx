"use client";

import { useEffect, useRef } from "react";
import { animate, useInView, useMotionValue } from "framer-motion";

interface AnimatedCounterProps {
  value: number;
  /** "money" formats as USD with 2 decimals; "integer" as a plain number. */
  format?: "money" | "integer";
  className?: string;
  durationSeconds?: number;
}

export function AnimatedCounter({ value, format = "integer", className, durationSeconds = 1 }: AnimatedCounterProps) {
  const ref = useRef<HTMLSpanElement>(null);
  const motionValue = useMotionValue(0);
  const inView = useInView(ref, { once: true, margin: "-40px" });

  useEffect(() => {
    if (!inView) return;
    const controls = animate(motionValue, value, {
      duration: durationSeconds,
      ease: [0.16, 1, 0.3, 1],
      onUpdate: (latest) => {
        if (!ref.current) return;
        ref.current.textContent =
          format === "money"
            ? new Intl.NumberFormat("en-US", { style: "currency", currency: "USD" }).format(latest)
            : Intl.NumberFormat("en-US").format(Math.round(latest));
      },
    });
    return () => controls.stop();
  }, [inView, value, format, durationSeconds, motionValue]);

  return (
    <span ref={ref} className={className}>
      {format === "money" ? "$0.00" : "0"}
    </span>
  );
}
