import { cn } from "@/lib/utils";

/**
 * AeroLink mark geometry (32×32 grid). A solid "A" whose crossbar runs through
 * the letter and slides OVER the right leg — the route passing through the
 * gateway. LETTER is drawn even-odd: the counter is open and two hairline
 * gaps are cut into the right leg on either side of the bar; BAR is solid.
 * Keep in sync with app/icon.svg, app/apple-icon.tsx and public/logo.svg.
 */
export const MARK_LETTER =
  "M5.25 26 15.25 5 25.25 26Z M9.85 26 15.25 14.66 20.65 26Z M16.6 17.5H21.2L21.63 18.4H17.03Z M18.22 20.9H22.82L23.25 21.8H18.65Z";
export const MARK_BAR = "M13.47 18.4H26.75V20.9H12.28Z";

/**
 * The mark on a brand-blue tile, coloured from the theme tokens so it reads on
 * light and dark surfaces alike.
 */
export function BrandMark({ className, title }: { className?: string; title?: string }) {
  return (
    <svg
      viewBox="0 0 32 32"
      className={cn("size-8 shrink-0", className)}
      role={title ? "img" : undefined}
      aria-hidden={title ? undefined : true}
      aria-label={title}
    >
      <rect width="32" height="32" rx="8" className="fill-primary" />
      <path d={MARK_LETTER} fillRule="evenodd" className="fill-primary-foreground" />
      <path d={MARK_BAR} className="fill-primary-foreground" />
    </svg>
  );
}
