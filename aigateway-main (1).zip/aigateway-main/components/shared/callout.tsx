import type { LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";

const TONES = {
  primary: { box: "border-primary/20 bg-primary/6", icon: "bg-primary/12 text-primary", title: "text-foreground" },
  success: { box: "border-success/25 bg-success/7", icon: "bg-success/15 text-success", title: "text-success" },
  warning: { box: "border-warning/30 bg-warning/8", icon: "bg-warning/15 text-warning", title: "text-warning" },
  destructive: {
    box: "border-destructive/25 bg-destructive/7",
    icon: "bg-destructive/12 text-destructive",
    title: "text-destructive",
  },
  muted: { box: "border-border bg-muted/50", icon: "bg-background text-muted-foreground", title: "text-foreground" },
} as const;

export type CalloutTone = keyof typeof TONES;

interface CalloutProps {
  tone?: CalloutTone;
  icon: LucideIcon;
  title?: React.ReactNode;
  children?: React.ReactNode;
  /** Buttons or links rendered under the body. */
  action?: React.ReactNode;
  role?: "alert" | "status";
  className?: string;
}

/** Tinted notice with an icon chip — the portal's alerts, confirmations and hints. */
export function Callout({ tone = "primary", icon: Icon, title, children, action, role, className }: CalloutProps) {
  const t = TONES[tone];
  return (
    <div role={role} className={cn("flex items-start gap-3.5 rounded-2xl border px-4 py-4 sm:px-5", t.box, className)}>
      <span className={cn("flex size-8 shrink-0 items-center justify-center rounded-lg", t.icon)}>
        <Icon className="size-4" />
      </span>
      <div className="min-w-0 flex-1 pt-1">
        {title ? <p className={cn("text-sm font-semibold", t.title)}>{title}</p> : null}
        {children ? (
          <div className={cn("text-sm leading-relaxed text-muted-foreground", title && "mt-0.5")}>{children}</div>
        ) : null}
        {action ? <div className="mt-3 flex flex-wrap items-center gap-2">{action}</div> : null}
      </div>
    </div>
  );
}
