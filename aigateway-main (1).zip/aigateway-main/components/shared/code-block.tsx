"use client";

import { Prism as SyntaxHighlighter } from "react-syntax-highlighter";
import { oneDark } from "react-syntax-highlighter/dist/esm/styles/prism";
import { CopyButton } from "@/components/shared/copy-button";

interface CodeBlockProps {
  code: string;
  language?: string;
}

export function CodeBlock({ code, language = "bash" }: CodeBlockProps) {
  const trimmed = code.replace(/\n$/, "");
  const showLineNumbers = trimmed.split("\n").length > 1;

  return (
    <div className="group relative my-4 overflow-hidden rounded-lg border bg-[#101116]">
      <div className="flex items-center justify-between border-b bg-foreground/[0.02] px-4 py-1.5">
        <span className="font-mono text-[11px] tracking-wide text-muted-foreground uppercase">{language}</span>
        <CopyButton value={trimmed} label="Command" size="icon-xs" />
      </div>
      <div className="overflow-x-auto">
        <SyntaxHighlighter
          language={language}
          style={oneDark}
          showLineNumbers={showLineNumbers}
          lineNumberStyle={{ minWidth: "2.25em", opacity: 0.35, userSelect: "none" }}
          customStyle={{
            margin: 0,
            padding: "0.9rem 1rem",
            background: "transparent",
            fontSize: "0.8125rem",
            lineHeight: 1.65,
          }}
          codeTagProps={{ style: { fontFamily: "var(--font-geist-mono), monospace" } }}
        >
          {trimmed}
        </SyntaxHighlighter>
      </div>
    </div>
  );
}
