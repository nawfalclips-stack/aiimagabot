import type { LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";

interface EmptyStateProps {
  icon: LucideIcon;
  title: string;
  description?: string;
  action?: React.ReactNode;
  className?: string;
}

export function EmptyState({ icon: Icon, title, description, action, className }: EmptyStateProps) {
  return (
    <div
      className={cn(
        "relative flex flex-col items-center justify-center overflow-hidden rounded-2xl border border-dashed bg-muted/25 px-6 py-16 text-center",
        className
      )}
    >
      <div aria-hidden className="dot-grid pointer-events-none absolute inset-0 [mask-image:radial-gradient(ellipse_at_center,black,transparent_70%)]" />
      <div className="relative flex size-12 items-center justify-center rounded-xl border bg-card shadow-card">
        <Icon className="size-5 text-muted-foreground" />
      </div>
      <h3 className="relative mt-4 text-base font-semibold">{title}</h3>
      {description ? <p className="relative mt-1 max-w-sm text-sm text-muted-foreground">{description}</p> : null}
      {action ? <div className="relative mt-5">{action}</div> : null}
    </div>
  );
}
