import type { LedgerEntry } from "@prisma/client";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { LocalTime } from "@/components/shared/local-time";
import { formatMicroUsd } from "@/lib/billing/money";
import { cn } from "@/lib/utils";

const TYPE_LABELS: Record<string, string> = {
  OPENING_BALANCE: "Opening balance",
  ORDER_ACTIVATION: "Order activated",
  RECHARGE: "Recharge",
  VOUCHER_REDEMPTION: "Voucher redeemed",
  USAGE: "API usage",
  REVIEW_BONUS: "Review bonus",
  AFFILIATE_REWARD: "Affiliate reward",
  LOYALTY_REWARD: "Loyalty reward",
  PROMO_BONUS: "Recharge promotion",
  REFUND: "Refund",
  CLAWBACK: "Clawback",
  ADMIN_ADJUSTMENT: "Adjustment",
  EXPIRY: "Expired",
  RESTORE: "Restored",
};

export function ledgerTypeLabel(type: string): string {
  return TYPE_LABELS[type] ?? type;
}

/**
 * Append-only ledger view shared by the customer portal and the admin
 * profile. Amounts are signed micro-USD; credits render green.
 */
export function LedgerTable({ entries, showActor = true }: { entries: LedgerEntry[]; showActor?: boolean }) {
  return (
    <div className="overflow-x-auto">
      <Table>
        <TableHeader>
          <TableRow className="hover:bg-transparent">
            <TableHead>Date</TableHead>
            <TableHead>Pot</TableHead>
            <TableHead>Entry</TableHead>
            <TableHead className="text-right">Amount</TableHead>
            <TableHead className="text-right">After</TableHead>
            {showActor && <TableHead>By</TableHead>}
          </TableRow>
        </TableHeader>
        <TableBody>
          {entries.map((e) => (
            <TableRow key={e.id}>
              <TableCell className="whitespace-nowrap text-muted-foreground">
                <LocalTime date={e.createdAt} variant="datetime" />
              </TableCell>
              <TableCell>
                <span
                  className={cn(
                    "inline-flex rounded-full px-2.5 py-0.5 text-xs font-medium",
                    e.pot === "BALANCE" ? "bg-primary/12 text-primary" : "bg-success/12 text-success"
                  )}
                >
                  {e.pot === "BALANCE" ? "Balance" : "Bonus"}
                </span>
              </TableCell>
              <TableCell className="max-w-[28rem]">
                <div className="font-medium">{ledgerTypeLabel(e.type)}</div>
                {e.note && <div className="truncate text-xs text-muted-foreground" title={e.note}>{e.note}</div>}
              </TableCell>
              <TableCell className={cn("text-right font-medium tabular-nums", e.amountMicroUsd > 0n && "text-success")}>
                {e.amountMicroUsd > 0n ? "+" : ""}
                {formatMicroUsd(e.amountMicroUsd)}
              </TableCell>
              <TableCell className="text-right tabular-nums text-muted-foreground">{formatMicroUsd(e.balanceAfterMicroUsd)}</TableCell>
              {showActor && <TableCell className="whitespace-nowrap text-muted-foreground">{e.actorLabel || "—"}</TableCell>}
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}
