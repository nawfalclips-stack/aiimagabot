"use client";

import { useSyncExternalStore } from "react";

const subscribeNoop = () => () => {};

type Variant = "date" | "datetime" | "log";

const OPTIONS: Record<Variant, Intl.DateTimeFormatOptions> = {
  date: { month: "short", day: "numeric", year: "numeric" },
  datetime: { month: "short", day: "numeric", year: "numeric", hour: "2-digit", minute: "2-digit" },
  log: { month: "short", day: "numeric", hour: "2-digit", minute: "2-digit", second: "2-digit" },
};

/**
 * Renders a timestamp in the VISITOR's local timezone. The server (and the
 * first client render) format in UTC so hydration matches; right after mount
 * it re-renders using the browser's own timezone — every visitor worldwide
 * sees their local time automatically.
 */
export function LocalTime({
  date,
  variant = "datetime",
  className,
}: {
  date: string | Date | null | undefined;
  variant?: Variant;
  className?: string;
}) {
  // false during SSR and hydration, true once the client takes over — without a
  // setState-in-effect, which the React compiler lint rejects.
  const mounted = useSyncExternalStore(subscribeNoop, () => true, () => false);

  if (!date) return <>—</>;
  const d = typeof date === "string" ? new Date(date) : date;
  if (Number.isNaN(d.getTime())) return <>—</>;

  const opts = OPTIONS[variant];
  const text = mounted
    ? d.toLocaleString("en-US", opts) // browser timezone
    : d.toLocaleString("en-US", { ...opts, timeZone: "UTC" }); // matches SSR output

  return (
    <time dateTime={d.toISOString()} className={className} suppressHydrationWarning>
      {text}
    </time>
  );
}
