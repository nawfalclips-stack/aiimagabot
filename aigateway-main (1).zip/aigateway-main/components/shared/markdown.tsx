"use client";

import ReactMarkdown from "react-markdown";
import remarkGfm from "remark-gfm";
import { CodeBlock } from "@/components/shared/code-block";
import { CopyButton } from "@/components/shared/copy-button";
import { cn } from "@/lib/utils";

interface MarkdownProps {
  content: string;
  className?: string;
}

/**
 * Renders documentation markdown with syntax-highlighted code blocks,
 * copy buttons, and GitHub-flavored tables.
 */
export function Markdown({ content, className }: MarkdownProps) {
  return (
    <div className={cn("max-w-none text-[0.9375rem] leading-relaxed", className)}>
      <ReactMarkdown
        remarkPlugins={[remarkGfm]}
        components={{
          h1: ({ children }) => <h1 className="mt-2 mb-4 text-2xl font-semibold tracking-tight">{children}</h1>,
          h2: ({ children }) => (
            <h2 className="mt-8 mb-3 border-b pb-2 text-lg font-semibold tracking-tight">{children}</h2>
          ),
          h3: ({ children }) => <h3 className="mt-6 mb-2 text-base font-semibold">{children}</h3>,
          p: ({ children }) => <p className="my-3 text-foreground/90">{children}</p>,
          ul: ({ children }) => <ul className="my-3 list-disc space-y-1.5 pl-6">{children}</ul>,
          ol: ({ children }) => <ol className="my-3 list-decimal space-y-1.5 pl-6">{children}</ol>,
          li: ({ children }) => <li className="text-foreground/90">{children}</li>,
          a: ({ children, href }) => (
            <a href={href} target="_blank" rel="noopener noreferrer" className="font-medium text-primary underline-offset-4 hover:underline">
              {children}
            </a>
          ),
          strong: ({ children }) => <strong className="font-semibold text-foreground">{children}</strong>,
          blockquote: ({ children }) => (
            <blockquote className="my-4 border-l-2 border-primary/50 bg-muted/40 py-1 pr-3 pl-4 text-muted-foreground italic">
              {children}
            </blockquote>
          ),
          table: ({ children }) => (
            <div className="my-4 overflow-x-auto rounded-lg border">
              <table className="w-full text-sm">{children}</table>
            </div>
          ),
          th: ({ children }) => (
            <th className="border-b bg-muted/50 px-3 py-2 text-left font-medium">{children}</th>
          ),
          td: ({ children }) => <td className="border-b px-3 py-2 last:border-0">{children}</td>,
          code: ({ className: codeClassName, children, ...props }) => {
            const match = /language-(\w+)/.exec(codeClassName ?? "");
            const value = String(children);
            const isBlock = match || value.includes("\n");
            if (!isBlock) {
              return (
                <code className="rounded-md border bg-muted/60 px-1.5 py-0.5 font-mono text-[0.8125em]" {...props}>
                  {children}
                </code>
              );
            }
            // A bare block (no language) holding a single value (e.g. an API
            // key or base URL) renders as a copyable value chip.
            if (!match && !value.trim().includes("\n")) {
              return <ValueChip value={value.trim()} />;
            }
            return <CodeBlock code={value} language={match?.[1] ?? "text"} />;
          },
          pre: ({ children }) => <>{children}</>,
        }}
      >
        {content}
      </ReactMarkdown>
    </div>
  );
}

function ValueChip({ value }: { value: string }) {
  return (
    <span className="my-3 flex items-center justify-between gap-3 rounded-lg border bg-muted/40 py-2 pr-1.5 pl-4">
      <code className="truncate font-mono text-[0.8125rem] text-foreground">{value}</code>
      <CopyButton value={value} label="Value" size="icon-xs" />
    </span>
  );
}
