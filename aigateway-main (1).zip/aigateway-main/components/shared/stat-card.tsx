"use client";

import {
  CalendarDays,
  CheckCircle2,
  CircleDollarSign,
  Hourglass,
  KeyRound,
  PackageOpen,
  PauseCircle,
  RefreshCcw,
  ShoppingCart,
  ThumbsDown,
  ThumbsUp,
  TrendingUp,
  UserCheck,
  Users,
  Wallet,
} from "lucide-react";
import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { AnimatedCounter } from "@/components/shared/animated-counter";
import { cn } from "@/lib/utils";

// Icons are referenced by name so server components can use <StatCard /> —
// component functions can't cross the server → client boundary.
const ICONS = {
  users: Users,
  userCheck: UserCheck,
  hourglass: Hourglass,
  shoppingCart: ShoppingCart,
  wallet: Wallet,
  trendingUp: TrendingUp,
  dollar: CircleDollarSign,
  calendar: CalendarDays,
  thumbsUp: ThumbsUp,
  thumbsDown: ThumbsDown,
  refresh: RefreshCcw,
  key: KeyRound,
  package: PackageOpen,
  check: CheckCircle2,
  pause: PauseCircle,
} as const;

export type StatIcon = keyof typeof ICONS;

interface StatCardProps {
  title: string;
  value: number;
  format?: "money" | "integer";
  icon: StatIcon;
  hint?: string;
  tone?: "default" | "primary" | "success" | "warning" | "destructive";
  index?: number;
}

const TONES = {
  default: { icon: "text-muted-foreground", bar: "bg-muted-foreground/40", wash: "var(--muted-foreground)" },
  primary: { icon: "text-primary", bar: "bg-primary", wash: "var(--primary)" },
  success: { icon: "text-success", bar: "bg-success", wash: "var(--success)" },
  warning: { icon: "text-warning", bar: "bg-warning", wash: "var(--warning)" },
  destructive: { icon: "text-destructive", bar: "bg-destructive", wash: "var(--destructive)" },
};

export function StatCard({ title, value, format = "integer", icon, hint, tone = "default", index = 0 }: StatCardProps) {
  const Icon = ICONS[icon];
  const t = TONES[tone];
  return (
    <motion.div
      initial={{ opacity: 0, y: 12 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.45, delay: index * 0.04, ease: [0.16, 1, 0.3, 1] }}
      className="h-full"
    >
      <Card className="group relative h-full gap-0 overflow-hidden p-5 transition-[transform,box-shadow] duration-300 hover:-translate-y-0.5 hover:shadow-raised">
        {/* Tone wash that blooms from the corner on hover */}
        <span
          aria-hidden
          className="pointer-events-none absolute -top-16 -right-16 size-40 rounded-full opacity-[0.07] blur-2xl transition-opacity duration-500 group-hover:opacity-[0.16]"
          style={{ background: t.wash }}
        />
        <div className="relative flex items-center gap-2">
          <span className={cn("h-3.5 w-1 rounded-full", t.bar)} aria-hidden />
          <p className="flex-1 truncate text-[13px] font-medium text-muted-foreground">{title}</p>
          <Icon className={cn("size-4 shrink-0 opacity-80 transition-transform duration-300 group-hover:scale-110", t.icon)} />
        </div>
        <div className="relative mt-3">
          <AnimatedCounter
            value={value}
            format={format}
            className="block font-display text-[1.75rem] leading-none font-semibold tracking-tight tabular-nums"
          />
          {hint ? <p className="mt-2 text-xs leading-snug text-muted-foreground">{hint}</p> : null}
        </div>
      </Card>
    </motion.div>
  );
}
