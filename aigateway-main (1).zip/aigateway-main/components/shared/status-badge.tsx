import { cn } from "@/lib/utils";
import { STATUS_LABELS, type CustomerStatus } from "@/lib/constants";

const STYLES: Record<CustomerStatus, string> = {
  ACTIVE: "bg-success/12 text-success border-success/25",
  LOW_BALANCE: "bg-warning/12 text-warning border-warning/25",
  BALANCE_FINISHED: "bg-destructive/12 text-destructive border-destructive/25",
  SUSPENDED: "bg-muted text-muted-foreground border-border",
  EXPIRED: "bg-red-950/60 text-red-400 border-red-900/60",
};

const DOTS: Record<CustomerStatus, string> = {
  ACTIVE: "bg-success",
  LOW_BALANCE: "bg-warning",
  BALANCE_FINISHED: "bg-destructive",
  SUSPENDED: "bg-muted-foreground",
  EXPIRED: "bg-red-500",
};

interface StatusBadgeProps {
  status: string;
  size?: "sm" | "lg";
  className?: string;
}

export function StatusBadge({ status, size = "sm", className }: StatusBadgeProps) {
  const s = (status in STATUS_LABELS ? status : "SUSPENDED") as CustomerStatus;
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border font-medium whitespace-nowrap",
        size === "sm" ? "px-2.5 py-0.5 text-xs" : "px-4 py-1.5 text-sm",
        STYLES[s],
        className
      )}
    >
      <span className={cn("rounded-full", size === "sm" ? "size-1.5" : "size-2", DOTS[s], s === "ACTIVE" && "animate-pulse")} />
      {STATUS_LABELS[s]}
    </span>
  );
}
