import { cn } from "@/lib/utils";

interface Step {
  title: React.ReactNode;
  body?: React.ReactNode;
}

/** Numbered vertical timeline — each step's number sits on a connecting rail. */
export function Steps({ items, className }: { items: Step[]; className?: string }) {
  return (
    <ol className={cn("relative", className)}>
      {items.map((step, i) => (
        <li key={i} className="relative flex gap-4 pb-5 last:pb-0">
          {i < items.length - 1 ? (
            <span aria-hidden className="absolute top-8 bottom-0 left-[13px] w-px bg-border" />
          ) : null}
          <span className="relative z-10 flex size-7 shrink-0 items-center justify-center rounded-full border bg-card text-xs font-semibold text-primary tabular-nums shadow-card">
            {i + 1}
          </span>
          <div className="min-w-0 pt-0.5 text-sm leading-relaxed">
            <p className="font-medium text-foreground">{step.title}</p>
            {step.body ? <div className="mt-0.5 text-muted-foreground">{step.body}</div> : null}
          </div>
        </li>
      ))}
    </ol>
  );
}
