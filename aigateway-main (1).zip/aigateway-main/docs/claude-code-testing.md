# Claude Code and platform testing

## 1. Platform abort probe (Phase 3 — verify before `enforce`)

What it proves: on Vercel's Node runtime, when a client disconnects mid-stream, (a) `request.signal` aborts, (b) the response stream's `cancel()` fires, and (c) `after()` still runs. The gateway relies on (b) to stop paying the provider and on (c) to settle the charge.

1. Deploy a preview (or use production) and note `CRON_SECRET`.
2. In a terminal:
   ```bash
   curl -N -H "Authorization: Bearer $CRON_SECRET" https://<host>/api/diag/abort
   ```
   Wait for three or four `data: tick N` lines, then press **Ctrl-C**.
3. Open the Vercel function logs for `/api/diag/abort` and look for lines like:
   ```
   [diag/abort] k3j2ab request.signal aborted at 2140 ms
   [diag/abort] k3j2ab cancel() fired (…) at 2141 ms
   [diag/abort] k3j2ab after() ran at 2150 ms
   [diag/abort] k3j2ab after() work completed 1.5 s later at 3651 ms
   ```
4. Interpretation:
   - All four lines within ~2 s of the interrupt → the platform behaves like the local tests; nothing to change.
   - `cancel()` missing but `request.signal aborted` present → the gateway still aborts upstream (the adapter listens to `request.signal` too); note it in `docs/gateway-audit.md` §15.2.
   - `after() ran` missing → settlement of cancelled streams would be lost on the platform. Switch the settlement keep-alive to `waitUntil` from `@vercel/functions` (see `settleWhen` in `lib/gateway/handler.ts`) and re-run the probe.
   - Nothing at all until 60 s → the platform buffers or ignores disconnects; treat every cut stream as COMPLETED at upstream end (already the metering's behaviour) and rely on the sweeper for crashes.

Record the outcome in `docs/gateway-audit.md` §15 (items 2 and 3).

## 2. Manual Claude Code procedure

Added in Phase 7 (WS13) together with the Anthropic conformance suite.
