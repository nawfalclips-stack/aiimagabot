# Copy audit — WS7 (honest units & copy) and WS10 (retire the API Pool)

**Phase 6** · 2026-09-23 · branch `feature/redesign`

Scope: every customer-facing string that named a model, a provider, an upstream key or a legacy endpoint, and every surface that showed a customer an upstream credential. Source: audit §8 and §12, decision #13.

## 1. Customer surfaces that showed an upstream key (WS10)

| Where | Before | After |
|---|---|---|
| Dashboard `app/portal/page.tsx` → `ApiKeyCard` | Full upstream key with reveal/copy | Card rendered only when `LEGACY_API_POOL_MODE=active`; the key column is not even selected otherwise. Customers holding a legacy key get the banner *"Create your AeroLink API token on the API Access page — your previous access method is being retired."* |
| Documentation `app/portal/documentation/page.tsx` | `YOUR_AEROLINK_API_KEY` replaced with the upstream key | Nothing key-related is substituted; `{{BASE_URL}}` / `{{MODEL}}` are filled in, the token placeholder stays literal. Also fixed: docs were loaded for **all stores** — now filtered by the customer's store. |
| Activity Logs `app/portal/activity/page.tsx` | `keyLabel` printed verbatim — the old "Deduct usage" flow wrote the customer's **full pool key** there | Only gateway requests are listed (`requestId` set); labels pass through `redactKeys()` anyway. |
| Hero mock-up `components/portal/hero-visual.tsx` (landing + `/new`) | `cgapi.aerolink.lat`, `aero_live_…` | The real Claude Code env names with this site's origin and an `al_…` token. |

Guard: `test/unit/copy-honesty.test.ts` (static, no customer-facing file may touch `apiPoolKey` or read `apiKey` except the gated dashboard read) and `test/integration/portal-key-exposure.test.ts` (fetches every `/portal/*` route as a customer who holds an Anthropic-shaped legacy key, an OpenRouter-shaped pool key and a DeepSeek-shaped usage label; fails on any match of `test/helpers/provider-key-patterns.ts`).

## 2. Seeded guides (`prisma/docs/*.md`, decision #13)

| Guide | Problem | Rewrite |
|---|---|---|
| Codex × 3 | `base_url = "https://cgapi.aerolink.lat"`, `wire_api = "responses"`, `model = "gpt-5.6-sol"`, "Your API key is already assigned to you" | `base_url = "{{BASE_URL}}/v1"`, `wire_api = "chat"`, `env_key = "AEROLINK_API_KEY"`, `model = "{{MODEL}}"` — same config the API Access page generates. Token from API Access. |
| Claude Code × 3 | `ANTHROPIC_BASE_URL: https://capi.aerolink.lat/`, pool key | `ANTHROPIC_BASE_URL: {{BASE_URL}}`, `ANTHROPIC_MODEL` + the three `ANTHROPIC_DEFAULT_*` set to `{{MODEL}}`, and a sentence saying `/model` inside Claude Code does not change the billed model. |
| "Claude Cowork Guide" × 3 | Named a real Anthropic product for something else; "FreeModel" base URL; `claude-fable-5` model | Retitled **API & SDK Guide**; OpenAI and Anthropic SDK examples against `{{BASE_URL}}`, `/v1/models` to list the plan's models, 402/429/5xx meanings, `x-request-id`. |

Rollout: `prisma/seed.ts` replaces a guide **only** when it still contains a legacy marker (`capi.aerolink.lat`, `cgapi.aerolink.lat`, "already assigned to you", "FreeModel"), and stores the old text as a `DocumentationVersion` ("Gateway docs migration (WS7)") so an admin can roll back. Guides without a marker — including admin edits — are left alone.

`{{MODEL}}` resolves to the first enabled catalog model of the customer's store (`MODEL_ID` if the catalog is empty).

## 3. Fabricated usage (`lib/usage-synth.ts`)

**Before:** "Deduct usage" split an amount the admin typed into 7–14 invented rows — "Claude Opus 5", "GPT-5.6 Sol"… — with random 3.5–10 s latencies and status `200`, shown to the customer as real API requests. It also displayed their cost × the store multiplier, which is not what was deducted.

**After:**
- `lib/usage-synth.ts`, the unused `QuickUsageDialog` and the unused `addUsageLogsByTitle` are deleted.
- `recordUsageFromAmount` writes **one** row: model `Manual charge`, status `manual`, label = the admin's note, and charges the exact amount through the ledger (`Manual usage charge: <note>`).
- The Deduct dialog no longer asks for a "model family".
- Customer Activity Logs list gateway requests only, with the amount actually charged (`customerMicroUsd`, from the pricing engine) rather than `costMicroUsd × multiplier`. Manual charges appear in the dashboard's Balance History, linked from Activity Logs.
- `deleteUsageLog` refunds what was charged: `customerMicroUsd` for gateway rows, face value for manual charges, the multiplier only for pasted rows.

Historical synthesized rows stay in the database (the money was really deducted and the ledger records it); they are no longer shown to customers as requests.

## 4. Other copy

| Where | Before | After |
|---|---|---|
| `components/portal/docs-viewer.tsx` | Hard-coded `cgapi`/`capi` base URLs; "GPT MODELS — Responses API routing"; "CLAUDE MODELS" | Base URLs from this deployment; badges "OPENAI-COMPATIBLE" / "ANTHROPIC-COMPATIBLE"; "connect it with an API token from the API Access page". `CODEX_BASE_URL`/`CLAUDE_BASE_URL` constants removed. |
| `app/new/page.tsx` metadata + hero | "Frontier models from several providers, automatic failover" (one provider enabled today); "<1 s failover" (never measured) | Failover wording and stat appear only when more than one provider is enabled; otherwise "exact cost per request". |
| `app/new/page.tsx` FAQ | "Most setup issues are fixed automatically within minutes" (the pool-key swap) | "Most setup issues come down to the base URL or the token — the guides show both." |
| `app/portal/rules/page.tsx` | "you will receive your API key automatically"; "a new API key will be added" on recharge | Activate, then create a token; tokens keep working across recharges; revoke a leaked token yourself. |
| `components/portal/activation-wizard.tsx` | "If your API key doesn't work, we'll replace it"; "your API key is ready" | "A token leaked? Revoke it yourself"; "create your API token on the API Access page". |
| `components/portal/new-ticket-form.tsx` | "API issues are fixed automatically — your key will be replaced right away" | Quick check (token + base URL); asks for the `x-request-id`. |
| API_ISSUE ticket bot reply (`lib/services/tickets.ts`) | "Your API key has been automatically replaced!" | Outside `active`: checklist pointing at API Access, balance, token revocation. |
| `components/portal/redeem-form.tsx` | "Create your API key" | "Create your API token" |

## 5. Admin surfaces (WS10)

- `LEGACY_API_POOL_MODE=active|readonly|off` (default `readonly`), read by `lib/services/legacy-pool.ts`.
- Assignments — Order-ID activation, recharge approval, API-ticket create/close, the `AUTO_FIXING` cron — all go through `swapPoolKey()`, which is a no-op unless `active`, always filters by the customer's store (fixes audit §13 #14) and claims conditionally.
- **Activation is decoupled from the pool:** `redeemOrder` no longer throws `NO_KEYS_AVAILABLE`; an empty pool never blocks activation in any mode.
- API Pool page: keys are masked on the server (`sk-…abcd`) and copy buttons are removed outside `active`; "Add keys" is hidden and refused server-side. New **Unassign all** (pool keys held by customers → `RETIRED`, never handed out again; customers' copies deleted) and **Purge pool keys** (deletes keys no customer holds), both behind a confirmation and logged as `API_POOL_UNASSIGNED` / `API_POOL_PURGED`. Both are refused while `active`. `off` hides the page from the navigation.
- Customers table, profile, export, Expired Balance and Usage Logs show masked keys outside `active`; the create/edit forms hide the key field, and the services ignore key writes. Past-client import no longer stores keys.

## 6. Open points

1. **Codex `wire_api = "chat"`.** The gateway serves Chat Completions only. Recent Codex releases are moving to the Responses API; if the installed Codex rejects `wire_api = "chat"`, the guides and the API Access snippet need a Responses endpoint (WS13-adjacent). Verify with the current Codex CLI before announcing the new guides.
2. `lib/format.ts → previewApiKey` is still used on the API Pool page in `active` mode only.
