# Gateway audit — Phase 0 (Discovery)

**Branch:** `feature/redesign` @ `b31d5b7` · **Audited:** 2026-09-21 · **Status:** approved 2026-09-21 — Phase 0.5 authorised (see §17).

**Baseline (Phase 0):** `tsc --noEmit` clean · `eslint .` → 16 errors / 38 warnings, all pre-existing and outside `lib/gateway/*` (listed in §10) · no test runner installed · `next build` not re-run for this audit (last commit's `build.log` exists).

Legend for severity tags used below: **[MONEY]** provider cost or customer balance can leak · **[SEC]** secret or upstream exposure · **[REL]** reliability · **[HONESTY]** customer sees something untrue.

---

## 1. Request flow map

### 1.1 `POST /v1/chat/completions` and `POST /v1/messages`

Both routes are two-liners that delegate to one pipeline:

| Step | File → function | Notes |
|---|---|---|
| Route | `app/v1/chat/completions/route.ts` → `POST` · `app/v1/messages/route.ts` → `POST` | `dynamic = "force-dynamic"`, `maxDuration = 300` (hard-coded). No `runtime` export (Node is the default in Next 16; Edge is deprecated — see §15). |
| Proxy bypass | `proxy.ts` → `proxy()` | `/v1/*` returns `NextResponse.next()` before any cookie/affiliate logic. |
| Request ID | `lib/gateway/handler.ts` → `requestIdFrom()` | `req_` + 20 hex chars. Sent as `x-request-id` on success and error responses from the handler. |
| Auth | `lib/gateway/tokens.ts` → `authenticateGatewayRequest(headers)` | Reads `Authorization: Bearer` then `x-api-key`. Requires `al_` prefix. **1 DB read** (`gatewayToken.findUnique` by `tokenHash` + `include customer`). Checks revoked / deleted / SUSPENDED-EXPIRED / not activated / `remaining ≤ 0` where `remaining = (initialBalance−usedBalance)+(initialBonus−usedBonus)`. Fire-and-forget `lastUsedAt` write (≤1/min/token). **No cache. No rate limit.** |
| Body | `handler.ts` → `readJson()` | `Content-Length` > 20 MB → 413; JSON object required. Vercel rejects > 4.5 MB before this runs (§15.1). |
| Model resolve | `lib/gateway/registry.ts` → `resolveModel(slug, storeId)` → `getModelRegistry()` | In-process cache, 30 s TTL; loads all enabled `GatewayModel` + enabled `ProviderModel` + enabled `Provider`, **decrypts every provider key into memory**. Per-store visibility via `enabledStoreIds` CSV. 404 if unknown, 503 if zero candidates. |
| Body shaping (OpenAI wire) | `handler.ts` | Allowlist `CHAT_ALLOWED_KEYS`; requires `messages[]`; rejects `n≠1`; forces `stream_options.include_usage=true` when streaming; clamps `max_tokens` / `max_completion_tokens` to `model.maxOutputTokens`. |
| Body shaping (Anthropic wire) | `lib/gateway/anthropic.ts` → `toChatRequest()` | Translates system/messages/tools/tool_choice/images/tool_results → OpenAI chat; **drops `thinking` blocks and `cache_control`**; sets `stream_options.include_usage`; clamps `max_tokens`. |
| Dispatch + failover | `lib/gateway/dispatch.ts` → `dispatchChat(model, body, request.signal)` | Filters candidates whose in-memory breaker is open (falls back to all if every breaker is open). Loops providers in `(provider.priority, mapping.priority)` order. Retriable = 408/409/425/429/5xx/network → next provider. Non-retriable 4xx → thrown to client **with the upstream error text** (§13 #11). Writes `Provider.healthStatus` on **every** success and on trip (§13 #15). |
| Upstream call | `lib/gateway/providers/openai-compatible.ts` → `chatCompletions(target, body, signal)` | `fetch(baseUrl + "/chat/completions")`, `Authorization: Bearer <providerKey>`, body with `model` rewritten to `upstreamModelId`. 30 s global first-byte timer. Client `signal` is forwarded **only until headers arrive** — the abort listener is removed in `finally` (§5). |
| Stream transform (OpenAI wire) | `lib/gateway/passthrough.ts` → `observeChatStream(body)` | `tee()`: one branch to the client byte-for-byte, the other parsed by `lib/gateway/sse.ts` → `parseSse()` to capture the final `usage` chunk, `finish_reason`, `error`. |
| Stream transform (Anthropic wire) | `anthropic.ts` → `toAnthropicStream(body, slug)` | Re-emits `message_start` / `content_block_*` / `input_json_delta` / `message_delta` / `message_stop`; `cache_*` usage fields are always `0`; `reasoning_content` deltas are **not** mapped (dropped). `cancel()` resolves `done` with whatever usage was seen (usually none). |
| Non-stream response | `handler.ts` | OpenAI: rewrites `json.model = model.slug`, returns. Anthropic: `toAnthropicResponse()`. |
| Billing | `handler.ts` → `after(() => bill(...))` → `lib/gateway/billing.ts` → `billRequest()` | Runs after the response is done (§4). |

### 1.2 `GET /v1/models`
`app/v1/models/route.ts` → `authenticateGatewayRequest` → `listModelsForStore(storeId)` → OpenAI list shape (`owned_by: "aerolink"`, plus `display_name`, `context_window`, `max_output_tokens`). No `x-request-id`, no `maxDuration`.

### 1.3 `POST /v1/messages/count_tokens`
`app/v1/messages/count_tokens/route.ts` → auth → `ceil(JSON.stringify(body).length / 4)`. Local estimate only; no upstream call; no `x-request-id`.

---

## 2. Every balance write site

Money lives in **four `Int` cents columns** on `Customer` (`initialBalanceCents`, `usedBalanceCents`, `initialBonusCents`, `usedBonusCents`; remaining is derived) plus `gatewayCarryMicroUsd` (sub-cent carry) and two side liabilities that are *not* balance: `pendingBonusCents` (review bonus offered, not yet credited) and `affiliateEarnedCents` (cash commission held for claim). History rows go to `BalanceHistory` / `BonusHistory` (`amountUsedCents` negative = credit).

| # | Trigger | File → function | Fields written | Pattern |
|---|---|---|---|---|
| 1 | Gateway usage | `lib/gateway/billing.ts` → `billRequest()` | `usedBalanceCents↑`, `usedBonusCents↑`, `gatewayCarryMicroUsd`, `status`, `finishedAt`; daily rollup in Balance/BonusHistory | `$transaction`; read-then-increment; **no concurrency guard**; `UsageLog` created *outside* the transaction |
| 2 | Admin "Update usage" | `lib/services/customers.ts` → `updateBalanceUsage()` / `updateBonusUsage()` | `usedBalanceCents` / `usedBonusCents`, status, finishedAt + history row | `$transaction` + optimistic `updateMany where used = expected` |
| 3 | Admin pasted usage rows | `lib/services/usage-logs.ts` → `addUsageLogs()` | via #2 | 80/20 split via `splitUsageCost()` |
| 4 | Admin usage "by title" | `usage-logs.ts` → `addUsageLogsByTitle()` | via #2 | **fabricates model rows** (`lib/usage-synth.ts`), see §12 |
| 5 | Admin quick usage | `lib/services/usage-quick.ts` → `recordUsageFromAmount()` | via #2 | |
| 6 | Admin deletes a usage log | `usage-logs.ts` → `deleteUsageLog()` | `initialBalanceCents↑` (refund) via `addBalanceFunds()` | refund computed with *current* multiplier, not the one used at charge time |
| 7 | Admin add funds | `customers.ts` → `addBalanceFunds()` / `addBonusFunds()` | `initialBalanceCents` / `initialBonusCents` + history | optimistic `updateMany` |
| 8 | Admin create/edit customer | `customers.ts` → `createCustomer()` / `updateCustomer()`; callers in `app/admin/(dashboard)/customers/actions.ts` (`createCustomerAction`, `updateCustomerAction`, `importCustomersAction`, `duplicateCustomer`) | `initialBalanceCents`, `initialBonusCents`, `profitCents` set directly | edit is a raw overwrite of *initial* values, no reason recorded |
| 9 | Past-client import | `app/admin/(dashboard)/expired/actions.ts` (~L74) | all four fields set directly | bulk create |
| 10 | Self-activation (Order ID) | `lib/services/redemption.ts` → `redeemOrder()` | `initialBalanceCents = parsed offer`, `initialBonusCents = $5 welcome if referred`, `pendingBonusCents = 10%` | `$transaction`; **requires an AVAILABLE `ApiPoolKey` or fails** (§8) |
| 11 | Activation approval | `app/admin/(dashboard)/activations/actions.ts` → `approveActivationAction()` | no money; flips `isActivated`; then plan auto-assign, loyalty, affiliate | |
| 12 | Recharge approval | `app/admin/(dashboard)/recharges/actions.ts` → `approveRechargeAction()` | `initialBalanceCents += req.balanceCents`, `pendingBonusCents = 15%`, `status`, `finishedAt=null` + history; rotates pool key | `$transaction([...])` array; then **always** `autoAssignPlanByPrice` (overrides admin's plan) |
| 13 | Review bonus claim / revoke | `lib/services/review-bonus.ts` → `claimReviewBonus()` / `revokeReviewBonus()` (and `verify`) | `initialBonusCents ±pendingBonusCents` + history | `$transaction`; idempotent on status |
| 14 | Affiliate commission | `lib/services/affiliate.ts` → `creditReferralCommission()` | `affiliateEarnedCents↑`, `loyaltyPoints↑` (+ BonusHistory *audit* row that does not move bonus) | not a balance write, but a liability |
| 15 | Affiliate milestone payout | `lib/services/affiliate-claims.ts` → `approveAffiliateClaim()` | `initialBalanceCents += reward` + history | |
| 16 | Loyalty cash reward | `lib/services/loyalty.ts` → `approveReward()` | `initialBonusCents += tier.reward` + history | |
| 17 | Soft delete / restore / permanent delete | `customers.ts` → `softDeleteCustomer()` / `restoreCustomer()` / `permanentlyDeleteCustomer()` | none / none / cascade | ledger needs `EXPIRY`/`RESTORE` semantics only if we decide deletion zeroes liability |
| 18 | Dev/test scripts | `scripts/test-*.ts` (11 files) | direct writes | not shipped; exclude from the grep test or delete |

**Findings**
- **[MONEY] Overspend window.** The only spend gate is `remaining > 0` at auth. 20 parallel streams all pass, all get served, `billRequest` clamps via `splitUsageCost`. Confirms WS2's premise.
- **[MONEY] `splitUsageCost` lets balance go to −$10** (`BALANCE_FLOOR_CENTS = -1000` in `lib/services/usage-logs.ts`). README says "can never go negative"; the brief says never negative. Decision needed (§16 Q8).
- The optimistic-concurrency pattern in `customers.ts` (`updateMany where field = expected`) is good and is the natural seam for `balance-service.ts`.
- No idempotency keys anywhere; a retried recharge approval is guarded only by `status !== PENDING`.

---

## 3. In-memory state assuming a single process

| Where | What | Impact on Vercel Fluid |
|---|---|---|
| `lib/gateway/circuit.ts` → `breakers: Map` | per-provider failures/openedAt, 3 → 60 s | per instance; rediscovered per instance (WS4) |
| `lib/rate-limit.ts` → `buckets: Map` | sliding-window limiter for admin/customer login and `/activate` | per instance (WS3 moves it) |
| `lib/gateway/registry.ts` → `cache` | model/provider catalog **with decrypted keys**, 30 s TTL; `invalidateModelRegistry()` only clears the *calling* instance | admin edits take up to 30 s to reach other instances (fine); brief wants 60 s + Redis-side invalidation |
| `lib/gateway/providers/deepinfra.ts` → `cache` | public DeepInfra catalog, 10 min | harmless |
| `lib/services/settings.ts` → `getSettings = cache(...)` | React request-scoped cache | fine |
| `lib/prisma.ts` | module singleton; in production **not** stored on `globalThis` (only in dev) — still a module singleton per instance, fine | no `connection_limit` set (WS12.2) |

No counters, no queues. Nothing shares state across instances today.

---

## 4. How `after()` billing works today

`handleGateway` returns the `Response` first and schedules `after(async () => { const o = await done; await bill(o.usage, status, provider) })`. Bundled Next 16 docs (`node_modules/next/dist/docs/.../after.md`) confirm: `after` runs after the response *finishes* (for a stream: when it closes), is bounded by the route's `maxDuration`, and runs even if the handler threw. On Vercel it is backed by the platform's `waitUntil`.

| Scenario | OpenAI wire (`observeChatStream`) | Anthropic wire (`toAnthropicStream`) | Result |
|---|---|---|---|
| Normal completion | usage from last chunk → `billRequest` | usage from last chunk → `billRequest` | correct |
| **Client disconnects mid-stream** | `tee()` client branch cancels; observer branch **keeps reading the upstream to the end** → provider generates to `max_tokens`; we pay; customer *is* billed the full amount because the usage chunk still arrives | `cancel()` resolves `done` with `usage=null`; the `start()` loop keeps draining upstream (`controller.enqueue` throws → caught → loop exits, but the upstream body is never `cancel()`ed, so the fetch keeps receiving) → `bill(null)` → `costMicroUsd=0`, **UsageLog written with cost 0, customer charged 0**, we pay in full | **[MONEY]** both wires pay upstream to completion; Anthropic wire charges nothing |
| Upstream error chunk mid-stream | forwarded raw; `error` captured; billed if usage present, `status="error"` | emits Anthropic `error` event; bills with whatever usage seen | ok-ish; no partial estimate |
| Upstream dies mid-stream (network) | observer `reader.read()` rejects → `error` set → bill with usage seen so far (null) | same | **[MONEY]** partial content delivered, nothing charged |
| **Function hits `maxDuration` (300 s)** | `after()` is killed with the invocation; usage arrives only in the *final* chunk → nothing logged, nothing charged | same | **[MONEY]** long reasoning generations cut by timeout are unbilled |
| `billRequest` throws (DB down) | `.catch(console.error)` | same | **[MONEY]** silent leak; no retry record |
| Two `after()`s for one request | impossible today (one per request) | | fine; settlement in WS2 must be idempotent anyway |

Also: `UsageLog.create` runs before the `$transaction`, so a DB failure between them leaves a log with no deduction.

---

## 5. Is `request.signal` passed to the upstream fetch?

**Partially.** `handler.ts` → `dispatchChat(model, body, request.signal)` → `chatCompletions(target, body, signal)`. Inside, `signal.addEventListener("abort", () => controller.abort())` is registered **and removed in `finally` as soon as `fetch()` resolves (headers received)**. Consequences:

- Client disconnect during connect/TTFB → upstream aborted ✔ (and `dispatchChat` maps it to a 499).
- Client disconnect during the body stream → **upstream is not aborted** ✘ (see §4).
- There is a 30 s first-byte timer (`FIRST_BYTE_TIMEOUT_MS`, global, not per model) and **no total timeout**. Reasoning models with TTFB > 30 s will spuriously fail over and trip the breaker.
- The `// @ts-expect-error duplex: "half"` option is set (Node fetch); fine.

---

## 6. How usage is parsed, and cached tokens

- `lib/gateway/billing.ts` → `readUsage(u)`: `prompt_tokens|input_tokens`, `completion_tokens|output_tokens`, `estimated_cost` (number). Nothing else: **no `cached_tokens`, `prompt_cache_hit_tokens`, `cache_read_input_tokens`, `reasoning_tokens`, `cache_write`.**
- `anthropic.ts` (stream and non-stream) re-implements the same three fields and always emits `cache_creation_input_tokens: 0, cache_read_input_tokens: 0` to Claude Code.
- `providerCostMicroUsd()`: if `estimated_cost` present → `round(cost × 1e6)`; else `promptTokens × inputPriceMicroPerMTok / 1e6 + completionTokens × outputPriceMicroPerMTok / 1e6`. All `Number` arithmetic.
- Customer charge: `lib/plan-usage.ts` → `customerMicroUsd(rate, providerCost, totalTokens)`; carry handled in `billRequest`.

Verified provider dialects (§15): DeepInfra reports only `prompt_tokens / completion_tokens / total_tokens / estimated_cost` (no cache fields); DeepSeek reports `prompt_cache_hit_tokens`, `prompt_cache_miss_tokens`, `prompt_tokens_details.cached_tokens`, `completion_tokens_details.reasoning_tokens`; OpenRouter reports `prompt_tokens_details.cached_tokens`, `cache_write_tokens`, `completion_tokens_details.reasoning_tokens`, `cost`, `cost_details.upstream_inference_cost` and includes usage in the last SSE chunk automatically (`stream_options` deprecated/no-op there). So WS6's cache pricing matters for DeepSeek-direct and OpenRouter; today's DeepInfra-only setup has no cache data to lose.

---

## 7. Plan assignment logic

- `lib/services/plan-usage.ts` → `findPlanByPrice(storeId, cents)`: active plans with `priceCents == amount`, `take: 2`, returns one only if exactly one. Zero or ≥2 → `null` → **silent fallback** to `usage_cost_multiplier` (store setting) in `getCustomerBillingRate()`.
- `autoAssignPlanByPrice` is called from `approveActivationAction` (only when `planId` is null) and from `approveRechargeAction` (**always**, so an admin-chosen plan is overwritten on the next recharge — contradicts the code comment "Admins can override").
- Admin override UI: `components/admin/customers/plan-card.tsx` → `assignPlan()`.
- `Plan.limitType` is `"USD" | "TOKENS"`; rate math in `lib/plan-usage.ts` → `planRate()` (`Number`, floats: `priceCents / limitUsageCents`).
- **Customers without a plan:** local dev DB → 5/5 activated customers have `planId = null`. Production count unknown — run:
  ```sql
  SELECT "storeId", COUNT(*) FROM "Customer" WHERE "deletedAt" IS NULL AND "isActivated" AND "planId" IS NULL GROUP BY 1;
  ```
- Seed (`prisma/seed.ts`) creates Starter/Plus/Pro/Ultimate per store with `limitUsageCents = round(price / 2.2)` → ×2.2 multiplier, but only when the store has zero plans.

---

## 8. API Pool — every path that reads, assigns or displays upstream keys

Models: `ApiPoolKey { key @unique, status AVAILABLE|ASSIGNED|PROBLEMATIC, customerId?, orderId? }` and `ApiKey { key, customerId @unique }` (the customer's current key). Pool keys are **plaintext** in the DB.

| Path | File | Kind |
|---|---|---|
| **Customer dashboard shows the full upstream key with copy/reveal** | `app/portal/page.tsx` L26-28, L171 → `components/portal/api-key-card.tsx` | **[SEC] customer-visible** |
| Docs render with the key substituted for `YOUR_AEROLINK_API_KEY` | `app/portal/documentation/page.tsx` L23-36 → `lib/services/documentation.ts` → `renderDocForCustomer()` | **[SEC] customer-visible** |
| Self-activation *requires* and assigns a pool key | `lib/services/redemption.ts` → `redeemOrder()` (throws `NO_KEYS_AVAILABLE`) | assignment — **blocks activation when pool is empty** |
| Recharge approval rotates the key (old → PROBLEMATIC, new → ASSIGNED) | `app/admin/(dashboard)/recharges/actions.ts` L18-40, L96-107 | assignment |
| Ticket auto-fix / close rotates the key | `lib/services/tickets.ts` L45-100, L170-200, L228-265 (`runAutoFix`, `closeTicket`) — `apiPoolKey.findFirst({ status: "AVAILABLE" })` **without `storeId`** → cross-store key handout | assignment **[SEC]** |
| Admin pool CRUD, import, status changes | `app/admin/(dashboard)/api-pool/actions.ts`, `page.tsx`, `components/admin/api-pool-view.tsx` | admin display (full keys) |
| Admin customer form / edit dialog (manual key) | `components/admin/customers/customer-form.tsx`, `edit-customer-dialog.tsx`, `customers/actions.ts` | admin write |
| Customer table / profile / search / export show keys | `components/admin/customers/customers-table.tsx`, `customers/[id]/page.tsx`, `search-actions.ts`, `lib/export.ts` (CSV/XLSX export includes `apiKey`) | admin display |
| Past-client import stores keys | `app/admin/(dashboard)/expired/actions.ts` | admin write |
| Usage logs `keyLabel` | `usage-logs/page.tsx`, `components/admin/usage-logs-view.tsx` | label only |
| Gateway upstream credentials | `Provider.apiKeyEnc` via `lib/gateway/registry.ts` / `crypto.ts` | **separate** — pool keys are never used by `lib/gateway/*` |

Conclusion for WS10: no pool key is a gateway credential, so nothing needs migrating into `Provider`; the work is removing the two customer-visible surfaces, gating assignment behind `LEGACY_API_POOL_MODE`, and **decoupling `redeemOrder` from the pool** (otherwise Order-ID activation fails in `readonly`/`off`, and the voucher flow would inherit the dependency).

---

## 9. Build, migration and seed behaviour on Vercel

- `package.json` → `vercel-build`: `prisma generate` → `scripts/migrate-prod.mjs` (raw SQL store upserts + `storeId` backfills, errors swallowed) → **`prisma db push --accept-data-loss`** → `prisma db seed` → `next build`.
- **There is no Prisma migration history.** `prisma/migrations/` holds two loose `.sql` files (`add_admin_role.sql`, `multi_store_setup.sql`) that Prisma does not track. Schema changes are applied by `db push` on **every build, in every environment**, against whatever `DATABASE_URL` that environment has. No `VERCEL_ENV` check → a preview deployment with production env vars **will** push schema (and could drop columns) on production.
- Two schemas: `prisma/schema.prisma` (Postgres) and `prisma/schema.sqlite.prisma` (local). `scripts/prisma.mjs` picks by URL prefix. Every schema change must be made twice.
- Seed (`prisma/seed.ts`) is idempotent: `upsert` for stores/admins/settings/docs, plans only when none exist, docs never overwrite edited content. ✔
- `vercel.json` = `{ "regions": ["cdg1"] }` — **no `crons` entry**. `app/api/cron/fix-tickets/route.ts` says it runs every 5 min, but nothing schedules it. It does check `CRON_SECRET` ✔.
- `.env.example` lacks `CRON_SECRET`, `DIRECT_URL`, all gateway vars.
- Postgres host, Vercel plan, and Fluid compute status are not derivable from the repo (§16).

---

## 10. Test setup

- **None.** No test runner, no `test` script, no fixtures. `scripts/test-*.ts` are ad-hoc `tsx` scripts that mutate the dev DB.
- `scripts/gateway-dev-seed.ts` registers two mock providers on `127.0.0.1:4010/4011` and references a `scratchpad/mock-provider.mjs` that is **not in the repo**.
- Lint errors (16, pre-existing) live in: `admin/(dashboard)/{documentation,expired,settings,tickets,usage-logs}/actions.ts`, `tickets/[id]/page.tsx`, `portal/page.tsx`, `portal/rules/page.tsx`, `portal/support/[id]/page.tsx`, `portal/support/actions.ts`, `components/admin/admin-shell.tsx`, `components/admin/api-pool-view.tsx`. Mostly `react-hooks/set-state-in-effect` and unused vars. I propose fixing them in Phase 1 so "lint passing" is a meaningful gate.
- Proposed infra (Phase 0.5, before WS1): **Vitest** (+ `vitest.config.ts` with a `unit` project on SQLite and an `integration` project on Postgres), `docker-compose.test.yml` (Postgres 16 + Redis 7 — Upstash-compatible via `@upstash/redis` pointed at a local `serverless-redis-http` container, or the in-process fallback), `test/mock-upstream/` (Node `http` server speaking OpenAI chat + Anthropic messages, scriptable per test via a control endpoint), and the grep test for balance writes.

---

## 11. Prisma schema summary (actual identifiers for raw SQL)

Prisma default mapping: table = model name, columns = camelCase, all **double-quoted** in Postgres. Types below are the Postgres ones (`Int` = `integer`, 32-bit).

```
"Customer"        "id" text PK · "storeId" · "accessCode" unique · "status" text
                  "initialBalanceCents" int · "usedBalanceCents" int · "initialBonusCents" int · "usedBonusCents" int
                  "gatewayCarryMicroUsd" int · "pendingBonusCents" int · "affiliateEarnedCents" int · "profitCents" int
                  "planId" text? · "planAssignedAt" · "isActivated" bool · "finishedAt" · "deletedAt" · "createdAt" · "updatedAt"
"UsageLog"        "id" · "storeId" · "customerId" · "happenedAt" · "keyLabel" · "model" · "tokens" text · "costMicroUsd" int
                  "latency" text · "status" text · "addedBy" · "promptTokens" int? · "completionTokens" int? · "providerSlug" · "gatewayTokenId" text? · "endpoint"
"GatewayToken"    "id" · "customerId" · "storeId" · "name" · "prefix" · "tokenHash" unique · "tokenEnc" · "lastUsedAt" · "revokedAt"
"Plan"            "id" · "storeId" · "name" · "priceCents" int · "limitType" text · "limitUsageCents" int · "limitMTokens" int · "isActive" · "sortOrder"
"Provider"        "id" · "slug" unique · "name" · "kind" · "baseUrl" · "apiKeyEnc" · "enabled" · "priority" · "healthStatus" · "lastCheckedAt" · "lastError"
"GatewayModel"    "id" · "slug" unique · "displayName" · "enabled" · "inputPriceMicroPerMTok" int · "outputPriceMicroPerMTok" int · "contextWindow" · "maxOutputTokens" · "enabledStoreIds" text
"ProviderModel"   "id" · "providerId" · "modelId" · "upstreamModelId" · "priority" · "enabled"   unique("providerId","modelId")
"BalanceHistory"  "id" · "customerId" · "amountUsedCents" int (negative = credit) · "remainingAfterCents" · "note" · "updatedBy"
"BonusHistory"    same shape
"RechargeRequest" "id" · "storeId" · "customerId" · "orderNumber" unique · "offerTitle" · "balanceCents" · "bonusCents" · "status" · "processedAt"
"ApiPoolKey"      "id" · "storeId" · "key" unique · "status" · "customerId" unique? · "orderId" · "assignedAt"
"ApiKey"          "id" · "key" · "customerId" unique
"Setting"         "id" · "storeId" · "key" · "value"   unique("storeId","key")
"Notification"    "id" · "storeId" · "type" · "title" · "message" · "customerId" · "relatedId" · "isRead"
"Order"           "id" · "customerId" unique · "orderNumber" unique
```

Reserve statement adapted to this schema (works verbatim on Postgres and SQLite):

```sql
UPDATE "Customer"
   SET "reservedCents" = "reservedCents" + $1
 WHERE "id" = $2
   AND ("initialBalanceCents" - "usedBalanceCents") + ("initialBonusCents" - "usedBonusCents") - "reservedCents" >= $1;
```

---

## 12. Customer-facing copy that names models, versions or upstreams

| Where | What it says | Problem |
|---|---|---|
| `prisma/docs/codex-*.md` (seeded `Documentation`, editable in admin, shown in portal) | `model = "gpt-5.6-sol"`, `wire_api = "responses"`, `base_url = "https://cgapi.aerolink.lat"`, "Your API key is already assigned to you" | **[HONESTY]** Describes the legacy pool-key flow through an external proxy. The gateway serves `/v1/chat/completions` only (no Responses API) and catalog slugs like `deepseek-v3`. A customer following these docs cannot reach the gateway. |
| `prisma/docs/claude-*.md` | `ANTHROPIC_BASE_URL: "https://capi.aerolink.lat/"`, `ANTHROPIC_API_KEY: YOUR_AEROLINK_API_KEY` | **[HONESTY]** same; and the key substituted is the upstream pool key |
| `lib/usage-synth.ts` (`CLAUDE_MODELS`, `GPT_MODELS`) | Fabricated rows labelled "Claude Opus 5", "Claude Sonnet 4.6", "GPT-5.6 Sol", … with random latency/status, shown to customers in **Activity Logs** | **[HONESTY]** invented per-model usage presented as real requests |
| `app/portal/documentation/page.tsx` | "every occurrence of YOUR_AEROLINK_API_KEY is replaced with the customer's assigned key" | ties docs to pool keys |
| `app/new/page.tsx` | "Frontier models from several providers", "Claude Code & Codex, one key" | fine once the catalog is real; "several providers" is currently one (DeepInfra) |
| `components/portal/api-access-view.tsx` | Config snippets with `${baseUrl}/v1`, `wire_api = "chat"`, gateway token | ✔ correct |
| `lib/plan-usage.ts` → `describePlanRate/Limit` | "$100 · $5.00 of real API usage" | ✔ honest but admin-only |

Full copy audit with rewrites belongs to WS7 (`docs/copy-audit.md`).

---

## 13. Deviations between the brief and reality — proposed adjustments

1. **Money is `Int` cents, not `BigInt`.** All four balance fields, `costMicroUsd`, prices and carry are 32-bit `Int` and `number` in TS; every UI/service consumes `number`. Widening every existing column and call site in one go is a large, risky change. **Proposal:** (a) all *new* tables (`LedgerEntry`, `GatewayReservation`, `GatewayAttempt`, `Pack`, `Voucher*`, `ProviderCostDaily`) and all *new* columns use `BigInt`/`bigint`; (b) the ledger is kept in **micro-USD** so gateway debits are exact and the carry field becomes derivable; (c) cached `Customer` fields stay `Int` cents this release (expand phase) with the invariant `sum(ledger µ$, pot) == (initial − used) × 10 000 − carry(pot)`; (d) a follow-up release widens the cached columns to `BigInt` once every reader goes through `balance-service.ts`. Needs your OK (Q9).
2. **No migrations — `db push --accept-data-loss` on every build.** "Additive migrations" and "`migrate deploy` only in production" need a migration history first. **Proposal:** in Phase 1 create a baseline (`prisma migrate diff --from-url <prod> --to-schema-datamodel` → `0000_baseline`, `migrate resolve --applied` on prod), switch `vercel-build` to `migrate deploy` gated on `VERCEL_ENV === "production"`, fail loudly if a preview's `DATABASE_URL` host equals the production host, keep `db push` for local SQLite only. Requires read access to the production schema (Q6).
3. **Balance floor −$10** in `splitUsageCost`. Gateway settlement will never go negative (per brief). Keep the floor for admin-imported usage or remove it? (Q8)
4. **Recharge approval overwrites the admin's plan** (`autoAssignPlanByPrice` unconditional). WS8 replaces price matching with Pack binding; until then I will not touch it.
5. **Order-ID activation depends on the pool** (`redeemOrder` throws `NO_KEYS_AVAILABLE`). The brief says keep that flow "unchanged"; it must change minimally: pool-key claim only when `LEGACY_API_POOL_MODE=active`. Same for recharge approval and ticket auto-fix.
6. **No crons are scheduled** (`vercel.json`). Also Hobby plan allows **once per day** only → the 5-min sweeper and hourly health snapshot require **Pro**. (Q10)
7. **`maxDuration`:** brief wants 800 from env. Hobby max is 300; Pro/Enterprise 800 (1800 beta). Will read `GATEWAY_MAX_DURATION` with a documented note that the platform clamps it. (Q10)
8. **Edge runtime is deprecated in Next 16** and `runtime = 'nodejs'` is the default; the explicit export is harmless and I will add it for clarity.
9. **`after()`** semantics confirmed from bundled docs; the *streaming-cancel* case still needs an empirical check on a preview deployment (first task of Phase 3; `@vercel/functions` `waitUntil` kept as the fallback path behind a tiny adapter).
10. **DeepSeek Anthropic endpoint** (`https://api.deepseek.com/anthropic`) exists: streaming, tools, images, thinking (`budget_tokens` ignored) supported; **`cache_control` ignored**; `count_tokens` not documented → keep the local estimate for `count_tokens` even in passthrough mode.
11. **[SEC] Upstream detail leaks today:** `dispatch.ts` returns the upstream error message verbatim on 4xx and lists provider slugs in the 503 text; `asGatewayError` wraps raw `Error.message` from fetch. WS4/WS12.6 fix this via `errors.ts`.
12. **Reasoning content is dropped** in the Anthropic translator (`reasoning_content` → no `thinking` block) and `thinking` request blocks are dropped. WS13's conformance suite should cover the mapping.
13. **`x-request-id` missing** on `/v1/models` and `/v1/messages/count_tokens`.
14. **Cross-store pool key handout** in `lib/services/tickets.ts` (no `storeId` filter). Will fix under WS10.
15. **Hot-path DB write per request:** `markHealth(providerId, "UP")` on every success. Will move to the WS4 hourly snapshot.
16. **OpenRouter:** `stream_options.include_usage` is deprecated/no-op there; usage is automatic in the last chunk. Harmless to send; `Provider.supportsStreamUsage` still useful for others.
17. **Auth `NO_BALANCE` uses balance+bonus > 0** while `computeStatus` uses balance only, so a `BALANCE_FINISHED` customer with bonus left can still call the API. Intentional? (Q11)
18. **Two Prisma schemas** must be edited in lockstep for every migration. I will add a CI check that both datamodels diff to the same set of models/fields.
19. **`scripts/test-*.ts`** write money fields directly; the WS1 grep test will exclude `scripts/` (or we delete them). (Q12)
20. **Brief §8 numbering skips WS7 in the body** — I treat WS7 (honest units & copy) as: rewrite seeded docs for the gateway, remove `usage-synth` fabrication from customer view, honest model/provider naming, plan-unit display via the pricing engine.

---

## 14. Phase plan and estimates

Estimates are engineering days for one engineer, excluding your review time and the production shadow window. Each phase ends with migrations, `tsc`, `eslint`, `vitest`, `next build` green, docs updated, and a summary of what you must configure.

| Phase | Scope | Est. | Key deliverables |
|---|---|---|---|
| **0.5** | Test infra (prerequisite for every acceptance test) | 2 d | Vitest, `docker-compose.test.yml`, `test/mock-upstream/`, provider fixture recorder, grep test scaffold, fix 16 pre-existing lint errors, baseline migration + `migrate deploy` gating (§13 #2) |
| **1** | WS1 Ledger · WS2 Reservations | 6–7 d | `LedgerEntry`, `balance-service.ts`, refactor of 17 write sites, `ledger:backfill`, `reservedCents`, `GatewayReservation`, `estimate.ts`, reserve/settle/release, fit-to-balance, sweeper cron, `GATEWAY_RESERVATIONS=off\|shadow\|enforce`, portal "Balance history", admin timeline |
| **2** | WS3 Rate limits & concurrency · WS4 Redis breaker | 3–4 d | `lib/redis.ts` (+ in-process fallback), Upstash ratelimit per token+customer, Lua concurrency lease, store ceiling, per-`ProviderModel` breaker keys, TTFB/total timeouts, 4xx no-failover, health snapshot cron, login limiter migration |
| **3** | WS5 Abort & partial metering · WS6 Cache-aware pricing | 4–5 d | Empirical `request.signal`/`cancel()` test on preview, `AbortSignal.any`, metering transform with `cancel()`, `usageSource`/`outcome`, `partialChargePolicy`, `lib/gateway/usage/*` normalisers + fixtures, new price columns with backfill, Anthropic cache field mapping |
| **4** | WS12 Platform hardening | 2–3 d | `GATEWAY_MAX_BODY_BYTES` (≤ 4 MB) + wire-shaped 413, `directUrl` + `connection_limit`, Redis auth cache with immediate revocation, `PROVIDER_KEY_SECRET` + `v2:` ciphertexts + `keys:reencrypt`, response hygiene, `.env.example` |
| **5** | WS8 Packs & pricing engine · WS9 GamsGo vouchers | 7–8 d | `Pack`, pack-required approvals, "No plan" badge/bulk assign, `pricing-engine.ts`, `VoucherBatch`/`Voucher`, code generator + HMAC, admin Vouchers page (generate/export/stock/lookup/revoke/clawback/listing helper), `/redeem` + Recharge field, risk rules → review queue, expiry cron, `docs/vouchers.md` |
| **6** | WS7 Honest units & copy · WS10 Retire API Pool | 3–4 d | Seeded docs rewritten for the gateway, `usage-synth` removed from customer view, `docs/copy-audit.md`, `LEGACY_API_POOL_MODE`, portal banner, masked admin history, unassign/purge, decoupled activation, key-pattern test |
| **7** | WS11 Multi-provider depth · WS13 Anthropic passthrough | 5–7 d | Provider capability flags, `gateway:deepseek` / `gateway:openrouter`, `GatewayAttempt`, provider stats UI, `license` gate, native `/v1/messages` per attempt, native metering, conformance fixtures, `docs/claude-code-testing.md` |
| **8** | WS14 Observability & reconciliation · load test | 3–4 d | Structured request log, margin stats, daily cron (reconciliation page, `ProviderCostDaily`, provider-reported cost form, voucher checks), notification types, k6 script, `docs/gateway.md`, `docs/runbook.md`, final summary |
| | **Total** | **≈ 36–44 d** | |

Production rollout order (unchanged from the brief §13): deploy additive schema → `ledger:backfill` → `keys:reencrypt` → flags one at a time, `GATEWAY_RESERVATIONS=shadow` for 24–48 h before `enforce`.

---

## 15. "Verify, don't assume" — results

| # | Item | Result | Source |
|---|---|---|---|
| 1 | Vercel body limit / maxDuration / Fluid | Body **4.5 MB** (413 `FUNCTION_PAYLOAD_TOO_LARGE`, applies to request *and* response body of non-streamed functions). maxDuration with Fluid: Hobby 300 s default+max; Pro/Ent 300 s default, **800 s max**, 1800 s beta. Fluid is default for new projects; **project status must be checked in the dashboard** (Q10). | vercel.com/docs/functions/limitations (updated 2026-08-24) |
| 2 | Next 16 `request.signal` on disconnect / stream `cancel()` | Docs and community sources say `request.signal` fires on client disconnect in Node route handlers and `ReadableStream.cancel()` fires when the consumer goes away; known flakiness reports are Edge-specific. **Not yet verified empirically on Vercel for this app** → first task of Phase 3 with a preview deployment and the mock upstream. | Next.js discussions #48682, #61972; bundled `after.md` |
| 3 | `after()` vs `waitUntil` | `after()` runs after the response finishes (stream close), bounded by `maxDuration`, executes even on error. Vercel implements it over `waitUntil`. Keep `after()`; wrap in an adapter so `@vercel/functions` `waitUntil` can be swapped in if #2 shows the callback is lost on cancel. | `node_modules/next/dist/docs/01-app/03-api-reference/04-functions/after.md` |
| 4 | DeepSeek usage fields / `include_usage` / Anthropic endpoint | Usage: `prompt_tokens`, `completion_tokens`, `prompt_tokens_details.cached_tokens`, `prompt_cache_hit_tokens`, `prompt_cache_miss_tokens`, `completion_tokens_details.reasoning_tokens`. `stream_options.include_usage` supported (usage on last chunk). Anthropic-compatible base `https://api.deepseek.com/anthropic`: streaming, tools, images, thinking supported; `cache_control` **ignored**; `count_tokens` not documented. | api-docs.deepseek.com |
| 5 | DeepInfra streaming usage / `estimated_cost` | Usage object: `prompt_tokens`, `completion_tokens`, `total_tokens`, `estimated_cost` (USD float). `stream_options.include_usage` yields a final usage chunk before `[DONE]`. **No cache fields.** Real recorded fixture still required (Phase 3). | deepinfra.com model API docs |
| 6 | OpenRouter usage / cache | `prompt_tokens_details.cached_tokens`, `prompt_tokens_details.cache_write_tokens`, `completion_tokens_details.reasoning_tokens`, `cost`, `cost_details.upstream_inference_cost`; usage always in the final SSE chunk; `stream_options`/`usage.include` deprecated no-ops. | openrouter.ai/docs/use-cases/usage-accounting |
| 7 | Upstash Lua / ratelimit | `@upstash/redis` supports `eval`, `evalsha`, `redis.createScript()` (EVALSHA with EVAL fallback, `readonly` option). `@upstash/ratelimit` current API: `Ratelimit.slidingWindow(n, "1 m")`, `limit(identifier)` → `{ success, reset, remaining }`. | Upstash blog/docs (direct docs host unreachable from this machine; confirmed via secondary sources) |
| 8 | Vercel cron limits | 100 jobs/project on every plan. **Hobby: once per day, ±59 min precision; Pro/Enterprise: once per minute.** | vercel.com/docs/cron-jobs/usage-and-pricing (updated 2026-07-15) |
| 9 | Model licenses | Not checked yet — per model at enable time (WS11 `license` field); catalog today has only local mock models. | — |

---

## 16. Questions for you

From the brief §16:

1. **TOKENS-mode cached input weight:** count cached tokens fully (`1.0`, current) or discounted (e.g. `0.1`)?
2. **Partial-charge default:** `CHARGE_DELIVERED` or `WAIVE_ON_UPSTREAM_ERROR`?
3. **Defaults for `rpm` / `maxConcurrent` per plan and the store-wide concurrency ceiling** (suggestion: Starter 60 rpm / 4, Plus 120 / 8, Pro 300 / 16, Ultimate 600 / 32; store ceiling 200).
4. **Voucher expiry default:** none, or 12 months?
5. **Vouchers auto-approve from day one?** Risk thresholds (suggestion: > 3 redemptions per IP per day → review queue).
6. **Production Postgres host** (Neon / Prisma Postgres / Supabase / other) for pooling config, and can I get read access to the production schema for the migration baseline?
7. **Low-stock threshold per pack** (suggestion: 10 unredeemed, or < 7 days of stock at the trailing-7-day rate).

Raised by this audit:

8. **Balance floor:** `splitUsageCost` allows −$10 for admin-imported usage. Keep it for admin imports only (gateway never negative), or remove it everywhere?
9. **Money units (§13 #1):** OK to keep cached `Customer` fields as `Int` cents this release, with the ledger in `BigInt` micro-USD and the invariant above, widening the cached columns in a follow-up?
10. **Vercel plan:** Hobby or Pro? This decides `maxDuration` (300 vs 800), cron frequency (daily vs 5-min sweeper), and whether Fluid compute is enabled on the project.
11. **Bonus-only spending:** today a customer at $0 balance with bonus left is `BALANCE_FINISHED` but can still call the API (auth checks balance+bonus). Keep?
12. **`scripts/test-*.ts`:** delete them (replaced by Vitest) or keep and exclude from the grep test?
13. **Legacy proxies** `capi.aerolink.lat` / `cgapi.aerolink.lat` referenced in the seeded docs: are they still live? Should the rewritten docs point only at this site's `/v1`?
14. **Lint:** may I fix the 16 pre-existing ESLint errors in Phase 0.5 so "lint passing" becomes a hard gate?

---

*End of Phase 0. No code has been modified. Waiting for your approval and answers before starting Phase 0.5 / Phase 1.*

---

## 17. Decisions (2026-09-21)

| # | Decision |
|---|---|
| 1 | TOKENS plans: `cachedTokenWeight = 1.0` |
| 2 | `partialChargePolicy` default `WAIVE_ON_UPSTREAM_ERROR` (charge on client disconnect, waive on upstream failure) |
| 3 | Plan limits: Starter 20 rpm / 4 concurrent · Plus 30 / 8 · Pro 40 / 16 · Ultimate 50 / 32 · store ceiling 200. Admin-editable per plan. |
| 4 | Voucher expiry default 12 months, editable per batch |
| 5 | `voucherAutoApprove` default **off**; risk rule `> 3` redemptions per IP per day → review queue |
| 6 | Production DB is **Supabase Postgres** (`supabase-cyan-mountain`; `DATABASE_URL` set manually in Vercel, Production env only — previews have no DB and fail to build today). Pooling: runtime `DATABASE_URL` = Supavisor transaction pooler (port 6543, `?pgbouncer=true&connection_limit=1`), `DIRECT_URL` = port 5432 for `migrate deploy`. Vercel env today: `CRON_SECRET`, `SESSION_SECRET`, `ADMIN_*`, `NEXT_PUBLIC_APP_URL`, `DATABASE_URL`. No Redis yet. |
| 7 | **A** — vouchers via GamsGo Automatic Delivery (one batch per pack, uploaded to that pack's offer; the code carries the pack, customer never chooses). The Order-ID activation flow is **kept unchanged as the manual fallback**. Low-stock threshold: < 10 unredeemed or < 7 days of stock. |
| 8 | Remove the −$10 balance floor everywhere (`BALANCE_FLOOR_CENTS`) |
| 9 | Staged money units: new tables/columns `BigInt` micro-USD; cached `Customer` fields stay `Int` cents this release; widen later |
| 10 | Vercel **Pro** (switching from Hobby). Build for 800 s / per-minute crons. |
| 11 | Bonus remains spendable at $0 balance; status shows `LOW_BALANCE` (not `BALANCE_FINISHED`) while bonus remains |
| 12 | Delete `scripts/test-*.ts` |
| 13 | Rewrite seeded docs to point only at this site's `/v1`; legacy `capi`/`cgapi` proxies dropped from docs |
| 14 | Fix the 16 pre-existing ESLint errors in Phase 0.5 |

---

## 18. Phase log

| Phase | Commit | Status |
|---|---|---|
| 0.5 test infra + migration baseline | `4489c65` | done 2026-09-21 |
| 1 WS1 ledger + WS2 reservations | `fd5051c` | done 2026-09-21 — see [gateway.md](gateway.md) and [runbook.md](runbook.md). Deviation from §13 #1 applied: ledger in BigInt µ$, cached cents kept. The audit's 17 write sites now all go through `lib/billing/balance-service.ts`; `splitUsageCost` and the −$10 floor are gone. |
| 2 WS3 rate limits & concurrency + WS4 shared breaker | `187b8c4` | done 2026-09-22. Deviation: `@upstash/ratelimit` replaced by a portable sliding-window Lua script (its Upstash-only shebang flag breaks on plain Redis). Old `lib/gateway/circuit.ts` removed; per-request `Provider.healthStatus` write moved to the hourly cron. |
| 3 WS5 upstream abort & partial metering + WS6 cache-aware pricing | `de70a9d` | done 2026-09-22. Client cancel reaches the upstream in < 1 s (both wires, tested); settlement now starts from the stream's end. Usage fixtures are doc-derived (`"source": "docs"`) until recorded with `npm run usage:record` — **TODO for the operator**. Platform abort probe at `/api/diag/abort` — **TODO: run on a preview and record §15.2/15.3**. |
| 4 WS12 platform hardening | `0ded915` | done 2026-09-22. Body cap 4 MB enforced while streaming, wire-shaped 413; `directUrl`/`DIRECT_URL` + pooling warning; Redis auth cache (token binding only — customer row always fresh, deviation from the brief's payload, see gateway.md) with immediate revocation and 10 s negative cache; catalog cache 60 s + cross-instance version; `PROVIDER_KEY_SECRET` with `enc:v2:` + `npm run keys:reencrypt`; response hygiene headers + generic 502; `isCronAuthorized` guard test. **Operator TODO:** set `DIRECT_URL`, `PROVIDER_KEY_SECRET` (then `keys:reencrypt`), confirm `DATABASE_URL` is the 6543 pooler URL with `pgbouncer=true&connection_limit=1`. |
| 5 WS8 packs + pricing engine, WS9 vouchers | (this commit) | done 2026-09-22. `Pack` bound to one plan, approvals require a pack (suggestion by amount only), price matching removed, "No plan" badge/count/bulk assign; exact-integer pricing engine behind hold, settlement and display. Vouchers per decisions #4/#5/#7: HMAC-only storage, conditional claim (20-way race tested), uniform failures, review queue (auto-approve off by default), clawback via ledger, batch revoke, stock + low-stock bell, expiry cron, `/redeem` + portal field, admin Vouchers/Packs pages, listing-text helper, `docs/vouchers.md`. Also: gateway + voucher settings finally have a UI on Settings; activation approve/reject now require write access. **Operator TODO:** set `VOUCHER_PEPPER`, review packs, decide on auto-approve. |
| 6 WS7 honest units & copy, WS10 retire API Pool | (this commit) | done 2026-09-23. `LEGACY_API_POOL_MODE` (default `readonly`) gates every key hand-out through `swapPoolKey` (store-scoped — fixes §13 #14); activation decoupled from the pool; portal key card/doc substitution removed, retirement banner added; admin keys masked, Unassign all / Purge pool keys; nine guides rewritten for `/v1` (legacy text kept as versions); `usage-synth` deleted, manual deductions are one honest row, portal Activity shows gateway requests at the charged amount; also found and fixed: the old deduct flow wrote the full pool key into customer-visible log labels, and portal docs ignored the store. See [copy-audit.md](copy-audit.md). **Operator TODO:** verify Codex accepts `wire_api = "chat"` (copy-audit §6), then Unassign all → Purge → `off`. |
