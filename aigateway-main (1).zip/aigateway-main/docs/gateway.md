# Gateway — architecture and operations

Living document; each phase adds its section. Audit and decisions: [gateway-audit.md](gateway-audit.md). Tests: [testing.md](testing.md). Operating it: [runbook.md](runbook.md).

## Request pipeline (`lib/gateway/handler.ts`)

```
authenticate (bearer/x-api-key -> GatewayToken -> Customer)
  -> RPM check per token and per customer                      <- Phase 2
  -> validate + shape the upstream body (allowlist, max_tokens clamp)
  -> resolve model (registry, 30 s cache)
  -> CONCURRENCY LEASE (customer cap + store ceiling)          <- Phase 2
  -> RESERVE worst-case hold                                   <- Phase 1
  -> dispatch with failover (breaker per provider+model)       <- Phase 2
  -> respond (stream or JSON)
  -> after(): SETTLE real cost -> ledger + UsageLog, release lease
```

Errors before the response release the hold and the lease. `x-request-id` (`req_…`) is the reservation id, the UsageLog `requestId`, and the ledger `refId`.

## Money model (Phase 1 — WS1 ledger)

Customer credit lives in two pots, **BALANCE** and **BONUS**. Every movement is a row in `LedgerEntry` (append-only, signed micro-USD, `balanceAfterMicroUsd`, `idempotencyKey` unique). The cached columns on `Customer` are derived and kept in step in the same transaction:

```
available(pot) µ$ = (initialXCents − usedXCents) × 10 000 − xCarryMicroUsd
invariant:  sum(LedgerEntry.amountMicroUsd where pot = X) == available(X)
```

- Credits are whole cents (`initialXCents += n`). Debits may be fractional: the sub-cent part accumulates in `balanceCarryMicroUsd` / `bonusCarryMicroUsd` until it reaches a cent (`usedXCents += 1`).
- `gatewayCarryMicroUsd` is deprecated (its value was copied into `balanceCarryMicroUsd` by migration `0001`); it is removed in a later release.
- **Never negative.** A debit larger than the pot charges what is there and returns `uncollectedMicroUsd`; the gateway stores it on `UsageLog.uncollectedMicroUsd`. The old −$10 floor is gone.
- **Only `lib/billing/balance-service.ts` writes money** (plus `lib/billing/reservations.ts` for `reservedMicroUsd`). `test/unit/money-write-sites.test.ts` fails the build otherwise. `pendingBonusCents` (an offer) and `affiliateEarnedCents` (a statistic) are not credit and are not guarded.

### Service API (`lib/billing/balance-service.ts`)

| Function | Ledger type | Notes |
|---|---|---|
| `credit()` | any credit type | whole cents |
| `debit()` | any debit type | never below zero |
| `chargeUsage()` | `USAGE` | Balance first: BALANCE pays all it can, BONUS only the shortfall, remainder uncollected (replaced the 80/20 split). Writes `key:BALANCE` / `key:BONUS`. |
| `adjust()` | `ADMIN_ADJUSTMENT` | signed; **reason mandatory** |
| `clawback()` / `refund()` | `CLAWBACK` / `REFUND` | reason mandatory for clawback |
| `verifyCustomerLedger()` | — | reconciliation check used by tests and the daily cron (Phase 8) |

Every call: `idempotencyKey` (replays return the existing entry), optional `tx` to join an outer transaction, `actor` (admin id + label), optional `ref` (`UsageLog`/`RechargeRequest`/`Order`/…). Concurrency: `lockCustomer()` takes the customer row lock (`FOR UPDATE`, Postgres only) so parallel settlements queue; the optimistic guard on the exact read values is the safety net. The low-balance threshold is read through the transaction's own connection — using the global client inside a transaction deadlocks the pool.

Legacy `BalanceHistory` / `BonusHistory` rows are still written (cents; gateway usage as a daily rollup) because the dashboard charts read them.

### Status (decision #11)

`computeStatus(balance, threshold, current, bonus)`: `SUSPENDED`/`EXPIRED` are manual; balance 0 with bonus left → `LOW_BALANCE`; balance 0 and bonus 0 → `BALANCE_FINISHED` (+ `finishedAt`); balance ≤ threshold → `LOW_BALANCE`; else `ACTIVE`.

### Write sites now on the service

Activation (`ORDER_ACTIVATION` + `AFFILIATE_REWARD` welcome gift), recharge approval (`RECHARGE`), review bonus (`REVIEW_BONUS` / `CLAWBACK`), affiliate milestone (`AFFILIATE_REWARD`), loyalty reward (`LOYALTY_REWARD`), admin create/import (`OPENING_BALANCE`), admin edit of initial amounts (`ADMIN_ADJUSTMENT`, reason field in the form), admin add funds (`ADMIN_ADJUSTMENT`, note required), admin usage entry (`USAGE` via `recordAdminUsage`), usage-log removal (`REFUND`), gateway settlement (`USAGE`).

### Backfill

`npm run ledger:backfill` (`--dry` to report): one `OPENING_BALANCE` per customer per non-empty pot equal to the cached available amount; pots that already have entries are verified and drift is printed (exit code 2). Idempotent. Run once after deploying Phase 1, before flipping any flag.

## Reservations (Phase 1 — WS2)

Flag `GATEWAY_RESERVATIONS=off | shadow | enforce` (default `shadow`).

1. **Estimate** (`lib/billing/estimate.ts`): input tokens = `ceil(utf8 bytes(messages + tools) / 3)`; output = clamped `max_tokens` (else the model cap, else setting `gateway_default_max_tokens`); priced at the customer's rate (plan or store multiplier) + `gateway_hold_margin_pct` (5 %), floor `gateway_min_hold_micro_usd` ($0.01).
2. **Reserve** (`lib/billing/reservations.ts` → `reserve()`): one portable `UPDATE … WHERE available − reserved ≥ hold` plus a `GatewayReservation` row (id = request id, `expiresAt` = now + maxDuration + 120 s). `shadow` writes the row with `amount 0` and logs `shadow would_reject …` when enforce would have refused.
3. **Fit-to-balance**: on refusal, if at least `GATEWAY_MIN_OUTPUT_TOKENS` (256) of output fit, `max_tokens` is lowered and the reservation retried once; otherwise **402** `insufficient_balance` (OpenAI: `insufficient_quota`).
4. **Settle** (`settle()`): `HELD → SETTLED` conditional flip (idempotent), `reserved −= hold`, `chargeUsage(real)`, UsageLog written in the same transaction. Triggered from `after()`; Phase 3 adds the cancel path.
5. **Release** on any error before the response. **Sweeper** `GET /api/cron/reservations` (every 5 min, `CRON_SECRET`) expires holds past `expiresAt` and raises a `RESERVATIONS_SWEPT` notification.

Route config: `/v1/chat/completions` and `/v1/messages` export `runtime = "nodejs"`, `maxDuration = 800` (Vercel Pro), mirrored by `GATEWAY_MAX_DURATION_S` in the handler.

## Schema (Phase 1)

`Customer` + `balanceCarryMicroUsd`, `bonusCarryMicroUsd`, `reservedMicroUsd` (BigInt); `UsageLog` + `requestId` (unique), `reservationId`, `customerMicroUsd`, `uncollectedMicroUsd`; new `LedgerEntry`, `GatewayReservation`. Migration `0001_ledger_reservations` (additive + carry copy). Both schema files updated; SQLite additionally gained the missing `Admin.role` column for parity.

## Shared state — Redis (Phase 2)

`lib/redis.ts` wraps the Upstash REST client (`UPSTASH_REDIS_REST_URL` / `UPSTASH_REDIS_REST_TOKEN`). `REDIS_DISABLED=true` (local only) or missing config → every consumer uses an in-process fallback and logs one loud warning. Locally the integration tests talk to a real Redis through an Upstash-compatible proxy (`docker-compose.test.yml`, `http://localhost:58079`, token `test-token`).

Failure policy per feature (Redis outage = REST error):

| Feature | Behaviour without Redis |
|---|---|
| RPM | fail **open** (serve, warn) |
| Concurrency lease | fail **open** to a per-instance counter |
| Circuit breaker | per-instance in-memory breaker (same semantics) |
| Reservations | unaffected (Postgres) — money is still protected |

## Rate limits and concurrency (Phase 2 — WS3)

Flag `GATEWAY_RATE_LIMITS=true|false`. Limits come from the plan (`Plan.rpm`, `Plan.maxConcurrent`), else the store settings `gateway_default_rpm` (20), `gateway_default_max_concurrent` (4); the store-wide ceiling is `gateway_store_max_concurrent` (200). Decision #3 seeded: Starter 20/4, Plus 30/8, Pro 40/16, Ultimate 50/32 (migration `0002` sets them on existing plans by name where unset).

- **RPM**: weighted sliding window (`rl:{key}:{slot}` + previous slot) in one Lua script, checked for `tok:{tokenId}` and `cus:{customerId}`; both must pass. **Deviation from the brief:** `@upstash/ratelimit` 2.x embeds an Upstash-only Lua shebang flag (`allow-key-locking`) that plain Redis rejects, so it cannot run against the local container and would have failed open unnoticed; a 12-line portable script replaced it.
- **Concurrency**: sorted set `conc:{customerId}` and `conc:store:{storeId}`, member = request id, score = lease expiry. One Lua script prunes expired members, checks both caps and adds the lease atomically. Lease TTL = maxDuration + 60 s so a killed function frees its slot on its own. Released after settlement and on any pre-response error (Phase 3 adds the client-cancel path).
- **429** carries `Retry-After` (window remainder for RPM, `5` for concurrency); OpenAI wire `type: rate_limit_error, code: rate_limit_exceeded`; Anthropic wire `error.type: rate_limit_error`. Claude Code and Codex back off on 429.
- The login / activation / admin-login limiters now go through the same module (`lib/rate-limit.ts`), so brute-force protection is shared across instances.

## Circuit breaker and failover (Phase 2 — WS4)

Flag `GATEWAY_REDIS_BREAKER=true|false`. Unit = **ProviderModel** (provider × upstream model), keys `cb:{pmId}:fails` (INCR + window PEXPIRE), `cb:{pmId}:open` (PX cooldown), `cb:{pmId}:probe` (SET NX: exactly one half-open probe per cooldown). Thresholds per provider: `breakerFailureThreshold` (3), `breakerWindowMs` (60 000), `breakerOpenMs` (60 000). A failure while open (failed probe) restarts the cooldown.

Failover in `dispatchChat` happens **only** on: breaker open, network error, TTFB timeout, HTTP 429, HTTP 5xx — always before the first byte. Any other 4xx goes straight back to the customer as a sanitised 400/404/413 (the upstream wording is logged server-side with the request id, never returned) and does not touch the breaker. When every candidate's breaker is open, all are tried (a probe beats a certain 503). Each attempt is classified (`OK | HTTP_4XX | HTTP_429 | HTTP_5XX | TTFB_TIMEOUT | NETWORK | BREAKER_OPEN`) — Phase 7 persists these as `GatewayAttempt`.

Timeouts: `ProviderModel.ttfbTimeoutMs` → `Provider.ttfbTimeoutMs` → 60 000 for `GatewayModel.isReasoning`, else 20 000. `Provider.totalTimeoutMs` (default 780 000) is carried on the candidate and enforced in Phase 3 together with client-abort propagation.

Breaker trips raise a `PROVIDER_BREAKER_OPEN` notification (once per opening). The hourly cron `/api/cron/provider-health` folds breaker state and the last hour's UsageLog outcomes into `Provider.healthStatus` / `lastError` for the admin Providers page; the per-request health write that used to run on the hot path is gone. Admin "save / test / delete provider" actions close that provider's breakers.

## Upstream abort and partial metering (Phase 3 — WS5)

`lib/gateway/providers/openai-compatible.ts` → `chatCompletions()` returns an `UpstreamHandle`. One `AbortController` is fed by three sources — the client's `request.signal`, the TTFB timer (cleared when headers arrive) and the total timer (`Provider.totalTimeoutMs`, default 780 s) — so any of them tears the upstream fetch and its body down immediately. `finish()` clears timers once the stream is consumed.

Two metering transforms, one per wire:

- `lib/gateway/metering.ts` → `meterChatStream()` (OpenAI wire): `tee()`s the bytes, forwards one branch untouched and parses the other for usage, finish reason, in-band errors and **forwarded bytes** (text, tool-call arguments, reasoning).
- `lib/gateway/anthropic.ts` → `toAnthropicStream()`: same accounting while translating; also maps `reasoning_content` to `thinking` blocks now.

Both resolve `done` with a `StreamOutcome { rawUsage, forwardedBytes, finishReason, outcome, error }`. `done` follows the **upstream**: it resolves when the provider has finished (the usage is known and the provider has billed us) even if the client is still draining buffered bytes. The returned stream's `cancel()` (client hung up) aborts the upstream and resolves `CLIENT_DISCONNECTED`. A socket drop or total timeout mid-stream sends a terminal error (`data: {"error":…}` + `[DONE]` on the OpenAI wire, `event: error` on the Anthropic wire) and closes cleanly — **never failover after the first byte**.

Settlement (`lib/gateway/billing.ts` → `settleRequest()`) starts the moment `done` resolves; `after()` only keeps the function alive until it completes. Usage resolution:

| Situation | `usageSource` | Tokens |
|---|---|---|
| provider sent a usage object (even on a partial stream) | `PROVIDER` | normalised per dialect |
| no usage object | `ESTIMATED` | input = the reservation's estimate, output = `ceil(forwardedBytes / 3.5)` |

`UsageLog.outcome` ∈ `COMPLETED | CLIENT_DISCONNECTED | UPSTREAM_ERROR | TIMEOUT`. Store setting `partial_charge_policy` (decision #2, default `WAIVE_ON_UPSTREAM_ERROR`): `UPSTREAM_ERROR` and `TIMEOUT` are waived (charge 0, ledger untouched, UsageLog kept); client disconnects are charged for what was delivered. `CHARGE_DELIVERED` charges every outcome.

**Empirical platform check (audit §15.2/15.3):** `GET /api/diag/abort` (Bearer `CRON_SECRET`) streams ticks for 60 s and logs which of `request.signal`, `cancel()` and `after()` fire when the client interrupts. Procedure in [claude-code-testing.md](claude-code-testing.md). Locally (Node 22, undici) all three fire; the tests prove the upstream cancellation lands within 1 s.

## Usage normalisation and cache-aware pricing (Phase 3 — WS6)

`lib/gateway/usage/index.ts` → `normalizeUsage(dialect, raw)` → `{ inputUncached, inputCached, cacheWrite, output, reasoning, providerCostMicroUsd }` (BigInt). `Provider.usageDialect` selects the reader:

| Dialect | Fields read |
|---|---|
| `openai` | `prompt_tokens`, `completion_tokens`, `prompt_tokens_details.cached_tokens`, `completion_tokens_details.reasoning_tokens` |
| `deepseek` | `prompt_cache_hit_tokens`, `prompt_cache_miss_tokens` (+ the OpenAI details) |
| `deepinfra` | OpenAI counts + `estimated_cost` (USD); no cache fields |
| `openrouter` | OpenAI details + `prompt_tokens_details.cache_write_tokens`, `cost` / `cost_details.upstream_inference_cost` |
| `anthropic` | `input_tokens`, `cache_read_input_tokens`, `cache_creation_input_tokens`, `output_tokens` |

Field names were verified against the providers' documentation (audit §15) and are pinned by `test/fixtures/usage/*.json`; each fixture says `"source": "docs"` until `npm run usage:record -- <dialect> <baseUrl> <model>` (with `RECORD_API_KEY`) replaces it with a recorded response — **do this for every provider before enabling it in production.**

Pricing (`priceProviderCostMicroUsd`): `inputUncached × input + inputCached × cachedInput + cacheWrite × cacheWrite + (output + reasoning) × output`, µ$ per MTok from `GatewayModel` (`cachedInputPriceMicroPerMTok` defaults to the input price — no discount until set; `cacheWritePriceMicroPerMTok` defaults to free). When the provider reports its own cost (DeepInfra `estimated_cost`, OpenRouter `cost`) that figure is used and compared with ours; a disagreement above 10 % + 100 µ$ logs `provider cost disagreement`. Customer price: multiplier plans pass the cache discount through; TOKENS plans weight cached input by `Plan.cachedTokenWeightPct` (decision #1: 100). The Anthropic translator returns real `cache_read_input_tokens` / `cache_creation_input_tokens`, so Claude Code's cache statistics are honest. `stream_options.include_usage` is sent only to providers with `supportsStreamUsage`. `UsageLog` stores every component plus `rawUsage` (the usage object only, never content).

## Platform hardening (Phase 4 — WS12)

**Body limit** (`lib/gateway/body.ts`). Vercel refuses function request bodies above 4.5 MB before our code runs (audit §15.1), with a platform error page. `GATEWAY_MAX_BODY_BYTES` (default 4 000 000, clamped to ≤ 4 500 000) is checked against `Content-Length` first and then enforced while the body streams in, so a missing or dishonest header cannot bypass it. The 413 is wire-shaped (`invalid_request_error`) and tells the customer what to do (shorten history, drop large tool results, new session). `/v1/messages/count_tokens` uses the same reader.

**Database pooling** (`lib/prisma.ts`, `prisma/schema.prisma`). One `PrismaClient` per instance. `datasource.url` is the runtime (pooled) URL, `datasource.directUrl = env("DIRECT_URL")` is used by `migrate deploy` / `migrate dev` / `db execute`. The build and test scripts default `DIRECT_URL` to `DATABASE_URL` when unset, with a warning in production when that means migrating through the pooler. On Vercel the client warns once at startup when `DATABASE_URL` lacks `pgbouncer` / `connection_limit`. Exact Supabase values: [runbook.md → Database pooling](runbook.md#database-pooling).

**Auth cache** (`lib/gateway/auth-cache.ts`). `gw:auth:{sha256(token)}` → `{tokenId, tokenName, customerId, storeId}` for 60 s; `gw:auth:neg:{hash}` for unknown and revoked tokens, 10 s. On a hit the gateway skips the `GatewayToken` lookup and reads the **customer row by primary key with its plan** (one indexed read that the request needed anyway for balance, plan rate and limits — `getCustomerLimits`, `loadHoldContext` accept the preloaded plan). Consequence: suspension, expiry, deletion, de-activation and balance exhaustion apply on the very next request; only the token → customer binding is cached, and `revokeGatewayToken()` deletes that key so revocation is immediate on every instance (tested). This deviates from the brief's `{…, status, planId}` payload on purpose: those fields have dozens of write sites and caching them would let a suspended customer keep calling for up to 60 s. Without Redis there is no cache. `lastUsedAt` is stamped on cache misses only.

**Catalog cache** (`lib/gateway/registry.ts`). 60 s in memory per instance plus a Redis version counter `gw:catalog:ver`. Every lookup compares its cached version with Redis (one GET); `invalidateModelRegistry()` clears memory **and** `INCR`s the counter, so an admin edit on one instance invalidates every other instance at once (tested). The compiled catalog contains decrypted provider keys and is never stored in Redis.

**Dedicated encryption secret** (`lib/gateway/crypto.ts`). Ciphertexts are versioned: `enc:v1:` = key derived from `SESSION_SECRET` (legacy, decrypt only), `enc:v2:` = `PROVIDER_KEY_SECRET` (32 random bytes, base64). Both decrypt; new writes are v2 whenever the secret is set, otherwise v1 with one loud warning (so a deploy never breaks before the secret exists). Covers `Provider.apiKeyEnc` and `GatewayToken.tokenEnc`. `npm run keys:reencrypt` (`scripts/keys-reencrypt.ts`) migrates every row to v2, idempotently (`--dry` to report). `scripts/gateway-setup-deepinfra.ts` now uses the shared module instead of its own copy of the v1 scheme.

**Migration safety** (`scripts/migrate-deploy.mjs`, Phase 0.5, unchanged in substance). Production → `migrate deploy` over `DIRECT_URL`; a preview needs its own `DATABASE_URL` and the build fails when its host equals `PRODUCTION_DB_HOST`; a `db push`-era database gets `0000_baseline` marked applied. The seed is idempotent (`upsert` with empty `update` for stores, settings, docs; plans only when the store has none). Two seed behaviours are deliberate and worth knowing: the main admin's password/name are **re-applied from `ADMIN_*` on every build** (this is how the owner rotates the admin password), and admin accounts other than the two authorised emails are removed.

**Response hygiene** (`lib/gateway/errors.ts`). Every `/v1` response — success, error, `/v1/models`, `count_tokens` — carries `x-request-id`, `cache-control: no-store, no-transform` (`no-cache, no-transform` + `x-accel-buffering: no` on SSE) and `x-content-type-options: nosniff`. Unknown exceptions become a generic 502 whose real message (which may name an upstream host) goes to the log with the request id, never to the customer; upstream 4xx wording was already sanitised in Phase 2.

**Cron security** (`lib/cron-auth.ts`). `isCronAuthorized(request)` — constant-time compare of `Authorization: Bearer ${CRON_SECRET}`, unset secret always denies — is the only accepted check; `test/unit/cron-auth.test.ts` scans every `app/api/cron/**` and `app/api/diag/**` route for it.

## Packs, plan binding and the pricing engine (Phase 5 — WS8)

**Pricing engine** (`lib/billing/pricing-engine.ts`, client-safe, BigInt only). A `BillingRate` is a rational number: `{kind: "multiplier", num, den}` (CREDITS/USD plans and the store multiplier — `rateFromPlan`, `rateFromMultiplier("2.2") = 22/10`) or `{kind: "perToken", num, den}` µ$ per token (TOKENS plans). `quote(rate, model, usage, {providerCostMicroUsd?, cachedTokenWeightPct?})` returns the customer price of one request: CREDITS = provider cost × multiplier (the provider-reported cost when we have one, else our list price with the cache components), so cache discounts pass through proportionally; TOKENS = weighted tokens × rate with cached input weighted by `Plan.cachedTokenWeightPct` (decision #1: 100). `estimateHold` and `maxOutputTokensAffordable` (reservations, fit-to-balance) and `effectivePrices` (API Access page, catalog — now shows the cached-input price) call the same `quote`, so hold, settlement and display cannot disagree. Rounding is half-up at the micro-dollar; there is no floating point on any money path (`rateToNumber` exists for display only). `lib/plan-usage.ts` keeps the plan vocabulary and delegates; `lib/billing/estimate.ts` is a thin wrapper.

**Packs** (`Pack`: `storeId, name, planId, balanceGrantMicroUsd, bonusGrantMicroUsd, listingPriceLabel, gamsgoOfferRef, active, sortOrder, deletedAt`). A pack is the thing sold on GamsGo and binds exactly one plan. Migration `0004` created one pack per existing plan (grant = plan price). Admin page `/admin/packs`; `lib/services/packs.ts`.

**No more assignment by price.** `findPlanByPrice` / `autoAssignPlanByPrice` are gone. Approving an activation or a recharge (`approveActivationAction(customerId, packId)`, `approveRechargeAction(requestId, packId)`) **requires a pack**; the dialog pre-selects the unique active pack whose balance grant equals the purchased amount (`suggestPack`) and warns on a mismatch, but the admin confirms. The pack sets `Customer.packId` and — unless an admin already chose one on the profile (activations) — `planId`. Both approvals are now behind `requireWriteAdmin`. Customers without a plan keep the global-multiplier fallback: the customers list shows a **No plan** badge and filter, the dashboard a *No plan* count, and the bulk bar an **Assign plan** action (`bulkAssignPlanAction`, activity `PLAN_ASSIGNED`).

## Vouchers (Phase 5 — WS9)

Full admin walkthrough: [vouchers.md](vouchers.md). Model A (decision #7): GamsGo Automatic Delivery hands one pre-generated single-use code per order; the Order-ID flow stays as the manual-delivery fallback.

- **Models.** `VoucherBatch` (`packId, quantity, channel, createdByAdminId, exportedAt, markedUploadedAt, expiresAt, compromisedAt, note`), `Voucher` (`batchId, packId, codeHmac @unique, codeLast4, status ISSUED|REDEEMED|REVOKED|EXPIRED, redeemedByCustomerId, redeemedAt, redeemIpHash, gamsgoOrderId, revokedReason, revokedByAdminId, clawedBackAt`). `Customer.activationSource` (`ORDER_ID|VOUCHER`), `activationVoucherId`, `packId`; `RechargeRequest.source`, `voucherId`, `packId`.
- **Codes** (`lib/vouchers/format.ts` client-safe, `lib/vouchers/code.ts` server). 20 Crockford-base32 chars from `randomBytes` (100 bits) + a check character (Σ value·(i+1) mod 31: every single substitution and adjacent transposition is caught, tested), formatted `ALK-XXXXX-XXXXX-XXXXX-XXXXX-C` (`CHF-` for ChefAPI). `normaliseVoucherCode` uppercases, strips separators and the prefix, maps `O→0`, `I/L→1`, and returns null for anything that cannot be a code, so garbage is never hashed. Stored: `HMAC-SHA256(VOUCHER_PEPPER, normalised)` and the last 4.
- **Service** (`lib/vouchers/service.ts`). `createVoucherBatch` returns the plaintext codes once; `redeemVoucher` = lookup by HMAC → status/expiry checks → risk rules → one transaction: conditional claim (`WHERE status='ISSUED'`), customer creation or top-up, `VOUCHER_REDEMPTION` ledger credits (`voucher:{id}:BALANCE|BONUS`, idempotent), welcome bonus for referred newcomers; then loyalty + affiliate side effects, activity `VOUCHER_REDEEMED` (last 4 only). Every failure returns `REDEEM_FAILURE_MESSAGE`. Review path: voucher `REDEEMED`, customer `isActivated=false` (new) or a `RechargeRequest{source: VOUCHER}` (existing), `VOUCHER_REVIEW` notification; approval calls `creditVoucherGrants` (same idempotency keys), rejection burns the code (`REVOKED`). `clawbackVoucher` → `CLAWBACK` per pot, min(grant, remaining), optional suspension; `revokeVoucher`, `revokeBatch` (+ `compromisedAt`), `packStock`, `notifyLowStock` (once a day per pack), `expireVouchers`, `lookupVouchers`, `listingText`.
- **Risk rules** (`reviewReason`): auto-approve off (setting, default off — decision #5) → `AUTO_APPROVE_OFF`; ≥ N redemptions from the same IP hash in 24 h (setting, 3) → `IP_VELOCITY`; batch compromised; customer suspended.
- **Entry points.** Public `/redeem` (`app/redeem`, store from host/path via `resolvePublicStoreId`, signs the new buyer in) and the portal Recharge page (`redeemVoucherAction`), both through `performRedemption` (`lib/vouchers/redeem.ts`): `VOUCHERS_ENABLED` flag, pepper check, 10 attempts / 10 min per IP **and** per session (`lib/rate-limit.ts`, Redis-shared), failure counter per IP (`lib/vouchers/abuse.ts`) with optional Cloudflare Turnstile step-up after N failures (setting + `TURNSTILE_SECRET_KEY` / `NEXT_PUBLIC_TURNSTILE_SITE_KEY`).
- **Admin** `/admin/vouchers`: stock cards, batches (mark uploaded, edit expiry, revoke unredeemed), generate dialog with one-time CSV (configurable columns, default `username=code, password=redeem URL`) / TXT / copy, lookup with revoke / clawback, listing-text helper. Write actions are `requireWriteAdmin`. Settings live on `/admin/settings` (new *API gateway* and *Vouchers* forms — the gateway settings from Phases 1–3 finally have a UI).
- **Cron** `/api/cron/vouchers` daily: expiry + low stock. **Notifications** `VOUCHER_REVIEW`, `VOUCHER_LOW_STOCK`. **Activity** `PACK_SAVED`, `VOUCHER_BATCH_CREATED|UPLOADED|REVOKED`, `VOUCHER_REVOKED`, `VOUCHER_CLAWBACK`, `VOUCHER_REDEEMED`, `PLAN_ASSIGNED`.
- **Tests** `test/integration/vouchers.test.ts`: plaintext appears nowhere in the DB; 20 parallel → 1 success + 19 identical failures; used/revoked/expired/malformed → same message; review path + approval credit (idempotent); IP velocity; existing-customer top-up with the 15 % review bonus; clawback never negative; batch revoke, stock, expiry, low-stock once a day. `test/unit/voucher-code.test.ts`, `test/unit/pricing-engine.test.ts`.

## Honest copy and the legacy pool (Phase 6 — WS7, WS10)

Full before/after list: [copy-audit.md](copy-audit.md).

- **Legacy pool** (`lib/services/legacy-pool.ts`). `legacyPoolMode()` reads `LEGACY_API_POOL_MODE` (`readonly` default). Every assignment path — `redeemOrder`, recharge approval, `createTicket`/`closeTicket` for `API_ISSUE`, `runAutoFix` — calls `swapPoolKey(tx, { customerId, storeId, orderId })`, which returns null unless `active`, only picks keys of the customer's store, claims with `WHERE status='AVAILABLE'` and retires the previous key as `PROBLEMATIC`. Activation never depends on the pool (`NO_KEYS_AVAILABLE` is gone). `maskKey()` (`sk-…abcd`) and `redactKeys()` (masks key shapes inside free text) are applied server-side outside `active`: `toCustomerRow` (`apiKey` masked, `apiKeyEditable=false`), API Pool page and lookup, Usage Logs, portal Activity. Admin actions `unassignAllPoolKeysAction` (held keys → `RETIRED`, `ApiKey` rows deleted) and `purgePoolKeysAction` (deletes unheld keys) are refused in `active`; activity `API_POOL_UNASSIGNED` / `API_POOL_PURGED`.
- **Docs** (`prisma/docs/*.md`). Placeholders `{{BASE_URL}}` and `{{MODEL}}` are filled by `renderDocForCustomer(content, { baseUrl, model })`; `YOUR_AEROLINK_API_KEY` stays literal. The seed replaces a stored guide only if it still holds a legacy marker, keeping the old text as a version.
- **Usage display.** Portal Activity lists gateway rows only (`requestId` set) at `customerMicroUsd`. Admin "Deduct usage" writes one `Manual charge` row (`MANUAL_CHARGE_MODEL`, status `manual`) and charges face value; `deleteUsageLog` refunds `customerMicroUsd` / face value / multiplier by row kind. `lib/usage-synth.ts` is deleted.
- **Tests.** `test/unit/legacy-pool.test.ts` (mode parsing, masking, redaction), `test/unit/copy-honesty.test.ts` (guides, customer code never reads upstream keys, no legacy URLs, no synthesiser), `test/integration/legacy-pool.test.ts` (activation with empty/other-store pools, ticket swap per store, readonly masking and ignored writes, manual charge + refund), `test/integration/portal-key-exposure.test.ts` (every `/portal/*` route against a running server — set `PORTAL_TEST_BASE_URL`).

## Model prices, aliases, announcements, usage history

**Price sync** (`lib/services/model-prices.ts`). Providers with a public catalog — OpenRouter (`lib/gateway/providers/openrouter.ts`, `GET https://openrouter.ai/api/v1/models`, USD per token as decimal strings, parsed exactly to µ$/MTok) and DeepInfra — feed `lib/gateway/providers/catalog.ts`. Imports arrive priced (input, output, cached input, cache write, context, max output). A model follows the catalog of its **primary mapping** (enabled provider with a catalog, lowest provider priority, then mapping priority). *Models → Sync prices* previews and applies; the daily cron `/api/cron/model-prices` applies and raises `MODEL_PRICES_SYNCED`.

**Real cost.** Dispatch sends `usage: {include: true}` to `openrouter`-dialect providers so every response carries the `cost` OpenRouter billed. Settlement (`settleRequest`) prices the customer from that cost × their plan rate (`quote()`); list prices only drive the hold, displayed prices and the no-cost fallback. `UsageLog.costMicroUsd` is the real cost, `customerMicroUsd` what the customer paid.

**Aliases.** `GatewayModel.slug` / `displayName` are the only model names a customer sees. Non-streaming responses go through `presentAsAlias()`; streams through `aliasSseStream()` (client branch of `meterChatStream`), which rewrites `model` and drops `provider` on every `data:` line, buffering partial lines across chunks. The Anthropic wire already synthesises its own events with the slug. `UsageLog.model` stores the slug; the portal maps it to the display name (`lib/services/customer-usage.ts`).

**Announcements** (`Announcement`, `AnnouncementRead`; migration `0005`). Kinds `INFO | PROMO | NEW_MODEL`, optional window (`startsAt`/`endsAt`), optional single-customer target, `archivedAt` = ended early. Admin: `/admin/announcements`. Portal: `/portal/notifications` (inbox, marks read on view), unread badge in the nav, dismissible dashboard banner.

**Recharge promotion.** `PROMO` with `rechargeBonusPct`. The best live promo is snapshotted on the `RechargeRequest` (`promoAnnouncementId`, `promoBonusPct`) when the customer submits it — also for voucher redemptions routed to review — and `approveRechargeAction` credits `floor(balanceCents × pct / 100)` to the **BONUS** pot as ledger type `PROMO_BONUS` (idempotency key `promo:RechargeRequest:{id}`). Voucher top-ups credited on the spot get it immediately (`promo:Voucher:{id}`). Ending or deleting a promo never changes what already-submitted recharges are owed.

**Usage history.** `/portal/activity` adds per-model totals for the last 30 days (requests, tokens, amount charged); the dashboard shows the last 5 requests under *Recent usage*. Both show display name + slug only.

## Plan billing example, default plan, public alias

**How a USD plan bills.** rate = plan price ÷ real usage included. A $100 plan worth $2 of real usage bills ×50: a request whose real (OpenRouter-reported) cost is $0.50 is charged **$25**, and the customer sees $25 everywhere (Activity, Recent usage, ledger) — never the real cost. `test/unit/plan-billing-alias.test.ts` pins the example.

**Balance first.** `splitUsageMicroUsd` charges the BALANCE pot for everything it can cover; BONUS only pays the shortfall once the balance is empty (replaced the 80/20 split). $100 balance + $15 bonus, $25 request → balance $75, bonus $15.

**Default plan.** Setting `default_plan_id` (Plans page → "Default plan for customers without one"). `getCustomerBillingRate` resolves: own active plan → store default plan (`source: "default"`) → `usage_cost_multiplier` (`source: "global"`). `getCustomerLimits` falls back to the default plan's RPM/concurrency too. A deactivated, deleted or misconfigured default plan is ignored.

**Public alias** (`GatewayModel.aliasSlug` unique, `aliasName`; migration `0006`). `lib/model-alias.ts`: `publicModelId` = alias id or slug, `publicModelName` = alias name, else alias id, else display name. `ResolvedModel.publicSlug/publicName` are used for `/v1/models`, every response body and stream (`presentAsAlias`, `aliasSseStream`, the Anthropic translator), customer-facing errors, API Access, docs `{{MODEL}}`, usage history and new-model notices. `resolveModel` accepts the alias first, then the internal slug (existing tool configs keep working; the slug is never listed). Slugs and aliases share one namespace (enforced on save). `aliasWarnings()` flags a missing alias or one that contains the upstream vendor/model name; shown on the Models page and in the edit dialog. `UsageLog.model` and reservations keep the internal slug.

**Balance = plan price.** Approving an order-ID activation sets the BALANCE pot to the chosen pack's **plan price**: the ORDER_ACTIVATION credits (from the offer title, or the signup default) are corrected by one `ADMIN_ADJUSTMENT` ("Balance set to the X plan price", key `activation:{customerId}:plan-balance`). Approving an order-ID recharge credits the plan price instead of the parsed title amount; the promotion bonus, review bonus and loyalty points follow that amount. Voucher activations and top-ups keep crediting the pack's balance grant. The approval dialog shows the amount and warns when the order said something else.

**Model prices shown to customers** are the prices saved on the Models page, as-is (API Access; `cachedInput` falls back to input). They are no longer multiplied by the customer's plan; billing is unchanged (real cost × plan rate).

## Hot-path caches and data retention

**Caches** (`lib/ttl-cache.ts`, per instance, concurrent misses share one load, failed loads are not cached). Store settings (`getSettings`, `SETTINGS_CACHE_TTL_MS`, 10 s) and the default plan (`getDefaultPlan`, `PLANS_CACHE_TTL_MS`, 10 s). `setSetting()` and every plan action clear the cache on the instance that made the change; other instances follow within the TTL. Customer rows and balances are never cached. Off under Vitest unless the env var is set.

**Retention** (`lib/services/retention.ts`, daily cron `/api/cron/retention` 05:00 UTC, `?dry=1` to preview). Finished `GatewayReservation` rows (SETTLED / RELEASED / EXPIRED) older than `RETENTION_RESERVATION_DAYS` (30) are deleted; `UsageLog.rawUsage` is emptied after `RETENTION_RAW_USAGE_DAYS` (90), every other column kept. HELD reservations and `LedgerEntry` are never touched. Batches of 2 000 rows, at most 100 000 per table per run.

## Plan profit

`Plan.profitCents` (Plans page → "Profit per purchase") is a fixed profit recorded on **every purchase** of the plan: approved order-ID activation (`Activation:{customerId}`), approved recharge (`RechargeRequest:{id}`), and any voucher credited at once or approved from the review queue (`Voucher:{id}`: a voucher purchase can never be counted twice). `lib/services/profit.ts` writes one `ProfitHistory` row (`source = PLAN`, `planId`, unique `idempotencyKey = plan-profit:{type}:{id}`) and increments `Customer.profitCents` in the purchase's transaction. The amount is a snapshot, so editing a plan never rewrites history. A voucher clawback writes the exact negative (`plan-profit-reversal:Voucher:{id}`). Manual profit edits on a customer remain as `source = MANUAL` adjustments. Dashboard and Analytics already sum `ProfitHistory`, so they include plan profit. The Plans page shows profit per purchase, the net profit recorded and the purchase count per plan. Migration `0007_plan_profit`.
