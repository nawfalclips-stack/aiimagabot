# Runbook

What each flag, cron and alert means, and what to do. Grows with each phase.

## Deploying a phase

1. Deploy (Vercel runs `scripts/migrate-deploy.mjs` → `migrate deploy`, then the idempotent seed).
2. Run one-off scripts in order, once: `npm run ledger:backfill` (Phase 1), `npm run keys:reencrypt` (Phase 4, after setting `PROVIDER_KEY_SECRET`).
3. Flip flags one at a time (below), watching logs for 24–48 h between steps.

Environment variables to set on Vercel for Phase 1: `PRODUCTION_DB_HOST` (all envs), `GATEWAY_RESERVATIONS=shadow`, `GATEWAY_MIN_OUTPUT_TOKENS=256`, and a Preview `DATABASE_URL` pointing at a non-production database. Phase 2: `UPSTASH_REDIS_REST_URL` / `UPSTASH_REDIS_REST_TOKEN`. Phase 4: `DIRECT_URL`, `PROVIDER_KEY_SECRET`, optionally `GATEWAY_MAX_BODY_BYTES`. Phase 5: `VOUCHER_PEPPER` (before generating any code), optionally `VOUCHERS_ENABLED`, `NEXT_PUBLIC_TURNSTILE_SITE_KEY` + `TURNSTILE_SECRET_KEY`. Plan: **Pro** (the `/v1` routes declare `maxDuration = 800`; the crons run every 5 minutes).

## Flags

| Flag | Values | Effect | Rollout |
|---|---|---|---|
| `GATEWAY_RESERVATIONS` | `off` · `shadow` (default) · `enforce` | `off`: bill after the response, no hold (pre-Phase-1 behaviour, but through the ledger). `shadow`: write reservation rows with a zero hold and log `shadow would_reject …` when enforce would have refused. `enforce`: atomic holds, 402 when the balance cannot cover the worst case, fit-to-balance first. | `shadow` for 24–48 h → grep logs for `would_reject` → `enforce` |
| `GATEWAY_MIN_OUTPUT_TOKENS` | integer, default 256 | Smallest completion fit-to-balance will shrink to before returning 402. | — |
| `GATEWAY_RATE_LIMITS` | `true` (default) · `false` | Per-plan RPM and concurrency caps (WS3). Off = no 429s from us at all. | Start with the seeded limits; raise per plan from the admin Plans page as traffic shows. |
| `GATEWAY_REDIS_BREAKER` | `true` (default) · `false` | Share circuit-breaker state through Redis (WS4). `false` = per instance. | On once `UPSTASH_REDIS_*` are set and the two-process test passes (it does in CI). |
| `REDIS_DISABLED` | `false` (default) · `true` | Local only: skip Redis entirely, in-process fallbacks. Never in production. | — |
| `GATEWAY_MAX_BODY_BYTES` | bytes, default 4 000 000 (max 4 500 000) | Request body cap; larger bodies get a wire-shaped 413 with advice instead of Vercel's platform error. | Leave the default unless customers hit it with legitimate prompts. |
| `VOUCHERS_ENABLED` | `true` (default) · `false` | `false` hides `/redeem` and the portal code field and refuses redemptions; admin pages keep working. | Kill switch for the voucher channel. |
| `LEGACY_API_POOL_MODE` | `active` · `readonly` (default) · `off` | WS10. `readonly`: no upstream key is ever assigned (activation, recharge, API tickets); customers never see one and get a "create your token" banner; admin pages show keys masked; *Unassign all* / *Purge pool keys* available on API Pool. `off`: as readonly, API Pool hidden from the navigation. `active`: the old key hand-out, for rollback only. | `readonly` now → *Unassign all* once customers have moved to tokens (banner) → *Purge pool keys* → `off`. |

Store settings (admin → Settings → *API gateway* / *Vouchers* forms, stored per store): `voucher_auto_approve` (false — decision #5), `voucher_max_redemptions_per_ip_day` (3), `voucher_expiry_months` (12 — decision #4), `voucher_low_stock_count` (10) / `voucher_low_stock_days` (7) (decision #7), `voucher_turnstile_after_failures` (0 = off); `partial_charge_policy` (`WAIVE_ON_UPSTREAM_ERROR` — decision #2 — or `CHARGE_DELIVERED`), `gateway_hold_margin_pct` (5), `gateway_min_hold_micro_usd` (10000 = $0.01), `gateway_default_max_tokens` (4096), `gateway_default_rpm` (20), `gateway_default_max_concurrent` (4), `gateway_store_max_concurrent` (200). Provider timeouts and breaker thresholds are per provider (`ttfbTimeoutMs`, `totalTimeoutMs`, `breakerFailureThreshold`, `breakerWindowMs`, `breakerOpenMs`, all optional); `GatewayModel.isReasoning` raises the default TTFB timeout to 60 s.

## Crons (`vercel.json`, all require `Authorization: Bearer $CRON_SECRET`)

| Schedule | Route | What it does | If it stops |
|---|---|---|---|
| every 5 min | `/api/cron/reservations` | Releases `GatewayReservation` rows still `HELD` past `expiresAt` (function died mid-request). | Holds from crashed functions lock customer money for good → customers see 402s they should not. Run it by hand: `curl -H "Authorization: Bearer $CRON_SECRET" https://<host>/api/cron/reservations`. |
| every 5 min | `/api/cron/fix-tickets` | Existing support auto-fix. | Tickets wait for a human. |
| hourly | `/api/cron/provider-health` | Writes breaker state + last-hour success rate into `Provider.healthStatus` / `lastError` (admin Providers page). | The page shows stale health; failover itself is unaffected. |
| daily 03:15 UTC | `/api/cron/vouchers` | `ISSUED` codes past their batch expiry → `EXPIRED`; low-stock notification per pack (once a day). | Expired codes stay redeemable until the next run; you miss the low-stock warning. Run by hand: `curl -H "Authorization: Bearer $CRON_SECRET" https://<host>/api/cron/vouchers`. |

## Alerts (admin notification bell)

| Type | Meaning | Action |
|---|---|---|
| `RESERVATIONS_SWEPT` | The sweeper expired N holds. A gateway function was killed before settlement (crash, deploy, hard kill). Since Phase 3, client disconnects and upstream failures settle themselves, so this should be rare. | Check Vercel function logs around the time for `req_…` ids in the sweeper log line. Frequent alerts → run the abort probe (docs/claude-code-testing.md) to confirm `after()` survives disconnects on the platform. |
| `VOUCHER_REVIEW` | A voucher redemption was held for review (auto-approve off, IP velocity, compromised batch or suspended customer). The code is consumed; the credit waits. | Open *Activations* (new buyer) or *Recharges* (existing customer): the card says "Voucher · <pack>". Approve → grants credited; Reject → code burned. Check the GamsGo order if in doubt (lookup by order id on the Vouchers page). |
| `VOUCHER_LOW_STOCK` | A pack has fewer uploaded, unredeemed codes than the threshold, or fewer days of stock at the last-7-day rate. | Generate a batch, upload it to the GamsGo offer, mark it uploaded (docs/vouchers.md). |
| `PROVIDER_BREAKER_OPEN` | A provider+model failed `breakerFailureThreshold` times within the window (429/5xx/network/TTFB). Requests fail over for `breakerOpenMs`. | Nothing to do if a second provider serves the model. Repeated openings → check the provider's status page, rate limits on our key, or raise its `ttfbTimeoutMs` for reasoning models. "Test connection" on the Providers page resets it. |

## Logs to know

- `[gateway] shadow would_reject request=… customer=… hold=… spendable=…` — enforce would have returned 402. Expect a handful at flip time for customers near zero; many for healthy balances means the estimate is too pessimistic (lower `gateway_hold_margin_pct` or check model prices).
- `[gateway] settlement failed <req_id>` — the charge could not be written; the reservation stays `HELD` and the sweeper will release it in ≤ 5 min. Investigate the error (usually DB).
- `[cron/reservations] expired=…` — ids the sweeper released.
- `[redis] … PER INSTANCE (in-process fallback)` — Redis is not configured; in production this is a misconfiguration (limits and breakers are per instance).
- `[limits] rate limit check failed, failing open` / `lease acquire failed, falling back` — Redis errored on the hot path; the request was served. Check Upstash status and quotas.
- `[breaker] OPEN <provider>/<model> for N ms: <reason>` — the trip, with the sanitised upstream reason.
- `[gateway] upstream <provider> rejected request: <status> <reason>` — a 4xx the customer got as a generic 400; the real wording is here.
- `[gateway] provider cost disagreement request=… reported=… computed=…` — the provider's own cost differs from our price list by more than 10 %; update the model's prices on the Models page.
- `[diag/abort] …` — output of the platform abort probe (see docs/claude-code-testing.md).
- `[crypto] PROVIDER_KEY_SECRET is not set` — new provider keys are being written with the legacy v1 scheme; set the secret and run `npm run keys:reencrypt`.
- `[prisma] DATABASE_URL has no connection_limit / pgbouncer parameter` — the runtime URL is not the pooler (see Database pooling).
- `[auth-cache] could not invalidate a revoked token` — Redis was unreachable at revocation; the token may keep working for up to 60 s. Retry the revocation from the portal once Redis is back.
- `[registry] could not bump the catalog version` — same cause; other instances pick the catalog change up within 60 s.
- `[gateway] <req_id> 502 <error>` — an unexpected exception; the customer saw a generic 502 with that request id.
- `[vouchers] VOUCHER_PEPPER is not configured; redemption refused` — set the secret and redeploy; the admin Vouchers page shows the same warning.
- `[cron/vouchers] expired=N lowStock={…}` — daily voucher run.

## Database pooling

Production is Supabase Postgres. Prisma opens real connections, and Vercel runs many instances, so the runtime must go through Supabase's **Supavisor transaction pooler** while migrations use the direct connection:

| Variable | Value | Used by |
|---|---|---|
| `DATABASE_URL` | `postgresql://postgres.<ref>:<pw>@aws-0-<region>.pooler.supabase.com:6543/postgres?pgbouncer=true&connection_limit=1` | the app (Prisma Client) |
| `DIRECT_URL` | `postgresql://postgres.<ref>:<pw>@aws-0-<region>.pooler.supabase.com:5432/postgres` | `migrate deploy`, `migrate dev`, `db execute` (build scripts) |

Both strings are on the Supabase dashboard → Connect → ORMs → Prisma. `pgbouncer=true` turns off prepared statements (required in transaction mode); `connection_limit` is **per Vercel instance** — start at 1 (Supabase's recommendation); if the logs show `Timed out fetching a new connection from the connection pool` under load, raise it to 3, not more. Without `DIRECT_URL` the build migrates through the pooler and logs a warning; it usually works but can fail on advisory locks, so set it. Local development (SQLite) needs neither. Never put the port-5432 URL in `DATABASE_URL`: each instance would hold direct connections and the database's connection cap would be reached within minutes of traffic.

## Secrets

| Secret | Purpose | Rotation |
|---|---|---|
| `SESSION_SECRET` | signs admin/customer session cookies; also derives the legacy v1 key for stored provider keys | Rotate after any leak. Once every stored secret is v2 (below), rotating it only logs everyone out. While v1 rows exist, rotating it **destroys** those provider keys — run `keys:reencrypt` first. |
| `PROVIDER_KEY_SECRET` | AES-256-GCM key for provider API keys and revealable gateway tokens (`enc:v2:`) | Generate: `openssl rand -base64 32`. To rotate: set the new value, keep the old one reachable only long enough to run a re-encrypt (the script currently migrates v1 → v2 and plaintext → v2; a v2 → v2 re-key would be a small extension of `scripts/keys-reencrypt.ts`). |
| `CRON_SECRET` | bearer for `/api/cron/*` and `/api/diag/*` | Rotate any time; Vercel Cron picks the new value up on the next invocation. |
| `VOUCHER_PEPPER` | HMAC key for voucher codes and redeem-IP hashes | **Do not rotate** while unredeemed codes are on GamsGo — every one of them would stop working. If it leaks together with the database, revoke all batches (Vouchers page → *Revoke unredeemed* per batch), rotate, regenerate. |

Migrating to the dedicated key (once, Phase 4): set `PROVIDER_KEY_SECRET` in Production → redeploy → `npm run keys:reencrypt` (locally with the production `DATABASE_URL`/`DIRECT_URL`, `SESSION_SECRET` and `PROVIDER_KEY_SECRET` in `.env.local`; `--dry` first) → confirm `SELECT count(*) FROM "Provider" WHERE "apiKeyEnc" NOT LIKE 'enc:v2:%' AND "apiKeyEnc" <> ''` is 0 (same for `GatewayToken`.`tokenEnc`). Dropping v1 support afterwards = deleting the `v1` branches in `lib/gateway/crypto.ts` (`deriveV1Key`, the `V1_PREFIX` cases) and their test.

## Money invariants (check any time)

```sql
-- per customer and pot: ledger sum must equal cached available amount
SELECT c."accessCode", l.pot, SUM(l."amountMicroUsd") AS ledger,
       CASE l.pot WHEN 'BALANCE' THEN (c."initialBalanceCents"-c."usedBalanceCents")*10000 - c."balanceCarryMicroUsd"
                  ELSE (c."initialBonusCents"-c."usedBonusCents")*10000 - c."bonusCarryMicroUsd" END AS cached
FROM "LedgerEntry" l JOIN "Customer" c ON c.id = l."customerId"
GROUP BY c.id, l.pot, c."accessCode"
HAVING SUM(l."amountMicroUsd") <> CASE l.pot WHEN 'BALANCE' THEN (c."initialBalanceCents"-c."usedBalanceCents")*10000 - c."balanceCarryMicroUsd"
                                             ELSE (c."initialBonusCents"-c."usedBonusCents")*10000 - c."bonusCarryMicroUsd" END;

-- reserved must be the sum of HELD reservations
SELECT c."accessCode", c."reservedMicroUsd", COALESCE(SUM(r."amountMicroUsd"),0) AS held
FROM "Customer" c LEFT JOIN "GatewayReservation" r ON r."customerId" = c.id AND r.status = 'HELD'
GROUP BY c.id HAVING c."reservedMicroUsd" <> COALESCE(SUM(r."amountMicroUsd"),0);
```

Both queries must return zero rows. `npm run ledger:backfill -- --dry` prints the same drift check per customer. Phase 8 automates it daily.
