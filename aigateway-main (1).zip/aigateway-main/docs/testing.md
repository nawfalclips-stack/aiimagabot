# Testing

Test runner: **Vitest** (`vitest.config.ts`), two projects.

| Project | Command | Needs | What lives there |
|---|---|---|---|
| `unit` | `npm run test:unit` | nothing | pure logic (`test/unit/**`, `lib/**/*.test.ts`), the mock-upstream contract, the money-write guard, the cron-auth guard, crypto versions, the body limit, the pricing engine, voucher code format |
| `integration` | `npm run test:integration` | Postgres (+ Redis) from `docker-compose.test.yml` | anything that touches the database: ledger, reservations, concurrency, metering, auth/catalog caches, vouchers (20-way redemption race, review path, clawback) |

`npm test` runs both; `npm run check` = typecheck + lint + unit tests + `next build` (the per-phase gate).

## Integration tests

```bash
docker compose -f docker-compose.test.yml up -d
export TEST_DATABASE_URL=postgresql://aerolink:aerolink@localhost:55432/aerolink_test   # PowerShell: $env:TEST_DATABASE_URL="…"
npm run test:integration
docker compose -f docker-compose.test.yml down -v
```

- The global setup (`test/helpers/global-setup.ts`) runs `prisma migrate reset` against `TEST_DATABASE_URL`, so the suite always starts from the committed migrations. It refuses any host other than `localhost` / `127.0.0.1` / `postgres`.
- Without `TEST_DATABASE_URL` the integration project is **skipped**, not failed (`describeIntegration` in `test/helpers/db.ts`).
- Integration files run one at a time (`fileParallelism: false`) because they share one database; call `truncateAll()` in `beforeAll`.
- Redis is exposed through an Upstash-compatible REST proxy on `http://localhost:58079` (token `test-token`), so app code uses the same `@upstash/redis` client as in production.

## Mock upstream provider

`test/mock-upstream/server.ts` is a scriptable LLM provider that speaks OpenAI Chat Completions and Anthropic Messages (streaming and not), on `{base}/chat/completions`, `{base}/messages`, `{base}/models` with `{base}` = `` or `/v1`.

In tests:

```ts
const mock = await startMockUpstream();
mock.setScenario({ ttfbDelayMs: 2000, failAfterChunks: 3, usageDialect: "deepseek" });
…
const rec = await mock.waitForCancel();   // proves the gateway aborted upstream
await mock.close();
```

For local development against `next dev`:

```bash
npm run mock:upstream -- 4010     # and 4011 in a second terminal
npm run gateway:dev-seed
curl -X POST localhost:4010/__control -d '{"failBeforeFirstByte":{"status":429}}'
curl localhost:4010/__requests
```

Scenario knobs: `ttfbDelayMs`, `chunkDelayMs`, `failBeforeFirstByte`, `failAfterChunks` + `failAfterMode` (`error_chunk` | `socket_close`), `omitUsage`, `usageDialect` (`openai` | `deepseek` | `deepinfra` | `openrouter` | `anthropic`), `text`, `chunkCount`, `toolCall`, `reasoning`, `usage {prompt, completion, cached, cacheWrite, reasoning, cost}`. Every request is recorded with `cancelled` / `chunksSent` / timings.

## The money-write guard

`test/unit/money-write-sites.test.ts` scans `lib/`, `app/`, `components/`, `prisma/seed.ts` and `scripts/` for Prisma `create`/`update`/`upsert` calls whose `data` block writes a money field (`initialBalanceCents`, `usedBalanceCents`, `initialBonusCents`, `usedBonusCents`, `gatewayCarryMicroUsd`, `balanceCarryMicroUsd`, `bonusCarryMicroUsd`, `reservedMicroUsd`). Only `lib/billing/balance-service.ts` and `lib/billing/reservations.ts` may write them; any other file fails the build, and so does a stale allowlist entry.

## Migrations

Postgres schema changes are Prisma migrations under `prisma/migrations/` (baseline `0000_baseline` = the schema as of Phase 0.5). SQLite local dev keeps `npm run db:push` from `prisma/schema.sqlite.prisma`; every schema change is made in **both** schema files.

- Create a migration (needs a local Postgres, e.g. the test container): `DATABASE_URL=… DIRECT_URL=… npm run db:migrate:dev -- --name add_ledger` (the schema declares `directUrl`; the CLI needs both variables, the build scripts default `DIRECT_URL` for you).
- Apply on Vercel: `scripts/migrate-deploy.mjs` runs inside `vercel-build`. Production runs `migrate deploy`; a preview needs its own `DATABASE_URL` and is refused when its host equals `PRODUCTION_DB_HOST`. A database created by the old `db push` flow (tables present, no `_prisma_migrations`) gets the baseline marked as applied automatically on first run.
- The two loose SQL files formerly in `prisma/migrations/` now live in `prisma/legacy-sql/` for reference; they are not applied by anything.

## Usage fixtures (WS6)

`test/fixtures/usage/<dialect>.json` pins each provider's usage field names. They start as `"source": "docs"` (built from the providers' documentation). Replace them with recorded responses — two ~20-token requests — before enabling a provider:

```bash
RECORD_API_KEY=… npm run usage:record -- deepinfra https://api.deepinfra.com/v1/openai deepseek-ai/DeepSeek-V3
RECORD_API_KEY=… npm run usage:record -- deepseek  https://api.deepseek.com/v1 deepseek-chat
RECORD_API_KEY=… npm run usage:record -- openrouter https://openrouter.ai/api/v1 deepseek/deepseek-chat
RECORD_API_KEY=… npm run usage:record -- anthropic https://api.deepseek.com/anthropic deepseek-chat --anthropic
```

The key is never written to disk; only the usage objects are. `test/unit/usage-normalisers.test.ts` then asserts the normaliser's output against the fixture's `expect` block.
