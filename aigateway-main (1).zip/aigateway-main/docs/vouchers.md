# Vouchers — selling through GamsGo Automatic Delivery

How a buyer goes from "Buy" on GamsGo to a working API key with no admin step, and what the admin does before and after. (Phase 5 — WS8 packs, WS9 vouchers; decisions #4, #5, #7.)

## The idea in one paragraph

GamsGo has no seller API and no order webhook. What it does have is **Automatic Delivery**: you pre-load an offer with inventory entries (one username/password pair per item) and GamsGo hands one entry to each buyer the moment they pay. We use that as the webhook: we generate single-use **voucher codes** for a pack, you paste them into the offer's inventory, GamsGo delivers one per order, and the buyer redeems it at `https://<your-site>/redeem`. The code carries 100 bits of entropy plus a check character, is stored only as an HMAC, works exactly once, and can be revoked or clawed back if GamsGo refunds the order. The old **Order-ID activation** (manual-delivery offers) keeps working unchanged next to it.

## One-time setup

1. **Server secret.** Set `VOUCHER_PEPPER` (32 random bytes, base64: `openssl rand -base64 32`) in Vercel → Production, redeploy. Codes cannot be generated or redeemed without it. **Never rotate it** while unredeemed codes exist on GamsGo — they would all stop working; revoke the batches first if you must.
2. **Packs** (`/admin/packs`). One pack per GamsGo offer: name, the **plan** it puts the buyer on, the balance (and optional bonus) it grants, the listing price label. The migration created one pack per existing plan; check the grants.
3. **Settings** (`/admin/settings` → *Vouchers*):
   - **Auto-approve redemptions** — off by default (decision #5). Off = every redemption goes to *Activations* (new buyers) or *Recharges* (existing customers) for your approval; the code is consumed either way. Turn it on once you trust the flow: buyers are then credited instantly.
   - **Redemptions per IP per day** (3) — above this a redemption is reviewed even with auto-approve on.
   - **Default code expiry** (12 months) — pre-filled per batch, editable per batch (decision #4).
   - **Low stock** thresholds (10 codes / 7 days, decision #7) — drive the bell notification.
   - **Captcha after N failures** (0 = off) — needs `NEXT_PUBLIC_TURNSTILE_SITE_KEY` + `TURNSTILE_SECRET_KEY`.
4. Optional: `VOUCHERS_ENABLED=false` hides `/redeem` and the portal code field without touching the admin pages.

## The workflow, step by step

### 1. Generate a batch
`/admin/vouchers` → **Generate codes** → pack, quantity (≤ 1000), expiry, note → **Generate**.

The next screen is the **only time the plaintext codes exist**. Download:
- **CSV** in GamsGo's inventory shape — two columns, by default `username = code`, `password = redeem URL`; both columns and the header row are configurable in the dialog;
- **TXT** — one code per line;
- or **Copy all**.

Closing the dialog without downloading asks for confirmation. Afterwards the database holds only the HMAC and the last 4 characters; nobody — including you — can list the codes again. The activity log records who generated what (never the codes).

### 2. Upload to GamsGo
In the GamsGo seller dashboard open the offer → delivery method **Automatic Delivery** → import the CSV (or paste the lines) into the inventory. GamsGo sends one entry per paid order.

### 3. Mark the batch as uploaded
Back on `/admin/vouchers`, **Mark uploaded** on the batch. From now on those codes count as *stock on GamsGo*; codes in batches not marked show as "generated, not uploaded" and never trigger low-stock alerts.

### 4. Write the listing
Use **GamsGo listing text** on the same page: pick the pack → title + description built from real pack data (credit, plan, models served, how to redeem, expiry, "usage right on our gateway, not a provider account"). Copy both into the offer. The generator follows GamsGo's title rules — no "official", "lifetime", "never banned", no keyword stuffing — do not add them by hand.

### 5. Watch stock
The stock cards show, per pack: uploaded-and-unredeemed, generated-not-uploaded, redemptions in the last 7 days, and days of stock left at that rate. A pack turns **Low stock** (and the bell rings once a day, `VOUCHER_LOW_STOCK`) below the thresholds in Settings. Generate the next batch before it runs out — GamsGo will pause the offer when its inventory is empty.

### 6. What the buyer sees
GamsGo shows the code right after checkout. The buyer opens **`/redeem`** (also linked from the landing page as *Redeem a voucher*; existing customers have the same field on *Portal → Recharge*):
- the form validates the check character locally (typos are caught before a request; `O/0` and `I/L/1` are interchangeable);
- **new buyer** → account + access code (shown once) + plan from the pack + credit → signed in → *Create your API key*. Same side effects as an approved Order-ID activation: affiliate attribution, loyalty points, review-bonus banner (10 % of the balance grant, review-gated as before);
- **signed-in customer** → credit added to their account, moved onto the pack's plan, returning-customer review bonus (15 %) offered, exactly like an approved recharge;
- optional **GamsGo order ID** field, stored on the voucher for support lookups.

With auto-approve **off**, or when a risk rule fires (IP velocity, compromised batch, suspended customer), the buyer sees "your credit is being verified" instead: the voucher is consumed, the account exists but is not activated (or a *Recharge request* is created), you get a `VOUCHER_REVIEW` notification, and **Approve** in *Activations* / *Recharges* credits the pack's grants. The pack is locked on those cards ("Voucher · Starter $100"). **Reject** burns the code.

### 7. Refunds, disputes, leaks
`/admin/vouchers` → **Look up a voucher** by full code, last 4, GamsGo order ID or the customer's access code.
- **Unredeemed, refunded** → *Revoke* (reason required). The code stops working.
- **Redeemed, refunded** → *Claw back* (reason required, optional *suspend the customer*). Takes back `min(grant, remaining)` from balance and bonus through the ledger (`CLAWBACK` entries); the balance never goes negative; the voucher is marked clawed back and cannot be clawed back twice.
- **Batch leaked** → *Revoke unredeemed* on the batch. Every `ISSUED` code in it is revoked in one statement and the batch is flagged compromised.

### 8. Expiry
Daily cron `/api/cron/vouchers` (03:15 UTC) marks `ISSUED` codes past their batch expiry as `EXPIRED` and runs the low-stock check. Change a batch's expiry with *edit* on the batch row.

## Security properties (what the code guarantees)

| Threat | Handling |
|---|---|
| Codes live on a third-party platform | 100-bit random codes, single-use, useless once redeemed; never gateway tokens or access codes |
| Database leak | Only `HMAC-SHA256(VOUCHER_PEPPER, code)` + last 4 stored; the pepper lives in the environment |
| Double redemption | `UPDATE … WHERE status = 'ISSUED'` claim; 20 parallel attempts → exactly 1 success (tested) |
| Guessing / brute force | Uniform failure text for invalid, used, revoked, expired and malformed codes; 10 attempts per 10 min per IP and per session; optional Turnstile after N failures; malformed codes are rejected by the check character before any database work |
| Fraud patterns | Auto-approve off by default; > N redemptions per IP per day, compromised batch or suspended customer → review queue |
| Wrong plan | The pack binds the plan; nothing is guessed from a price (WS8) |

## Manual-delivery offers still work

Buyers of offers without automatic delivery keep using the landing page's **Order ID + offer title** activation and the portal's recharge request. Those approvals now also ask you to pick the pack (pre-selected when one pack's grant matches the amount).

## Operator checklist

- [ ] `VOUCHER_PEPPER` set in Production, redeployed
- [ ] Packs reviewed (`/admin/packs`)
- [ ] Voucher settings reviewed; decide when to turn auto-approve on
- [ ] First batch generated, downloaded, uploaded, marked uploaded
- [ ] Listing text pasted into the GamsGo offer; offer switched to Automatic Delivery
- [ ] Test purchase → `/redeem` → API key works
- [ ] Optional: Turnstile keys + "captcha after N failures"
