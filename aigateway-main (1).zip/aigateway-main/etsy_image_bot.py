"""
Etsy Image Creation Bot for Croché Products
===========================================
Creates beautiful, elegant, professional 2000x2000 product images
for Etsy listings. Uses Python Pillow/PIL only.

ONLY creates images — does NOT write text, descriptions, or titles.
"""

import os
import random
from PIL import Image, ImageDraw, ImageFilter, ImageEnhance
from typing import List, Tuple, Optional


# ── Configuration ──────────────────────────────────────────────
OUTPUT_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "etsy_product_images")
IMAGE_SIZE = (2000, 2000)
BACKGROUND_COLORS = [
    ((245, 235, 220), (230, 215, 195)),   # Warm cream
    ((250, 240, 225), (225, 205, 185)),   # Soft beige
    ((240, 230, 215), (215, 200, 180)),   # Vintage sand
    ((235, 225, 210), (210, 195, 175)),   # Light taupe
    ((250, 245, 235), (225, 215, 200)),   # Off-white ivory
]

PRODUCT_PALETTES = {
    "blanket": {
        "primary": [(180, 100, 70), (200, 120, 80), (160, 80, 60)],
        "secondary": [(220, 180, 150), (200, 160, 130)],
        "accent": [(90, 60, 40), (120, 85, 55)],
        "name": "Warm Terracotta",
    },
    "cushion": {
        "primary": [(80, 120, 160), (100, 140, 180), (60, 100, 140)],
        "secondary": [(180, 200, 220), (160, 180, 200)],
        "accent": [(40, 70, 110), (60, 90, 130)],
        "name": "Sage Blue",
    },
    "scarf": {
        "primary": [(200, 80, 100), (220, 100, 120), (180, 60, 80)],
        "secondary": [(240, 200, 210), (220, 180, 190)],
        "accent": [(140, 40, 60), (160, 60, 80)],
        "name": "Rose Pink",
    },
    "rug": {
        "primary": [(140, 100, 60), (160, 120, 80), (120, 80, 50)],
        "secondary": [(200, 170, 140), (180, 150, 120)],
        "accent": [(80, 55, 35), (100, 70, 45)],
        "name": "Caramel Brown",
    },
    "hat": {
        "primary": [(60, 80, 50), (80, 100, 70), (40, 60, 35)],
        "secondary": [(140, 160, 130), (120, 140, 110)],
        "accent": [(30, 50, 25), (50, 70, 40)],
        "name": "Olive Green",
    },
    "bag": {
        "primary": [(200, 160, 100), (220, 180, 120), (180, 140, 80)],
        "secondary": [(240, 220, 180), (220, 200, 160)],
        "accent": [(120, 90, 50), (140, 110, 70)],
        "name": "Dusty Gold",
    },
}


# ── Helper Functions ───────────────────────────────────────────

def create_gradient_background(img: Image, color1: Tuple[int, int, int], color2: Tuple[int, int, int], direction: str = "diagonal"):
    """Create a smooth gradient background."""
    draw = ImageDraw.Draw(img)
    w, h = img.size

    if direction == "diagonal":
        for i in range(w):
            ratio = i / w
            r = int(color1[0] * (1 - ratio) + color2[0] * ratio)
            g = int(color1[1] * (1 - ratio) + color2[1] * ratio)
            b = int(color1[2] * (1 - ratio) + color2[2] * ratio)
            draw.line([(i, 0), (i, h)], fill=(r, g, b))
    elif direction == "vertical":
        for i in range(h):
            ratio = i / h
            r = int(color1[0] * (1 - ratio) + color2[0] * ratio)
            g = int(color1[1] * (1 - ratio) + color2[1] * ratio)
            b = int(color1[2] * (1 - ratio) + color2[2] * ratio)
            draw.line([(0, i), (w, i)], fill=(r, g, b))
    elif direction == "radial":
        cx, cy = w // 2, h // 2
        max_dist = int((w ** 2 + h ** 2) ** 0.5 / 2)
        for y in range(h):
            for x in range(w):
                dist = ((x - cx) ** 2 + (y - cy) ** 2) ** 0.5
                ratio = min(dist / max_dist, 1.0)
                r = int(color1[0] * (1 - ratio) + color2[0] * ratio)
                g = int(color1[1] * (1 - ratio) + color2[1] * ratio)
                b = int(color1[2] * (1 - ratio) + color2[2] * ratio)
                img.putpixel((x, y), (r, g, b))


def add_texture_noise(img: Image, intensity: int = 15):
    """Add subtle fabric/thread texture noise."""
    draw = ImageDraw.Draw(img)
    w, h = img.size
    pixels = img.load()
    for _ in range(int(w * h * 0.02)):
        x = random.randint(0, w - 1)
        y = random.randint(0, h - 1)
        px = pixels[x, y]
        noise = random.randint(-intensity, intensity)
        pixels[x, y] = (
            max(0, min(255, px[0] + noise)),
            max(0, min(255, px[1] + noise)),
            max(0, min(255, px[2] + noise)),
        )


def draw_stitch_pattern(draw: ImageDraw.Draw, bounds: Tuple[int, int, int, int],
                         color: Tuple[int, int, int], thickness: int = 2):
    """Draw croché stitch pattern (X-shaped stitches)."""
    x1, y1, x2, y2 = bounds
    step = 40
    for y in range(y1, y2, step):
        for x in range(x1, x2, step):
            # X stitch
            draw.line([(x, y), (x + step // 2, y + step // 2)], fill=color, width=thickness)
            draw.line([(x + step // 2, y), (x, y + step // 2)], fill=color, width=thickness)


def draw_soft_shadow(draw: ImageDraw.Draw, shape_bounds: Tuple[int, int, int, int],
                     shadow_color: Tuple[int, int, int] = (30, 20, 15, 80)):
    """Draw a soft drop shadow beneath a product."""
    x1, y1, x2, y2 = shape_bounds
    shadow = Image.new("RGBA", (2000, 2000), (0, 0, 0, 0))
    shadow_draw = ImageDraw.Draw(shadow)
    ellipse_bounds = (x1 + 20, y2 + 10, x2 + 20, y2 + 100)
    shadow_draw.ellipse(ellipse_bounds, fill=shadow_color)
    blurred = shadow.filter(ImageFilter.GaussianBlur(15))
    img_array = Image.alpha_composite(img.convert("RGBA"), blurred)
    return img_array.convert("RGB")


def create_beautiful_frame(img: Image, border_color: Tuple[int, int, int], thickness: int = 8):
    """Add an elegant decorative border."""
    draw = ImageDraw.Draw(img)
    w, h = img.size
    # Outer border
    draw.rectangle([0, 0, w - 1, h - 1], outline=border_color, width=thickness)
    # Inner border
    inner = thickness + 4
    draw.rectangle([inner, inner, w - inner - 1, h - inner - 1], outline=border_color, width=2)


# ── Product Image Generators ───────────────────────────────────

def create_blanket_image(output_path: str, palette: dict = None):
    """Create a beautiful croché blanket product image."""
    img = Image.new("RGB", IMAGE_SIZE, (255, 255, 255))
    bg_color1, bg_color2 = random.choice(BACKGROUND_COLORS)
    create_gradient_background(img, bg_color1, bg_color2, "diagonal")

    if palette is None:
        palette = random.choice(list(PRODUCT_PALETTES.values()))

    draw = ImageDraw.Draw(img)
    w, h = img.size

    # Blanket shape (centered rectangle with rounded feel)
    margin = 250
    bx1, by1 = margin, h // 2 - 300
    bx2, by2 = w - margin, h // 2 + 300

    # Draw blanket body
    blanket_color = random.choice(palette["primary"])
    draw.rectangle([bx1, by1, bx2, by2], fill=blanket_color)

    # Add croché texture to blanket
    stitch_color = tuple(c + random.randint(-20, 20) for c in blanket_color)
    draw_stitch_pattern(draw, (bx1 + 20, by1 + 20, bx2 - 20, by2 - 20), stitch_color, 3)

    # Add highlight/shimmer
    highlight = Image.new("RGBA", IMAGE_SIZE, (0, 0, 0, 0))
    hl_draw = ImageDraw.Draw(highlight)
    hl_draw.rectangle([bx1 + 50, by1 + 50, bx2 - 50, by2 - 50], fill=(255, 255, 255, 25))
    img = Image.alpha_composite(img.convert("RGBA"), highlight).convert("RGB")

    # Add soft shadow beneath blanket
    shadow = Image.new("RGBA", IMAGE_SIZE, (0, 0, 0, 0))
    s_draw = ImageDraw.Draw(shadow)
    s_draw.ellipse([bx1 - 50, by2 + 20, bx2 + 50, by2 + 120], fill=(30, 20, 15, 60))
    shadow_blur = shadow.filter(ImageFilter.GaussianBlur(20))
    img = Image.alpha_composite(img.convert("RGBA"), shadow_blur).convert("RGB")

    # Add decorative border
    create_beautiful_frame(img, (180, 140, 100), 10)

    # Add subtle texture
    add_texture_noise(img, 10)

    # Color grade for warmth
    enhancer = ImageEnhance.Color(img)
    img = enhancer.enhance(1.2)
    enhancer = ImageEnhance.Sharpness(img)
    img = enhancer.enhance(0.8)

    img.save(output_path, "PNG", quality=95)
    return output_path


def create_cushion_image(output_path: str, palette: dict = None):
    """Create a beautiful croché cushion/pillow product image."""
    img = Image.new("RGB", IMAGE_SIZE, (255, 255, 255))
    bg_color1, bg_color2 = random.choice(BACKGROUND_COLORS)
    create_gradient_background(img, bg_color1, bg_color2, "vertical")

    if palette is None:
        palette = random.choice(list(PRODUCT_PALETTES.values()))

    draw = ImageDraw.Draw(img)
    w, h = img.size

    # Cushion shape (square with slight perspective)
    cx, cy = w // 2, h // 2
    cushion_size = 500

    # Perspective quadrilateral for cushion
    top_left = (cx - cushion_size, cy - cushion_size + 50)
    top_right = (cx + cushion_size, cy - cushion_size + 50)
    bot_right = (cx + cushion_size + 30, cy + cushion_size + 30)
    bot_left = (cx - cushion_size + 30, cy + cushion_size + 30)

    cushion_color = random.choice(palette["primary"])
    draw.polygon([top_left, top_right, bot_right, bot_left], fill=cushion_color)

    # Cushion texture
    for _ in range(50):
        sx = random.randint(top_left[0] + 20, top_right[0] - 20)
        sy = random.randint(top_left[1] + 20, bot_left[1] - 20)
        scolor = tuple(c + random.randint(-15, 15) for c in cushion_color)
        draw.ellipse([sx - 15, sy - 15, sx + 15, sy + 15], fill=scolor)

    # Stitch outline
    stitch_color = tuple(c + random.randint(-25, 25) for c in palette["accent"][0])
    draw.polygon([top_left, top_right, bot_right, bot_left], outline=stitch_color, width=4)
    # Cross stitches
    for i in range(0, cushion_size, 50):
        draw.line([(top_left[0] + i, top_left[1]), (bot_left[0] + i, bot_left[1])],
                   fill=stitch_color, width=2)
        draw.line([(top_left[0], top_left[1] + i), (top_right[0], top_right[1] + i)],
                   fill=stitch_color, width=2)

    # Shadow
    shadow = Image.new("RGBA", IMAGE_SIZE, (0, 0, 0, 0))
    s_draw = ImageDraw.Draw(shadow)
    shadow_ellipse = [cx - cushion_size - 30, cy + cushion_size + 30,
                       cx + cushion_size + 50, cy + cushion_size + 120]
    s_draw.ellipse(shadow_ellipse, fill=(30, 20, 15, 50))
    shadow_blur = shadow.filter(ImageFilter.GaussianBlur(18))
    img = Image.alpha_composite(img.convert("RGBA"), shadow_blur).convert("RGB")

    # Frame
    create_beautiful_frame(img, (160, 130, 90), 10)

    # Texture
    add_texture_noise(img, 8)

    # Warmth
    enhancer = ImageEnhance.Color(img)
    img = enhancer.enhance(1.1)
    enhancer = ImageEnhance.Brightness(img)
    img = enhancer.enhance(1.05)

    img.save(output_path, "PNG", quality=95)
    return output_path


def create_scarf_image(output_path: str, palette: dict = None):
    """Create a beautiful croché scarf product image."""
    img = Image.new("RGB", IMAGE_SIZE, (255, 255, 255))
    bg_color1, bg_color2 = random.choice(BACKGROUND_COLORS)
    create_gradient_background(img, bg_color1, bg_color2, "vertical")

    if palette is None:
        palette = random.choice(list(PRODUCT_PALETTES.values()))

    draw = ImageDraw.Draw(img)
    w, h = img.size

    # Scarf shape (long drape)
    scarf_width = 180
    scarf_color = random.choice(palette["primary"])

    # Left side of scarf
    lx1, ly1 = w // 2 - 200, 150
    lx2, ly2 = lx1 + scarf_width, h - 150
    draw.rectangle([lx1, ly1, lx2, ly2], fill=scarf_color)

    # Right side of scarf (draped)
    rx1 = w // 2 + 200 - scarf_width
    ry1 = 150
    rx2 = rx1 + scarf_width
    ry2 = h - 150
    draw.rectangle([rx1, ry1, rx2, ry2], fill=scarf_color)

    # Drape fold effect
    fold_color = tuple(c + random.randint(-20, 20) for c in scarf_color)
    for i in range(3):
        fy = ly1 + (ly2 - ly1) // 4 * (i + 1)
        draw.line([(lx1 - 10, fy), (lx2 + 10, fy)], fill=fold_color, width=8)
        draw.line([(rx1 - 10, fy), (rx2 + 10, fy)], fill=fold_color, width=8)

    # Stitches along edges
    stitch_color = palette["accent"][0]
    for y in range(ly1, ly2, 30):
        draw.line([(lx1, y), (lx1 + 10, y)], fill=stitch_color, width=3)
        draw.line([(lx2 - 10, y), (lx2, y)], fill=stitch_color, width=3)
        draw.line([(rx1, y), (rx1 + 10, y)], fill=stitch_color, width=3)
        draw.line([(rx2 - 10, y), (rx2, y)], fill=stitch_color, width=3)

    # Shadow
    shadow = Image.new("RGBA", IMAGE_SIZE, (0, 0, 0, 0))
    s_draw = ImageDraw.Draw(shadow)
    s_draw.ellipse([lx1 - 30, ly2 - 20, lx2 + 30, ly2 + 80], fill=(30, 20, 15, 45))
    s_draw.ellipse([rx1 - 30, ry2 - 20, rx2 + 30, ry2 + 80], fill=(30, 20, 15, 45))
    shadow_blur = shadow.filter(ImageFilter.GaussianBlur(15))
    img = Image.alpha_composite(img.convert("RGBA"), shadow_blur).convert("RGB")

    create_beautiful_frame(img, (170, 140, 100), 10)
    add_texture_noise(img, 12)

    enhancer = ImageEnhance.Color(img)
    img = enhancer.enhance(1.15)

    img.save(output_path, "PNG", quality=95)
    return output_path


def create_rug_image(output_path: str, palette: dict = None):
    """Create a beautiful croché rug product image."""
    img = Image.new("RGB", IMAGE_SIZE, (255, 255, 255))
    bg_color1, bg_color2 = random.choice(BACKGROUND_COLORS)
    create_gradient_background(img, bg_color1, bg_color2, "radial")

    if palette is None:
        palette = random.choice(list(PRODUCT_PALETTES.values()))

    draw = ImageDraw.Draw(img)
    w, h = img.size

    # Rug shape (large oval)
    cx, cy = w // 2, h // 2
    rx, ry = 600, 500

    rug_color = random.choice(palette["primary"])
    draw.ellipse([cx - rx, cy - ry, cx + rx, cy + ry], fill=rug_color)

    # Inner ring texture
    inner_color = random.choice(palette["secondary"])
    draw.ellipse([cx - rx + 40, cy - ry + 40, cx + rx - 40, cy + ry - 40], fill=inner_color)

    # Crochet ring pattern
    for r in range(30, rx, 60):
        ring_color = random.choice(palette["primary"] + palette["secondary"])
        draw.ellipse([cx - r, cy - r, cx + r, cy + r], outline=ring_color, width=6)

    # Center motif
    center_color = palette["accent"][0]
    draw.ellipse([cx - 80, cy - 80, cx + 80, cy + 80], fill=center_color)
    draw.ellipse([cx - 50, cy - 50, cx + 50, cy + 50], fill=random.choice(palette["secondary"]))

    # Fringe at bottom
    fringe_color = random.choice(palette["secondary"])
    for i in range(0, rx * 2, 20):
        if cx - rx + i < cx + rx:
            fx = cx - rx + i
            draw.line([(fx, cy + ry), (fx + 5, cy + ry + 60)], fill=fringe_color, width=4)

    # Shadow
    shadow = Image.new("RGBA", IMAGE_SIZE, (0, 0, 0, 0))
    s_draw = ImageDraw.Draw(shadow)
    s_draw.ellipse([cx - rx - 20, cy + ry - 20, cx + rx + 20, cy + ry + 80], fill=(30, 20, 15, 50))
    shadow_blur = shadow.filter(ImageFilter.GaussianBlur(25))
    img = Image.alpha_composite(img.convert("RGBA"), shadow_blur).convert("RGB")

    create_beautiful_frame(img, (150, 120, 80), 12)
    add_texture_noise(img, 8)

    enhancer = ImageEnhance.Color(img)
    img = enhancer.enhance(1.1)
    enhancer = ImageEnhance.Sharpness(img)
    img = enhancer.enhance(0.7)

    img.save(output_path, "PNG", quality=95)
    return output_path


def create_hat_image(output_path: str, palette: dict = None):
    """Create a beautiful croché hat product image."""
    img = Image.new("RGB", IMAGE_SIZE, (255, 255, 255))
    bg_color1, bg_color2 = random.choice(BACKGROUND_COLORS)
    create_gradient_background(img, bg_color1, bg_color2, "diagonal")

    if palette is None:
        palette = random.choice(list(PRODUCT_PALETTES.values()))

    draw = ImageDraw.Draw(img)
    w, h = img.size

    hat_color = random.choice(palette["primary"])
    accent_color = palette["accent"][0]

    # Hat body (trapezoid/cylinder perspective)
    hat_top_w = 300
    hat_bot_w = 360
    hat_height = 250
    cx = w // 2
    top_y = h // 2 - 200
    bot_y = top_y + hat_height

    # Hat crown
    draw.polygon([
        (cx - hat_top_w // 2, top_y),
        (cx + hat_top_w // 2, top_y),
        (cx + hat_bot_w // 2 + 30, bot_y),
        (cx - hat_bot_w // 2 - 30, bot_y)
    ], fill=hat_color)

    # Brim
    brim_color = random.choice(palette["secondary"])
    draw.ellipse([cx - hat_bot_w // 2 - 20, bot_y - 30, cx + hat_bot_w // 2 + 20, bot_y + 30], fill=brim_color)

    # Stitch pattern on hat
    stitch_color = tuple(c + random.randint(-15, 15) for c in hat_color)
    for y in range(top_y + 20, bot_y - 20, 25):
        current_w = hat_top_w // 2 + (hat_bot_w // 2 - hat_top_w // 2) * (y - top_y) / hat_height
        draw.arc([cx - current_w - 10, y - 12, cx + current_w + 10, y + 12],
                 start=0, end=180, fill=stitch_color, width=2)

    # Pom-pom
    pom_x, pom_y = cx + hat_top_w // 2 + 20, top_y - 40
    for _ in range(20):
        px = pom_x + random.randint(-30, 30)
        py = pom_y + random.randint(-30, 30)
        pr = random.randint(10, 30)
        pcolor = random.choice(palette["secondary"] + [accent_color])
        draw.ellipse([px - pr, py - pr, px + pr, py + pr], fill=pcolor)

    # Shadow
    shadow = Image.new("RGBA", IMAGE_SIZE, (0, 0, 0, 0))
    s_draw = ImageDraw.Draw(shadow)
    s_draw.ellipse([cx - hat_bot_w, bot_y + 10, cx + hat_bot_w + 40, bot_y + 80], fill=(30, 20, 15, 50))
    shadow_blur = shadow.filter(ImageFilter.GaussianBlur(18))
    img = Image.alpha_composite(img.convert("RGBA"), shadow_blur).convert("RGB")

    create_beautiful_frame(img, (140, 110, 70), 10)
    add_texture_noise(img, 10)

    enhancer = ImageEnhance.Color(img)
    img = enhancer.enhance(1.1)

    img.save(output_path, "PNG", quality=95)
    return output_path


def create_bag_image(output_path: str, palette: dict = None):
    """Create a beautiful croché bag/purse product image."""
    img = Image.new("RGB", IMAGE_SIZE, (255, 255, 255))
    bg_color1, bg_color2 = random.choice(BACKGROUND_COLORS)
    create_gradient_background(img, bg_color1, bg_color2, "vertical")

    if palette is None:
        palette = random.choice(list(PRODUCT_PALETTES.values()))

    draw = ImageDraw.Draw(img)
    w, h = img.size

    bag_color = random.choice(palette["primary"])
    accent_color = palette["accent"][0]
    secondary_color = random.choice(palette["secondary"])

    # Bag body (trapezoid)
    bag_top_w = 320
    bag_bot_w = 360
    bag_height = 350
    cx = w // 2
    top_y = h // 2 - 150
    bot_y = top_y + bag_height

    draw.polygon([
        (cx - bag_top_w // 2, top_y),
        (cx + bag_top_w // 2, top_y),
        (cx + bag_bot_w // 2, bot_y),
        (cx - bag_bot_w // 2, bot_y)
    ], fill=bag_color)

    # Handle (two straps)
    handle_color = accent_color
    handle_top_y = top_y - 120
    draw.line([(cx - 100, handle_top_y), (cx - 100, top_y + 20)], fill=handle_color, width=12)
    draw.line([(cx + 100, handle_top_y), (cx + 100, top_y + 20)], fill=handle_color, width=12)
    draw.arc([cx - 100 - 15, handle_top_y - 15, cx - 100 + 15, handle_top_y + 15],
             start=0, end=180, fill=handle_color, width=10)
    draw.arc([cx + 100 - 15, handle_top_y - 15, cx + 100 + 15, handle_top_y + 15],
             start=0, end=180, fill=handle_color, width=10)

    # Texture
    for _ in range(40):
        tx = random.randint(cx - bag_top_w // 2 + 20, cx + bag_top_w // 2 - 20)
        ty = random.randint(top_y + 20, bot_y - 20)
        tcolor = tuple(c + random.randint(-15, 15) for c in bag_color)
        draw.ellipse([tx - 8, ty - 8, tx + 8, ty + 8], fill=tcolor)

    # Stitch border
    stitch_color = accent_color
    draw.polygon([(cx - bag_top_w // 2, top_y), (cx + bag_top_w // 2, top_y),
                   (cx + bag_bot_w // 2, bot_y), (cx - bag_bot_w // 2, bot_y)],
                  outline=stitch_color, width=5)

    # Shadow
    shadow = Image.new("RGBA", IMAGE_SIZE, (0, 0, 0, 0))
    s_draw = ImageDraw.Draw(shadow)
    s_draw.ellipse([cx - bag_bot_w, bot_y, cx + bag_bot_w + 40, bot_y + 80], fill=(30, 20, 15, 50))
    shadow_blur = shadow.filter(ImageFilter.GaussianBlur(20))
    img = Image.alpha_composite(img.convert("RGBA"), shadow_blur).convert("RGB")

    create_beautiful_frame(img, (160, 130, 90), 10)
    add_texture_noise(img, 10)

    enhancer = ImageEnhance.Color(img)
    img = enhancer.enhance(1.15)

    img.save(output_path, "PNG", quality=95)
    return output_path


# ── Main Bot ───────────────────────────────────────────────────

class EtsyImageBot:
    """Etsy Image Creation Bot for Croché Products."""

    def __init__(self, output_dir: str = None):
        self.output_dir = output_dir or OUTPUT_DIR
        os.makedirs(self.output_dir, exist_ok=True)
        self.product_types = ["blanket", "cushion", "scarf", "rug", "hat", "bag"]
        self.created_images: List[str] = []

    def generate_product_image(self, product_type: str = None, variant: int = None) -> str:
        """Generate a single product image and return its path."""
        if product_type is None:
            product_type = random.choice(self.product_types)

        if variant is None:
            variant = random.randint(1, 99)

        palette = random.choice(list(PRODUCT_PALETTES.values()))
        filename = f"croche_{product_type}_{variant:03d}.png"
        output_path = os.path.join(self.output_dir, filename)

        generators = {
            "blanket": create_blanket_image,
            "cushion": create_cushion_image,
            "scarf": create_scarf_image,
            "rug": create_rug_image,
            "hat": create_hat_image,
            "bag": create_bag_image,
        }

        generator = generators[product_type]
        generator(output_path, palette)
        self.created_images.append(output_path)
        return output_path

    def generate_bulk(self, count: int = 6) -> List[str]:
        """Generate multiple product images covering all product types."""
        self.created_images = []
        for i in range(count):
            product_type = self.product_types[i % len(self.product_types)]
            path = self.generate_product_image(product_type=product_type, variant=i + 1)

        return self.created_images

    def get_image_info(self, image_path: str) -> dict:
        """Get dimensions and info about an image."""
        img = Image.open(image_path)
        return {
            "path": image_path,
            "size": img.size,
            "mode": img.mode,
            "format": img.format,
        }


# ── Entry Point ────────────────────────────────────────────────

def main():
    """Run the Etsy Image Creation Bot."""
    print("=" * 60)
    print("  Etsy Image Creation Bot — Croché Products")
    print("  Resolution: 2000x2000 pixels")
    print("  Library: Pillow/PIL")
    print("=" * 60)
    print()

    bot = EtsyImageBot()

    # Generate 6 product images (one per product type)
    images = bot.generate_bulk(count=6)

    print(f"\n✅ Created {len(images)} product images:\n")
    for img_path in images:
        info = bot.get_image_info(img_path)
        print(f"  📸 {info['size'][0]}x{info['size'][1]} → {os.path.basename(img_path)}")

    print(f"\n📁 Output directory: {bot.output_dir}")
    print("✅ All images created successfully!")

    return images


if __name__ == "__main__":
    main()
