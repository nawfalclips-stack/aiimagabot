"use client";

import { useCallback, useRef, useState } from "react";
import { toast } from "sonner";

export function useCopy(resetAfterMs = 2000) {
  const [copied, setCopied] = useState(false);
  const timer = useRef<ReturnType<typeof setTimeout> | null>(null);

  const copy = useCallback(
    async (text: string, label?: string) => {
      try {
        await navigator.clipboard.writeText(text);
        setCopied(true);
        if (label) toast.success(`${label} copied to clipboard`);
        if (timer.current) clearTimeout(timer.current);
        timer.current = setTimeout(() => setCopied(false), resetAfterMs);
      } catch {
        toast.error("Could not copy to clipboard");
      }
    },
    [resetAfterMs]
  );

  return { copied, copy };
}
