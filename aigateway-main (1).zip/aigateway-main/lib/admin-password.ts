// Admin password rules shared by the change-password form and its server action. Client-safe.

/** Minimum length of an admin password set from the panel. */
export const MIN_ADMIN_PASSWORD_LENGTH = 12;

/**
 * True when a session was issued before the admin's last password change, so
 * changing the password signs out every other browser. Compared in whole
 * seconds (JWT `iat` precision); the session that made the change is re-issued
 * right after it and stays valid.
 */
export function sessionPredatesPasswordChange(issuedAtSeconds: number | undefined, passwordChangedAt: Date | null): boolean {
  if (!passwordChangedAt) return false;
  if (typeof issuedAtSeconds !== "number") return true;
  return issuedAtSeconds < Math.floor(passwordChangedAt.getTime() / 1000);
}
