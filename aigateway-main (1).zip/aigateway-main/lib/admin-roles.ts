/**
 * Admin role definitions and page access control
 */

export const ADMIN_ROLES = {
  FULL_ACCESS: "FULL_ACCESS",
  API_VIEWER: "API_VIEWER",
  STATISTICS_ONLY: "STATISTICS_ONLY",
} as const;

export type AdminRole = (typeof ADMIN_ROLES)[keyof typeof ADMIN_ROLES];

/**
 * Define which pages each role can access
 */
export const ROLE_PERMISSIONS: Record<AdminRole, string[]> = {
  FULL_ACCESS: [
    "/admin",
    "/admin/customers",
    "/admin/customers/new",
    "/admin/customers/[id]",
    "/admin/customers/[id]/edit",
    "/admin/orders",
    "/admin/activations",
    "/admin/recharges",
    "/admin/tickets",
    "/admin/tickets/[id]",
    "/admin/usage-logs",
    "/admin/api-pool",
    "/admin/activity",
    "/admin/statistics",
    "/admin/analytics",
    "/admin/expired",
    "/admin/documentation",
    "/admin/settings",
    "/admin/account",
  ],
  API_VIEWER: [
    "/admin",
    "/admin/customers", // view only
    "/admin/customers/[id]", // view only
    "/admin/api-pool", // view only
    "/admin/usage-logs",
    "/admin/activity",
    "/admin/account",
  ],
  STATISTICS_ONLY: [
    "/admin",
    "/admin/statistics",
    "/admin/analytics",
    "/admin/activity",
    "/admin/account",
  ],
};

/**
 * Check if an admin with given role can access a path
 */
export function canAccessPath(role: AdminRole, path: string): boolean {
  const allowedPaths = ROLE_PERMISSIONS[role] || [];

  // Check exact match first
  if (allowedPaths.includes(path)) {
    return true;
  }

  // Check dynamic routes (e.g., /admin/customers/[id])
  return allowedPaths.some((allowedPath) => {
    if (allowedPath.includes("[id]")) {
      const pattern = allowedPath.replace("[id]", "[^/]+");
      const regex = new RegExp(`^${pattern}$`);
      return regex.test(path);
    }
    return false;
  });
}

/**
 * Check if admin can perform write operations
 */
export function canWrite(role: AdminRole): boolean {
  return role === ADMIN_ROLES.FULL_ACCESS;
}

/**
 * Get role display name
 */
export function getRoleLabel(role: AdminRole): string {
  switch (role) {
    case ADMIN_ROLES.FULL_ACCESS:
      return "Full Access";
    case ADMIN_ROLES.API_VIEWER:
      return "API Viewer";
    case ADMIN_ROLES.STATISTICS_ONLY:
      return "Statistics Only";
    default:
      return role;
  }
}

/**
 * Get role description
 */
export function getRoleDescription(role: AdminRole): string {
  switch (role) {
    case ADMIN_ROLES.FULL_ACCESS:
      return "Full access to all features - can create, edit, and delete";
    case ADMIN_ROLES.API_VIEWER:
      return "View customers, API pool, usage logs, and activity";
    case ADMIN_ROLES.STATISTICS_ONLY:
      return "View statistics and analytics only";
    default:
      return "";
  }
}
