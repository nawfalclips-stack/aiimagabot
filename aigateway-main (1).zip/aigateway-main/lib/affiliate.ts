/**
 * Affiliate program — pure logic, no database access.
 *
 * Every customer gets a referral code. When a friend they invited activates
 * (or recharges), the inviter earns a cash commission + loyalty points:
 *   per referral purchase ... $5 cash + 15 pts
 *
 * Milestone bonuses are computed on the TOTAL amount spent by everyone the
 * customer invited, and are claimed by the customer then approved by an admin:
 *   invited friends spent $100+ ... $120 bonus
 *   invited friends spent $200+ ... $250 bonus
 *   invited friends spent $300+ ... $400 bonus
 */

export const AFFILIATE = {
  /** Cash commission for each purchase made by an invited friend. */
  commissionCents: 500, // $5
  /** Loyalty points for each purchase made by an invited friend. */
  commissionPoints: 15,
  /** One-time welcome gift credited to a NEW referred customer on activation. */
  welcomeBonusCents: 500, // $5
} as const;

export interface AffiliateMilestone {
  id: string;
  /** Pack size (cents) that must be purchased the required number of times. */
  packCents: number;
  /** How many times the pack must be bought by invited friends. */
  requiredCount: number;
  label: string;
  rewardCents: number;
}

/**
 * Milestones are COUNT-based: e.g. the $100 tier unlocks when invited friends
 * buy a $100 pack (or bigger) 10 times in total — not on total dollars spent.
 * A purchase counts toward every milestone whose pack it covers
 * (a $300 pack = 3 counts of $100, 1.5 → rounds to 1 count of $200, etc.).
 */
export const AFFILIATE_MILESTONES: AffiliateMilestone[] = [
  { id: "m100", packCents: 10_000, requiredCount: 10, label: "10 × $100 packs", rewardCents: 12_000 }, // $120
  { id: "m200", packCents: 20_000, requiredCount: 10, label: "10 × $200 packs", rewardCents: 25_000 }, // $250
  { id: "m300", packCents: 30_000, requiredCount: 10, label: "10 × $300 packs", rewardCents: 40_000 }, // $400
];

/** How many times each milestone's pack is covered by one purchase (in counts). */
export function packCountsFor(purchaseCents: number): Record<string, number> {
  const out: Record<string, number> = {};
  for (const m of AFFILIATE_MILESTONES) {
    if (purchaseCents >= m.packCents) {
      out[m.id] = Math.floor(purchaseCents / m.packCents);
    }
  }
  return out;
}

/** Progress per milestone given the referral rows' plan sizes. */
export function milestoneProgress(
  purchasesCents: number[]
): Array<{ milestone: AffiliateMilestone; count: number; done: boolean }> {
  const counts: Record<string, number> = {};
  for (const m of AFFILIATE_MILESTONES) counts[m.id] = 0;
  for (const cents of purchasesCents) {
    for (const [id, n] of Object.entries(packCountsFor(cents))) {
      counts[id] += n;
    }
  }
  return AFFILIATE_MILESTONES.map((m) => ({
    milestone: m,
    count: Math.min(counts[m.id], m.requiredCount),
    done: counts[m.id] >= m.requiredCount,
  }));
}

/** The best milestone fully completed (null when none). */
export function getReachedMilestone(purchasesCents: number[]): AffiliateMilestone | null {
  let reached: AffiliateMilestone | null = null;
  for (const p of milestoneProgress(purchasesCents)) {
    if (p.done) reached = p.milestone;
  }
  return reached;
}

/** The next milestone still incomplete. */
export function getNextMilestone(purchasesCents: number[]): AffiliateMilestone | null {
  return AFFILIATE_MILESTONES.find((m) => !milestoneProgress(purchasesCents).find((p) => p.milestone.id === m.id)?.done) ?? null;
}

/**
 * Generate a unique-looking referral code, e.g. "AERO-4K7QX2".
 * Collision-safe enough at this scale; DB unique constraint is the backstop.
 */
export function generateAffiliateCode(): string {
  const alphabet = "ABCDEFGHJKMNPQRSTUVWXYZ23456789"; // no confusing 0/O/1/L/I
  let code = "";
  for (let i = 0; i < 6; i++) {
    code += alphabet[Math.floor(Math.random() * alphabet.length)];
  }
  return `AERO-${code}`;
}

/** Loose validation for codes typed into the activation form. */
export function isValidAffiliateCodeFormat(code: string): boolean {
  return /^AERO-[A-HJ-KM-NP-Z2-9]{6}$/.test(code.trim().toUpperCase());
}
