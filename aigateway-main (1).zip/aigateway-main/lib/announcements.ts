// Announcement vocabulary shared by the admin form, the portal and the
// service (lib/services/announcements.ts). Client-safe: no server imports.

export const ANNOUNCEMENT_KINDS = ["INFO", "PROMO", "NEW_MODEL"] as const;
export type AnnouncementKind = (typeof ANNOUNCEMENT_KINDS)[number];

export const ANNOUNCEMENT_KIND_LABELS: Record<AnnouncementKind, string> = {
  INFO: "Message",
  PROMO: "Recharge promotion",
  NEW_MODEL: "New model",
};

/** Upper bound for a recharge bonus, so a typo cannot hand out 1500 %. */
export const MAX_RECHARGE_BONUS_PCT = 100;

/** Whole cents of promo bonus on a recharge (rounded down; pct clamped to 0..MAX). */
export function promoBonusCents(balanceCents: number, pct: number): number {
  const p = Math.min(MAX_RECHARGE_BONUS_PCT, Math.max(0, Math.round(pct)));
  return Math.floor((Math.max(0, balanceCents) * p) / 100);
}
