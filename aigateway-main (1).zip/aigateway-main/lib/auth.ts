import "server-only";
import { cache } from "react";
import { redirect, forbidden } from "next/navigation";
import type { Admin, Customer } from "@prisma/client";
import { prisma } from "@/lib/prisma";
import { getAdminSession, getCustomerSession } from "@/lib/session";
import { canAccessPath, canWrite, type AdminRole } from "@/lib/admin-roles";
import { sessionPredatesPasswordChange } from "@/lib/admin-password";

/** Returns the logged-in admin or null. Cached per request. */
export const getCurrentAdmin = cache(async (): Promise<Admin | null> => {
  const session = await getAdminSession();
  if (!session) return null;
  const admin = await prisma.admin.findUnique({ where: { id: session.adminId } });
  if (!admin || sessionPredatesPasswordChange(session.iat, admin.passwordChangedAt)) return null;
  return admin;
});

/** Returns the logged-in admin or redirects to the admin login page. */
export async function requireAdmin(): Promise<Admin> {
  const admin = await getCurrentAdmin();
  if (!admin) redirect("/admin/login");
  return admin;
}

/**
 * Same as requireAdmin() but also enforces that the account is NOT read-only.
 * Call this in any Server Action or page that mutates data.
 * GamsGo inspector accounts (isReadOnly = true) are blocked here.
 */
export async function requireWriteAdmin(): Promise<Admin> {
  const admin = await requireAdmin();
  if (admin.isReadOnly) {
    forbidden();
  }
  return admin;
}

/**
 * Require admin with access to specific path
 */
export async function requireAdminWithAccess(path: string): Promise<Admin> {
  const admin = await requireAdmin();
  // All non-read-only admins have full access
  if (admin.isReadOnly) {
    forbidden();
  }
  return admin;
}

/** Returns the logged-in customer (never soft-deleted) or null. Cached per request. */
export const getCurrentCustomer = cache(async (): Promise<Customer | null> => {
  const session = await getCustomerSession();
  if (!session) return null;
  const customer = await prisma.customer.findUnique({ where: { id: session.customerId } });
  if (!customer || customer.deletedAt) return null;
  return customer;
});

/** Returns the logged-in customer or redirects to the landing page. */
export async function requireCustomer(): Promise<Customer> {
  const customer = await getCurrentCustomer();
  if (!customer) redirect("/");
  return customer;
}
