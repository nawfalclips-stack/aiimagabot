import "server-only";
import { prisma } from "@/lib/prisma";
import { POTS, potAvailableMicroUsd, formatMicroUsd, type Pot } from "@/lib/billing/money";

export interface BackfillResult {
  carried: number;
  created: number;
  verified: number;
  drift: string[];
}

/**
 * Idempotent ledger backfill (WS1). For every customer and pot with no ledger
 * history yet, writes one OPENING_BALANCE entry equal to the cached available
 * amount so that  sum(ledger, pot) == (initial - used) * 10_000 - carry  holds
 * from now on. Pots that already have entries are verified, never touched:
 * drift is reported for a human.
 *
 * Also copies the pre-Phase-1 `gatewayCarryMicroUsd` into
 * `balanceCarryMicroUsd` where the migration's data step did not run (SQLite
 * dev databases use `db push`). Raw SQL on purpose: the one place outside the
 * balance service allowed to touch a money column, and only to move a value
 * between two columns that mean the same thing.
 */
export async function backfillLedger({ dry = false }: { dry?: boolean } = {}): Promise<BackfillResult> {
  const carried = dry
    ? 0
    : await prisma.$executeRaw`
        UPDATE "Customer" SET "balanceCarryMicroUsd" = "gatewayCarryMicroUsd"
         WHERE "gatewayCarryMicroUsd" <> 0 AND "balanceCarryMicroUsd" = 0`;

  const customers = await prisma.customer.findMany({ orderBy: { createdAt: "asc" } });
  const sums = await prisma.ledgerEntry.groupBy({ by: ["customerId", "pot"], _sum: { amountMicroUsd: true } });
  const sumOf = (id: string, pot: Pot) => sums.find((s) => s.customerId === id && s.pot === pot)?._sum.amountMicroUsd ?? null;

  const result: BackfillResult = { carried, created: 0, verified: 0, drift: [] };

  for (const c of customers) {
    for (const pot of POTS) {
      const cached = potAvailableMicroUsd(c, pot);
      const existing = sumOf(c.id, pot);
      if (existing !== null) {
        if (existing === cached) result.verified++;
        else result.drift.push(`${c.accessCode} ${pot}: ledger ${formatMicroUsd(existing)} vs cached ${formatMicroUsd(cached)}`);
        continue;
      }
      if (cached === 0n) continue; // nothing to open; the first real movement starts the ledger
      result.created++;
      if (dry) continue;
      await prisma.ledgerEntry.create({
        data: {
          storeId: c.storeId,
          customerId: c.id,
          pot,
          type: "OPENING_BALANCE",
          amountMicroUsd: cached,
          balanceAfterMicroUsd: cached,
          idempotencyKey: `opening:${c.id}:${pot}`,
          actorLabel: "Ledger backfill",
          note: `Opening balance carried over from the pre-ledger cached values (initial ${pot === "BALANCE" ? c.initialBalanceCents : c.initialBonusCents} cents, used ${pot === "BALANCE" ? c.usedBalanceCents : c.usedBonusCents} cents)`,
        },
      });
    }
  }
  return result;
}
