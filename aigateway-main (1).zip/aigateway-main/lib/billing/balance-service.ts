import "server-only";
import type { Customer, LedgerEntry, Prisma, PrismaClient } from "@prisma/client";
import { prisma } from "@/lib/prisma";
import { logActivity } from "@/lib/services/activity";
import { DEFAULT_SETTINGS, SETTING_KEYS } from "@/lib/constants";
import { computeStatus } from "@/lib/services/status";
import type { StoreId } from "@/lib/store";
import {
  MICRO_PER_CENT,
  NOTE_REQUIRED,
  POTS,
  centsToMicro,
  formatMicroUsd,
  microToCents,
  potAvailableMicroUsd,
  splitUsageMicroUsd,
  type LedgerType,
  type Pot,
  type PotSplit,
} from "@/lib/billing/money";
import { mulDiv, SAME_RATE, type BonusConversion } from "@/lib/billing/pricing-engine";

/**
 * The single source of truth for customer credit.
 *
 * Every change to a customer's BALANCE or BONUS pot goes through here: the
 * cached cents on `Customer` and an append-only `LedgerEntry` are written in
 * the same transaction, guarded by optimistic concurrency on the exact values
 * that were read, and de-duplicated by `idempotencyKey`. Nothing else in the
 * codebase may write `initial*Cents`, `used*Cents`, `*CarryMicroUsd` or
 * `reservedMicroUsd` (test/unit/money-write-sites.test.ts enforces it).
 *
 * Amounts are BigInt micro-USD. Credits must be whole cents. Debits never
 * take a pot below zero — the part that could not be collected is returned.
 */

export type Tx = Prisma.TransactionClient;
type Db = PrismaClient | Tx;

export interface Actor {
  adminId?: string | null;
  /** Shown in history ("Administrator", "Gateway", "Affiliate program", …). */
  label: string;
}

export interface LedgerRef {
  type: string;
  id: string;
}

export interface MoneyInput {
  customerId: string;
  pot: Pot;
  /** Positive. */
  amountMicroUsd: bigint;
  type: LedgerType;
  /** Globally unique per logical operation, e.g. `recharge:{requestId}:BALANCE`. */
  idempotencyKey: string;
  ref?: LedgerRef;
  actor: Actor;
  note?: string;
  /** Join an outer transaction (no retries; conflicts propagate). */
  tx?: Tx;
  /** How the legacy history tables are written. Default "row". */
  history?: HistoryMode;
}

export type HistoryMode = "row" | "daily-rollup" | "none";

export interface MoneyResult {
  customer: Customer;
  /** The entry written (or the existing one on an idempotent replay). Null when nothing was applied. */
  entry: LedgerEntry | null;
  replayed: boolean;
  appliedMicroUsd: bigint;
  uncollectedMicroUsd: bigint;
  justFinished: boolean;
}

export class ConcurrentUpdateError extends Error {
  constructor() {
    super("The balance was just updated elsewhere. Refresh and try again.");
  }
}

const MAX_RETRIES = 5;

/** Interactive-transaction limits: money paths queue on the customer row lock, so allow a real wait. */
export const TX_OPTIONS = { maxWait: 15_000, timeout: 30_000 } as const;

const IS_POSTGRES = /^postgres(ql)?:/.test(process.env.DATABASE_URL ?? "");

/**
 * Serialise concurrent money movements for one customer at the database:
 * on Postgres, take the row lock for the rest of the transaction so parallel
 * settlements queue instead of thrashing on the optimistic guard. SQLite
 * has a single writer and needs nothing. The optimistic guard in movePot
 * stays as the safety net.
 */
export async function lockCustomer(tx: Tx, customerId: string): Promise<void> {
  if (!IS_POSTGRES) return;
  await tx.$queryRaw`SELECT "id" FROM "Customer" WHERE "id" = ${customerId} FOR UPDATE`;
}

function requireNote(type: LedgerType, note: string | undefined): void {
  if (NOTE_REQUIRED.has(type) && !(note ?? "").trim()) {
    throw new Error(`A reason is required for ${type}.`);
  }
}

/** Run `fn` in the caller's transaction, or in a fresh one with retries on optimistic conflicts. */
async function withTx<T>(tx: Tx | undefined, fn: (tx: Tx) => Promise<T>): Promise<T> {
  if (tx) return fn(tx);
  for (let attempt = 1; ; attempt++) {
    try {
      return await prisma.$transaction(fn, TX_OPTIONS);
    } catch (e) {
      if (e instanceof ConcurrentUpdateError && attempt < MAX_RETRIES) continue;
      throw e;
    }
  }
}

interface PotState {
  initial: number;
  used: number;
  carry: bigint;
}

function potState(c: Customer, pot: Pot): PotState {
  return pot === "BALANCE"
    ? { initial: c.initialBalanceCents, used: c.usedBalanceCents, carry: c.balanceCarryMicroUsd }
    : { initial: c.initialBonusCents, used: c.usedBonusCents, carry: c.bonusCarryMicroUsd };
}

/**
 * Apply one signed movement to one pot inside `tx`. Returns the ledger entry
 * (or null when the movement collapsed to zero) and the refreshed customer.
 */
async function movePot(
  tx: Tx,
  customer: Customer,
  thresholdCents: number,
  p: {
    pot: Pot;
    /** Signed. Credits must be whole cents. */
    deltaMicroUsd: bigint;
    type: LedgerType;
    idempotencyKey: string;
    ref?: LedgerRef;
    actor: Actor;
    note: string;
    history: HistoryMode;
  }
): Promise<{ customer: Customer; entry: LedgerEntry | null; applied: bigint; uncollected: bigint; justFinished: boolean }> {
  const before = potState(customer, p.pot);
  const available = centsToMicro(before.initial - before.used) - before.carry;

  let initial = before.initial;
  let used = before.used;
  let carry = before.carry;
  let applied: bigint;
  let uncollected = 0n;

  if (p.deltaMicroUsd >= 0n) {
    if (p.deltaMicroUsd % MICRO_PER_CENT !== 0n) throw new RangeError("Credits must be whole cents.");
    initial += microToCents(p.deltaMicroUsd);
    applied = p.deltaMicroUsd;
  } else {
    const wanted = -p.deltaMicroUsd;
    const charge = wanted <= available ? wanted : available > 0n ? available : 0n;
    uncollected = wanted - charge;
    carry += charge;
    const cents = Number(carry / MICRO_PER_CENT);
    carry -= BigInt(cents) * MICRO_PER_CENT;
    used += cents;
    applied = -charge;
  }

  const after = available + applied;

  // Status is a function of both pots; recompute with the updated one.
  const balanceRemaining = p.pot === "BALANCE" ? initial - used : customer.initialBalanceCents - customer.usedBalanceCents;
  const bonusRemaining = p.pot === "BONUS" ? initial - used : customer.initialBonusCents - customer.usedBonusCents;
  const status = computeStatus(balanceRemaining, thresholdCents, customer.status, bonusRemaining);
  const finished = status === "BALANCE_FINISHED";
  const justFinished = finished && customer.finishedAt === null;

  const finishedAt = finished ? (customer.finishedAt ?? new Date()) : null;
  // Explicit per-pot writes (no spreads) so the write-site guard can see them.
  const claimed =
    p.pot === "BALANCE"
      ? await tx.customer.updateMany({
          where: { id: customer.id, initialBalanceCents: before.initial, usedBalanceCents: before.used, balanceCarryMicroUsd: before.carry },
          data: { initialBalanceCents: initial, usedBalanceCents: used, balanceCarryMicroUsd: carry, status, finishedAt },
        })
      : await tx.customer.updateMany({
          where: { id: customer.id, initialBonusCents: before.initial, usedBonusCents: before.used, bonusCarryMicroUsd: before.carry },
          data: { initialBonusCents: initial, usedBonusCents: used, bonusCarryMicroUsd: carry, status, finishedAt },
        });
  if (claimed.count === 0) throw new ConcurrentUpdateError();

  let entry: LedgerEntry | null = null;
  if (applied !== 0n) {
    entry = await tx.ledgerEntry.create({
      data: {
        storeId: customer.storeId,
        customerId: customer.id,
        pot: p.pot,
        type: p.type,
        amountMicroUsd: applied,
        balanceAfterMicroUsd: after,
        refType: p.ref?.type ?? "",
        refId: p.ref?.id ?? "",
        idempotencyKey: p.idempotencyKey,
        actorAdminId: p.actor.adminId ?? null,
        actorLabel: p.actor.label,
        note: p.note,
      },
    });
    await writeHistory(tx, customer.id, p.pot, applied, initial - used, p.note, p.actor.label, p.history);
  }

  const refreshed = await tx.customer.findUniqueOrThrow({ where: { id: customer.id } });
  return { customer: refreshed, entry, applied, uncollected, justFinished };
}

/**
 * The pre-ledger history tables still feed the admin timeline and the portal
 * charts, so they are kept in step: negative `amountUsedCents` = credit.
 * Gateway usage is rolled up per day so hundreds of requests stay readable.
 */
async function writeHistory(
  tx: Tx,
  customerId: string,
  pot: Pot,
  appliedMicroUsd: bigint,
  remainingCents: number,
  note: string,
  updatedBy: string,
  mode: HistoryMode
): Promise<void> {
  if (mode === "none") return;
  // Sub-cent movements are carried; the history is in cents.
  const cents = Number(-appliedMicroUsd / MICRO_PER_CENT);
  if (cents === 0) return;

  if (mode === "daily-rollup") {
    const dayStart = new Date();
    dayStart.setUTCHours(0, 0, 0, 0);
    const rollupNote = `${note} — ${dayStart.toISOString().slice(0, 10)}`;
    const where = { customerId, updatedBy, createdAt: { gte: dayStart } };
    if (pot === "BALANCE") {
      const existing = await tx.balanceHistory.findFirst({ where });
      if (existing) await tx.balanceHistory.update({ where: { id: existing.id }, data: { amountUsedCents: { increment: cents }, remainingAfterCents: remainingCents } });
      else await tx.balanceHistory.create({ data: { customerId, amountUsedCents: cents, remainingAfterCents: remainingCents, note: rollupNote, updatedBy } });
    } else {
      const existing = await tx.bonusHistory.findFirst({ where });
      if (existing) await tx.bonusHistory.update({ where: { id: existing.id }, data: { amountUsedCents: { increment: cents }, remainingAfterCents: remainingCents } });
      else await tx.bonusHistory.create({ data: { customerId, amountUsedCents: cents, remainingAfterCents: remainingCents, note: rollupNote, updatedBy } });
    }
    return;
  }
  const data = { customerId, amountUsedCents: cents, remainingAfterCents: remainingCents, note, updatedBy };
  if (pot === "BALANCE") await tx.balanceHistory.create({ data });
  else await tx.bonusHistory.create({ data });
}

/**
 * Low-balance threshold read through the transaction's own connection. Using
 * the global client here would need a second pool connection per open
 * transaction and deadlocks the pool under parallel settlements.
 */
async function thresholdVia(tx: Tx, storeId: string): Promise<number> {
  const row = await tx.setting.findUnique({ where: { storeId_key: { storeId, key: SETTING_KEYS.lowBalanceThresholdCents } }, select: { value: true } });
  const parsed = parseInt(row?.value ?? DEFAULT_SETTINGS[SETTING_KEYS.lowBalanceThresholdCents], 10);
  return Number.isFinite(parsed) && parsed >= 0 ? parsed : 1000;
}

async function loadForMutation(tx: Tx, customerId: string): Promise<{ customer: Customer; threshold: number }> {
  const customer = await tx.customer.findUniqueOrThrow({ where: { id: customerId } });
  const threshold = await thresholdVia(tx, customer.storeId);
  return { customer, threshold };
}

async function replayIfSeen(tx: Tx, key: string, customerId: string): Promise<MoneyResult | null> {
  const existing = await tx.ledgerEntry.findUnique({ where: { idempotencyKey: key } });
  if (!existing) return null;
  const customer = await tx.customer.findUniqueOrThrow({ where: { id: customerId } });
  return { customer, entry: existing, replayed: true, appliedMicroUsd: existing.amountMicroUsd, uncollectedMicroUsd: 0n, justFinished: false };
}

async function afterCommit(result: MoneyResult, ownsTx: boolean, via: string): Promise<void> {
  if (!ownsTx || !result.justFinished) return;
  await logActivity({
    storeId: result.customer.storeId as StoreId,
    action: "CUSTOMER_FINISHED",
    description: `Customer ${result.customer.accessCode} has fully consumed their balance (${via})`,
    customerId: result.customer.id,
  });
}

// ─── Public API ────────────────────────────────────────────────────────────

/** Add whole-cent credit to a pot. */
export async function credit(input: MoneyInput): Promise<MoneyResult> {
  if (input.amountMicroUsd <= 0n) throw new RangeError("Credit amount must be positive.");
  requireNote(input.type, input.note);
  const result = await withTx(input.tx, async (tx) => {
    await lockCustomer(tx, input.customerId);
    const seen = await replayIfSeen(tx, input.idempotencyKey, input.customerId);
    if (seen) return seen;
    const { customer, threshold } = await loadForMutation(tx, input.customerId);
    const r = await movePot(tx, customer, threshold, {
      pot: input.pot,
      deltaMicroUsd: input.amountMicroUsd,
      type: input.type,
      idempotencyKey: input.idempotencyKey,
      ref: input.ref,
      actor: input.actor,
      note: input.note ?? "",
      history: input.history ?? "row",
    });
    return { customer: r.customer, entry: r.entry, replayed: false, appliedMicroUsd: r.applied, uncollectedMicroUsd: 0n, justFinished: r.justFinished };
  });
  await afterCommit(result, !input.tx, input.type.toLowerCase());
  return result;
}

/** Take up to `amountMicroUsd` from a pot; never below zero. */
export async function debit(input: MoneyInput): Promise<MoneyResult> {
  if (input.amountMicroUsd <= 0n) throw new RangeError("Debit amount must be positive.");
  requireNote(input.type, input.note);
  const result = await withTx(input.tx, async (tx) => {
    await lockCustomer(tx, input.customerId);
    const seen = await replayIfSeen(tx, input.idempotencyKey, input.customerId);
    if (seen) return seen;
    const { customer, threshold } = await loadForMutation(tx, input.customerId);
    const r = await movePot(tx, customer, threshold, {
      pot: input.pot,
      deltaMicroUsd: -input.amountMicroUsd,
      type: input.type,
      idempotencyKey: input.idempotencyKey,
      ref: input.ref,
      actor: input.actor,
      note: input.note ?? "",
      history: input.history ?? "row",
    });
    return { customer: r.customer, entry: r.entry, replayed: false, appliedMicroUsd: r.applied, uncollectedMicroUsd: r.uncollected, justFinished: r.justFinished };
  });
  await afterCommit(result, !input.tx, input.type.toLowerCase());
  return result;
}

export interface UsageChargeInput {
  customerId: string;
  /** Positive customer-priced amount. */
  amountMicroUsd: bigint;
  /** Bonus µ$ per balance µ$ (the plan's bonus rate / its rate); default 1/1. */
  bonusConversion?: BonusConversion;
  /** Real provider cost behind `amountMicroUsd`, to attribute the bonus's share of it. */
  realCostMicroUsd?: bigint;
  /** Base key; `:BALANCE` / `:BONUS` are appended per pot. */
  idempotencyKey: string;
  ref?: LedgerRef;
  actor: Actor;
  note?: string;
  tx?: Tx;
  history?: HistoryMode;
}

export interface UsageChargeResult extends PotSplit {
  /** Share of `realCostMicroUsd` the bonus paid for (0 on replays and without a real cost). */
  bonusRealMicroUsd: bigint;
  customer: Customer;
  entries: LedgerEntry[];
  replayed: boolean;
  justFinished: boolean;
}

/**
 * Charge usage across both pots, balance first (bonus only once the balance is empty). Idempotent per key.
 * The bonus pot pays at its own rate when `bonusConversion` says so (see splitUsageMicroUsd).
 * Whatever neither pot can cover is returned as `uncollectedMicroUsd` (customer-priced).
 */
export async function chargeUsage(input: UsageChargeInput): Promise<UsageChargeResult> {
  if (input.amountMicroUsd < 0n) throw new RangeError("Usage amount cannot be negative.");
  const keyBalance = `${input.idempotencyKey}:BALANCE`;
  const keyBonus = `${input.idempotencyKey}:BONUS`;
  const history = input.history ?? "row";
  const note = input.note ?? "API usage";

  const result = await withTx(input.tx, async (tx): Promise<UsageChargeResult> => {
    await lockCustomer(tx, input.customerId);
    const prior = await tx.ledgerEntry.findMany({ where: { idempotencyKey: { in: [keyBalance, keyBonus] } } });
    if (prior.length > 0) {
      const customer = await tx.customer.findUniqueOrThrow({ where: { id: input.customerId } });
      const bal = prior.find((e) => e.pot === "BALANCE")?.amountMicroUsd ?? 0n;
      const bon = prior.find((e) => e.pot === "BONUS")?.amountMicroUsd ?? 0n;
      return { customer, entries: prior, replayed: true, balanceMicroUsd: -bal, bonusMicroUsd: -bon, bonusCoveredMicroUsd: 0n, bonusRealMicroUsd: 0n, uncollectedMicroUsd: 0n, justFinished: false };
    }

    const { customer, threshold } = await loadForMutation(tx, input.customerId);
    if (input.amountMicroUsd === 0n) {
      return { customer, entries: [], replayed: false, balanceMicroUsd: 0n, bonusMicroUsd: 0n, bonusCoveredMicroUsd: 0n, bonusRealMicroUsd: 0n, uncollectedMicroUsd: 0n, justFinished: false };
    }
    const split = splitUsageMicroUsd(
      input.amountMicroUsd,
      potAvailableMicroUsd(customer, "BALANCE"),
      potAvailableMicroUsd(customer, "BONUS"),
      input.bonusConversion ?? SAME_RATE
    );
    const bonusRealMicroUsd =
      input.realCostMicroUsd && input.realCostMicroUsd > 0n ? mulDiv(input.realCostMicroUsd, split.bonusCoveredMicroUsd, input.amountMicroUsd) : 0n;

    const entries: LedgerEntry[] = [];
    let current = customer;
    let justFinished = false;
    const steps: Array<[Pot, bigint, string]> = [
      ["BONUS", split.bonusMicroUsd, keyBonus],
      ["BALANCE", split.balanceMicroUsd, keyBalance],
    ];
    for (const [pot, amount, key] of steps) {
      if (amount <= 0n) continue;
      const r = await movePot(tx, current, threshold, {
        pot,
        deltaMicroUsd: -amount,
        type: "USAGE",
        idempotencyKey: key,
        ref: input.ref,
        actor: input.actor,
        note,
        history,
      });
      current = r.customer;
      if (r.entry) entries.push(r.entry);
      justFinished ||= r.justFinished;
    }
    return { customer: current, entries, replayed: false, ...split, bonusRealMicroUsd, justFinished };
  });

  if (!input.tx && result.justFinished) {
    await logActivity({
      storeId: result.customer.storeId as StoreId,
      action: "CUSTOMER_FINISHED",
      description: `Customer ${result.customer.accessCode} has fully consumed their balance (${input.actor.label})`,
      customerId: result.customer.id,
    });
  }
  return result;
}

export interface AdjustInput {
  customerId: string;
  pot: Pot;
  /** Signed, whole cents when positive. */
  deltaMicroUsd: bigint;
  idempotencyKey: string;
  actor: Actor;
  /** Mandatory: why the admin changed the number. */
  note: string;
  ref?: LedgerRef;
  tx?: Tx;
}

/** Manual admin correction in either direction, always with a reason. */
export async function adjust(input: AdjustInput): Promise<MoneyResult> {
  const base = {
    customerId: input.customerId,
    pot: input.pot,
    type: "ADMIN_ADJUSTMENT" as const,
    idempotencyKey: input.idempotencyKey,
    ref: input.ref,
    actor: input.actor,
    note: input.note,
    tx: input.tx,
  };
  if (input.deltaMicroUsd === 0n) {
    const customer = await (input.tx ?? prisma).customer.findUniqueOrThrow({ where: { id: input.customerId } });
    return { customer, entry: null, replayed: false, appliedMicroUsd: 0n, uncollectedMicroUsd: 0n, justFinished: false };
  }
  return input.deltaMicroUsd > 0n
    ? credit({ ...base, amountMicroUsd: input.deltaMicroUsd })
    : debit({ ...base, amountMicroUsd: -input.deltaMicroUsd });
}

/** Take back previously granted credit (refund dispute, revoked bonus). Never below zero. */
export async function clawback(input: Omit<MoneyInput, "type">): Promise<MoneyResult> {
  return debit({ ...input, type: "CLAWBACK" });
}

/** Give money back (e.g. an admin removed a usage log). */
export async function refund(input: Omit<MoneyInput, "type">): Promise<MoneyResult> {
  return credit({ ...input, type: "REFUND" });
}

// ─── Reconciliation ─────────────────────────────────────────────────────────

export interface PotCheck {
  pot: Pot;
  ledgerMicroUsd: bigint;
  cachedMicroUsd: bigint;
  driftMicroUsd: bigint;
}

/** Compare the ledger with the cached fields; drift ≠ 0 means a bug or an unledgered write. */
export async function verifyCustomerLedger(customerId: string, db: Db = prisma): Promise<{ ok: boolean; pots: PotCheck[] }> {
  const customer = await db.customer.findUniqueOrThrow({ where: { id: customerId } });
  const sums = await db.ledgerEntry.groupBy({ by: ["pot"], where: { customerId }, _sum: { amountMicroUsd: true } });
  const pots = POTS.map((pot) => {
    const ledger = sums.find((s) => s.pot === pot)?._sum.amountMicroUsd ?? 0n;
    const cached = potAvailableMicroUsd(customer, pot);
    return { pot, ledgerMicroUsd: ledger, cachedMicroUsd: cached, driftMicroUsd: cached - ledger };
  });
  return { ok: pots.every((p) => p.driftMicroUsd === 0n), pots };
}

export function describeDrift(check: { pots: PotCheck[] }): string {
  return check.pots.map((p) => `${p.pot}: ledger ${formatMicroUsd(p.ledgerMicroUsd)} vs cached ${formatMicroUsd(p.cachedMicroUsd)}`).join("; ");
}
