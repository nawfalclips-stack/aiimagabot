// Worst-case cost estimate for a gateway request, used to size the hold a
// reservation takes before the request is forwarded (WS2). Client-safe.
//
// Deliberately conservative: input is counted at ~3 bytes per token (real
// tokenisers average 3.5–4 for English, less for code and other scripts),
// output at the full max_tokens, and a safety margin is added on top.
// The pricing itself is the engine's (lib/billing/pricing-engine.ts).

import { estimateHold, maxOutputTokensAffordable as affordable, type BillingRate, type ModelPrices } from "@/lib/billing/pricing-engine";

const encoder = new TextEncoder();

/** ceil(utf8 bytes / 3) of the request's textual content. */
export function estimateInputTokens(parts: unknown[]): number {
  let bytes = 0;
  for (const part of parts) {
    if (part === undefined || part === null) continue;
    bytes += encoder.encode(typeof part === "string" ? part : JSON.stringify(part)).length;
  }
  return Math.max(1, Math.ceil(bytes / 3));
}

export type HoldPricing = ModelPrices;

export interface HoldParams {
  rate: BillingRate;
  model: HoldPricing;
  inputTokens: number;
  outputTokens: number;
  /** e.g. 5 → +5 %. */
  marginPct: number;
  minHoldMicroUsd: bigint;
}

/** Customer-priced worst case, in micro-USD. */
export function estimateHoldMicroUsd(p: HoldParams): bigint {
  return estimateHold(p.rate, p.model, { inputTokens: p.inputTokens, outputTokens: p.outputTokens, marginPct: p.marginPct, minHoldMicroUsd: p.minHoldMicroUsd });
}

/**
 * Largest `max_tokens` whose hold fits in `availableMicroUsd`, or 0 when even
 * the input alone does not fit. Used by fit-to-balance.
 */
export function maxOutputTokensAffordable(p: Omit<HoldParams, "outputTokens"> & { availableMicroUsd: bigint }): number {
  return affordable(p.rate, p.model, { inputTokens: p.inputTokens, marginPct: p.marginPct, availableMicroUsd: p.availableMicroUsd });
}
