// Money units. Client-safe: no server imports.
//
// Customer credit is held in two pots (BALANCE, BONUS). The ledger and every
// gateway amount are BigInt micro-USD (1 USD = 1_000_000 µ$). The cached
// columns on Customer are integer cents plus a per-pot sub-cent carry:
//
//   available(pot) µ$ = (initialXCents − usedXCents) × 10_000 − xCarryMicroUsd
//
// Credits are always whole cents; debits may be fractional — the fraction
// accumulates in the carry until it reaches a cent.

import { mulDiv, SAME_RATE, type BonusConversion } from "@/lib/billing/pricing-engine";

export const MICRO_PER_CENT = 10_000n;
export const MICRO_PER_USD = 1_000_000n;

export type Pot = "BALANCE" | "BONUS";
export const POTS: readonly Pot[] = ["BALANCE", "BONUS"] as const;

export const LEDGER_TYPES = [
  "OPENING_BALANCE",
  "ORDER_ACTIVATION",
  "RECHARGE",
  "VOUCHER_REDEMPTION",
  "USAGE",
  "REVIEW_BONUS",
  "AFFILIATE_REWARD",
  "LOYALTY_REWARD",
  "PROMO_BONUS",
  "PLAN_BONUS",
  "REFUND",
  "CLAWBACK",
  "ADMIN_ADJUSTMENT",
  "EXPIRY",
  "RESTORE",
] as const;
export type LedgerType = (typeof LEDGER_TYPES)[number];

/** Ledger types that must carry a human-written reason. */
export const NOTE_REQUIRED: ReadonlySet<LedgerType> = new Set<LedgerType>(["ADMIN_ADJUSTMENT", "CLAWBACK"]);

export function centsToMicro(cents: number): bigint {
  if (!Number.isInteger(cents)) throw new RangeError(`cents must be an integer, got ${cents}`);
  return BigInt(cents) * MICRO_PER_CENT;
}

export function usdToMicro(usd: number): bigint {
  return BigInt(Math.round(usd * 1_000_000));
}

/** Whole cents contained in a micro-USD amount (truncates toward zero). */
export function microToCents(micro: bigint): number {
  return Number(micro / MICRO_PER_CENT);
}

export function microToUsd(micro: bigint): number {
  return Number(micro) / 1_000_000;
}

/** "$12.34" / "$0.0012" — cents when whole, up to 4 decimals otherwise. */
export function formatMicroUsd(micro: bigint): string {
  const neg = micro < 0n;
  const abs = neg ? -micro : micro;
  const usd = Number(abs) / 1_000_000;
  const text = abs % MICRO_PER_CENT === 0n ? usd.toFixed(2) : usd.toFixed(4).replace(/0+$/, "");
  return `${neg ? "−" : ""}$${text}`;
}

export interface PotFields {
  initialBalanceCents: number;
  usedBalanceCents: number;
  initialBonusCents: number;
  usedBonusCents: number;
  balanceCarryMicroUsd: bigint;
  bonusCarryMicroUsd: bigint;
}

export function potAvailableMicroUsd(c: PotFields, pot: Pot): bigint {
  return pot === "BALANCE"
    ? centsToMicro(c.initialBalanceCents - c.usedBalanceCents) - c.balanceCarryMicroUsd
    : centsToMicro(c.initialBonusCents - c.usedBonusCents) - c.bonusCarryMicroUsd;
}

export function totalAvailableMicroUsd(c: PotFields): bigint {
  return potAvailableMicroUsd(c, "BALANCE") + potAvailableMicroUsd(c, "BONUS");
}

/** What a gateway request may still spend: available minus what other in-flight requests hold. */
export function spendableMicroUsd(c: PotFields & { reservedMicroUsd: bigint }): bigint {
  return totalAvailableMicroUsd(c) - c.reservedMicroUsd;
}

export interface PotSplit {
  /** Debited from the BALANCE pot. */
  balanceMicroUsd: bigint;
  /** Debited from the BONUS pot (bonus units: × the bonus conversion). */
  bonusMicroUsd: bigint;
  /** Part of the customer-priced amount the bonus paid for (= bonusMicroUsd at the same rate). */
  bonusCoveredMicroUsd: bigint;
  /** Customer-priced amount neither pot could cover. */
  uncollectedMicroUsd: bigint;
}

/**
 * Balance-first rule for a usage charge: the BALANCE pot pays everything it
 * can; the BONUS pot only pays what the balance cannot cover (so bonus is
 * spent once the balance reaches zero); whatever neither pot can cover is
 * uncollected. Never negative.
 *
 * `amount` is priced at the plan (balance) rate. When the plan gives the bonus
 * its own rate, the bonus pot pays the remainder × `conversion`
 * (bonusRate / balanceRate) — e.g. ×4: $1 the balance could not cover costs
 * $4 of bonus.
 *
 * Example: $100 plan, request charged $25 → balance $100 → $75, bonus untouched.
 */
export function splitUsageMicroUsd(
  amount: bigint,
  balanceAvailable: bigint,
  bonusAvailable: bigint,
  conversion: BonusConversion = SAME_RATE
): PotSplit {
  if (amount <= 0n) return { balanceMicroUsd: 0n, bonusMicroUsd: 0n, bonusCoveredMicroUsd: 0n, uncollectedMicroUsd: 0n };
  const bal = balanceAvailable > 0n ? balanceAvailable : 0n;
  const bon = bonusAvailable > 0n ? bonusAvailable : 0n;
  const balance = min(amount, bal);
  const rest = amount - balance;
  const needed = mulDiv(rest, conversion.num, conversion.den);
  if (needed <= bon) {
    return { balanceMicroUsd: balance, bonusMicroUsd: needed, bonusCoveredMicroUsd: rest, uncollectedMicroUsd: 0n };
  }
  // The bonus runs out: it covers what it can at its rate (rounded down), the rest is uncollected.
  const covered = min((bon * conversion.den) / conversion.num, rest);
  return { balanceMicroUsd: balance, bonusMicroUsd: bon, bonusCoveredMicroUsd: covered, uncollectedMicroUsd: rest - covered };
}

export function isSameRate(c: BonusConversion): boolean {
  return c.num === c.den;
}

/**
 * A customer-priced hold expressed in pot µ$ (what reserve() compares with
 * balance + bonus): the part the free balance covers as is, the rest at the
 * bonus rate. `balanceFree` = balance available minus other holds.
 */
export function pricedToPotMicroUsd(priced: bigint, balanceFree: bigint, conversion: BonusConversion): bigint {
  if (priced <= 0n) return 0n;
  const fromBalance = min(priced, balanceFree > 0n ? balanceFree : 0n);
  return fromBalance + mulDiv(priced - fromBalance, conversion.num, conversion.den);
}

/** Inverse of pricedToPotMicroUsd: how much customer-priced usage `pot` µ$ of spendable credit buys. */
export function potToPricedMicroUsd(pot: bigint, balanceFree: bigint, conversion: BonusConversion): bigint {
  if (pot <= 0n) return 0n;
  const fromBalance = min(pot, balanceFree > 0n ? balanceFree : 0n);
  return fromBalance + ((pot - fromBalance) * conversion.den) / conversion.num;
}

function min(a: bigint, b: bigint): bigint {
  return a < b ? a : b;
}

