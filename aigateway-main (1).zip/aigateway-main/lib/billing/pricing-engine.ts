// The one pricing engine (WS8). Converts provider cost or normalised usage
// into what the customer pays, in micro-USD, for any plan mode — so the
// reservation hold, the settlement charge and every displayed price agree.
//
// Client-safe, exact integer arithmetic (BigInt), never floats on money:
//
//   CREDITS (USD plans / global multiplier)
//     charge = providerCost × price / limitUsage          (rational multiplier)
//     A cached-input discount from the provider passes through proportionally
//     because it is already inside providerCost.
//
//   TOKENS plans
//     charge = weightedTokens × price / includedTokens     (flat µ$ per token)
//     weightedTokens = uncached input + cache writes + output + reasoning
//                    + cached input × cachedTokenWeightPct / 100
//
// Rounding: half-up to the micro-dollar.

import type { PlanLike } from "@/lib/plan-usage";

/** A rate is a rational number: multiplier (dimensionless) or µ$ per token. */
export type BillingRate =
  | { kind: "multiplier"; num: bigint; den: bigint }
  | { kind: "perToken"; num: bigint; den: bigint };

export interface ModelPrices {
  inputPriceMicroPerMTok: number;
  outputPriceMicroPerMTok: number;
  cachedInputPriceMicroPerMTok?: number | null;
  cacheWritePriceMicroPerMTok?: number | null;
}

export interface UsageComponents {
  inputUncached: bigint;
  inputCached: bigint;
  cacheWrite: bigint;
  output: bigint;
  reasoning: bigint;
}

const MTOK = 1_000_000n;

/** a × num / den, rounded half-up. */
export function mulDiv(a: bigint, num: bigint, den: bigint): bigint {
  if (den <= 0n) throw new Error("pricing: zero denominator");
  const p = a * num;
  const q = p / den;
  const r = p - q * den;
  return r * 2n >= den ? q + 1n : q;
}

/** Exact rational from a decimal such as 2.2 or "2.25" (no floating-point drift). */
export function rateFromMultiplier(multiplier: number | string): BillingRate {
  const text = typeof multiplier === "number" ? multiplier.toString() : multiplier.trim();
  const m = /^(\d+)(?:\.(\d+))?(?:e-(\d+))?$/i.exec(text);
  if (!m) throw new Error(`pricing: invalid multiplier ${text}`);
  const frac = m[2] ?? "";
  const exp = Number(m[3] ?? 0);
  return {
    kind: "multiplier",
    num: BigInt(m[1] + frac),
    den: 10n ** BigInt(frac.length + exp),
  };
}

/** The rate a plan bills at, or null when the plan is misconfigured (zero limit). */
export function rateFromPlan(plan: PlanLike): BillingRate | null {
  if (plan.priceCents <= 0) return null;
  if (plan.limitType === "TOKENS") {
    if (plan.limitMTokens <= 0) return null;
    // µ$ per token = priceCents × 10 000 / (limitMTokens × 1 000 000)
    return { kind: "perToken", num: BigInt(plan.priceCents) * 10_000n, den: BigInt(plan.limitMTokens) * MTOK };
  }
  if (plan.limitUsageCents <= 0) return null;
  return { kind: "multiplier", num: BigInt(plan.priceCents), den: BigInt(plan.limitUsageCents) };
}

/**
 * The rate the BONUS pot bills at, or null when the plan gives the bonus no
 * value of its own (bonus or bonus limit is 0) — the bonus then bills at the
 * plan rate. Same units as rateFromPlan, so the two compare directly.
 */
export function bonusRateFromPlan(plan: PlanLike): BillingRate | null {
  const bonus = plan.bonusCents ?? 0;
  if (bonus <= 0) return null;
  if (plan.limitType === "TOKENS") {
    const mtok = plan.bonusLimitMTokens ?? 0;
    if (mtok <= 0) return null;
    return { kind: "perToken", num: BigInt(bonus) * 10_000n, den: BigInt(mtok) * MTOK };
  }
  const usage = plan.bonusLimitUsageCents ?? 0;
  if (usage <= 0) return null;
  return { kind: "multiplier", num: BigInt(bonus), den: BigInt(usage) };
}

/** Pot-to-pot factor: bonus µ$ debited per balance-rate µ$ of usage (bonusRate / balanceRate). */
export interface BonusConversion {
  num: bigint;
  den: bigint;
}

export const SAME_RATE: BonusConversion = { num: 1n, den: 1n };

/**
 * How much more (or less) the bonus pot pays than the balance pot for the
 * same usage. 1/1 without a plan, a valid plan rate or a bonus rate.
 */
export function bonusConversion(plan: PlanLike | null | undefined): BonusConversion {
  if (!plan) return SAME_RATE;
  const base = rateFromPlan(plan);
  const bonus = bonusRateFromPlan(plan);
  if (!base || !bonus || base.kind !== bonus.kind) return SAME_RATE;
  // (bonus.num / bonus.den) / (base.num / base.den)
  const num = bonus.num * base.den;
  const den = bonus.den * base.num;
  const g = gcd(num, den);
  return { num: num / g, den: den / g };
}

function gcd(a: bigint, b: bigint): bigint {
  while (b > 0n) [a, b] = [b, a % b];
  return a > 0n ? a : 1n;
}

/** Float view of a rate for display only (never for money). */
export function rateToNumber(rate: BillingRate): number {
  return Number(rate.num) / Number(rate.den);
}

/** Provider list price for a usage breakdown, in µ$ (our own price list). */
export function providerCostMicroUsd(model: ModelPrices, usage: UsageComponents): bigint {
  const cachedPrice = model.cachedInputPriceMicroPerMTok ?? model.inputPriceMicroPerMTok;
  const writePrice = model.cacheWritePriceMicroPerMTok ?? 0;
  const total =
    usage.inputUncached * BigInt(model.inputPriceMicroPerMTok) +
    usage.inputCached * BigInt(cachedPrice) +
    usage.cacheWrite * BigInt(writePrice) +
    (usage.output + usage.reasoning) * BigInt(model.outputPriceMicroPerMTok);
  return mulDiv(total, 1n, MTOK);
}

/** Weighted token count for TOKENS plans. */
export function weightedTokens(usage: UsageComponents, cachedTokenWeightPct: number): bigint {
  const pct = BigInt(Math.max(0, Math.round(cachedTokenWeightPct)));
  return usage.inputUncached + usage.cacheWrite + usage.output + usage.reasoning + mulDiv(usage.inputCached, pct, 100n);
}

/**
 * What the customer pays for one request, in µ$.
 * `providerCost` is the figure we settle on (provider-reported when present,
 * else our list price); TOKENS plans ignore it.
 */
export function quote(
  rate: BillingRate,
  model: ModelPrices,
  usage: UsageComponents,
  opts: { providerCostMicroUsd?: bigint; cachedTokenWeightPct?: number } = {}
): bigint {
  if (rate.kind === "perToken") return mulDiv(weightedTokens(usage, opts.cachedTokenWeightPct ?? 100), rate.num, rate.den);
  const cost = opts.providerCostMicroUsd ?? providerCostMicroUsd(model, usage);
  return mulDiv(cost, rate.num, rate.den);
}

export interface HoldEstimate {
  inputTokens: number;
  outputTokens: number;
  /** e.g. 5 → +5 %. */
  marginPct: number;
  minHoldMicroUsd: bigint;
}

/** Worst-case customer price of a request before it is sent, in µ$. */
export function estimateHold(rate: BillingRate, model: ModelPrices, e: HoldEstimate): bigint {
  const usage: UsageComponents = { inputUncached: BigInt(e.inputTokens), inputCached: 0n, cacheWrite: 0n, output: BigInt(e.outputTokens), reasoning: 0n };
  const base = quote(rate, model, usage);
  const pct = BigInt(Math.max(0, Math.round(e.marginPct)));
  const withMargin = base + mulDiv(base, pct, 100n);
  return withMargin > e.minHoldMicroUsd ? withMargin : e.minHoldMicroUsd;
}

/**
 * Largest `max_tokens` whose hold fits in `availableMicroUsd`, or 0 when even
 * the input alone does not fit (fit-to-balance).
 */
export function maxOutputTokensAffordable(
  rate: BillingRate,
  model: ModelPrices,
  p: { inputTokens: number; marginPct: number; availableMicroUsd: bigint }
): number {
  const pct = BigInt(Math.max(0, Math.round(p.marginPct)));
  const budget = mulDiv(p.availableMicroUsd, 100n, 100n + pct);
  const inputOnly = estimateHold(rate, model, { inputTokens: p.inputTokens, outputTokens: 0, marginPct: 0, minHoldMicroUsd: 0n });
  const remaining = budget - inputOnly;
  if (remaining <= 0n) return 0;
  const perMillion = estimateHold(rate, model, { inputTokens: 0, outputTokens: 1_000_000, marginPct: 0, minHoldMicroUsd: 0n });
  if (perMillion <= 0n) return Number.MAX_SAFE_INTEGER;
  return Number((remaining * MTOK) / perMillion);
}

export interface EffectivePrices {
  /** µ$ per 1M tokens the customer pays. */
  inputMicroPerMTok: bigint;
  cachedInputMicroPerMTok: bigint;
  outputMicroPerMTok: bigint;
}

/** Customer-facing prices per 1M tokens for a model (API Access page, catalog). */
export function effectivePrices(rate: BillingRate, model: ModelPrices, cachedTokenWeightPct = 100): EffectivePrices {
  const one = (u: Partial<UsageComponents>) =>
    quote(rate, model, { inputUncached: 0n, inputCached: 0n, cacheWrite: 0n, output: 0n, reasoning: 0n, ...u }, { cachedTokenWeightPct });
  return {
    inputMicroPerMTok: one({ inputUncached: MTOK }),
    cachedInputMicroPerMTok: one({ inputCached: MTOK }),
    outputMicroPerMTok: one({ output: MTOK }),
  };
}

/** µ$ per MTok → cents per MTok (display). */
export function microPerMTokToCents(micro: bigint): number {
  return Number(mulDiv(micro, 1n, 10_000n));
}
