import "server-only";
import type { GatewayReservation, Prisma } from "@prisma/client";
import { prisma } from "@/lib/prisma";
import { chargeUsage, ConcurrentUpdateError, lockCustomer, TX_OPTIONS, type Actor, type LedgerRef, type Tx, type UsageChargeResult } from "@/lib/billing/balance-service";
import type { BonusConversion } from "@/lib/billing/pricing-engine";
import { getCustomerBillingRate } from "@/lib/services/plan-usage";
import { createNotification, NOTIFICATION_TYPES } from "@/lib/services/notifications";
import type { StoreId } from "@/lib/store";

/**
 * Reserve-then-settle for gateway requests (WS2).
 *
 *   reserve()  — one atomic UPDATE holds the worst-case cost against
 *                balance + bonus − reserved. Two requests can never both see
 *                the same free amount.
 *   settle()   — flips HELD → SETTLED exactly once, releases the hold and
 *                charges the real cost through the balance service.
 *   release()  — HELD → RELEASED/EXPIRED without a charge.
 *   sweep()    — the cron path for holds whose function died mid-request.
 */

export type ReservationMode = "off" | "shadow" | "enforce";

export function reservationMode(): ReservationMode {
  const v = (process.env.GATEWAY_RESERVATIONS ?? "shadow").toLowerCase();
  return v === "off" || v === "enforce" ? v : "shadow";
}

export type ReserveResult =
  | { ok: true; reservation: GatewayReservation }
  | { ok: false; spendableMicroUsd: bigint };

export interface ReserveInput {
  requestId: string;
  customerId: string;
  storeId: StoreId;
  holdMicroUsd: bigint;
  model: string;
  expiresAt: Date;
  mode: Exclude<ReservationMode, "off">;
}

/** Atomic check-and-hold. In shadow mode the row is written but nothing is held. */
export async function reserve(input: ReserveInput): Promise<ReserveResult> {
  const hold = input.holdMicroUsd > 0n ? input.holdMicroUsd : 0n;
  return prisma.$transaction(async (tx) => {
    let held = 0n;
    if (input.mode === "enforce") {
      // Portable SQL (Postgres + SQLite). CAST keeps the cents×10 000 product
      // out of 32-bit range on Postgres.
      const rows = await tx.$executeRaw`
        UPDATE "Customer"
           SET "reservedMicroUsd" = "reservedMicroUsd" + ${hold}
         WHERE "id" = ${input.customerId}
           AND (CAST(("initialBalanceCents" - "usedBalanceCents" + "initialBonusCents" - "usedBonusCents") AS BIGINT) * 10000
                - "balanceCarryMicroUsd" - "bonusCarryMicroUsd" - "reservedMicroUsd") >= ${hold}`;
      if (rows !== 1) {
        const c = await tx.customer.findUniqueOrThrow({
          where: { id: input.customerId },
          select: { initialBalanceCents: true, usedBalanceCents: true, initialBonusCents: true, usedBonusCents: true, balanceCarryMicroUsd: true, bonusCarryMicroUsd: true, reservedMicroUsd: true },
        });
        const spendable =
          BigInt(c.initialBalanceCents - c.usedBalanceCents + c.initialBonusCents - c.usedBonusCents) * 10_000n -
          c.balanceCarryMicroUsd -
          c.bonusCarryMicroUsd -
          c.reservedMicroUsd;
        return { ok: false, spendableMicroUsd: spendable };
      }
      held = hold;
    }
    const reservation = await tx.gatewayReservation.create({
      data: {
        id: input.requestId,
        storeId: input.storeId,
        customerId: input.customerId,
        amountMicroUsd: held,
        status: "HELD",
        mode: input.mode,
        model: input.model,
        expiresAt: input.expiresAt,
      },
    });
    return { ok: true, reservation };
  }, TX_OPTIONS);
}

export interface SettleInput {
  reservationId: string;
  /** Customer-priced real charge. */
  chargeMicroUsd: bigint;
  /** The bonus pot's rate relative to the balance's (the customer's plan); default 1/1. */
  bonusConversion?: BonusConversion;
  /** Real provider cost behind the charge, to attribute the bonus's share. */
  realCostMicroUsd?: bigint;
  ref?: LedgerRef;
  actor: Actor;
  note?: string;
  /** Extra writes to perform in the same transaction (e.g. the UsageLog), given the charge. */
  also?: (tx: Tx, charge: UsageChargeResult) => Promise<void>;
}

export type SettleResult =
  | { status: "settled"; balanceMicroUsd: bigint; bonusMicroUsd: bigint; bonusRealMicroUsd: bigint; uncollectedMicroUsd: bigint; justFinished: boolean }
  | { status: "already-settled"; reservation: GatewayReservation }
  | { status: "not-found" };

/** Idempotent: the HELD → SETTLED flip is the lock; a second call is a no-op. */
export async function settle(input: SettleInput): Promise<SettleResult> {
  for (let attempt = 1; ; attempt++) {
    try {
      return await prisma.$transaction(async (tx): Promise<SettleResult> => {
        const existing = await tx.gatewayReservation.findUnique({ where: { id: input.reservationId } });
        if (!existing) return { status: "not-found" };
        await lockCustomer(tx, existing.customerId);
        const flipped = await tx.gatewayReservation.updateMany({
          where: { id: input.reservationId, status: "HELD" },
          data: { status: "SETTLED", settledAt: new Date(), chargedMicroUsd: input.chargeMicroUsd },
        });
        if (flipped.count === 0) return { status: "already-settled", reservation: existing };

        if (existing.amountMicroUsd > 0n) {
          await tx.customer.update({
            where: { id: existing.customerId },
            data: { reservedMicroUsd: { decrement: existing.amountMicroUsd } },
          });
        }
        const charge = await chargeUsage({
          customerId: existing.customerId,
          amountMicroUsd: input.chargeMicroUsd,
          bonusConversion: input.bonusConversion,
          realCostMicroUsd: input.realCostMicroUsd,
          idempotencyKey: `usage:${existing.id}`,
          ref: input.ref,
          actor: input.actor,
          note: input.note,
          history: "daily-rollup",
          tx,
        });
        if (input.also) await input.also(tx, charge);
        return {
          status: "settled",
          balanceMicroUsd: charge.balanceMicroUsd,
          bonusMicroUsd: charge.bonusMicroUsd,
          bonusRealMicroUsd: charge.bonusRealMicroUsd,
          uncollectedMicroUsd: charge.uncollectedMicroUsd,
          justFinished: charge.justFinished,
        };
      }, TX_OPTIONS);
    } catch (e) {
      if (e instanceof ConcurrentUpdateError && attempt < 5) continue;
      throw e;
    }
  }
}

/** Drop a hold without charging (request failed before any bytes were sent, or expired). */
export async function release(reservationId: string, as: "RELEASED" | "EXPIRED" = "RELEASED"): Promise<boolean> {
  return prisma.$transaction(async (tx) => {
    const existing = await tx.gatewayReservation.findUnique({ where: { id: reservationId } });
    if (!existing) return false;
    const flipped = await tx.gatewayReservation.updateMany({
      where: { id: reservationId, status: "HELD" },
      data: { status: as, settledAt: new Date(), chargedMicroUsd: 0n },
    });
    if (flipped.count === 0) return false;
    if (existing.amountMicroUsd > 0n) {
      await tx.customer.update({
        where: { id: existing.customerId },
        data: { reservedMicroUsd: { decrement: existing.amountMicroUsd } },
      });
    }
    return true;
  }, TX_OPTIONS);
}

/** Where `also` callbacks write the UsageLog; kept here so the type is shared. */
export type UsageLogWrite = Prisma.UsageLogUncheckedCreateInput;

export interface SweepResult {
  expired: string[];
  settledFromLog: string[];
}

/**
 * Release holds still HELD past `expiresAt`. If a UsageLog already exists for
 * the request (settlement wrote it but died before the flip committed — which
 * cannot happen with the single transaction above, but is cheap to honour),
 * settle from it instead. Raises one admin notification per store per run.
 */
export async function sweepExpiredReservations(now = new Date()): Promise<SweepResult> {
  const stale = await prisma.gatewayReservation.findMany({
    where: { status: "HELD", expiresAt: { lt: now } },
    take: 500,
    orderBy: { expiresAt: "asc" },
  });
  const result: SweepResult = { expired: [], settledFromLog: [] };
  const perStore = new Map<string, number>();

  for (const r of stale) {
    const log = await prisma.usageLog.findFirst({ where: { requestId: r.id }, select: { customerMicroUsd: true, costMicroUsd: true } });
    if (log && log.customerMicroUsd !== null) {
      const { bonusConversion } = await getCustomerBillingRate(r.customerId, r.storeId as StoreId);
      const s = await settle({
        reservationId: r.id,
        chargeMicroUsd: log.customerMicroUsd,
        bonusConversion,
        realCostMicroUsd: BigInt(log.costMicroUsd),
        actor: { label: "Gateway" },
        ref: { type: "UsageLog", id: r.id },
      });
      if (s.status === "settled") result.settledFromLog.push(r.id);
      continue;
    }
    if (await release(r.id, "EXPIRED")) {
      result.expired.push(r.id);
      perStore.set(r.storeId, (perStore.get(r.storeId) ?? 0) + 1);
    }
  }

  for (const [storeId, count] of perStore) {
    await createNotification({
      storeId,
      type: NOTIFICATION_TYPES.RESERVATIONS_SWEPT,
      title: "Gateway holds released by the sweeper",
      message: `${count} reservation${count === 1 ? "" : "s"} expired without settlement — a gateway function died mid-request. Check the logs for the request ids.`,
    });
  }
  return result;
}
