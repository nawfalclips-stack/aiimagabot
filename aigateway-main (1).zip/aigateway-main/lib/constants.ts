export const CUSTOMER_STATUSES = [
  "ACTIVE",
  "LOW_BALANCE",
  "BALANCE_FINISHED",
  "SUSPENDED",
  "EXPIRED",
] as const;

export type CustomerStatus = (typeof CUSTOMER_STATUSES)[number];

export const STATUS_LABELS: Record<CustomerStatus, string> = {
  ACTIVE: "Active",
  LOW_BALANCE: "Low Balance",
  BALANCE_FINISHED: "Balance Finished",
  SUSPENDED: "Suspended",
  EXPIRED: "Expired",
};

export const PURCHASED_AGAIN_VALUES = ["UNKNOWN", "YES", "NO"] as const;
export type PurchasedAgain = (typeof PURCHASED_AGAIN_VALUES)[number];

/** Guide categories in display order. Stored as plain strings on Documentation.category. */
export const DOC_CATEGORIES = ["CLAUDE", "DESKTOP", "CODEX", "OPENCODE", "AGENTS", "SKILLS", "SDK"] as const;
export type DocCategory = (typeof DOC_CATEGORIES)[number];

export const DOC_OSES = ["WINDOWS", "MACOS", "LINUX"] as const;
export type DocOS = (typeof DOC_OSES)[number];

export const DOC_CATEGORY_LABELS: Record<DocCategory, string> = {
  CLAUDE: "Claude Code",
  DESKTOP: "Claude Desktop",
  CODEX: "Codex CLI",
  OPENCODE: "OpenCode",
  AGENTS: "More agents",
  SKILLS: "Skills",
  SDK: "API & SDKs",
};

/** Categories every customer sees, whatever their offer (not tied to one model family). */
export const UNIVERSAL_DOC_CATEGORIES: readonly DocCategory[] = ["OPENCODE", "AGENTS", "SKILLS", "SDK"];

export const DOC_OS_LABELS: Record<DocOS, string> = {
  WINDOWS: "Windows",
  MACOS: "macOS",
  LINUX: "Linux",
};

export const ACTIVITY_ACTIONS = [
  "CUSTOMER_CREATED",
  "CUSTOMER_EDITED",
  "CUSTOMER_DELETED",
  "CUSTOMER_RESTORED",
  "CUSTOMER_PERMANENTLY_DELETED",
  "CUSTOMER_DUPLICATED",
  "API_KEY_CHANGED",
  "API_POOL_UNASSIGNED",
  "API_POOL_PURGED",
  "BALANCE_UPDATED",
  "BONUS_UPDATED",
  "CUSTOMER_FINISHED",
  "PURCHASED_AGAIN_UPDATED",
  "STATUS_CHANGED",
  "DOCUMENTATION_UPDATED",
  "SETTINGS_CHANGED",
  "ADMIN_LOGIN",
  "ADMIN_LOGOUT",
  "ADMIN_PASSWORD_CHANGED",
  "CUSTOMERS_IMPORTED",
  "CUSTOMERS_EXPORTED",
  "REVIEW_BONUS_CLAIMED",
  "REVIEW_BONUS_VERIFIED",
  "REVIEW_BONUS_REVOKED",
  "RECHARGE_APPROVED",
  "RECHARGE_REJECTED",
  "ACTIVATION_APPROVED",
  "ACTIVATION_REJECTED",
  "LOYALTY_POINTS_AWARDED",
  "REWARD_REQUESTED",
  "REWARD_APPROVED",
  "REWARD_REJECTED",
  "AFFILIATE_COMMISSION_CREDITED",
  "AFFILIATE_MILESTONE_CLAIMED",
  "AFFILIATE_MILESTONE_APPROVED",
  "AFFILIATE_MILESTONE_REJECTED",
  "PLAN_ASSIGNED",
  "PACK_SAVED",
  "VOUCHER_BATCH_CREATED",
  "VOUCHER_BATCH_UPLOADED",
  "VOUCHER_BATCH_REVOKED",
  "VOUCHER_REVOKED",
  "VOUCHER_CLAWBACK",
  "VOUCHER_REDEEMED",
] as const;

export type ActivityAction = (typeof ACTIVITY_ACTIONS)[number];

// Documentation placeholders (WS7). {{BASE_URL}} and {{MODEL}} are filled in
// at render time; YOUR_AEROLINK_API_KEY stays literal — the customer pastes
// their own gateway token from the API Access page.
export const API_KEY_PLACEHOLDER = "YOUR_AEROLINK_API_KEY";
export const BASE_URL_PLACEHOLDER = "{{BASE_URL}}";
export const MODEL_PLACEHOLDER = "{{MODEL}}";

export const SETTING_KEYS = {
  siteName: "site_name",
  logoText: "logo_text",
  supportEmail: "support_email",
  brandColor: "brand_color",
  footerText: "footer_text",
  lowBalanceThresholdCents: "low_balance_threshold_cents",
  defaultCurrency: "default_currency",
  timezone: "timezone",
  /** Customers see usage costs multiplied by this rate, and it is what gets deducted. */
  usageCostMultiplier: "usage_cost_multiplier",
  /** Plan id customers WITHOUT a plan are billed at ("" = the usage cost multiplier). */
  defaultPlanId: "default_plan_id",
  /** JSON loyalty program (levels, points brackets); "" = the default program (lib/loyalty.ts). */
  loyaltyProgram: "loyalty_program",
  /** Starting balance (cents) for customers who self-activate with an Order ID. */
  signupBalanceCents: "signup_balance_cents",
  /** Starting bonus (cents) for customers who self-activate with an Order ID. */
  signupBonusCents: "signup_bonus_cents",
  /** Store URL for renewals and support (shown to customers). */
  storeUrl: "store_url",
  /** JSON array of { label, url } shown in every footer; empty = nothing rendered. */
  socialLinks: "social_links",
  /** Safety margin added to the worst-case hold of a gateway request, in percent. */
  gatewayHoldMarginPct: "gateway_hold_margin_pct",
  /** Smallest hold a gateway request takes, in micro-USD. */
  gatewayMinHoldMicroUsd: "gateway_min_hold_micro_usd",
  /** max_tokens assumed for the hold when the client sends none and the model has no cap. */
  gatewayDefaultMaxTokens: "gateway_default_max_tokens",
  /** Requests per minute for customers whose plan sets none (WS3). */
  gatewayDefaultRpm: "gateway_default_rpm",
  /** Parallel requests per customer when the plan sets none (WS3). */
  gatewayDefaultMaxConcurrent: "gateway_default_max_concurrent",
  /** Parallel requests across the whole store — protects provider limits (WS3). */
  gatewayStoreMaxConcurrent: "gateway_store_max_concurrent",
  /** CHARGE_DELIVERED | WAIVE_ON_UPSTREAM_ERROR — what a cut-off stream costs the customer (WS5). */
  partialChargePolicy: "partial_charge_policy",
  // Vouchers (WS9). Decision #5: auto-approve OFF by default, > N redemptions per IP per day → review.
  /** "true" credits a redemption at once; "false" routes every redemption to the review queue. */
  voucherAutoApprove: "voucher_auto_approve",
  /** Redemptions from one IP per day above which a redemption is reviewed even when auto-approve is on. */
  voucherMaxRedemptionsPerIpDay: "voucher_max_redemptions_per_ip_day",
  /** Default months until a new batch's codes expire (decision #4: 12, editable per batch). */
  voucherExpiryMonths: "voucher_expiry_months",
  /** Low-stock alert when a pack's uploaded, unredeemed codes drop below this count … */
  voucherLowStockCount: "voucher_low_stock_count",
  /** … or below this many days at the last-7-day redemption rate. */
  voucherLowStockDays: "voucher_low_stock_days",
  /** Require Cloudflare Turnstile on /redeem after this many failures per IP per hour (0 = never). */
  voucherTurnstileAfterFailures: "voucher_turnstile_after_failures",
} as const;

export const PARTIAL_CHARGE_POLICIES = ["CHARGE_DELIVERED", "WAIVE_ON_UPSTREAM_ERROR"] as const;
export type PartialChargePolicy = (typeof PARTIAL_CHARGE_POLICIES)[number];

export const DEFAULT_SETTINGS: Record<string, string> = {
  [SETTING_KEYS.siteName]: "AeroLink API Portal",
  [SETTING_KEYS.logoText]: "AeroLink",
  [SETTING_KEYS.supportEmail]: "support@aerolink.lat",
  [SETTING_KEYS.brandColor]: "#2563EB",
  [SETTING_KEYS.footerText]: "© AeroLink. All rights reserved.",
  [SETTING_KEYS.lowBalanceThresholdCents]: "1000", // 10 USD
  [SETTING_KEYS.defaultCurrency]: "USD",
  [SETTING_KEYS.timezone]: "UTC",
  [SETTING_KEYS.usageCostMultiplier]: "2.2",
  [SETTING_KEYS.defaultPlanId]: "",
  [SETTING_KEYS.loyaltyProgram]: "",
  [SETTING_KEYS.signupBalanceCents]: "30000", // 300 USD
  [SETTING_KEYS.signupBonusCents]: "0",
  [SETTING_KEYS.storeUrl]: "https://www.gamsgo.com/shop-store/ab3a9d0e-937f-e93e-1b66-5dca973aa779",
  [SETTING_KEYS.socialLinks]: "[]",
  [SETTING_KEYS.gatewayHoldMarginPct]: "5",
  [SETTING_KEYS.gatewayMinHoldMicroUsd]: "10000", // $0.01
  [SETTING_KEYS.gatewayDefaultMaxTokens]: "4096",
  [SETTING_KEYS.gatewayDefaultRpm]: "20",
  [SETTING_KEYS.gatewayDefaultMaxConcurrent]: "4",
  [SETTING_KEYS.gatewayStoreMaxConcurrent]: "200",
  [SETTING_KEYS.partialChargePolicy]: "WAIVE_ON_UPSTREAM_ERROR", // decision #2
  [SETTING_KEYS.voucherAutoApprove]: "false", // decision #5
  [SETTING_KEYS.voucherMaxRedemptionsPerIpDay]: "3",
  [SETTING_KEYS.voucherExpiryMonths]: "12", // decision #4
  [SETTING_KEYS.voucherLowStockCount]: "10", // decision #7
  [SETTING_KEYS.voucherLowStockDays]: "7",
  [SETTING_KEYS.voucherTurnstileAfterFailures]: "0",
};

export const ACTIVATION_SOURCES = ["ORDER_ID", "VOUCHER"] as const;
export type ActivationSource = (typeof ACTIVATION_SOURCES)[number];

export const VOUCHER_STATUSES = ["ISSUED", "REDEEMED", "REVOKED", "EXPIRED"] as const;
export type VoucherStatus = (typeof VOUCHER_STATUSES)[number];

export const POOL_KEY_STATUSES = ["AVAILABLE", "ASSIGNED", "PROBLEMATIC"] as const;
export type PoolKeyStatus = (typeof POOL_KEY_STATUSES)[number];

export const TICKET_TYPES = ["API_ISSUE", "BALANCE", "DOCUMENTATION", "OTHER"] as const;
export type TicketType = (typeof TICKET_TYPES)[number];

export const TICKET_STATUSES = ["OPEN", "AUTO_FIXING", "AUTO_RESOLVED", "RESOLVED", "CLOSED"] as const;
export type TicketStatus = (typeof TICKET_STATUSES)[number];

export const TICKET_TYPE_LABELS: Record<TicketType, string> = {
  API_ISSUE: "API Issue",
  BALANCE: "Balance Issue",
  DOCUMENTATION: "Documentation / Setup",
  OTHER: "Other",
};

export const TICKET_STATUS_LABELS: Record<TicketStatus, string> = {
  OPEN: "Open",
  AUTO_FIXING: "Auto-fixing…",
  AUTO_RESOLVED: "Auto-resolved",
  RESOLVED: "Resolved",
  CLOSED: "Closed",
};

// Review-gated bonus lifecycle:
// NONE (no bonus in the offer) → OFFERED (waiting for the customer's review)
// → CLAIMED (customer says they reviewed; bonus credited; admin should check)
// → VERIFIED (admin confirmed) | REVOKED (admin removed the bonus).
export const REVIEW_BONUS_STATUSES = ["NONE", "OFFERED", "CLAIMED", "VERIFIED", "REVOKED"] as const;
export type ReviewBonusStatus = (typeof REVIEW_BONUS_STATUSES)[number];
