import { timingSafeEqual } from "node:crypto";

/**
 * Every cron and diagnostic route must be called with
 * `Authorization: Bearer ${CRON_SECRET}` (WS12.7). Vercel Cron sends this
 * header automatically when CRON_SECRET is set on the project. The compare
 * is constant-time and an unset secret always denies.
 */
export function isCronAuthorized(request: Request): boolean {
  const secret = process.env.CRON_SECRET;
  if (!secret) return false;
  const header = request.headers.get("authorization") ?? "";
  const m = /^Bearer\s+(.+)$/i.exec(header);
  if (!m) return false;
  const given = Buffer.from(m[1].trim());
  const expected = Buffer.from(secret);
  return given.length === expected.length && timingSafeEqual(given, expected);
}

/** The 401 body every cron route returns. */
export function cronUnauthorized(): Response {
  return Response.json({ error: "Unauthorized" }, { status: 401 });
}
