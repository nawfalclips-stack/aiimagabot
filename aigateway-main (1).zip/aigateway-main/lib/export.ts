// Client-side export helpers (CSV / Excel / PDF). Heavy libraries are
// imported dynamically so they never enter the initial bundle.

import type { CustomerRow } from "@/lib/types";
import { STATUS_LABELS, type CustomerStatus } from "@/lib/constants";

const HEADERS = [
  "Access Code",
  "Order Number",
  "API Key",
  "Initial Balance",
  "Used Balance",
  "Remaining Balance",
  "Initial Bonus",
  "Used Bonus",
  "Remaining Bonus",
  "Profit",
  "Status",
  "Purchased Again",
  "Notes",
  "Created Date",
];

function usd(cents: number): string {
  return (cents / 100).toFixed(2);
}

function toRow(c: CustomerRow): (string | number)[] {
  return [
    c.accessCode,
    c.orderNumber,
    c.apiKey,
    usd(c.initialBalanceCents),
    usd(c.usedBalanceCents),
    usd(c.remainingBalanceCents),
    usd(c.initialBonusCents),
    usd(c.usedBonusCents),
    usd(c.remainingBonusCents),
    usd(c.profitCents),
    STATUS_LABELS[c.status as CustomerStatus] ?? c.status,
    c.purchasedAgain === "YES" ? "Yes" : c.purchasedAgain === "NO" ? "No" : "Unknown",
    c.notes,
    new Date(c.createdAt).toISOString().slice(0, 10),
  ];
}

function download(blob: Blob, filename: string) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

function stamp(): string {
  return new Date().toISOString().slice(0, 10);
}

export function exportCsv(customers: CustomerRow[]) {
  const escape = (v: string | number) => {
    const s = String(v);
    return /[",\n]/.test(s) ? `"${s.replace(/"/g, '""')}"` : s;
  };
  const lines = [HEADERS.join(","), ...customers.map((c) => toRow(c).map(escape).join(","))];
  download(new Blob(["﻿" + lines.join("\n")], { type: "text/csv;charset=utf-8" }), `customers-${stamp()}.csv`);
}

export async function exportExcel(customers: CustomerRow[]) {
  const XLSX = await import("xlsx");
  const sheet = XLSX.utils.aoa_to_sheet([HEADERS, ...customers.map(toRow)]);
  sheet["!cols"] = HEADERS.map((h, i) => ({ wch: Math.max(h.length + 2, i === 2 ? 34 : 14) }));
  const book = XLSX.utils.book_new();
  XLSX.utils.book_append_sheet(book, sheet, "Customers");
  XLSX.writeFile(book, `customers-${stamp()}.xlsx`);
}

export async function exportPdf(customers: CustomerRow[]) {
  const { jsPDF } = await import("jspdf");
  const autoTable = (await import("jspdf-autotable")).default;
  const doc = new jsPDF({ orientation: "landscape", unit: "pt", format: "a4" });

  doc.setFontSize(14);
  doc.text("Customers", 40, 36);
  doc.setFontSize(9);
  doc.setTextColor(120);
  doc.text(`Exported ${new Date().toLocaleString()} · ${customers.length} customers`, 40, 52);

  autoTable(doc, {
    head: [HEADERS],
    body: customers.map(toRow),
    startY: 64,
    styles: { fontSize: 6.5, cellPadding: 3, overflow: "linebreak" },
    headStyles: { fillColor: [37, 99, 235], fontSize: 6.5 },
    alternateRowStyles: { fillColor: [245, 247, 250] },
    columnStyles: { 2: { cellWidth: 90 }, 12: { cellWidth: 70 } },
  });

  doc.save(`customers-${stamp()}.pdf`);
}

/** Parse a CSV or Excel file into import rows keyed by our header names. */
export async function parseImportFile(file: File): Promise<Record<string, unknown>[]> {
  const XLSX = await import("xlsx");
  const buffer = await file.arrayBuffer();
  const workbook = XLSX.read(buffer, { type: "array" });
  const sheet = workbook.Sheets[workbook.SheetNames[0]];
  const raw = XLSX.utils.sheet_to_json<Record<string, unknown>>(sheet, { defval: "" });

  const keyMap: Record<string, string> = {
    "access code": "accessCode",
    accesscode: "accessCode",
    "order number": "orderNumber",
    ordernumber: "orderNumber",
    "api key": "apiKey",
    apikey: "apiKey",
    "initial balance": "initialBalance",
    initialbalance: "initialBalance",
    "initial bonus": "initialBonus",
    initialbonus: "initialBonus",
    profit: "profit",
    notes: "notes",
  };

  return raw.map((row) => {
    const out: Record<string, unknown> = {};
    for (const [key, value] of Object.entries(row)) {
      const mapped = keyMap[key.trim().toLowerCase()];
      if (mapped) out[mapped] = typeof value === "string" ? value.trim() : value;
    }
    return out;
  });
}
