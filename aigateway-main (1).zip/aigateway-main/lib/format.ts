import { formatDistanceToNow } from "date-fns";

// Dates are always formatted in UTC via Intl so the server-rendered HTML and
// the client hydration pass produce byte-identical strings regardless of the
// server's or visitor's timezone.

const DATE_FMT = new Intl.DateTimeFormat("en-US", {
  timeZone: "UTC",
  month: "short",
  day: "numeric",
  year: "numeric",
});

const TIME_FMT = new Intl.DateTimeFormat("en-US", {
  timeZone: "UTC",
  hour: "2-digit",
  minute: "2-digit",
  hour12: false,
});

export function formatDate(date: Date | string | null | undefined): string {
  if (!date) return "—";
  return DATE_FMT.format(new Date(date));
}

export function formatDateTime(date: Date | string | null | undefined): string {
  if (!date) return "—";
  const d = new Date(date);
  return `${DATE_FMT.format(d)} at ${TIME_FMT.format(d)}`;
}

/**
 * Relative time. Clock-dependent — only use in server components (RSC output
 * is not re-rendered on hydration); client components should prefer
 * formatDate/formatDateTime.
 */
export function timeAgo(date: Date | string | null | undefined): string {
  if (!date) return "—";
  return formatDistanceToNow(new Date(date), { addSuffix: true });
}

export function maskApiKey(key: string): string {
  if (key.length <= 8) return "•".repeat(Math.max(4, key.length));
  return `${key.slice(0, 4)}${"•".repeat(12)}${key.slice(-4)}`;
}

/**
 * Pool-key preview: show everything up to the last underscore segment, then dots.
 * e.g.  "aero_live_E7OMTW3xKpqZ" → "aero_live_E7OMTW••••"
 * Falls back to maskApiKey for keys with no underscores.
 */
export function previewApiKey(key: string): string {
  const lastUnderscore = key.lastIndexOf("_");
  if (lastUnderscore === -1) return maskApiKey(key);
  const prefix = key.slice(0, lastUnderscore + 1);   // "aero_live_"
  const suffix = key.slice(lastUnderscore + 1);       // "E7OMTW3xKpqZ"
  // Show up to 6 chars of the suffix, then bullets.
  const visible = suffix.slice(0, 6);
  return `${prefix}${visible}${"•".repeat(4)}`;
}
