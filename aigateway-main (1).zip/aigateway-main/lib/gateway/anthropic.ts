// Translation between the Anthropic Messages API (what Claude Code speaks)
// and OpenAI Chat Completions (what DeepInfra & co. speak).
//
// Request:  Messages body → Chat Completions body
// Response: Chat Completions JSON → Messages JSON
// Stream:   Chat Completions SSE chunks → Messages SSE events

import { GatewayError } from "@/lib/gateway/errors";
import { encodeSse, parseSse } from "@/lib/gateway/sse";
import { normalizeUsage, toAnthropicUsage } from "@/lib/gateway/usage";
import { chunkContentBytes, type StreamOutcome } from "@/lib/gateway/metering";
import type { UpstreamHandle } from "@/lib/gateway/providers/openai-compatible";

// ─── Types (only the fields we touch) ────────────────────────────────────────

type Json = Record<string, unknown>;

interface AnthropicTextBlock { type: "text"; text: string; cache_control?: unknown }
interface AnthropicImageBlock { type: "image"; source: { type: "base64"; media_type: string; data: string } | { type: "url"; url: string } }
interface AnthropicToolUseBlock { type: "tool_use"; id: string; name: string; input: unknown }
interface AnthropicToolResultBlock { type: "tool_result"; tool_use_id: string; content?: string | Array<AnthropicTextBlock | AnthropicImageBlock>; is_error?: boolean }
interface AnthropicThinkingBlock { type: "thinking" | "redacted_thinking"; thinking?: string }
type AnthropicBlock = AnthropicTextBlock | AnthropicImageBlock | AnthropicToolUseBlock | AnthropicToolResultBlock | AnthropicThinkingBlock;

export interface AnthropicMessage { role: "user" | "assistant"; content: string | AnthropicBlock[] }

export interface AnthropicTool { name: string; description?: string; input_schema: Json; type?: string }

export interface AnthropicRequest {
  model: string;
  messages: AnthropicMessage[];
  max_tokens: number;
  system?: string | AnthropicTextBlock[];
  tools?: AnthropicTool[];
  tool_choice?: { type: "auto" | "any" | "tool" | "none"; name?: string; disable_parallel_tool_use?: boolean };
  temperature?: number;
  top_p?: number;
  stop_sequences?: string[];
  stream?: boolean;
  metadata?: { user_id?: string };
  thinking?: unknown;
}

type OpenAIContentPart = { type: "text"; text: string } | { type: "image_url"; image_url: { url: string } };

interface OpenAIMessage {
  role: "system" | "user" | "assistant" | "tool";
  content: string | OpenAIContentPart[] | null;
  tool_calls?: Array<{ id: string; type: "function"; function: { name: string; arguments: string } }>;
  tool_call_id?: string;
}

// ─── Request translation ─────────────────────────────────────────────────────

function textOf(content: string | AnthropicTextBlock[] | undefined): string {
  if (!content) return "";
  if (typeof content === "string") return content;
  return content
    .filter((b) => b.type === "text")
    .map((b) => b.text)
    .join("\n");
}

function toImagePart(block: AnthropicImageBlock): OpenAIContentPart {
  const src = block.source;
  const url = src.type === "url" ? src.url : `data:${src.media_type};base64,${src.data}`;
  return { type: "image_url", image_url: { url } };
}

function toolResultText(block: AnthropicToolResultBlock): string {
  if (block.content === undefined || block.content === null) return "";
  if (typeof block.content === "string") return block.content;
  return block.content
    .map((b) => (b.type === "text" ? b.text : "[image]"))
    .join("\n");
}

export function toChatRequest(req: AnthropicRequest): Record<string, unknown> {
  if (!Array.isArray(req.messages) || req.messages.length === 0) {
    throw new GatewayError(400, "invalid_request_error", "messages: at least one message is required");
  }
  if (typeof req.max_tokens !== "number" || req.max_tokens <= 0) {
    throw new GatewayError(400, "invalid_request_error", "max_tokens: must be a positive integer");
  }

  const messages: OpenAIMessage[] = [];
  const system = textOf(req.system);
  if (system.trim()) messages.push({ role: "system", content: system });

  for (const m of req.messages) {
    if (typeof m.content === "string") {
      messages.push({ role: m.role, content: m.content });
      continue;
    }

    if (m.role === "user") {
      // tool_result blocks become separate `tool` messages; the rest is one user message.
      const parts: OpenAIContentPart[] = [];
      for (const b of m.content) {
        if (b.type === "tool_result") {
          messages.push({ role: "tool", tool_call_id: b.tool_use_id, content: toolResultText(b) });
        } else if (b.type === "text") {
          parts.push({ type: "text", text: b.text });
        } else if (b.type === "image") {
          parts.push(toImagePart(b));
        }
      }
      if (parts.length > 0) {
        const onlyText = parts.every((p) => p.type === "text");
        messages.push({
          role: "user",
          content: onlyText ? parts.map((p) => (p as { text: string }).text).join("\n") : parts,
        });
      }
      continue;
    }

    // assistant
    let text = "";
    const toolCalls: NonNullable<OpenAIMessage["tool_calls"]> = [];
    for (const b of m.content) {
      if (b.type === "text") text += (text ? "\n" : "") + b.text;
      else if (b.type === "tool_use") {
        toolCalls.push({
          id: b.id,
          type: "function",
          function: { name: b.name, arguments: JSON.stringify(b.input ?? {}) },
        });
      }
      // thinking blocks are dropped — upstream models don't accept them back.
    }
    const msg: OpenAIMessage = { role: "assistant", content: text || null };
    if (toolCalls.length > 0) msg.tool_calls = toolCalls;
    messages.push(msg);
  }

  const out: Record<string, unknown> = {
    messages,
    max_tokens: req.max_tokens,
    stream: !!req.stream,
  };
  if (req.stream) out.stream_options = { include_usage: true };
  if (typeof req.temperature === "number") out.temperature = req.temperature;
  if (typeof req.top_p === "number") out.top_p = req.top_p;
  if (Array.isArray(req.stop_sequences) && req.stop_sequences.length > 0) out.stop = req.stop_sequences.slice(0, 4);
  if (req.metadata?.user_id) out.user = String(req.metadata.user_id).slice(0, 64);

  if (Array.isArray(req.tools) && req.tools.length > 0) {
    out.tools = req.tools
      .filter((t) => t.input_schema) // server tools (web_search etc.) have no schema — unsupported here
      .map((t) => ({
        type: "function",
        function: { name: t.name, description: t.description ?? "", parameters: t.input_schema },
      }));
    const tc = req.tool_choice;
    if (tc?.type === "any") out.tool_choice = "required";
    else if (tc?.type === "tool" && tc.name) out.tool_choice = { type: "function", function: { name: tc.name } };
    else if (tc?.type === "none") out.tool_choice = "none";
    else out.tool_choice = "auto";
    if (tc?.disable_parallel_tool_use) out.parallel_tool_calls = false;
  }

  return out;
}

// ─── Response translation ────────────────────────────────────────────────────

export function mapFinishReason(reason: string | null | undefined): "end_turn" | "max_tokens" | "tool_use" | "stop_sequence" {
  switch (reason) {
    case "length":
      return "max_tokens";
    case "tool_calls":
    case "function_call":
      return "tool_use";
    case "stop":
    default:
      return "end_turn";
  }
}

function newMessageId(): string {
  return `msg_${crypto.randomUUID().replace(/-/g, "").slice(0, 24)}`;
}

function parseArgs(raw: string): unknown {
  if (!raw || !raw.trim()) return {};
  try {
    return JSON.parse(raw);
  } catch {
    return { _raw: raw };
  }
}

export function toAnthropicResponse(chat: Json, modelSlug: string, dialect: string): { body: Json; rawUsage: unknown | null } {
  const choice = (Array.isArray(chat.choices) ? chat.choices[0] : undefined) as Json | undefined;
  const message = (choice?.message ?? {}) as Json;
  const content: AnthropicBlock[] = [];

  if (typeof message.reasoning_content === "string" && message.reasoning_content.length > 0) {
    content.push({ type: "thinking", thinking: message.reasoning_content });
  }
  if (typeof message.content === "string" && message.content.length > 0) {
    content.push({ type: "text", text: message.content });
  }
  const toolCalls = Array.isArray(message.tool_calls) ? (message.tool_calls as Json[]) : [];
  for (const tc of toolCalls) {
    const fn = (tc.function ?? {}) as Json;
    content.push({
      type: "tool_use",
      id: String(tc.id ?? `toolu_${crypto.randomUUID().slice(0, 12)}`),
      name: String(fn.name ?? ""),
      input: parseArgs(String(fn.arguments ?? "")),
    });
  }

  const rawUsage = chat.usage && typeof chat.usage === "object" ? chat.usage : null;
  const stopReason = toolCalls.length > 0 ? "tool_use" : mapFinishReason(choice?.finish_reason as string | undefined);

  return {
    body: {
      id: newMessageId(),
      type: "message",
      role: "assistant",
      model: modelSlug,
      content,
      stop_reason: stopReason,
      stop_sequence: null,
      // Cache statistics are passed through so Claude Code shows real numbers.
      usage: toAnthropicUsage(normalizeUsage(dialect, rawUsage)),
    },
    rawUsage,
  };
}

// ─── Stream translation ──────────────────────────────────────────────────────

/**
 * Convert an upstream Chat Completions SSE stream into Anthropic Messages SSE
 * events, metering it on the way (WS5): delivered bytes, usage, outcome.
 * `cancel()` (client went away) aborts the upstream so the provider stops.
 */
export function toAnthropicStream(
  upstream: UpstreamHandle,
  modelSlug: string,
  dialect: string
): { stream: ReadableStream<Uint8Array>; done: Promise<StreamOutcome> } {
  let resolveDone!: (o: StreamOutcome) => void;
  const done = new Promise<StreamOutcome>((r) => (resolveDone = r));
  let settled = false;
  const finishWith = (o: StreamOutcome) => {
    if (settled) return;
    settled = true;
    upstream.finish();
    resolveDone(o);
  };

  const messageId = newMessageId();
  let started = false;
  let nextIndex = 0;
  let textIndex: number | null = null; // open text block index
  let thinkingIndex: number | null = null; // open thinking block index
  const toolBlocks = new Map<number, { index: number; id: string; name: string }>(); // by upstream tool_call index
  let rawUsage: unknown | null = null;
  let forwardedBytes = 0;
  let finish: string | null = null;
  let sawToolCall = false;
  let error: string | null = null;
  let cancelled = false;

  const body = upstream.response.body;
  if (!body) {
    const stream = new ReadableStream<Uint8Array>({
      start(c) {
        c.close();
      },
    });
    finishWith({ rawUsage: null, forwardedBytes: 0, finishReason: null, outcome: "UPSTREAM_ERROR", error: "empty upstream body" });
    return { stream, done };
  }
  const events = parseSse(body);

  const stream = new ReadableStream<Uint8Array>({
    async start(controller) {
      const emit = (event: string, data: unknown) => {
        try {
          controller.enqueue(encodeSse(event, data));
        } catch {
          /* client gone; the cancel path settles */
        }
      };

      const ensureStarted = () => {
        if (started) return;
        started = true;
        emit("message_start", {
          type: "message_start",
          message: {
            id: messageId,
            type: "message",
            role: "assistant",
            model: modelSlug,
            content: [],
            stop_reason: null,
            stop_sequence: null,
            usage: { input_tokens: 0, output_tokens: 0, cache_creation_input_tokens: 0, cache_read_input_tokens: 0 },
          },
        });
      };

      const closeText = () => {
        if (textIndex === null) return;
        emit("content_block_stop", { type: "content_block_stop", index: textIndex });
        textIndex = null;
      };
      const closeThinking = () => {
        if (thinkingIndex === null) return;
        emit("content_block_stop", { type: "content_block_stop", index: thinkingIndex });
        thinkingIndex = null;
      };
      const closeTools = () => {
        for (const tb of toolBlocks.values()) {
          emit("content_block_stop", { type: "content_block_stop", index: tb.index });
        }
        toolBlocks.clear();
      };

      const reader = events.getReader();
      try {
        for (;;) {
          const { value, done: finished } = await reader.read();
          if (finished) break;
          if (value.data === "[DONE]") break;

          let chunk: Json;
          try {
            chunk = JSON.parse(value.data) as Json;
          } catch {
            continue;
          }

          if (chunk.error) {
            const e = chunk.error as Json | string;
            error = typeof e === "string" ? e : String(e.message ?? "upstream error");
            break;
          }

          if (chunk.usage && typeof chunk.usage === "object") rawUsage = chunk.usage;
          forwardedBytes += chunkContentBytes(chunk);

          const choice = (Array.isArray(chunk.choices) ? chunk.choices[0] : undefined) as Json | undefined;
          if (!choice) continue;
          ensureStarted();

          const delta = (choice.delta ?? {}) as Json;

          // Reasoning models stream their thinking as reasoning_content; Claude Code renders thinking blocks.
          const reasoning = typeof delta.reasoning_content === "string" ? delta.reasoning_content : typeof delta.reasoning === "string" ? delta.reasoning : "";
          if (reasoning.length > 0) {
            if (thinkingIndex === null) {
              closeText();
              closeTools();
              thinkingIndex = nextIndex++;
              emit("content_block_start", { type: "content_block_start", index: thinkingIndex, content_block: { type: "thinking", thinking: "" } });
            }
            emit("content_block_delta", { type: "content_block_delta", index: thinkingIndex, delta: { type: "thinking_delta", thinking: reasoning } });
          }

          if (typeof delta.content === "string" && delta.content.length > 0) {
            if (textIndex === null) {
              closeThinking();
              closeTools();
              textIndex = nextIndex++;
              emit("content_block_start", { type: "content_block_start", index: textIndex, content_block: { type: "text", text: "" } });
            }
            emit("content_block_delta", { type: "content_block_delta", index: textIndex, delta: { type: "text_delta", text: delta.content } });
          }

          if (Array.isArray(delta.tool_calls)) {
            closeThinking();
            closeText();
            for (const tc of delta.tool_calls as Json[]) {
              sawToolCall = true;
              const upstreamIdx = Number(tc.index ?? 0);
              const fn = (tc.function ?? {}) as Json;
              let tb = toolBlocks.get(upstreamIdx);
              if (!tb) {
                tb = {
                  index: nextIndex++,
                  id: String(tc.id ?? `toolu_${crypto.randomUUID().slice(0, 12)}`),
                  name: String(fn.name ?? ""),
                };
                toolBlocks.set(upstreamIdx, tb);
                emit("content_block_start", {
                  type: "content_block_start",
                  index: tb.index,
                  content_block: { type: "tool_use", id: tb.id, name: tb.name, input: {} },
                });
              }
              if (typeof fn.arguments === "string" && fn.arguments.length > 0) {
                emit("content_block_delta", {
                  type: "content_block_delta",
                  index: tb.index,
                  delta: { type: "input_json_delta", partial_json: fn.arguments },
                });
              }
            }
          }

          if (typeof choice.finish_reason === "string" && choice.finish_reason) {
            finish = choice.finish_reason;
          }
        }
      } catch (e) {
        if (!cancelled) error = e instanceof Error ? e.message : String(e);
      } finally {
        reader.releaseLock();
      }

      if (cancelled) return; // the cancel path settles

      ensureStarted();
      closeThinking();
      closeText();
      closeTools();

      const timedOut = upstream.timedOut();
      const stopReason = sawToolCall ? "tool_use" : mapFinishReason(finish);
      if (error || timedOut) {
        emit("error", {
          type: "error",
          error: { type: timedOut ? "overloaded_error" : "api_error", message: timedOut ? "The model stopped responding (timeout)." : "The model connection was interrupted." },
        });
      } else {
        const usage = toAnthropicUsage(normalizeUsage(dialect, rawUsage));
        emit("message_delta", {
          type: "message_delta",
          delta: { stop_reason: stopReason, stop_sequence: null },
          usage,
        });
        emit("message_stop", { type: "message_stop" });
      }
      try {
        controller.close();
      } catch {
        /* already closed */
      }
      finishWith({ rawUsage, forwardedBytes, finishReason: finish, outcome: timedOut ? "TIMEOUT" : error ? "UPSTREAM_ERROR" : "COMPLETED", error });
    },
    cancel(reason) {
      cancelled = true;
      upstream.abort(reason);
      finishWith({ rawUsage, forwardedBytes, finishReason: finish, outcome: "CLIENT_DISCONNECTED", error: "client disconnected" });
    },
  });

  return { stream, done };
}
