import "server-only";
import { getRedis } from "@/lib/redis";

/**
 * Gateway token cache (WS12.3). Maps sha256(token) → the token's identity so
 * the hot path skips the GatewayToken lookup. The customer row itself is
 * still read by primary key on every request (status, activation, balance),
 * so a suspension or deletion takes effect immediately and only the token →
 * customer binding is cached.
 *
 *   gw:auth:{hash}      positive, 60 s — deleted on revocation (immediate)
 *   gw:auth:neg:{hash}  negative, 10 s — blunts brute force on unknown tokens
 *
 * Without Redis there is no cache: every request goes to the database.
 */

export interface CachedToken {
  tokenId: string;
  tokenName: string;
  customerId: string;
  storeId: string;
}

export const AUTH_CACHE_TTL_S = 60;
export const AUTH_NEG_CACHE_TTL_S = 10;

const key = (hash: string) => `gw:auth:${hash}`;
const negKey = (hash: string) => `gw:auth:neg:${hash}`;

/** Counters for tests and the diag endpoint. */
export const authCacheStats = { hits: 0, misses: 0, negativeHits: 0 };

export type AuthCacheLookup = { kind: "hit"; token: CachedToken } | { kind: "negative" } | { kind: "miss" };

export async function lookupAuthCache(hash: string): Promise<AuthCacheLookup> {
  const redis = getRedis();
  if (!redis) return { kind: "miss" };
  try {
    const [positive, negative] = await Promise.all([redis.get<CachedToken>(key(hash)), redis.get<number>(negKey(hash))]);
    if (positive && typeof positive === "object" && positive.tokenId) {
      authCacheStats.hits++;
      return { kind: "hit", token: positive };
    }
    if (negative !== null && negative !== undefined) {
      authCacheStats.negativeHits++;
      return { kind: "negative" };
    }
  } catch (e) {
    console.warn("[auth-cache] lookup failed, falling back to the database", e instanceof Error ? e.message : e);
  }
  authCacheStats.misses++;
  return { kind: "miss" };
}

export async function storeAuthCache(hash: string, token: CachedToken): Promise<void> {
  const redis = getRedis();
  if (!redis) return;
  try {
    await redis.set(key(hash), token, { ex: AUTH_CACHE_TTL_S });
  } catch {
    /* cache is best-effort */
  }
}

export async function storeNegativeAuthCache(hash: string): Promise<void> {
  const redis = getRedis();
  if (!redis) return;
  try {
    await redis.set(negKey(hash), 1, { ex: AUTH_NEG_CACHE_TTL_S });
  } catch {
    /* cache is best-effort */
  }
}

/** Called on revocation: the next request must miss, whatever instance serves it. */
export async function invalidateAuthCache(hash: string): Promise<void> {
  const redis = getRedis();
  if (!redis) return;
  try {
    await redis.del(key(hash));
  } catch (e) {
    // A revoked token must not keep working: surface this loudly.
    console.error("[auth-cache] could not invalidate a revoked token; it may stay valid for up to 60 s", e instanceof Error ? e.message : e);
  }
}

export function _resetAuthCacheStatsForTests(): void {
  authCacheStats.hits = 0;
  authCacheStats.misses = 0;
  authCacheStats.negativeHits = 0;
}
