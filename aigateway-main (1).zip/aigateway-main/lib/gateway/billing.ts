import "server-only";
import { prisma } from "@/lib/prisma";
import { getCustomerBillingRate } from "@/lib/services/plan-usage";
import { getSettings } from "@/lib/services/settings";
import { SETTING_KEYS } from "@/lib/constants";
import { customerPricePerMTokCents as pricePerMTok, type BillingRate } from "@/lib/plan-usage";
import { quote, rateFromMultiplier, type BonusConversion } from "@/lib/billing/pricing-engine";
import { isSameRate, potAvailableMicroUsd, potToPricedMicroUsd, pricedToPotMicroUsd } from "@/lib/billing/money";
import { normalizeUsage, priceProviderCostMicroUsd, totalInputTokens, totalOutputTokens, type NormalizedUsage } from "@/lib/gateway/usage";
import { estimateOutputTokensFromBytes, type StreamEnd, type StreamOutcome } from "@/lib/gateway/metering";
import type { PartialChargePolicy } from "@/lib/constants";
import { chargeUsage, lockCustomer, TX_OPTIONS, type Tx } from "@/lib/billing/balance-service";
import { estimateHoldMicroUsd, estimateInputTokens, maxOutputTokensAffordable } from "@/lib/billing/estimate";
import { reservationMode, reserve, settle, type ReservationMode } from "@/lib/billing/reservations";
import type { ResolvedModel } from "@/lib/gateway/registry";
import type { StoreId } from "@/lib/store";
import type { Plan } from "@prisma/client";
import { logActivity } from "@/lib/services/activity";

// ─── Reservation (before the upstream call) ─────────────────────────────────

export interface HoldContext {
  rate: BillingRate;
  /** The bonus pot's rate relative to `rate` (plan bonus); 1/1 when it has none. */
  bonusConversion: BonusConversion;
  marginPct: number;
  minHoldMicroUsd: bigint;
  defaultMaxTokens: number;
}

export async function loadHoldContext(customerId: string, storeId: StoreId, plan?: Plan | null): Promise<HoldContext> {
  const [{ rate, bonusConversion }, settings] = await Promise.all([getCustomerBillingRate(customerId, storeId, plan), getSettings(storeId)]);
  return {
    rate,
    bonusConversion,
    marginPct: Number(settings[SETTING_KEYS.gatewayHoldMarginPct] ?? 5) || 0,
    minHoldMicroUsd: BigInt(Math.max(0, Math.round(Number(settings[SETTING_KEYS.gatewayMinHoldMicroUsd] ?? 10_000) || 0))),
    defaultMaxTokens: Math.max(1, Math.round(Number(settings[SETTING_KEYS.gatewayDefaultMaxTokens] ?? 4096) || 4096)),
  };
}

export interface OpenReservationInput {
  requestId: string;
  customerId: string;
  storeId: StoreId;
  model: ResolvedModel;
  ctx: HoldContext;
  /** Request pieces that count as input: messages, system, tools. */
  inputParts: unknown[];
  /** The clamped max_tokens the request will carry; undefined = unknown. */
  maxTokens: number | undefined;
  expiresAt: Date;
}

export type OpenReservationResult =
  | { kind: "held"; reservationId: string; holdMicroUsd: bigint; inputTokens: number; outputTokens: number; mode: ReservationMode }
  | { kind: "off"; inputTokens: number; outputTokens: number }
  | { kind: "insufficient"; spendableMicroUsd: bigint; affordableOutputTokens: number; inputTokens: number };

/**
 * Estimate the worst case and take the hold. Mode comes from GATEWAY_RESERVATIONS:
 *   off     — no hold, no row
 *   shadow  — row written, nothing held, a would-reject is only logged
 *   enforce — atomic hold; insufficient funds → the caller returns 402 or fits max_tokens
 */
export async function openReservation(p: OpenReservationInput): Promise<OpenReservationResult> {
  const mode = reservationMode();
  const inputTokens = estimateInputTokens(p.inputParts);
  const outputTokens = p.maxTokens ?? p.model.maxOutputTokens ?? p.ctx.defaultMaxTokens;
  if (mode === "off") return { kind: "off", inputTokens, outputTokens };

  const pricedHold = estimateHoldMicroUsd({
    rate: p.ctx.rate,
    model: p.model,
    inputTokens,
    outputTokens,
    marginPct: p.ctx.marginPct,
    minHoldMicroUsd: p.ctx.minHoldMicroUsd,
  });
  // The hold is priced at the balance rate; when the plan gives the bonus its
  // own rate, the part the free balance cannot cover is held at the bonus rate
  // (reserve() compares pot µ$). Approximate under concurrency — settlement is exact.
  const sameRate = isSameRate(p.ctx.bonusConversion);
  const balanceFree = sameRate ? 0n : await freeBalanceMicroUsd(p.customerId);
  const hold = sameRate ? pricedHold : pricedToPotMicroUsd(pricedHold, balanceFree, p.ctx.bonusConversion);

  const r = await reserve({
    requestId: p.requestId,
    customerId: p.customerId,
    storeId: p.storeId,
    holdMicroUsd: hold,
    model: p.model.slug,
    expiresAt: p.expiresAt,
    mode,
  });
  if (r.ok) {
    if (mode === "shadow") {
      // Shadow: compute what enforce would have done, log it, never reject.
      const c = await prisma.customer.findUniqueOrThrow({
        where: { id: p.customerId },
        select: { initialBalanceCents: true, usedBalanceCents: true, initialBonusCents: true, usedBonusCents: true, balanceCarryMicroUsd: true, bonusCarryMicroUsd: true, reservedMicroUsd: true },
      });
      const spendable =
        BigInt(c.initialBalanceCents - c.usedBalanceCents + c.initialBonusCents - c.usedBonusCents) * 10_000n -
        c.balanceCarryMicroUsd - c.bonusCarryMicroUsd - c.reservedMicroUsd;
      if (spendable < hold) {
        console.warn(`[gateway] shadow would_reject request=${p.requestId} customer=${p.customerId} hold=${hold} spendable=${spendable} model=${p.model.slug}`);
      }
    }
    return { kind: "held", reservationId: r.reservation.id, holdMicroUsd: r.reservation.amountMicroUsd, inputTokens, outputTokens, mode };
  }

  const affordable = maxOutputTokensAffordable({
    rate: p.ctx.rate,
    model: p.model,
    inputTokens,
    marginPct: p.ctx.marginPct,
    minHoldMicroUsd: p.ctx.minHoldMicroUsd,
    availableMicroUsd: sameRate ? r.spendableMicroUsd : potToPricedMicroUsd(r.spendableMicroUsd, balanceFree, p.ctx.bonusConversion),
  });
  return { kind: "insufficient", spendableMicroUsd: r.spendableMicroUsd, affordableOutputTokens: affordable, inputTokens };
}

/** Balance pot available minus every in-flight hold (holds are taken balance first). */
async function freeBalanceMicroUsd(customerId: string): Promise<bigint> {
  const c = await prisma.customer.findUniqueOrThrow({
    where: { id: customerId },
    select: { initialBalanceCents: true, usedBalanceCents: true, initialBonusCents: true, usedBonusCents: true, balanceCarryMicroUsd: true, bonusCarryMicroUsd: true, reservedMicroUsd: true },
  });
  return potAvailableMicroUsd(c, "BALANCE") - c.reservedMicroUsd;
}

// ─── Settlement (after the response) ────────────────────────────────────────

export type UsageSource = "PROVIDER" | "ESTIMATED";

export interface SettleRequestParams {
  requestId: string;
  /** Null when reservations are off. */
  reservationId: string | null;
  customerId: string;
  storeId: StoreId;
  tokenId: string;
  tokenName: string;
  model: ResolvedModel;
  providerSlug: string;
  /** Provider usage dialect (WS6). */
  usageDialect: string;
  endpoint: string;
  /** What the stream/response reported (WS5). */
  result: StreamOutcome;
  /** Input estimate from the reservation, used when the provider sent no usage. */
  estimatedInputTokens: number;
  latencyMs: number;
}

export interface SettleRequestResult {
  usage: NormalizedUsage;
  usageSource: UsageSource;
  outcome: StreamEnd;
  costMicroUsd: bigint;
  customerMicroUsd: bigint;
  chargedMicroUsd: bigint;
  uncollectedMicroUsd: bigint;
  waived: boolean;
  replayed: boolean;
}

/** Outcomes the customer did not cause. */
const UPSTREAM_CAUSED: ReadonlySet<StreamEnd> = new Set<StreamEnd>(["UPSTREAM_ERROR", "TIMEOUT"]);

async function partialChargePolicy(storeId: StoreId): Promise<PartialChargePolicy> {
  const settings = await getSettings(storeId);
  return settings[SETTING_KEYS.partialChargePolicy] === "CHARGE_DELIVERED" ? "CHARGE_DELIVERED" : "WAIVE_ON_UPSTREAM_ERROR";
}

/**
 * Turn the stream outcome into billable usage: the provider's numbers when
 * it sent them (even on a partial stream), otherwise an estimate from the
 * reservation's input count and the bytes actually delivered.
 */
export function resolveUsage(p: Pick<SettleRequestParams, "result" | "usageDialect" | "estimatedInputTokens">): { usage: NormalizedUsage; source: UsageSource } {
  const fromProvider = normalizeUsage(p.usageDialect, p.result.rawUsage);
  if (fromProvider) return { usage: fromProvider, source: "PROVIDER" };
  return {
    usage: {
      inputUncached: BigInt(Math.max(0, p.estimatedInputTokens)),
      inputCached: 0n,
      cacheWrite: 0n,
      output: BigInt(estimateOutputTokensFromBytes(p.result.forwardedBytes)),
      reasoning: 0n,
      providerCostMicroUsd: null,
    },
    source: "ESTIMATED",
  };
}

/** Provider cost: the provider's own figure when it sends one, else our price list — with a sanity check between the two. */
export function resolveProviderCost(model: ResolvedModel, usage: NormalizedUsage, requestId: string): bigint {
  const computed = priceProviderCostMicroUsd(usage, model);
  const reported = usage.providerCostMicroUsd;
  if (reported === null) return computed;
  const diff = reported > computed ? reported - computed : computed - reported;
  const tolerance = computed / 10n + 100n; // 10 % + 100 µ$
  if (diff > tolerance) {
    console.warn(`[gateway] provider cost disagreement request=${requestId} model=${model.slug} reported=${reported} computed=${computed} — check the model's price list`);
  }
  return reported;
}

/**
 * Record one gateway request: normalise usage, price it (provider cost x the
 * customer's rate, cache-aware), apply the partial-charge policy, settle the
 * reservation (or charge directly when reservations are off), and write the
 * UsageLog — all in one transaction, idempotent per request id.
 */
export async function settleRequest(p: SettleRequestParams): Promise<SettleRequestResult> {
  const [{ rate, plan, bonusConversion }, policy] = await Promise.all([getCustomerBillingRate(p.customerId, p.storeId), partialChargePolicy(p.storeId)]);
  const { usage, source } = resolveUsage(p);
  const outcome = p.result.outcome;
  const costMicroUsd = resolveProviderCost(p.model, usage, p.requestId);
  const waived = policy === "WAIVE_ON_UPSTREAM_ERROR" && UPSTREAM_CAUSED.has(outcome);
  const priced = quote(rate, p.model, usage, { providerCostMicroUsd: costMicroUsd, cachedTokenWeightPct: plan?.cachedTokenWeightPct ?? 100 });
  const customerMicroUsd = waived ? 0n : priced > 0n ? priced : 0n;

  const status = outcome === "COMPLETED" ? (p.endpoint.includes("messages") || p.result.finishReason !== null ? "200" : "200") : outcome === "CLIENT_DISCONNECTED" ? "cancelled" : "error";
  const inTokens = Number(totalInputTokens(usage));
  const outTokens = Number(totalOutputTokens(usage));

  const usageLog = (tx: Tx, uncollected: bigint, bonusCost: bigint) =>
    tx.usageLog.create({
      data: {
        customerId: p.customerId,
        storeId: p.storeId,
        happenedAt: new Date(),
        keyLabel: p.tokenName,
        model: p.model.slug,
        tokens: `${inTokens} in / ${outTokens} out${usage.inputCached > 0n ? ` (${usage.inputCached} cached)` : ""}${source === "ESTIMATED" ? " ~" : ""}`,
        costMicroUsd: Number(costMicroUsd),
        bonusCostMicroUsd: Number(bonusCost),
        latency: `${p.latencyMs} ms`,
        status,
        addedBy: "Gateway",
        promptTokens: inTokens,
        completionTokens: outTokens,
        providerSlug: p.providerSlug,
        gatewayTokenId: p.tokenId,
        endpoint: p.endpoint,
        requestId: p.requestId,
        reservationId: p.reservationId,
        customerMicroUsd,
        uncollectedMicroUsd: uncollected,
        inputCachedTokens: Number(usage.inputCached),
        cacheWriteTokens: Number(usage.cacheWrite),
        reasoningTokens: Number(usage.reasoning),
        usageSource: source,
        outcome,
        rawUsage: p.result.rawUsage ? JSON.stringify(p.result.rawUsage).slice(0, 2000) : "",
      },
    });

  const ref = { type: "UsageLog", id: p.requestId };
  const actor = { label: "Gateway" };
  const note = waived ? `API usage (waived: ${outcome.toLowerCase().replace("_", " ")})` : outcome === "COMPLETED" ? "API usage" : `API usage (${outcome.toLowerCase().replace("_", " ")})`;
  const base = { usage, usageSource: source, outcome, costMicroUsd, customerMicroUsd, waived };

  if (p.reservationId) {
    const s = await settle({
      reservationId: p.reservationId,
      chargeMicroUsd: customerMicroUsd,
      bonusConversion,
      realCostMicroUsd: costMicroUsd,
      ref,
      actor,
      note,
      also: (tx, charge) => usageLog(tx, charge.uncollectedMicroUsd, charge.bonusRealMicroUsd).then(() => undefined),
    });
    if (s.status === "settled") {
      if (s.justFinished) await logFinished(p.customerId, p.storeId);
      return { ...base, chargedMicroUsd: customerMicroUsd - s.uncollectedMicroUsd, uncollectedMicroUsd: s.uncollectedMicroUsd, replayed: false };
    }
    if (s.status === "already-settled") {
      return { ...base, chargedMicroUsd: s.reservation.chargedMicroUsd ?? 0n, uncollectedMicroUsd: 0n, replayed: true };
    }
    // Reservation row vanished (should not happen); fall through to a direct charge.
  }

  // Reservations off: charge directly, still idempotent per request id.
  return prisma.$transaction(async (tx) => {
    await lockCustomer(tx, p.customerId);
    const existing = await tx.usageLog.findUnique({ where: { requestId: p.requestId }, select: { customerMicroUsd: true, uncollectedMicroUsd: true } });
    if (existing) {
      return { ...base, chargedMicroUsd: (existing.customerMicroUsd ?? 0n) - existing.uncollectedMicroUsd, uncollectedMicroUsd: existing.uncollectedMicroUsd, replayed: true, justFinished: false };
    }
    const charge = await chargeUsage({
      customerId: p.customerId,
      amountMicroUsd: customerMicroUsd,
      bonusConversion,
      realCostMicroUsd: costMicroUsd,
      idempotencyKey: `usage:${p.requestId}`,
      ref,
      actor,
      note,
      history: "daily-rollup",
      tx,
    });
    await usageLog(tx, charge.uncollectedMicroUsd, charge.bonusRealMicroUsd);
    return { ...base, chargedMicroUsd: customerMicroUsd - charge.uncollectedMicroUsd, uncollectedMicroUsd: charge.uncollectedMicroUsd, replayed: false, justFinished: charge.justFinished };
  }, TX_OPTIONS).then(async (r) => {
    if (r.justFinished) await logFinished(p.customerId, p.storeId);
    return r;
  });
}

async function logFinished(customerId: string, storeId: StoreId): Promise<void> {
  const c = await prisma.customer.findUnique({ where: { id: customerId }, select: { accessCode: true } });
  await logActivity({
    storeId,
    action: "CUSTOMER_FINISHED",
    description: `Customer ${c?.accessCode ?? customerId} has fully consumed their balance (via API gateway)`,
    customerId,
  });
}

/** Customer-facing price for a model, per 1M tokens, in cents. */
export function customerPricePerMTokCents(model: ResolvedModel, rate: BillingRate | number): { input: number; cachedInput: number; output: number } {
  const r: BillingRate = typeof rate === "number" ? rateFromMultiplier(rate) : rate;
  return pricePerMTok(r, model);
}
