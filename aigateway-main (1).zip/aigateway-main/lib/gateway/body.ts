// Request body limits (WS12.1). Vercel rejects function request bodies above
// its platform limit (4.5 MB, audit §15) before our code runs, with a generic
// platform error. We cap below that so a too-large prompt gets a proper,
// wire-shaped 413 with advice — and we enforce the cap while reading, not only
// from Content-Length (which a client may omit or misstate).

import { GatewayError } from "@/lib/gateway/errors";

/** Hard ceiling: never configure above this, the platform would reject first. */
export const PLATFORM_BODY_LIMIT_BYTES = 4_500_000;
const DEFAULT_MAX_BODY_BYTES = 4_000_000;

export function maxBodyBytes(): number {
  const n = Number(process.env.GATEWAY_MAX_BODY_BYTES ?? DEFAULT_MAX_BODY_BYTES);
  if (!Number.isFinite(n) || n <= 0) return DEFAULT_MAX_BODY_BYTES;
  return Math.min(Math.floor(n), PLATFORM_BODY_LIMIT_BYTES);
}

function tooLarge(limit: number, declared?: number): GatewayError {
  const mb = (n: number) => `${(n / 1_000_000).toFixed(1)} MB`;
  return new GatewayError(
    413,
    "invalid_request_error",
    `Request body${declared ? ` (${mb(declared)})` : ""} exceeds the ${mb(limit)} limit. Shorten the conversation history, drop large tool results, or start a new session.`
  );
}

/**
 * Read the body as UTF-8 text, refusing it once `limit` bytes have arrived.
 * Checks Content-Length first so an honest oversized client is refused
 * before any upload; then counts bytes while streaming.
 */
export async function readBodyText(request: Request, limit = maxBodyBytes()): Promise<string> {
  const declared = Number(request.headers.get("content-length") ?? 0);
  if (Number.isFinite(declared) && declared > limit) throw tooLarge(limit, declared);
  if (!request.body) return "";

  const reader = request.body.getReader();
  const chunks: Uint8Array[] = [];
  let received = 0;
  try {
    for (;;) {
      const { value, done } = await reader.read();
      if (done) break;
      received += value.byteLength;
      if (received > limit) {
        await reader.cancel("body too large").catch(() => undefined);
        throw tooLarge(limit);
      }
      chunks.push(value);
    }
  } finally {
    reader.releaseLock();
  }
  const merged = new Uint8Array(received);
  let offset = 0;
  for (const c of chunks) {
    merged.set(c, offset);
    offset += c.byteLength;
  }
  return new TextDecoder().decode(merged);
}

/** Read and parse a JSON object body under the size limit. */
export async function readJsonBody(request: Request, limit = maxBodyBytes()): Promise<Record<string, unknown>> {
  const text = await readBodyText(request, limit);
  let json: unknown;
  try {
    json = JSON.parse(text);
  } catch {
    throw new GatewayError(400, "invalid_request_error", "Request body must be a JSON object.");
  }
  if (!json || typeof json !== "object" || Array.isArray(json)) {
    throw new GatewayError(400, "invalid_request_error", "Request body must be a JSON object.");
  }
  return json as Record<string, unknown>;
}
