import "server-only";
import type { Redis } from "@upstash/redis";
import { getRedis } from "@/lib/redis";
import { prisma } from "@/lib/prisma";

/**
 * Circuit breaker per provider+model mapping (WS4), shared across instances
 * through Redis:
 *   cb:{pmId}:fails  — failures in the rolling window (INCR + PEXPIRE)
 *   cb:{pmId}:open   — set while the breaker is open (PX = cooldown)
 *   cb:{pmId}:probe  — SET NX during the cooldown: exactly one request may
 *                      test a recovering provider (half-open)
 *
 * GATEWAY_REDIS_BREAKER=false or a Redis outage → the in-memory breaker below
 * (same semantics, per instance).
 */

export interface BreakerConfig {
  failureThreshold: number;
  windowMs: number;
  openMs: number;
}

export const BREAKER_DEFAULTS: BreakerConfig = { failureThreshold: 3, windowMs: 60_000, openMs: 60_000 };

export type BreakerState = "closed" | "open" | "half-open";

export function redisBreakerEnabled(): boolean {
  return (process.env.GATEWAY_REDIS_BREAKER ?? "true").toLowerCase() !== "false";
}

const k = (id: string) => ({ fails: `cb:${id}:fails`, open: `cb:${id}:open`, probe: `cb:${id}:probe` });

// KEYS: fails, open ; ARGV: windowMs, threshold, openMs
// returns {0,n} below threshold · {1,n} tripped now · {2,n} already open
// (a failure while open — a failed half-open probe — restarts the cooldown)
const FAIL_LUA = `
if redis.call('EXISTS', KEYS[2]) == 1 then
  redis.call('PEXPIRE', KEYS[2], ARGV[3])
  return {2, 0}
end
local n = redis.call('INCR', KEYS[1])
if n == 1 then redis.call('PEXPIRE', KEYS[1], ARGV[1]) end
if n >= tonumber(ARGV[2]) then
  redis.call('SET', KEYS[2], '1', 'PX', ARGV[3])
  redis.call('DEL', KEYS[1])
  return {1, n}
end
return {0, n}
`;

// ─── in-memory fallback ───────────────────────────────────────────────────
interface Mem {
  fails: number;
  windowEnds: number;
  openUntil: number;
  probeUntil: number;
}
const memory = new Map<string, Mem>();
function mem(id: string): Mem {
  let m = memory.get(id);
  if (!m) {
    m = { fails: 0, windowEnds: 0, openUntil: 0, probeUntil: 0 };
    memory.set(id, m);
  }
  return m;
}
function memState(id: string, now: number): BreakerState {
  const m = memory.get(id);
  if (!m || m.openUntil <= now) return "closed";
  if (m.probeUntil <= now) {
    m.probeUntil = m.openUntil;
    return "half-open";
  }
  return "open";
}
function memFailure(id: string, cfg: BreakerConfig, now: number): "tripped" | "open" | "counted" {
  const m = mem(id);
  if (m.openUntil > now) {
    // Failed probe: restart the cooldown.
    m.openUntil = now + cfg.openMs;
    return "open";
  }
  if (m.windowEnds <= now) {
    m.fails = 0;
    m.windowEnds = now + cfg.windowMs;
  }
  m.fails += 1;
  if (m.fails >= cfg.failureThreshold) {
    m.openUntil = now + cfg.openMs;
    m.probeUntil = 0;
    m.fails = 0;
    m.windowEnds = 0;
    return "tripped";
  }
  return "counted";
}

let failScript: { eval(keys: string[], args: string[]): Promise<unknown> } | null = null;

/**
 * Whether a request may go to this provider+model right now. "half-open"
 * means this caller won the single probe slot and should try.
 */
export async function breakerState(pmId: string): Promise<BreakerState> {
  const now = Date.now();
  const redis = redisBreakerEnabled() ? getRedis() : null;
  if (!redis) return memState(pmId, now);
  try {
    const keys = k(pmId);
    const openTtl = await redis.pttl(keys.open);
    if (openTtl <= 0) return "closed"; // -2 missing, -1 no expiry (never set by us)
    const probe = await redis.set(keys.probe, "1", { px: openTtl, nx: true });
    return probe ? "half-open" : "open";
  } catch (e) {
    console.warn("[breaker] redis unavailable, using in-memory state:", e instanceof Error ? e.message : e);
    return memState(pmId, now);
  }
}

/** Record a retriable failure. Returns "tripped" exactly once per opening. */
export async function recordFailure(pmId: string, cfg: BreakerConfig = BREAKER_DEFAULTS): Promise<"tripped" | "open" | "counted"> {
  const now = Date.now();
  const redis = redisBreakerEnabled() ? getRedis() : null;
  if (!redis) return memFailure(pmId, cfg, now);
  try {
    failScript ??= redis.createScript<[number, number]>(FAIL_LUA);
    const keys = k(pmId);
    const [code] = (await failScript.eval([keys.fails, keys.open], [String(cfg.windowMs), String(cfg.failureThreshold), String(cfg.openMs)])) as [number, number];
    return code === 1 ? "tripped" : code === 2 ? "open" : "counted";
  } catch (e) {
    console.warn("[breaker] redis unavailable, using in-memory state:", e instanceof Error ? e.message : e);
    return memFailure(pmId, cfg, now);
  }
}

/** A successful response closes the breaker and clears the failure window. */
export async function recordSuccess(pmId: string): Promise<void> {
  memory.delete(pmId);
  const redis = redisBreakerEnabled() ? getRedis() : null;
  if (!redis) return;
  try {
    const keys = k(pmId);
    await redis.del(keys.fails, keys.open, keys.probe);
  } catch {
    /* next success will clear it */
  }
}

export async function resetBreaker(pmId: string): Promise<void> {
  return recordSuccess(pmId);
}

/** Admin edited/tested a provider: close the breakers of all its mappings. */
export async function resetProviderBreakers(providerId: string): Promise<void> {
  const mappings = await prisma.providerModel.findMany({ where: { providerId }, select: { id: true } }).catch(() => []);
  await Promise.all(mappings.map((m) => recordSuccess(m.id)));
}

/** Snapshot for the health cron / admin UI: is the mapping open, and for how long. */
export async function breakerSnapshot(pmId: string): Promise<{ open: boolean; remainingMs: number }> {
  const now = Date.now();
  const redis = redisBreakerEnabled() ? getRedis() : null;
  if (!redis) {
    const m = memory.get(pmId);
    const remaining = m ? Math.max(0, m.openUntil - now) : 0;
    return { open: remaining > 0, remainingMs: remaining };
  }
  try {
    const ttl = await redis.pttl(k(pmId).open);
    return { open: ttl > 0, remainingMs: Math.max(0, ttl) };
  } catch {
    return { open: false, remainingMs: 0 };
  }
}

/** Test hook. */
export function _resetBreakersForTests(): void {
  memory.clear();
  failScript = null;
}
