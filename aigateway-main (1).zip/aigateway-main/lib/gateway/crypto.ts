import "server-only";

// Secrets at rest (provider API keys, revealable gateway tokens) are encrypted
// with AES-256-GCM. Ciphertexts are versioned by prefix:
//
//   enc:v1:<iv>:<data>  key derived from SESSION_SECRET (legacy; decrypt only)
//   enc:v2:<iv>:<data>  key = PROVIDER_KEY_SECRET (32 random bytes, base64)
//
// Both decrypt. New ciphertexts are v2 whenever PROVIDER_KEY_SECRET is set;
// without it we fall back to v1 (with one loud warning in production) so a
// deploy never breaks before the operator has configured the secret.
// `npm run keys:reencrypt` migrates every stored row to v2 (WS12.4).

export type CipherVersion = "v1" | "v2" | "plain";

const V1_PREFIX = "enc:v1:";
const V2_PREFIX = "enc:v2:";

let warnedFallback = false;

/** True when PROVIDER_KEY_SECRET is configured (32 bytes, base64). */
export function keySecretConfigured(): boolean {
  return decodeKeySecret() !== null;
}

function decodeKeySecret(): Uint8Array<ArrayBuffer> | null {
  const raw = process.env.PROVIDER_KEY_SECRET;
  if (!raw) return null;
  const bytes = Buffer.from(raw.trim(), "base64");
  if (bytes.length !== 32) {
    throw new Error("PROVIDER_KEY_SECRET must be exactly 32 random bytes, base64-encoded (openssl rand -base64 32).");
  }
  return new Uint8Array(bytes.buffer.slice(bytes.byteOffset, bytes.byteOffset + bytes.byteLength));
}

async function deriveV1Key(): Promise<CryptoKey> {
  const secret = process.env.SESSION_SECRET;
  if (!secret || secret.length < 16) {
    throw new Error("SESSION_SECRET must be set to a long random string");
  }
  const material = await crypto.subtle.digest("SHA-256", new TextEncoder().encode(`gateway-keys:${secret}`));
  return crypto.subtle.importKey("raw", material, { name: "AES-GCM" }, false, ["encrypt", "decrypt"]);
}

async function importV2Key(): Promise<CryptoKey> {
  const bytes = decodeKeySecret();
  if (!bytes) throw new Error("PROVIDER_KEY_SECRET is not set");
  return crypto.subtle.importKey("raw", bytes, { name: "AES-GCM" }, false, ["encrypt", "decrypt"]);
}

function toBase64(bytes: Uint8Array): string {
  return Buffer.from(bytes).toString("base64");
}

function fromBase64(value: string): Uint8Array<ArrayBuffer> {
  const buf = Buffer.from(value, "base64");
  return new Uint8Array(buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength));
}

/** Which scheme a stored value uses ("plain" = legacy unencrypted row). */
export function cipherVersion(stored: string): CipherVersion {
  if (stored.startsWith(V2_PREFIX)) return "v2";
  if (stored.startsWith(V1_PREFIX)) return "v1";
  return "plain";
}

export async function encryptSecret(plain: string): Promise<string> {
  if (!plain) return "";
  const useV2 = keySecretConfigured();
  if (!useV2 && !warnedFallback) {
    warnedFallback = true;
    const level = process.env.NODE_ENV === "production" ? "error" : "warn";
    console[level](
      "[crypto] PROVIDER_KEY_SECRET is not set — encrypting with the SESSION_SECRET-derived key (v1). " +
        "Rotating SESSION_SECRET would then destroy every stored provider key. Set PROVIDER_KEY_SECRET and run `npm run keys:reencrypt`."
    );
  }
  const key = useV2 ? await importV2Key() : await deriveV1Key();
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const cipher = await crypto.subtle.encrypt({ name: "AES-GCM", iv }, key, new TextEncoder().encode(plain));
  return `${useV2 ? V2_PREFIX : V1_PREFIX}${toBase64(iv)}:${toBase64(new Uint8Array(cipher))}`;
}

export async function decryptSecret(stored: string): Promise<string> {
  if (!stored) return "";
  const version = cipherVersion(stored);
  if (version === "plain") return stored; // tolerate legacy plaintext rows
  const prefix = version === "v2" ? V2_PREFIX : V1_PREFIX;
  const [ivB64, dataB64] = stored.slice(prefix.length).split(":");
  const key = version === "v2" ? await importV2Key() : await deriveV1Key();
  const plain = await crypto.subtle.decrypt({ name: "AES-GCM", iv: fromBase64(ivB64) }, key, fromBase64(dataB64));
  return new TextDecoder().decode(plain);
}

/**
 * Re-encrypt a stored value under the current scheme. Returns null when the
 * row is already v2 (nothing to do), so callers can count and skip.
 */
export async function reencryptSecret(stored: string): Promise<string | null> {
  if (!stored) return null;
  if (!keySecretConfigured()) throw new Error("PROVIDER_KEY_SECRET must be set to re-encrypt");
  if (cipherVersion(stored) === "v2") return null;
  return encryptSecret(await decryptSecret(stored));
}

/** "sk-abc…xyz" — enough to recognise a key without revealing it. */
export function maskSecret(plain: string): string {
  if (!plain) return "";
  if (plain.length <= 10) return "•".repeat(plain.length);
  return `${plain.slice(0, 6)}…${plain.slice(-4)}`;
}

/** Tests reset the one-time fallback warning. */
export function _resetCryptoWarningForTests(): void {
  warnedFallback = false;
}
