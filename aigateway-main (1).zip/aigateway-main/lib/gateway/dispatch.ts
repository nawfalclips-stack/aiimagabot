import "server-only";
import { prisma } from "@/lib/prisma";
import { GatewayError } from "@/lib/gateway/errors";
import { breakerState, recordFailure, recordSuccess } from "@/lib/gateway/breaker";
import { chatCompletions, ClientDisconnectedError, UpstreamTimeoutError, type UpstreamHandle } from "@/lib/gateway/providers/openai-compatible";
import { createNotification, NOTIFICATION_TYPES } from "@/lib/services/notifications";
import type { ProviderCandidate, ResolvedModel } from "@/lib/gateway/registry";

export interface DispatchResult {
  response: Response;
  /** Abort/finish control over the winning upstream request (WS5). */
  upstream: UpstreamHandle;
  provider: ProviderCandidate;
  ttfbMs: number;
  /** Providers that were tried and failed before this one answered. */
  failedOver: string[];
}

export type AttemptOutcome = "OK" | "HTTP_4XX" | "HTTP_429" | "HTTP_5XX" | "TTFB_TIMEOUT" | "NETWORK" | "BREAKER_OPEN";

export interface Attempt {
  providerSlug: string;
  providerModelId: string;
  outcome: AttemptOutcome;
  statusCode: number | null;
  ttfbMs: number | null;
  /** Server-side only; never sent to the customer. */
  detail: string;
}

/**
 * Failover happens only on: breaker open, network error, TTFB timeout,
 * HTTP 429, HTTP 5xx. A 4xx other than 429 means the request itself is
 * bad — it goes straight back to the customer and does not touch the breaker.
 */
function classify(status: number): "ok" | "retriable" | "client" {
  if (status < 400) return "ok";
  if (status === 429 || status >= 500) return "retriable";
  return "client";
}

/**
 * Send a chat-completions request to the first healthy provider that serves
 * this model. Failover happens only *before* any bytes reach the client, so a
 * customer never sees a half-answer stitched from two providers.
 */
export async function dispatchChat(
  model: ResolvedModel,
  body: Record<string, unknown>,
  signal?: AbortSignal,
  onAttempt?: (a: Attempt) => void
): Promise<DispatchResult> {
  if (model.candidates.length === 0) {
    throw new GatewayError(503, "overloaded_error", `No provider is configured for model "${model.publicSlug}".`);
  }

  const failedOver: string[] = [];
  const attempts: Attempt[] = [];
  const record = (a: Attempt) => {
    attempts.push(a);
    onAttempt?.(a);
  };

  // Providers whose breaker is open are skipped; if every breaker is open,
  // try them all anyway (a probe is better than a guaranteed 503).
  const states = await Promise.all(model.candidates.map((c) => breakerState(c.providerModelId)));
  let order = model.candidates.filter((_, i) => states[i] !== "open");
  if (order.length === 0) order = model.candidates;
  for (const [i, c] of model.candidates.entries()) {
    if (states[i] === "open" && !order.includes(c)) {
      record({ providerSlug: c.slug, providerModelId: c.providerModelId, outcome: "BREAKER_OPEN", statusCode: null, ttfbMs: null, detail: "breaker open" });
    }
  }

  for (const provider of order) {
    // Ask for the usage chunk only where the provider honours it; some reject the field.
    const candidateBody = { ...body };
    if (candidateBody.stream === true) {
      if (provider.supportsStreamUsage) candidateBody.stream_options = { include_usage: true };
      else delete candidateBody.stream_options;
    }
    // OpenRouter: ask for usage accounting so every response carries the real
    // `cost` it billed us — settlement prices the customer from that figure.
    if (provider.usageDialect === "openrouter") candidateBody.usage = { include: true };
    let handle: UpstreamHandle;
    try {
      handle = await chatCompletions(
        { baseUrl: provider.baseUrl, apiKey: provider.apiKey, upstreamModelId: provider.upstreamModelId },
        candidateBody,
        signal,
        { ttfbTimeoutMs: provider.ttfbTimeoutMs, totalTimeoutMs: provider.totalTimeoutMs }
      );
    } catch (e) {
      if (e instanceof ClientDisconnectedError || signal?.aborted) throw new GatewayError(499, "api_error", "Client disconnected.");
      const timeout = e instanceof UpstreamTimeoutError;
      record({
        providerSlug: provider.slug,
        providerModelId: provider.providerModelId,
        outcome: timeout ? "TTFB_TIMEOUT" : "NETWORK",
        statusCode: null,
        ttfbMs: null,
        detail: e instanceof Error ? e.message : String(e),
      });
      await failed(provider, e instanceof Error ? e.message : String(e));
      failedOver.push(provider.slug);
      continue;
    }

    const { response, ttfbMs } = handle;
    const kind = classify(response.status);
    if (kind === "ok") {
      record({ providerSlug: provider.slug, providerModelId: provider.providerModelId, outcome: "OK", statusCode: response.status, ttfbMs, detail: "" });
      void recordSuccess(provider.providerModelId);
      return { response, upstream: handle, provider, ttfbMs, failedOver };
    }

    const text = await response.text().catch(() => "");
    handle.finish();
    const detail = summarizeUpstreamError(text, response.status);

    if (kind === "client") {
      record({ providerSlug: provider.slug, providerModelId: provider.providerModelId, outcome: "HTTP_4XX", statusCode: response.status, ttfbMs, detail });
      // Never leak the upstream's wording or identity; log it with the id instead.
      console.warn(`[gateway] upstream ${provider.slug} rejected request: ${response.status} ${detail}`);
      throw new GatewayError(
        response.status === 404 ? 404 : response.status === 413 ? 413 : 400,
        response.status === 404 ? "not_found_error" : "invalid_request_error",
        response.status === 404
          ? `Model "${model.publicSlug}" is not available right now.`
          : response.status === 413
            ? "The request is too large for this model."
            : "The request was rejected by the model. Check the message format, tool definitions and parameters."
      );
    }

    record({
      providerSlug: provider.slug,
      providerModelId: provider.providerModelId,
      outcome: response.status === 429 ? "HTTP_429" : "HTTP_5XX",
      statusCode: response.status,
      ttfbMs,
      detail,
    });
    await failed(provider, `${response.status} ${detail}`);
    failedOver.push(provider.slug);
  }

  console.error(`[gateway] all providers failed for ${model.slug}: ${attempts.map((a) => `${a.providerSlug}=${a.outcome}${a.statusCode ? `(${a.statusCode})` : ""}`).join(", ")}`);
  throw new GatewayError(503, "overloaded_error", `Model "${model.publicSlug}" is temporarily unavailable. Please retry in a moment.`);
}

/** Count a retriable failure; when it trips the breaker, tell the admin once per opening. */
async function failed(provider: ProviderCandidate, detail: string): Promise<void> {
  const result = await recordFailure(provider.providerModelId, provider.breaker);
  if (result !== "tripped") return;
  console.warn(`[breaker] OPEN ${provider.slug}/${provider.upstreamModelId} for ${provider.breaker.openMs} ms: ${detail}`);
  // The durable health flag is refreshed by the hourly cron; the trip itself
  // is worth an immediate notification for every store using the gateway.
  try {
    const stores = await prisma.store.findMany({ select: { id: true } });
    await Promise.all(
      stores.map((s) =>
        createNotification({
          storeId: s.id,
          type: NOTIFICATION_TYPES.PROVIDER_BREAKER_OPEN,
          title: "Provider circuit breaker opened",
          message: `${provider.name} stopped serving ${provider.upstreamModelId} after repeated failures (${detail.slice(0, 120)}). Requests fail over to the next provider for ${Math.round(provider.breaker.openMs / 1000)} s.`,
          relatedId: provider.providerId,
        })
      )
    );
  } catch (e) {
    console.error("[breaker] could not notify:", e);
  }
}

function summarizeUpstreamError(text: string, status: number): string {
  try {
    const json = JSON.parse(text) as { error?: { message?: string } | string; message?: string; detail?: unknown };
    const inner = typeof json.error === "string" ? json.error : json.error?.message;
    const msg = inner ?? json.message ?? (typeof json.detail === "string" ? json.detail : undefined);
    if (msg) return msg.slice(0, 300);
  } catch {
    /* not JSON */
  }
  return text.trim().slice(0, 300) || `Upstream returned HTTP ${status}`;
}
