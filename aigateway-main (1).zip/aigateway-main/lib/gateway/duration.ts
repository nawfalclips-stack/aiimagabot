// How long one gateway request may run, in one place.
//
// Vercel limits: Hobby 300 s, Pro/Enterprise 800 s. The /v1 route files must
// export the same number as a literal (`export const maxDuration = 300`) —
// Next.js reads it statically — so when moving to Pro change all three:
//   GATEWAY_MAX_DURATION_S below, app/v1/chat/completions/route.ts,
//   app/v1/messages/route.ts   (and GATEWAY_MAX_DURATION in the Vercel env).

/** Route maxDuration in seconds. Hobby: 300. Pro: 800. */
export const GATEWAY_MAX_DURATION_S = 300;

/** Upstream request ceiling: 20 s under the route limit so the stream ends cleanly (terminal error + settlement) before Vercel kills the function. */
export const UPSTREAM_TOTAL_TIMEOUT_MS = (GATEWAY_MAX_DURATION_S - 20) * 1000;
