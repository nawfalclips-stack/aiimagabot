// Error responses in the two wire formats the gateway speaks.

export type Wire = "openai" | "anthropic";

export type GatewayErrorType =
  | "invalid_request_error"
  | "authentication_error"
  | "permission_error"
  | "not_found_error"
  | "rate_limit_error"
  | "api_error"
  | "overloaded_error"
  | "insufficient_balance";

export class GatewayError extends Error {
  constructor(
    public status: number,
    public type: GatewayErrorType,
    message: string,
    /** Extra response headers, e.g. Retry-After on 429. */
    public headers: Record<string, string> = {}
  ) {
    super(message);
  }
}

function openaiCode(type: GatewayErrorType): string {
  switch (type) {
    case "authentication_error":
      return "invalid_api_key";
    case "insufficient_balance":
      return "insufficient_quota";
    case "not_found_error":
      return "model_not_found";
    case "rate_limit_error":
      return "rate_limit_exceeded";
    default:
      return type;
  }
}

/** Headers every gateway response carries (WS12.6): never cached, never transformed. */
export const RESPONSE_HYGIENE_HEADERS = {
  "cache-control": "no-store, no-transform",
  "x-content-type-options": "nosniff",
} as const;

/** A short opaque id for one gateway request; returned as `x-request-id`. */
export function newRequestId(): string {
  return `req_${crypto.randomUUID().replace(/-/g, "").slice(0, 20)}`;
}

export function errorResponse(wire: Wire, err: GatewayError, requestId?: string): Response {
  const body =
    wire === "anthropic"
      ? { type: "error", error: { type: err.type, message: err.message }, request_id: requestId }
      : { error: { message: err.message, type: err.type, code: openaiCode(err.type), param: null } };
  return Response.json(body, {
    status: err.status,
    headers: { ...RESPONSE_HYGIENE_HEADERS, ...err.headers, ...(requestId ? { "x-request-id": requestId } : {}) },
  });
}

/**
 * Map any thrown value onto a GatewayError so callers always get a clean
 * body. Unknown errors become a generic 502: their message (which may name
 * an upstream host or an internal path) goes to the log, not the customer.
 */
export function asGatewayError(e: unknown): GatewayError {
  if (e instanceof GatewayError) return e;
  return new GatewayError(502, "api_error", "Upstream request failed. Please retry; if it persists, contact support with the x-request-id.");
}
