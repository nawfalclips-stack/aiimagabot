import "server-only";
import { after } from "next/server";
import { authenticateGatewayRequest, AUTH_FAILURE_MESSAGES } from "@/lib/gateway/tokens";
import { GatewayError, asGatewayError, errorResponse, newRequestId, RESPONSE_HYGIENE_HEADERS, type Wire } from "@/lib/gateway/errors";
import { readJsonBody } from "@/lib/gateway/body";
import { resolveModel, type ResolvedModel } from "@/lib/gateway/registry";
import { dispatchChat } from "@/lib/gateway/dispatch";
import { loadHoldContext, openReservation, settleRequest } from "@/lib/gateway/billing";
import { release } from "@/lib/billing/reservations";
import { acquireLease, checkGatewayRpm, releaseLease } from "@/lib/gateway/limits";
import { getCustomerLimits } from "@/lib/services/plan-usage";
import { formatMicroUsd } from "@/lib/billing/money";
import { meterChatStream, presentAsAlias, type StreamOutcome } from "@/lib/gateway/metering";
import { toAnthropicResponse, toAnthropicStream, toChatRequest, type AnthropicRequest } from "@/lib/gateway/anthropic";
import { SSE_HEADERS } from "@/lib/gateway/sse";
import type { StoreId } from "@/lib/store";
import { GATEWAY_MAX_DURATION_S } from "@/lib/gateway/duration";

/** Route maxDuration (seconds); must match the literal exported by the /v1 routes (lib/gateway/duration.ts). */
export { GATEWAY_MAX_DURATION_S };
/** A hold outlives the function by this much before the sweeper may release it. */
const RESERVATION_GRACE_S = 120;
/** A concurrency lease outlives the function by this much before it expires on its own. */
const LEASE_GRACE_S = 60;

function minOutputTokens(): number {
  const n = Number(process.env.GATEWAY_MIN_OUTPUT_TOKENS ?? 256);
  return Number.isFinite(n) && n > 0 ? Math.floor(n) : 256;
}

/** Body keys clients may set on /v1/chat/completions. Everything else is dropped. */
const CHAT_ALLOWED_KEYS = new Set([
  "messages", "max_tokens", "max_completion_tokens", "temperature", "top_p", "n", "stream", "stream_options",
  "stop", "presence_penalty", "frequency_penalty", "logit_bias", "user", "tools", "tool_choice",
  "parallel_tool_calls", "response_format", "seed", "logprobs", "top_logprobs", "reasoning_effort",
]);

/** The max_tokens the upstream will honour, clamped to the model cap. */
function clampMaxTokens(body: Record<string, unknown>, model: ResolvedModel): number | undefined {
  let effective: number | undefined;
  for (const key of ["max_tokens", "max_completion_tokens"] as const) {
    if (typeof body[key] === "number" && Number.isFinite(body[key])) {
      if (model.maxOutputTokens && (body[key] as number) > model.maxOutputTokens) body[key] = model.maxOutputTokens;
      effective = body[key] as number;
    }
  }
  return effective;
}

function setMaxTokens(body: Record<string, unknown>, value: number): void {
  if (typeof body.max_completion_tokens === "number") body.max_completion_tokens = value;
  body.max_tokens = value;
}

/**
 * Shared pipeline for both wire formats:
 *   authenticate → validate → resolve model → reserve → dispatch with failover → respond → settle.
 */
export async function handleGateway(request: Request, wire: Wire): Promise<Response> {
  const requestId = newRequestId();
  const started = Date.now();
  let reservationId: string | null = null;
  let lease: { customerId: string; storeId: string } | null = null;

  try {
    const auth = await authenticateGatewayRequest(request.headers);
    if (!auth.ok) {
      const { status, message } = AUTH_FAILURE_MESSAGES[auth.reason];
      const type =
        status === 402 ? "insufficient_balance" : status === 403 ? "permission_error" : "authentication_error";
      throw new GatewayError(status, type, message);
    }
    const { customer, token } = auth;
    const storeId = customer.storeId as StoreId;

    // ── Rate limit (per token and per customer) ─────────────────────────
    const limits = await getCustomerLimits(customer.id, storeId, customer.plan);
    const rpm = await checkGatewayRpm({ tokenId: token.tokenId, customerId: customer.id, rpm: limits.rpm });
    if (!rpm.ok) {
      throw new GatewayError(
        429,
        "rate_limit_error",
        `Rate limit of ${limits.rpm} requests per minute reached${rpm.scope === "token" ? " for this token" : ""}. Retry after ${rpm.retryAfterSeconds} s.`,
        { "retry-after": String(rpm.retryAfterSeconds) }
      );
    }

    const raw = await readJsonBody(request);
    const requestedModel = typeof raw.model === "string" ? raw.model : "";
    if (!requestedModel) throw new GatewayError(400, "invalid_request_error", "model: is required");

    const model = await resolveModel(requestedModel, storeId);
    if (!model) {
      throw new GatewayError(404, "not_found_error", `Model "${requestedModel}" is not available. See GET /v1/models.`);
    }
    if (model.candidates.length === 0) {
      throw new GatewayError(503, "overloaded_error", `Model "${model.publicSlug}" has no active provider right now.`);
    }

    // ── Shape the upstream body ─────────────────────────────────────────
    let chatBody: Record<string, unknown>;
    if (wire === "anthropic") {
      chatBody = toChatRequest(raw as unknown as AnthropicRequest);
    } else {
      chatBody = {};
      for (const [k, v] of Object.entries(raw)) if (CHAT_ALLOWED_KEYS.has(k)) chatBody[k] = v;
      if (!Array.isArray(chatBody.messages) || chatBody.messages.length === 0) {
        throw new GatewayError(400, "invalid_request_error", "messages: at least one message is required");
      }
      if (chatBody.n !== undefined && Number(chatBody.n) !== 1) {
        throw new GatewayError(400, "invalid_request_error", "n: only 1 is supported");
      }
      if (chatBody.stream === true) chatBody.stream_options = { include_usage: true };
    }
    const streaming = chatBody.stream === true;
    let maxTokens = clampMaxTokens(chatBody, model);

    // ── Concurrency lease (customer cap + store ceiling) ────────────────
    const leased = await acquireLease({
      requestId,
      customerId: customer.id,
      storeId,
      maxConcurrent: limits.maxConcurrent,
      storeCeiling: limits.storeCeiling,
      ttlMs: (GATEWAY_MAX_DURATION_S + LEASE_GRACE_S) * 1000,
    });
    if (!leased.ok) {
      const what = leased.scope === "store" ? "The service is at its concurrency ceiling" : `You already have ${limits.maxConcurrent} requests in flight`;
      throw new GatewayError(429, "rate_limit_error", `${what}. Retry in a few seconds.`, { "retry-after": "5" });
    }
    lease = { customerId: customer.id, storeId };

    // ── Reserve the worst case ──────────────────────────────────────────
    const ctx = await loadHoldContext(customer.id, storeId, customer.plan);
    const expiresAt = new Date(started + (GATEWAY_MAX_DURATION_S + RESERVATION_GRACE_S) * 1000);
    const inputParts = [chatBody.messages, chatBody.tools];
    let opened = await openReservation({ requestId, customerId: customer.id, storeId, model, ctx, inputParts, maxTokens, expiresAt });

    if (opened.kind === "insufficient") {
      // Fit-to-balance: shrink the completion instead of refusing outright.
      const floor = minOutputTokens();
      if (opened.affordableOutputTokens >= floor && (maxTokens === undefined || opened.affordableOutputTokens < maxTokens)) {
        maxTokens = opened.affordableOutputTokens;
        setMaxTokens(chatBody, maxTokens);
        opened = await openReservation({ requestId, customerId: customer.id, storeId, model, ctx, inputParts, maxTokens, expiresAt });
      }
    }
    if (opened.kind === "insufficient") {
      throw new GatewayError(
        402,
        "insufficient_balance",
        `Your remaining balance (${formatMicroUsd(opened.spendableMicroUsd)}) cannot cover this request's worst case. Top up from the store, or send a smaller prompt / lower max_tokens.`
      );
    }
    if (opened.kind === "held") reservationId = opened.reservationId;

    const endpoint = wire === "anthropic" ? "/v1/messages" : "/v1/chat/completions";
    const estimatedInputTokens = opened.inputTokens;

    /**
     * Settlement runs the moment the stream ends — completion, upstream
     * failure, timeout or client cancel — and `after()` only keeps the
     * function alive until it has finished. It is idempotent per request id.
     */
    const settle = async (result: StreamOutcome, providerSlug: string, usageDialect: string) => {
      await settleRequest({
        requestId,
        reservationId,
        customerId: customer.id,
        storeId,
        tokenId: token.tokenId,
        tokenName: token.tokenName,
        model,
        providerSlug,
        usageDialect,
        endpoint,
        result,
        estimatedInputTokens,
        latencyMs: Date.now() - started,
      }).catch((e) => console.error("[gateway] settlement failed", requestId, e));
      await releaseLease({ requestId, customerId: customer.id, storeId });
    };
    const settleWhen = (done: Promise<StreamOutcome>, providerSlug: string, usageDialect: string) => {
      const settlement = done.then((o) => settle(o, providerSlug, usageDialect));
      after(() => settlement);
    };

    // ── Upstream ────────────────────────────────────────────────────────
    const { response, upstream, provider } = await dispatchChat(model, chatBody, request.signal);

    // ── Anthropic Messages wire ─────────────────────────────────────────
    if (wire === "anthropic") {
      if (streaming) {
        const { stream, done } = toAnthropicStream(upstream, model.publicSlug, provider.usageDialect);
        settleWhen(done, provider.slug, provider.usageDialect);
        return new Response(stream, { status: 200, headers: { ...SSE_HEADERS, "x-request-id": requestId } });
      }
      const chatJson = await readUpstreamJson(upstream);
      const { body, rawUsage } = toAnthropicResponse(chatJson, model.publicSlug, provider.usageDialect);
      settleWhen(Promise.resolve(completed(rawUsage)), provider.slug, provider.usageDialect);
      return Response.json(body, { status: 200, headers: { ...RESPONSE_HYGIENE_HEADERS, "x-request-id": requestId } });
    }

    // ── OpenAI Chat Completions wire ────────────────────────────────────
    if (streaming) {
      const { stream, done } = meterChatStream(upstream, { modelAlias: model.publicSlug });
      settleWhen(done, provider.slug, provider.usageDialect);
      return new Response(stream, { status: 200, headers: { ...SSE_HEADERS, "x-request-id": requestId } });
    }
    const json = await readUpstreamJson(upstream);
    // Present the catalog alias, never the upstream model or provider.
    presentAsAlias(json, model.publicSlug);
    settleWhen(Promise.resolve(completed(json.usage)), provider.slug, provider.usageDialect);
    return Response.json(json, { status: 200, headers: { ...RESPONSE_HYGIENE_HEADERS, "x-request-id": requestId } });
  } catch (e) {
    // Nothing reached the customer: give the hold and the lease back.
    if (reservationId) await release(reservationId).catch(() => undefined);
    if (lease) await releaseLease({ requestId, ...lease }).catch(() => undefined);
    const err = asGatewayError(e);
    // Unknown errors are logged with their real message; the customer only sees the generic one.
    if (err.status >= 500) console.error("[gateway]", requestId, err.status, err === e ? err.message : e);
    return errorResponse(wire, err, requestId);
  }
}

/** Non-streaming body read that respects the total timeout and clears the upstream timers. */
async function readUpstreamJson(upstream: import("@/lib/gateway/providers/openai-compatible").UpstreamHandle): Promise<Record<string, unknown>> {
  try {
    return (await upstream.response.json()) as Record<string, unknown>;
  } catch (e) {
    const timedOut = upstream.timedOut();
    throw new GatewayError(timedOut ? 504 : 502, timedOut ? "overloaded_error" : "api_error", timedOut ? "The model stopped responding (timeout)." : "Upstream returned an unreadable response.");
  } finally {
    upstream.finish();
  }
}

function completed(rawUsage: unknown): StreamOutcome {
  return { rawUsage: rawUsage && typeof rawUsage === "object" ? rawUsage : null, forwardedBytes: 0, finishReason: "stop", outcome: "COMPLETED", error: null };
}

export type { ResolvedModel };
