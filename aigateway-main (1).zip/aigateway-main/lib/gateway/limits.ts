import "server-only";
import { getRedis } from "@/lib/redis";

/**
 * Rate limits and concurrency leases (WS3).
 *
 * RPM: sliding window (two fixed windows, weighted) in one portable Lua
 * script, keyed per token AND per customer. (@upstash/ratelimit was tried
 * first: its scripts carry an Upstash-only shebang flag that plain Redis
 * rejects, so it cannot be tested locally and would fail open elsewhere.)
 * Concurrency: a sorted set `conc:{scope}` of request ids scored by lease
 * expiry; one Lua script prunes expired leases, checks the customer cap and
 * the store-wide ceiling, and adds the lease — atomically.
 *
 * Redis outage: both FAIL OPEN. RPM serves and warns; concurrency falls back
 * to a per-instance counter. Reservations (WS2) still protect the money.
 */

export function rateLimitsEnabled(): boolean {
  return (process.env.GATEWAY_RATE_LIMITS ?? "true").toLowerCase() !== "false";
}

// ─── RPM ────────────────────────────────────────────────────────────────────

export interface RpmResult {
  ok: boolean;
  /** Seconds until the window frees a slot (for Retry-After). */
  retryAfterSeconds: number;
  /** Which key refused: "token" | "customer". */
  scope?: "token" | "customer";
  /** True when Redis was unavailable and the check was skipped. */
  degraded?: boolean;
}

// KEYS[1] = current window counter, KEYS[2] = previous window counter
// ARGV = limit, windowMs, now
// Weighted sliding window: previous × (remaining share of the window) + current.
const RATE_LUA = `
local cur = tonumber(redis.call('GET', KEYS[1]) or '0')
local prev = tonumber(redis.call('GET', KEYS[2]) or '0')
local win = tonumber(ARGV[2])
local elapsed = tonumber(ARGV[3]) % win
local est = prev * ((win - elapsed) / win) + cur
if est >= tonumber(ARGV[1]) then return 0 end
local n = redis.call('INCR', KEYS[1])
if n == 1 then redis.call('PEXPIRE', KEYS[1], win * 2) end
return 1
`;
let rateScript: { eval(keys: string[], args: string[]): Promise<unknown> } | null = null;

// In-process sliding window for the fallback path.
const windows = new Map<string, number[]>();
function memoryLimit(key: string, limit: number, windowMs = 60_000): { ok: boolean; retryAfterSeconds: number } {
  const now = Date.now();
  const hits = (windows.get(key) ?? []).filter((t) => now - t < windowMs);
  if (hits.length >= limit) {
    windows.set(key, hits);
    return { ok: false, retryAfterSeconds: Math.max(1, Math.ceil((hits[0] + windowMs - now) / 1000)) };
  }
  hits.push(now);
  windows.set(key, hits);
  if (windows.size > 20_000) for (const [k, v] of windows) if (v.every((t) => now - t >= windowMs)) windows.delete(k);
  return { ok: true, retryAfterSeconds: 0 };
}

/** Generic sliding-window check (also used by login/activation forms). */
export async function checkRateLimit(key: string, limit: number, windowMs = 60_000): Promise<{ ok: boolean; retryAfterSeconds: number; degraded?: boolean }> {
  const redis = getRedis();
  if (!redis) return memoryLimit(key, limit, windowMs);
  try {
    rateScript ??= redis.createScript<number>(RATE_LUA);
    const now = Date.now();
    const slot = Math.floor(now / windowMs);
    const ok = (await rateScript.eval([`rl:${key}:${slot}`, `rl:${key}:${slot - 1}`], [String(limit), String(windowMs), String(now)])) as number;
    if (ok === 1) return { ok: true, retryAfterSeconds: 0 };
    return { ok: false, retryAfterSeconds: Math.max(1, Math.ceil((windowMs - (now % windowMs)) / 1000)) };
  } catch (e) {
    console.warn("[limits] rate limit check failed, failing open:", e instanceof Error ? e.message : e);
    return { ok: true, retryAfterSeconds: 0, degraded: true };
  }
}

/** Per-token and per-customer RPM; both must pass. */
export async function checkGatewayRpm(p: { tokenId: string; customerId: string; rpm: number }): Promise<RpmResult> {
  if (!rateLimitsEnabled() || p.rpm <= 0) return { ok: true, retryAfterSeconds: 0 };
  const token = await checkRateLimit(`tok:${p.tokenId}`, p.rpm);
  if (!token.ok) return { ok: false, retryAfterSeconds: token.retryAfterSeconds, scope: "token" };
  const customer = await checkRateLimit(`cus:${p.customerId}`, p.rpm);
  if (!customer.ok) return { ok: false, retryAfterSeconds: customer.retryAfterSeconds, scope: "customer" };
  return { ok: true, retryAfterSeconds: 0, degraded: token.degraded || customer.degraded };
}

// ─── Concurrency leases ─────────────────────────────────────────────────────

export interface LeaseInput {
  requestId: string;
  customerId: string;
  storeId: string;
  maxConcurrent: number;
  storeCeiling: number;
  /** Lease lifetime; must outlive the longest possible request. */
  ttlMs: number;
}

export type LeaseResult =
  | { ok: true; active: number; degraded?: boolean }
  | { ok: false; scope: "customer" | "store"; active: number };

// KEYS[1] = customer zset, KEYS[2] = store zset
// ARGV = now, member, expireAt, customerLimit, storeLimit, ttlMs
const ACQUIRE_LUA = `
redis.call('ZREMRANGEBYSCORE', KEYS[1], '-inf', ARGV[1])
redis.call('ZREMRANGEBYSCORE', KEYS[2], '-inf', ARGV[1])
local n1 = redis.call('ZCARD', KEYS[1])
local n2 = redis.call('ZCARD', KEYS[2])
if n1 >= tonumber(ARGV[4]) then return {0, 'customer', n1} end
if n2 >= tonumber(ARGV[5]) then return {0, 'store', n2} end
redis.call('ZADD', KEYS[1], ARGV[3], ARGV[2])
redis.call('ZADD', KEYS[2], ARGV[3], ARGV[2])
redis.call('PEXPIRE', KEYS[1], ARGV[6])
redis.call('PEXPIRE', KEYS[2], ARGV[6])
return {1, '', n1 + 1}
`;

const customerKey = (id: string) => `conc:${id}`;
const storeKey = (id: string) => `conc:store:${id}`;

// In-process fallback: member → expiry per scope.
const memoryLeases = new Map<string, Map<string, number>>();
function memoryScope(key: string, now: number): Map<string, number> {
  let m = memoryLeases.get(key);
  if (!m) {
    m = new Map();
    memoryLeases.set(key, m);
  }
  for (const [member, exp] of m) if (exp <= now) m.delete(member);
  return m;
}
function memoryAcquire(p: LeaseInput): LeaseResult {
  const now = Date.now();
  const c = memoryScope(customerKey(p.customerId), now);
  const s = memoryScope(storeKey(p.storeId), now);
  if (c.size >= p.maxConcurrent) return { ok: false, scope: "customer", active: c.size };
  if (s.size >= p.storeCeiling) return { ok: false, scope: "store", active: s.size };
  c.set(p.requestId, now + p.ttlMs);
  s.set(p.requestId, now + p.ttlMs);
  return { ok: true, active: c.size, degraded: true };
}
function memoryRelease(customerId: string, storeId: string, requestId: string): void {
  memoryLeases.get(customerKey(customerId))?.delete(requestId);
  memoryLeases.get(storeKey(storeId))?.delete(requestId);
}

let acquireScript: { eval(keys: string[], args: string[]): Promise<unknown> } | null = null;

export async function acquireLease(p: LeaseInput): Promise<LeaseResult> {
  if (!rateLimitsEnabled()) return { ok: true, active: 0 };
  const redis = getRedis();
  if (!redis) return memoryAcquire(p);
  try {
    acquireScript ??= redis.createScript<[number, string, number]>(ACQUIRE_LUA);
    const now = Date.now();
    const [ok, scope, active] = (await acquireScript.eval(
      [customerKey(p.customerId), storeKey(p.storeId)],
      [String(now), p.requestId, String(now + p.ttlMs), String(p.maxConcurrent), String(p.storeCeiling), String(p.ttlMs)]
    )) as [number, string, number];
    if (ok === 1) return { ok: true, active: Number(active) };
    return { ok: false, scope: scope === "store" ? "store" : "customer", active: Number(active) };
  } catch (e) {
    console.warn("[limits] lease acquire failed, falling back to per-instance counter:", e instanceof Error ? e.message : e);
    return memoryAcquire(p);
  }
}

export async function releaseLease(p: { requestId: string; customerId: string; storeId: string }): Promise<void> {
  if (!rateLimitsEnabled()) return;
  memoryRelease(p.customerId, p.storeId, p.requestId);
  const redis = getRedis();
  if (!redis) return;
  try {
    await redis.zrem(customerKey(p.customerId), p.requestId);
    await redis.zrem(storeKey(p.storeId), p.requestId);
  } catch (e) {
    // The lease expires on its own; nothing is stuck.
    console.warn("[limits] lease release failed (will expire):", e instanceof Error ? e.message : e);
  }
}

/** Live count for the admin UI / tests. */
export async function activeLeases(scope: { customerId: string } | { storeId: string }): Promise<number> {
  const key = "customerId" in scope ? customerKey(scope.customerId) : storeKey(scope.storeId);
  const redis = getRedis();
  const now = Date.now();
  if (!redis) return memoryScope(key, now).size;
  try {
    await redis.zremrangebyscore(key, "-inf", now);
    return await redis.zcard(key);
  } catch {
    return memoryScope(key, now).size;
  }
}

/** Test hook. */
export function _resetLimitsForTests(): void {
  windows.clear();
  memoryLeases.clear();
  rateScript = null;
  acquireScript = null;
}
