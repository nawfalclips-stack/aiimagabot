// Stream metering (WS5). Forwards the upstream Chat Completions SSE stream
// byte-for-byte while watching it: usage chunk, finish reason, error chunks,
// and how much content was actually delivered (so a cut-off stream can be
// estimated). When the client goes away, `cancel()` aborts the upstream so
// the provider stops generating — and stops billing us.

import { parseSse } from "@/lib/gateway/sse";
import type { UpstreamHandle } from "@/lib/gateway/providers/openai-compatible";

export type StreamEnd = "COMPLETED" | "CLIENT_DISCONNECTED" | "UPSTREAM_ERROR" | "TIMEOUT";

export interface StreamOutcome {
  /** The provider's usage object exactly as received, or null when none arrived. */
  rawUsage: unknown | null;
  /** UTF-8 bytes of content forwarded to the client: text, tool-call arguments, reasoning. */
  forwardedBytes: number;
  finishReason: string | null;
  outcome: StreamEnd;
  error: string | null;
}

const encoder = new TextEncoder();
const byteLen = (s: string) => encoder.encode(s).length;

/** Bytes of customer-visible content in one Chat Completions chunk. */
export function chunkContentBytes(chunk: Record<string, unknown>): number {
  const choice = (Array.isArray(chunk.choices) ? chunk.choices[0] : undefined) as Record<string, unknown> | undefined;
  const delta = (choice?.delta ?? {}) as Record<string, unknown>;
  let n = 0;
  if (typeof delta.content === "string") n += byteLen(delta.content);
  if (typeof delta.reasoning_content === "string") n += byteLen(delta.reasoning_content);
  if (typeof delta.reasoning === "string") n += byteLen(delta.reasoning);
  if (Array.isArray(delta.tool_calls)) {
    for (const tc of delta.tool_calls as Array<{ function?: { arguments?: string; name?: string } }>) {
      if (typeof tc.function?.arguments === "string") n += byteLen(tc.function.arguments);
      if (typeof tc.function?.name === "string") n += byteLen(tc.function.name);
    }
  }
  return n;
}

/** Output tokens estimated from delivered bytes when the provider sent no usage chunk. */
export function estimateOutputTokensFromBytes(forwardedBytes: number): number {
  return Math.ceil(forwardedBytes / 3.5);
}

/** Response fields that would reveal which upstream served the request (OpenRouter adds `provider`). */
const UPSTREAM_IDENTITY_KEYS = ["provider"] as const;

/**
 * Customers only ever see the catalog alias: replace the upstream model id
 * with it and drop fields naming the upstream provider. Mutates and returns `json`.
 */
export function presentAsAlias<T extends Record<string, unknown>>(json: T, alias: string): T {
  if ("model" in json) (json as Record<string, unknown>).model = alias;
  for (const k of UPSTREAM_IDENTITY_KEYS) delete (json as Record<string, unknown>)[k];
  return json;
}

/**
 * SSE rewriter for the client branch: every `data: {…}` line is re-emitted
 * with the model alias (see presentAsAlias); comments, `[DONE]` and anything
 * unparsable pass through untouched. Lines are split on "\n" and a partial
 * trailing line is held until its end arrives, so chunk boundaries never
 * corrupt an event.
 */
export function aliasSseStream(alias: string): TransformStream<Uint8Array, Uint8Array> {
  const decoder = new TextDecoder();
  let buffer = "";
  const rewrite = (line: string): string => {
    const m = /^data:\s?(\{.*\})(\r?)$/.exec(line);
    if (!m) return line;
    try {
      const json = JSON.parse(m[1]) as Record<string, unknown>;
      if (!("model" in json) && !UPSTREAM_IDENTITY_KEYS.some((k) => k in json)) return line;
      return `data: ${JSON.stringify(presentAsAlias(json, alias))}${m[2]}`;
    } catch {
      return line;
    }
  };
  return new TransformStream<Uint8Array, Uint8Array>({
    transform(chunk, controller) {
      buffer += decoder.decode(chunk, { stream: true });
      const cut = buffer.lastIndexOf("\n");
      if (cut === -1) return;
      const complete = buffer.slice(0, cut + 1);
      buffer = buffer.slice(cut + 1);
      controller.enqueue(encoder.encode(complete.split("\n").map(rewrite).join("\n")));
    },
    flush(controller) {
      buffer += decoder.decode();
      if (buffer) controller.enqueue(encoder.encode(rewrite(buffer)));
    },
  });
}

/**
 * Pass an OpenAI-format SSE stream through while metering it. With
 * `modelAlias`, the client's copy is rewritten so it names the catalog alias
 * instead of the upstream model (aliasSseStream); otherwise it is byte-exact. On a
 * mid-stream upstream failure, a terminal `{"error": …}` chunk is sent (no
 * failover after the first byte) and the stream is closed cleanly.
 *
 * `done` follows the *upstream*: it resolves when the provider has finished
 * (or died), because that is when the usage is known and the provider has
 * billed us — even if the client is still draining buffered bytes. A client
 * cancel before that resolves it as CLIENT_DISCONNECTED and aborts upstream.
 */
export function meterChatStream(upstream: UpstreamHandle, opts: { modelAlias?: string } = {}): { stream: ReadableStream<Uint8Array>; done: Promise<StreamOutcome> } {
  let resolveDone!: (o: StreamOutcome) => void;
  const done = new Promise<StreamOutcome>((r) => (resolveDone = r));
  let settled = false;
  const finish = (o: StreamOutcome) => {
    if (settled) return;
    settled = true;
    upstream.finish();
    resolveDone(o);
  };

  const body = upstream.response.body;
  if (!body) {
    const stream = new ReadableStream<Uint8Array>({
      start(c) {
        c.close();
      },
    });
    finish({ rawUsage: null, forwardedBytes: 0, finishReason: null, outcome: "UPSTREAM_ERROR", error: "empty upstream body" });
    return { stream, done };
  }

  let rawUsage: unknown | null = null;
  let forwardedBytes = 0;
  let finishReason: string | null = null;
  let error: string | null = null;
  let cancelled = false;

  // Two consumers of the same bytes: the client gets them raw, the meter
  // parses a copy. tee() keeps the passthrough byte-exact.
  const [toClient, toMeter] = body.tee();
  const events = parseSse(toMeter).getReader();

  void (async () => {
    try {
      for (;;) {
        const { value, done: eof } = await events.read();
        if (eof) break;
        if (value.data === "[DONE]") break;
        let chunk: Record<string, unknown>;
        try {
          chunk = JSON.parse(value.data) as Record<string, unknown>;
        } catch {
          continue;
        }
        if (chunk.error) {
          const e = chunk.error as { message?: string } | string;
          error = typeof e === "string" ? e : String(e.message ?? "upstream error");
        }
        if (chunk.usage && typeof chunk.usage === "object") rawUsage = chunk.usage;
        forwardedBytes += chunkContentBytes(chunk);
        const choice = (Array.isArray(chunk.choices) ? chunk.choices[0] : undefined) as Record<string, unknown> | undefined;
        if (choice && typeof choice.finish_reason === "string") finishReason = choice.finish_reason;
      }
      if (!cancelled) {
        const timedOut = upstream.timedOut();
        finish({ rawUsage, forwardedBytes, finishReason, outcome: timedOut ? "TIMEOUT" : error ? "UPSTREAM_ERROR" : "COMPLETED", error });
      }
    } catch (e) {
      if (!cancelled) {
        const timedOut = upstream.timedOut();
        if (!error) error = e instanceof Error ? e.message : String(e);
        finish({ rawUsage, forwardedBytes, finishReason, outcome: timedOut ? "TIMEOUT" : "UPSTREAM_ERROR", error });
      }
    } finally {
      events.releaseLock();
    }
  })();

  const reader = (opts.modelAlias ? toClient.pipeThrough(aliasSseStream(opts.modelAlias)) : toClient).getReader();
  const stream = new ReadableStream<Uint8Array>({
    async pull(controller) {
      try {
        const { value, done: eof } = await reader.read();
        if (eof) {
          controller.close();
          return;
        }
        controller.enqueue(value);
      } catch {
        // Upstream died mid-stream (socket close, timeout): tell the client in-band, then close.
        const timedOut = upstream.timedOut();
        const message = timedOut ? "The model stopped responding (timeout)." : "The model connection was interrupted.";
        try {
          controller.enqueue(encoder.encode(`data: ${JSON.stringify({ error: { message, type: "server_error", code: null } })}\n\ndata: [DONE]\n\n`));
          controller.close();
        } catch {
          /* client already gone */
        }
      }
    },
    cancel(reason) {
      cancelled = true;
      upstream.abort(reason);
      reader.cancel(reason).catch(() => undefined);
      // If the upstream had already finished, the meter settled it as COMPLETED
      // (the provider generated everything); otherwise this is a real disconnect.
      finish({ rawUsage, forwardedBytes, finishReason, outcome: "CLIENT_DISCONNECTED", error: "client disconnected" });
    },
  });

  return { stream, done };
}
