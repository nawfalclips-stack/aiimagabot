// Public price catalogs of the providers that publish one. Given a provider's
// base URL, returns its models' list prices so imports arrive priced and the
// Models page can re-sync them. Providers without a catalog return an empty map.

import { fetchDeepInfraCatalog, isDeepInfra } from "@/lib/gateway/providers/deepinfra";
import { fetchOpenRouterCatalog, isOpenRouter } from "@/lib/gateway/providers/openrouter";

export interface CatalogEntry {
  id: string;
  /** The provider's display name (admin-only; customers see our alias). */
  name: string;
  description: string;
  /** Provider price in micro-USD per 1M tokens (what GatewayModel stores). */
  inputMicroPerMTok: number;
  outputMicroPerMTok: number;
  /** Null = the provider publishes no cache price for this model. */
  cachedInputMicroPerMTok: number | null;
  cacheWriteMicroPerMTok: number | null;
  contextWindow: number | null;
  maxOutputTokens: number | null;
  deprecated: boolean;
  replacedBy: string | null;
}

export type CatalogSource = "deepinfra" | "openrouter";

export function catalogSource(baseUrl: string): CatalogSource | null {
  if (isDeepInfra(baseUrl)) return "deepinfra";
  if (isOpenRouter(baseUrl)) return "openrouter";
  return null;
}

/**
 * The usage dialect a provider must be read with. Known hosts override the
 * generic "openai" default: an OpenRouter provider left on "openai" would
 * never have its reported `cost` read (nor be asked for it), and would be
 * billed from list prices alone. An explicitly chosen non-default dialect wins.
 */
export function inferUsageDialect(baseUrl: string, stored: string): string {
  if (stored && stored !== "openai") return stored;
  return catalogSource(baseUrl) ?? (stored || "openai");
}

/** The provider's public catalog, or an empty map when it has none or it is unreachable. */
export async function loadProviderCatalog(baseUrl: string, opts: { fresh?: boolean } = {}): Promise<Map<string, CatalogEntry>> {
  const source = catalogSource(baseUrl);
  if (!source) return new Map();
  try {
    return source === "deepinfra" ? await fetchDeepInfraCatalog() : await fetchOpenRouterCatalog(opts);
  } catch (e) {
    console.warn(`[gateway] ${source} catalog unavailable:`, e instanceof Error ? e.message : e);
    return new Map();
  }
}
