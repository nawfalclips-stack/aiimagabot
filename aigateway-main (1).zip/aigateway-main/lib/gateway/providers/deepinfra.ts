// DeepInfra specifics. Its chat endpoint is plain OpenAI-compatible (handled
// by openai-compatible.ts); what's special is the public catalog at
// https://api.deepinfra.com/models/list — no key required — which carries
// per-token prices and context sizes, so imported models arrive priced.

import type { CatalogEntry } from "@/lib/gateway/providers/catalog";

export const DEEPINFRA_BASE_URL = "https://api.deepinfra.com/v1/openai";
const CATALOG_URL = "https://api.deepinfra.com/models/list";

export function isDeepInfra(baseUrl: string): boolean {
  try {
    return new URL(baseUrl).hostname.endsWith("deepinfra.com");
  } catch {
    return false;
  }
}

interface RawEntry {
  model_name: string;
  type?: string;
  description?: string;
  max_tokens?: number | null;
  deprecated?: number | null;
  replaced_by?: string | null;
  pricing?: {
    type?: string;
    cents_per_input_token?: number | null;
    cents_per_output_token?: number | null;
  } | null;
}

/** cents per token → micro-USD per 1M tokens (0.0005 ¢/tok = $5/M = 5 000 000 µ$/M). */
function centsPerTokenToMicroPerMTok(cents: number | null | undefined): number {
  if (typeof cents !== "number" || !Number.isFinite(cents) || cents < 0) return 0;
  return Math.round(cents * 1e10);
}

let cache: { at: number; entries: Map<string, CatalogEntry> } | null = null;
const CACHE_MS = 10 * 60 * 1000;

/** Text-generation models in DeepInfra's public catalog, keyed by model id. Cached 10 min. */
export async function fetchDeepInfraCatalog(): Promise<Map<string, CatalogEntry>> {
  if (cache && Date.now() - cache.at < CACHE_MS) return cache.entries;
  const res = await fetch(CATALOG_URL, { headers: { Accept: "application/json" }, signal: AbortSignal.timeout(15_000) });
  if (!res.ok) throw new Error(`DeepInfra catalog returned ${res.status}`);
  const raw = (await res.json()) as RawEntry[];
  const entries = new Map<string, CatalogEntry>();
  for (const m of raw) {
    if (!m?.model_name || m.type !== "text-generation") continue;
    if (m.pricing?.type && m.pricing.type !== "tokens") continue;
    entries.set(m.model_name, {
      id: m.model_name,
      name: m.model_name,
      description: m.description ?? "",
      inputMicroPerMTok: centsPerTokenToMicroPerMTok(m.pricing?.cents_per_input_token),
      outputMicroPerMTok: centsPerTokenToMicroPerMTok(m.pricing?.cents_per_output_token),
      // DeepInfra publishes no cache prices.
      cachedInputMicroPerMTok: null,
      cacheWriteMicroPerMTok: null,
      contextWindow: typeof m.max_tokens === "number" && m.max_tokens > 0 ? m.max_tokens : null,
      maxOutputTokens: null,
      deprecated: typeof m.deprecated === "number" && m.deprecated > 0,
      replacedBy: m.replaced_by ?? null,
    });
  }
  cache = { at: Date.now(), entries };
  return entries;
}
