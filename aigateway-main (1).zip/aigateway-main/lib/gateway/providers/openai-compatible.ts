import "server-only";
import { UPSTREAM_TOTAL_TIMEOUT_MS } from "@/lib/gateway/duration";

// Adapter for any provider exposing the OpenAI Chat Completions surface
// (DeepInfra, DeepSeek, Together, Groq, OpenRouter, OpenAI itself …).

export interface ProviderTarget {
  baseUrl: string; // e.g. https://api.deepinfra.com/v1/openai
  apiKey: string;
  upstreamModelId: string;
  /** Extra headers (e.g. OpenRouter attribution). */
  extraHeaders?: Record<string, string>;
}

/** Connect + first-byte timeout when the caller gives none. Generation itself may run much longer. */
const FIRST_BYTE_TIMEOUT_MS = 20_000;
/** Whole-request ceiling when the caller gives none; below the route maxDuration. */
const TOTAL_TIMEOUT_MS = UPSTREAM_TOTAL_TIMEOUT_MS;

export class UpstreamTimeoutError extends Error {
  constructor(public phase: "ttfb" | "total", ms: number) {
    super(`Upstream ${phase === "ttfb" ? "first-byte" : "total"} timeout after ${ms} ms`);
  }
}

export class ClientDisconnectedError extends Error {
  constructor() {
    super("Client disconnected");
  }
}

/**
 * Control over an in-flight upstream request (WS5). The three abort sources
 * — client disconnect, TTFB timeout, total timeout — all feed one controller,
 * so the upstream fetch (and its body stream) is torn down the moment any of
 * them fires and we stop paying for tokens nobody reads.
 */
export interface UpstreamHandle {
  response: Response;
  /** Milliseconds until upstream headers arrived. */
  ttfbMs: number;
  /** Abort the upstream body (client went away). */
  abort(reason?: unknown): void;
  /** Stream fully consumed or given up: clear timers and listeners. */
  finish(): void;
  /** Which timeout fired, if any. */
  timedOut(): "ttfb" | "total" | null;
  clientAborted(): boolean;
}

export async function chatCompletions(
  target: ProviderTarget,
  body: Record<string, unknown>,
  signal?: AbortSignal,
  opts: { ttfbTimeoutMs?: number; totalTimeoutMs?: number } = {}
): Promise<UpstreamHandle> {
  const ttfb = opts.ttfbTimeoutMs ?? FIRST_BYTE_TIMEOUT_MS;
  const total = opts.totalTimeoutMs ?? TOTAL_TIMEOUT_MS;
  const controller = new AbortController();
  let timedOut: "ttfb" | "total" | null = null;
  let clientAborted = signal?.aborted ?? false;

  const ttfbTimer = setTimeout(() => {
    timedOut = "ttfb";
    controller.abort(new UpstreamTimeoutError("ttfb", ttfb));
  }, ttfb);
  const totalTimer = setTimeout(() => {
    timedOut = "total";
    controller.abort(new UpstreamTimeoutError("total", total));
  }, total);
  const onClientAbort = () => {
    clientAborted = true;
    controller.abort(new ClientDisconnectedError());
  };
  if (clientAborted) controller.abort(new ClientDisconnectedError());
  signal?.addEventListener("abort", onClientAbort, { once: true });

  const finish = () => {
    clearTimeout(ttfbTimer);
    clearTimeout(totalTimer);
    signal?.removeEventListener("abort", onClientAbort);
  };

  const started = Date.now();
  let response: Response;
  try {
    response = await fetch(`${target.baseUrl}/chat/completions`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${target.apiKey}`,
        Accept: body.stream ? "text/event-stream" : "application/json",
        ...(target.extraHeaders ?? {}),
      },
      body: JSON.stringify({ ...body, model: target.upstreamModelId }),
      signal: controller.signal,
      // @ts-expect-error — Node fetch option, ignored elsewhere: never buffer the response body.
      duplex: "half",
    });
  } catch (e) {
    finish();
    if (clientAborted) throw new ClientDisconnectedError();
    if (timedOut) throw new UpstreamTimeoutError(timedOut, timedOut === "ttfb" ? ttfb : total);
    throw e;
  }
  // Headers arrived: the first-byte clock stops, the total clock keeps running.
  clearTimeout(ttfbTimer);

  return {
    response,
    ttfbMs: Date.now() - started,
    abort: (reason) => controller.abort(reason ?? new ClientDisconnectedError()),
    finish,
    timedOut: () => timedOut,
    clientAborted: () => clientAborted,
  };
}

export interface UpstreamModel {
  id: string;
  ownedBy?: string;
}

export async function listModels(target: Pick<ProviderTarget, "baseUrl" | "apiKey">): Promise<UpstreamModel[]> {
  const res = await fetch(`${target.baseUrl}/models`, {
    headers: { Authorization: `Bearer ${target.apiKey}`, Accept: "application/json" },
    signal: AbortSignal.timeout(15_000),
  });
  if (!res.ok) {
    throw new Error(`GET /models returned ${res.status} ${res.statusText}`);
  }
  const json = (await res.json()) as { data?: Array<{ id: string; owned_by?: string }> };
  return (json.data ?? []).map((m) => ({ id: m.id, ownedBy: m.owned_by }));
}

/** Cheap liveness probe used by the admin "Test connection" button. */
export async function probe(target: Pick<ProviderTarget, "baseUrl" | "apiKey">): Promise<{ ok: boolean; message: string; ms: number }> {
  const started = Date.now();
  try {
    const models = await listModels(target);
    return { ok: true, message: `Reachable — ${models.length} models listed`, ms: Date.now() - started };
  } catch (e) {
    return { ok: false, message: e instanceof Error ? e.message : String(e), ms: Date.now() - started };
  }
}
