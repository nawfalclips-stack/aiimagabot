// OpenRouter specifics. Chat goes through openai-compatible.ts; what's special
// is the public model list at https://openrouter.ai/api/v1/models — no key
// required — which carries per-token prices (USD strings) including prompt
// cache reads and writes, so imported models arrive fully priced and can be
// re-synced when OpenRouter changes a price.
//
// Billing does not depend on this list: every OpenRouter response reports the
// `cost` it actually charged (usage accounting, see dispatch.ts), and
// settlement prices the customer from that. The list feeds the reservation
// estimate, the prices customers see, and the fallback when no cost arrives.

import type { CatalogEntry } from "@/lib/gateway/providers/catalog";

export const OPENROUTER_BASE_URL = "https://openrouter.ai/api/v1";
const CATALOG_URL = "https://openrouter.ai/api/v1/models";

export function isOpenRouter(baseUrl: string): boolean {
  try {
    return new URL(baseUrl).hostname.endsWith("openrouter.ai");
  } catch {
    return false;
  }
}

interface RawModel {
  id: string;
  name?: string;
  description?: string;
  context_length?: number | null;
  architecture?: { output_modalities?: string[] } | null;
  pricing?: Record<string, string | undefined> | null;
  top_provider?: { context_length?: number | null; max_completion_tokens?: number | null } | null;
}

/**
 * USD per token (a decimal string such as "0.0000025") → micro-USD per 1M
 * tokens, exactly: µ$/MTok = USD/token × 10^12. Parsed as a decimal, not a
 * float, so "0.000003" becomes 3 000 000 and not 2 999 999.
 * Null for missing values and for OpenRouter's "-1" (price decided per request, e.g. openrouter/auto).
 */
export function usdPerTokenToMicroPerMTok(v: string | number | null | undefined): number | null {
  if (v === null || v === undefined) return null;
  const text = typeof v === "number" ? v.toFixed(15) : v.trim();
  const m = /^(\d+)(?:\.(\d+))?$/.exec(text);
  if (!m) return null; // negative ("-1") or malformed
  const frac = (m[2] ?? "").padEnd(12, "0");
  const whole = BigInt(m[1]) * 1_000_000_000_000n;
  const head = BigInt(frac.slice(0, 12) || "0");
  // Round half up on the 13th decimal.
  const roundUp = frac.length > 12 && Number(frac[12]) >= 5 ? 1n : 0n;
  const micro = whole + head + roundUp;
  return micro > BigInt(Number.MAX_SAFE_INTEGER) ? null : Number(micro);
}

/** Normalise one entry of OpenRouter's /models response; null when it cannot be priced per token. */
export function parseOpenRouterModel(m: RawModel): CatalogEntry | null {
  if (!m?.id) return null;
  const outputs = m.architecture?.output_modalities;
  if (Array.isArray(outputs) && outputs.length > 0 && !outputs.includes("text")) return null;
  const input = usdPerTokenToMicroPerMTok(m.pricing?.prompt);
  const output = usdPerTokenToMicroPerMTok(m.pricing?.completion);
  if (input === null || output === null) return null;
  const context = m.top_provider?.context_length ?? m.context_length ?? null;
  const maxOut = m.top_provider?.max_completion_tokens ?? null;
  return {
    id: m.id,
    name: m.name ?? m.id,
    description: m.description ?? "",
    inputMicroPerMTok: input,
    outputMicroPerMTok: output,
    cachedInputMicroPerMTok: usdPerTokenToMicroPerMTok(m.pricing?.input_cache_read),
    cacheWriteMicroPerMTok: usdPerTokenToMicroPerMTok(m.pricing?.input_cache_write),
    contextWindow: typeof context === "number" && context > 0 ? context : null,
    maxOutputTokens: typeof maxOut === "number" && maxOut > 0 ? maxOut : null,
    deprecated: false,
    replacedBy: null,
  };
}

let cache: { at: number; entries: Map<string, CatalogEntry> } | null = null;
const CACHE_MS = 10 * 60 * 1000;

/** OpenRouter's public catalog keyed by model id (e.g. "anthropic/claude-opus-4.5"). Cached 10 min. */
export async function fetchOpenRouterCatalog(opts: { fresh?: boolean } = {}): Promise<Map<string, CatalogEntry>> {
  if (!opts.fresh && cache && Date.now() - cache.at < CACHE_MS) return cache.entries;
  const res = await fetch(CATALOG_URL, { headers: { Accept: "application/json" }, signal: AbortSignal.timeout(15_000) });
  if (!res.ok) throw new Error(`OpenRouter catalog returned ${res.status}`);
  const json = (await res.json()) as { data?: RawModel[] };
  const entries = new Map<string, CatalogEntry>();
  for (const raw of json.data ?? []) {
    const entry = parseOpenRouterModel(raw);
    if (entry) entries.set(entry.id, entry);
  }
  cache = { at: Date.now(), entries };
  return entries;
}
