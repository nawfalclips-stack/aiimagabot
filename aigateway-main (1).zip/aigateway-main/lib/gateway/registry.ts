import "server-only";
import { prisma } from "@/lib/prisma";
import { decryptSecret } from "@/lib/gateway/crypto";
import { BREAKER_DEFAULTS, type BreakerConfig } from "@/lib/gateway/breaker";
import { getRedis } from "@/lib/redis";
import { UPSTREAM_TOTAL_TIMEOUT_MS } from "@/lib/gateway/duration";
import { inferUsageDialect } from "@/lib/gateway/providers/catalog";
import { publicModelId, publicModelName } from "@/lib/model-alias";

/** TTFB defaults (ms): reasoning models think before the first token. */
export const TTFB_DEFAULT_MS = 20_000;
export const TTFB_REASONING_MS = 60_000;
/** Total upstream time (ms) unless the provider says otherwise; below the route maxDuration. */
export const TOTAL_TIMEOUT_DEFAULT_MS = UPSTREAM_TOTAL_TIMEOUT_MS;

export interface ProviderCandidate {
  providerId: string;
  /** ProviderModel id — the breaker's unit. */
  providerModelId: string;
  slug: string;
  name: string;
  baseUrl: string;
  apiKey: string;
  upstreamModelId: string;
  /** Provider priority first, then mapping priority (lower wins). */
  order: [number, number];
  ttfbTimeoutMs: number;
  totalTimeoutMs: number;
  breaker: BreakerConfig;
  /** Which normaliser reads this provider's usage object (WS6). */
  usageDialect: string;
  /** Whether stream_options.include_usage may be sent on streams. */
  supportsStreamUsage: boolean;
}

export interface ResolvedModel {
  id: string;
  /** Internal id (admin, UsageLog.model, reservations). Never shown to customers. */
  slug: string;
  displayName: string;
  /** What customers see and type: the public alias, else the slug. Use this in every response. */
  publicSlug: string;
  publicName: string;
  inputPriceMicroPerMTok: number;
  outputPriceMicroPerMTok: number;
  cachedInputPriceMicroPerMTok: number | null;
  cacheWritePriceMicroPerMTok: number | null;
  contextWindow: number | null;
  maxOutputTokens: number | null;
  isReasoning: boolean;
  enabledStoreIds: string[];
  candidates: ProviderCandidate[];
}

/**
 * Catalog cache (WS12.3): 60 s in memory per instance, plus a version counter
 * in Redis (`gw:catalog:ver`) that admin edits bump. Every lookup compares
 * its cached version with Redis, so an edit on one instance invalidates the
 * others' copies at once instead of after the TTL. The compiled catalog holds
 * decrypted provider keys and is therefore never itself stored in Redis.
 */
const TTL_MS = 60_000;
const VERSION_KEY = "gw:catalog:ver";
let cache: { at: number; version: number | null; models: Map<string, ResolvedModel> } | null = null;

async function catalogVersion(): Promise<number | null> {
  const redis = getRedis();
  if (!redis) return null;
  try {
    const v = await redis.get<number>(VERSION_KEY);
    return typeof v === "number" ? v : Number(v ?? 0) || 0;
  } catch {
    return null; // Redis hiccup: fall back to the TTL alone
  }
}

async function load(): Promise<Map<string, ResolvedModel>> {
  const rows = await prisma.gatewayModel.findMany({
    where: { enabled: true },
    include: {
      providers: {
        where: { enabled: true, provider: { enabled: true } },
        include: { provider: true },
      },
    },
    orderBy: { slug: "asc" },
  });

  const models = new Map<string, ResolvedModel>();
  for (const row of rows) {
    const candidates: ProviderCandidate[] = [];
    for (const pm of row.providers) {
      candidates.push({
        providerId: pm.provider.id,
        providerModelId: pm.id,
        slug: pm.provider.slug,
        name: pm.provider.name,
        baseUrl: pm.provider.baseUrl.replace(/\/+$/, ""),
        apiKey: await decryptSecret(pm.provider.apiKeyEnc),
        upstreamModelId: pm.upstreamModelId,
        order: [pm.provider.priority, pm.priority],
        ttfbTimeoutMs: pm.ttfbTimeoutMs ?? pm.provider.ttfbTimeoutMs ?? (row.isReasoning ? TTFB_REASONING_MS : TTFB_DEFAULT_MS),
        totalTimeoutMs: pm.provider.totalTimeoutMs ?? TOTAL_TIMEOUT_DEFAULT_MS,
        breaker: {
          failureThreshold: pm.provider.breakerFailureThreshold ?? BREAKER_DEFAULTS.failureThreshold,
          windowMs: pm.provider.breakerWindowMs ?? BREAKER_DEFAULTS.windowMs,
          openMs: pm.provider.breakerOpenMs ?? BREAKER_DEFAULTS.openMs,
        },
        usageDialect: inferUsageDialect(pm.provider.baseUrl, pm.provider.usageDialect),
        supportsStreamUsage: pm.provider.supportsStreamUsage,
      });
    }
    candidates.sort((a, b) => a.order[0] - b.order[0] || a.order[1] - b.order[1]);
    models.set(row.slug, {
      id: row.id,
      slug: row.slug,
      displayName: row.displayName,
      publicSlug: publicModelId(row),
      publicName: publicModelName(row),
      inputPriceMicroPerMTok: row.inputPriceMicroPerMTok,
      outputPriceMicroPerMTok: row.outputPriceMicroPerMTok,
      cachedInputPriceMicroPerMTok: row.cachedInputPriceMicroPerMTok,
      cacheWritePriceMicroPerMTok: row.cacheWritePriceMicroPerMTok,
      contextWindow: row.contextWindow,
      maxOutputTokens: row.maxOutputTokens,
      isReasoning: row.isReasoning,
      enabledStoreIds: row.enabledStoreIds
        .split(",")
        .map((s) => s.trim())
        .filter(Boolean),
      candidates,
    });
  }
  return models;
}

export async function getModelRegistry(): Promise<Map<string, ResolvedModel>> {
  const version = await catalogVersion();
  if (cache && Date.now() - cache.at < TTL_MS && (version === null || cache.version === version)) return cache.models;
  const models = await load();
  cache = { at: Date.now(), version, models };
  return models;
}

/**
 * Admin actions call this after editing providers/models so changes apply
 * immediately — on this instance (memory) and on every other one (Redis
 * version bump). Resolves once the bump is written; safe to call without
 * awaiting when the caller only needs the local effect.
 */
export async function invalidateModelRegistry(): Promise<void> {
  cache = null;
  const redis = getRedis();
  if (!redis) return;
  try {
    await redis.incr(VERSION_KEY);
  } catch (e) {
    console.warn("[registry] could not bump the catalog version; other instances refresh within 60 s", e instanceof Error ? e.message : e);
  }
}

export function modelVisibleToStore(model: ResolvedModel, storeId: string): boolean {
  return model.enabledStoreIds.length === 0 || model.enabledStoreIds.includes(storeId);
}

/** Models a given store's customers may use (with at least one live provider). */
export async function listModelsForStore(storeId: string): Promise<ResolvedModel[]> {
  const registry = await getModelRegistry();
  return [...registry.values()].filter((m) => modelVisibleToStore(m, storeId) && m.candidates.length > 0);
}

/**
 * Resolve the model a customer asked for — by public alias first, then by the
 * internal slug (so configs written before an alias existed keep working);
 * null when unknown or not allowed for the store.
 */
export async function resolveModel(slug: string, storeId: string): Promise<ResolvedModel | null> {
  const registry = await getModelRegistry();
  const key = slug.trim();
  let model: ResolvedModel | undefined;
  for (const m of registry.values()) {
    if (m.publicSlug === key) {
      model = m;
      break;
    }
  }
  model ??= registry.get(key);
  if (!model || !modelVisibleToStore(model, storeId)) return null;
  return model;
}
