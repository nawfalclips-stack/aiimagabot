// Server-Sent Events helpers: parse an upstream OpenAI-style stream into
// `data:` payloads, and encode outgoing events.

export interface SseEvent {
  event?: string;
  data: string;
}

/**
 * Turn a byte stream of SSE into a stream of parsed events. Handles events
 * split across chunks and multi-line `data:` fields.
 */
export function parseSse(input: ReadableStream<Uint8Array>): ReadableStream<SseEvent> {
  const decoder = new TextDecoder();
  let buffer = "";

  const flush = (block: string, controller: { enqueue(e: SseEvent): void }) => {
    let event: string | undefined;
    const dataLines: string[] = [];
    for (const line of block.split(/\r?\n/)) {
      if (line.startsWith("event:")) event = line.slice(6).trim();
      else if (line.startsWith("data:")) dataLines.push(line.slice(5).replace(/^ /, ""));
      // comments (":") and other fields are ignored
    }
    if (dataLines.length > 0) controller.enqueue({ event, data: dataLines.join("\n") });
  };

  return input.pipeThrough(
    new TransformStream<Uint8Array, SseEvent>({
      transform(chunk, controller) {
        buffer += decoder.decode(chunk, { stream: true });
        let idx: number;
        // Events are separated by a blank line.
        while ((idx = buffer.search(/\r?\n\r?\n/)) !== -1) {
          const block = buffer.slice(0, idx);
          buffer = buffer.slice(idx).replace(/^\r?\n\r?\n/, "");
          if (block.trim()) flush(block, controller);
        }
      },
      flush(controller) {
        buffer += decoder.decode();
        if (buffer.trim()) flush(buffer, controller);
        buffer = "";
      },
    })
  );
}

const encoder = new TextEncoder();

export function encodeSse(event: string | undefined, data: unknown): Uint8Array {
  const payload = typeof data === "string" ? data : JSON.stringify(data);
  return encoder.encode(`${event ? `event: ${event}\n` : ""}data: ${payload}\n\n`);
}

export const SSE_HEADERS = {
  "Content-Type": "text/event-stream; charset=utf-8",
  "Cache-Control": "no-cache, no-transform",
  Connection: "keep-alive",
  "X-Accel-Buffering": "no",
  "X-Content-Type-Options": "nosniff",
} as const;
