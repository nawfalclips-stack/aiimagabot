import "server-only";
import { createHash, randomBytes } from "node:crypto";
import type { Customer, Plan } from "@prisma/client";
import { prisma } from "@/lib/prisma";
import { decryptSecret, encryptSecret } from "@/lib/gateway/crypto";
import { invalidateAuthCache, lookupAuthCache, storeAuthCache, storeNegativeAuthCache, type CachedToken } from "@/lib/gateway/auth-cache";

export const TOKEN_PREFIX = "al_";
const TOKEN_BODY_LENGTH = 40;
const ALPHABET = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

/** Customers may hold this many active tokens at once. */
export const MAX_ACTIVE_TOKENS = 5;

export function hashToken(token: string): string {
  return createHash("sha256").update(token).digest("hex");
}

/** Generate a fresh plaintext token. Lookups go through its sha256 hash. */
export function generateToken(): string {
  const bytes = randomBytes(TOKEN_BODY_LENGTH);
  let body = "";
  for (let i = 0; i < TOKEN_BODY_LENGTH; i++) body += ALPHABET[bytes[i] % ALPHABET.length];
  return `${TOKEN_PREFIX}${body}`;
}

export function tokenPrefix(token: string): string {
  return token.slice(0, 12);
}

export async function createGatewayToken(customerId: string, storeId: string, name: string) {
  const active = await prisma.gatewayToken.count({ where: { customerId, revokedAt: null } });
  if (active >= MAX_ACTIVE_TOKENS) {
    throw new Error(`You can keep at most ${MAX_ACTIVE_TOKENS} active tokens. Revoke one first.`);
  }
  const token = generateToken();
  const row = await prisma.gatewayToken.create({
    data: {
      customerId,
      storeId,
      name: name.trim().slice(0, 40) || "Default",
      prefix: tokenPrefix(token),
      tokenHash: hashToken(token),
      // Kept encrypted (same scheme as provider keys) so the portal can show
      // the full token again when the customer selects it.
      tokenEnc: await encryptSecret(token),
    },
  });
  return { token, row };
}

/** Full plaintext of one of the customer's tokens, or null when it was created before reveal existed. */
export async function revealGatewayToken(customerId: string, tokenId: string): Promise<string | null> {
  const row = await prisma.gatewayToken.findFirst({ where: { id: tokenId, customerId }, select: { tokenEnc: true } });
  if (!row || !row.tokenEnc) return null;
  return decryptSecret(row.tokenEnc);
}

export async function revokeGatewayToken(customerId: string, tokenId: string): Promise<boolean> {
  const row = await prisma.gatewayToken.findFirst({ where: { id: tokenId, customerId, revokedAt: null }, select: { tokenHash: true } });
  if (!row) return false;
  const result = await prisma.gatewayToken.updateMany({
    where: { id: tokenId, customerId, revokedAt: null },
    data: { revokedAt: new Date() },
  });
  if (result.count > 0) await invalidateAuthCache(row.tokenHash); // revocation is immediate on every instance
  return result.count > 0;
}

export type AuthFailure =
  | "MISSING"
  | "INVALID"
  | "REVOKED"
  | "CUSTOMER_DELETED"
  | "SUSPENDED"
  | "NOT_ACTIVATED"
  | "NO_BALANCE";

/** The customer as the gateway needs it: the row plus the plan it bills at. */
export type AuthCustomer = Customer & { plan: Plan | null };

/** Token identity (the cached part of an authentication). */
export type AuthToken = CachedToken;

export type AuthResult =
  | { ok: true; customer: AuthCustomer; token: AuthToken; cached: boolean }
  | { ok: false; reason: AuthFailure };

function customerGate(customer: Customer): AuthFailure | null {
  if (customer.deletedAt) return "CUSTOMER_DELETED";
  if (customer.status === "SUSPENDED" || customer.status === "EXPIRED") return "SUSPENDED";
  if (!customer.isActivated) return "NOT_ACTIVATED";
  const remaining =
    customer.initialBalanceCents - customer.usedBalanceCents + (customer.initialBonusCents - customer.usedBonusCents);
  if (remaining <= 0) return "NO_BALANCE";
  return null;
}

/**
 * Resolve the bearer token on a gateway request. Accepts `Authorization: Bearer`
 * (Codex / OpenAI clients) and `x-api-key` (Claude Code / Anthropic clients).
 *
 * The token → customer binding comes from the Redis auth cache when present
 * (WS12.3); the customer row is always read fresh so status changes apply at
 * once. Unknown and revoked tokens are negative-cached for 10 s.
 */
export async function authenticateGatewayRequest(headers: Headers): Promise<AuthResult> {
  const bearer = headers.get("authorization");
  let raw = "";
  if (bearer && /^bearer\s+/i.test(bearer)) raw = bearer.replace(/^bearer\s+/i, "").trim();
  if (!raw) raw = (headers.get("x-api-key") ?? "").trim();
  if (!raw) return { ok: false, reason: "MISSING" };
  if (!raw.startsWith(TOKEN_PREFIX)) return { ok: false, reason: "INVALID" };

  const hash = hashToken(raw);
  const cached = await lookupAuthCache(hash);
  if (cached.kind === "negative") return { ok: false, reason: "INVALID" };

  if (cached.kind === "hit") {
    const customer = await prisma.customer.findUnique({ where: { id: cached.token.customerId }, include: { plan: true } });
    if (!customer) return { ok: false, reason: "CUSTOMER_DELETED" };
    const gate = customerGate(customer);
    if (gate) return { ok: false, reason: gate };
    return { ok: true, customer, token: cached.token, cached: true };
  }

  const token = await prisma.gatewayToken.findUnique({
    where: { tokenHash: hash },
    include: { customer: { include: { plan: true } } },
  });
  if (!token) {
    await storeNegativeAuthCache(hash);
    return { ok: false, reason: "INVALID" };
  }
  if (token.revokedAt) {
    await storeNegativeAuthCache(hash);
    return { ok: false, reason: "REVOKED" };
  }

  const identity: AuthToken = { tokenId: token.id, tokenName: token.name, customerId: token.customerId, storeId: token.storeId };
  await storeAuthCache(hash, identity);

  const gate = customerGate(token.customer);
  if (gate) return { ok: false, reason: gate };

  // Last-used stamp: only on a cache miss, i.e. at most once per cache TTL
  // with Redis, once a minute without it.
  const stale = !token.lastUsedAt || Date.now() - token.lastUsedAt.getTime() > 60_000;
  if (stale) {
    prisma.gatewayToken
      .update({ where: { id: token.id }, data: { lastUsedAt: new Date() } })
      .catch(() => undefined);
  }

  return { ok: true, customer: token.customer, token: identity, cached: false };
}

export const AUTH_FAILURE_MESSAGES: Record<AuthFailure, { status: number; message: string }> = {
  MISSING: { status: 401, message: "Missing API token. Send it as `Authorization: Bearer <token>` or `x-api-key`." },
  INVALID: { status: 401, message: "Invalid API token." },
  REVOKED: { status: 401, message: "This API token has been revoked. Create a new one in your portal." },
  CUSTOMER_DELETED: { status: 403, message: "This account is no longer active." },
  SUSPENDED: { status: 403, message: "This account is suspended. Contact support through the store." },
  NOT_ACTIVATED: { status: 403, message: "Your account is waiting for activation approval." },
  NO_BALANCE: { status: 402, message: "Your balance is exhausted. Top up from the store to keep using the API." },
};
