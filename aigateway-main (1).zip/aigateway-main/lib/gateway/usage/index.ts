// Usage normalisation (WS6). Every provider reports token usage in its own
// dialect; the gateway prices one internal shape. Field names come from the
// providers' documentation (verified 2026-09-21, see docs/gateway-audit.md
// §15) and are pinned by test/fixtures/usage/*.json — record real responses
// with `npm run usage:record` when a key is available.
//
// Client-safe: no server imports.

export type UsageDialect = "openai" | "deepseek" | "deepinfra" | "openrouter" | "anthropic";
export const USAGE_DIALECTS: readonly UsageDialect[] = ["openai", "deepseek", "deepinfra", "openrouter", "anthropic"] as const;

export interface NormalizedUsage {
  /** Prompt tokens billed at the full input rate. */
  inputUncached: bigint;
  /** Prompt tokens served from the provider's prompt cache. */
  inputCached: bigint;
  /** Prompt tokens written to the cache (Anthropic-style cache creation). */
  cacheWrite: bigint;
  /** Completion tokens (visible output). */
  output: bigint;
  /** Reasoning/thinking tokens, when the provider reports them separately; billed as output unless priced apart. */
  reasoning: bigint;
  /** Provider-reported cost in micro-USD, when the dialect carries one (DeepInfra, OpenRouter). */
  providerCostMicroUsd: bigint | null;
}

export const ZERO_USAGE: NormalizedUsage = { inputUncached: 0n, inputCached: 0n, cacheWrite: 0n, output: 0n, reasoning: 0n, providerCostMicroUsd: null };

type Json = Record<string, unknown>;

function num(v: unknown): bigint {
  if (typeof v === "number" && Number.isFinite(v) && v >= 0) return BigInt(Math.round(v));
  if (typeof v === "string" && /^\d+$/.test(v)) return BigInt(v);
  return 0n;
}

function usd(v: unknown): bigint | null {
  return typeof v === "number" && Number.isFinite(v) && v >= 0 ? BigInt(Math.round(v * 1_000_000)) : null;
}

function obj(v: unknown): Json {
  return v && typeof v === "object" && !Array.isArray(v) ? (v as Json) : {};
}

/** OpenAI Chat Completions: prompt_tokens_details.cached_tokens, completion_tokens_details.reasoning_tokens. */
function fromOpenAI(u: Json): NormalizedUsage {
  const prompt = num(u.prompt_tokens);
  const cached = num(obj(u.prompt_tokens_details).cached_tokens);
  const reasoning = num(obj(u.completion_tokens_details).reasoning_tokens);
  const completion = num(u.completion_tokens);
  return {
    inputUncached: prompt > cached ? prompt - cached : 0n,
    inputCached: cached,
    cacheWrite: 0n,
    // OpenAI counts reasoning inside completion_tokens; keep it visible but do not double count.
    output: completion > reasoning ? completion - reasoning : completion,
    reasoning,
    providerCostMicroUsd: null,
  };
}

/** DeepSeek: prompt_cache_hit_tokens / prompt_cache_miss_tokens (+ the OpenAI-style details). */
function fromDeepSeek(u: Json): NormalizedUsage {
  const hit = u.prompt_cache_hit_tokens !== undefined ? num(u.prompt_cache_hit_tokens) : num(obj(u.prompt_tokens_details).cached_tokens);
  const miss = u.prompt_cache_miss_tokens !== undefined ? num(u.prompt_cache_miss_tokens) : (() => {
    const p = num(u.prompt_tokens);
    return p > hit ? p - hit : 0n;
  })();
  const reasoning = num(obj(u.completion_tokens_details).reasoning_tokens);
  const completion = num(u.completion_tokens);
  return {
    inputUncached: miss,
    inputCached: hit,
    cacheWrite: 0n,
    output: completion > reasoning ? completion - reasoning : completion,
    reasoning,
    providerCostMicroUsd: null,
  };
}

/** DeepInfra: plain OpenAI counts plus `estimated_cost` (USD); no cache fields. */
function fromDeepInfra(u: Json): NormalizedUsage {
  const base = fromOpenAI(u);
  return { ...base, providerCostMicroUsd: usd(u.estimated_cost) };
}

/** OpenRouter: OpenAI details plus cache_write_tokens and `cost` (USD). */
function fromOpenRouter(u: Json): NormalizedUsage {
  const base = fromOpenAI(u);
  const details = obj(u.prompt_tokens_details);
  const cacheWrite = num(details.cache_write_tokens);
  const cost = usd(u.cost) ?? usd(obj(u.cost_details).upstream_inference_cost);
  return {
    ...base,
    // Written tokens are part of the prompt; do not bill them twice as uncached.
    inputUncached: base.inputUncached > cacheWrite ? base.inputUncached - cacheWrite : 0n,
    cacheWrite,
    providerCostMicroUsd: cost,
  };
}

/** Anthropic Messages: input_tokens excludes cache reads/writes, which are reported separately. */
function fromAnthropic(u: Json): NormalizedUsage {
  return {
    inputUncached: num(u.input_tokens),
    inputCached: num(u.cache_read_input_tokens),
    cacheWrite: num(u.cache_creation_input_tokens),
    output: num(u.output_tokens),
    reasoning: 0n,
    providerCostMicroUsd: null,
  };
}

/** Normalise a raw usage object; null when it is not an object. */
export function normalizeUsage(dialect: string, raw: unknown): NormalizedUsage | null {
  if (!raw || typeof raw !== "object" || Array.isArray(raw)) return null;
  const u = raw as Json;
  switch (dialect) {
    case "deepseek":
      return fromDeepSeek(u);
    case "deepinfra":
      return fromDeepInfra(u);
    case "openrouter":
      return fromOpenRouter(u);
    case "anthropic":
      return fromAnthropic(u);
    case "openai":
    default:
      return fromOpenAI(u);
  }
}

export function totalInputTokens(u: NormalizedUsage): bigint {
  return u.inputUncached + u.inputCached + u.cacheWrite;
}

export function totalOutputTokens(u: NormalizedUsage): bigint {
  return u.output + u.reasoning;
}

export function totalTokens(u: NormalizedUsage): bigint {
  return totalInputTokens(u) + totalOutputTokens(u);
}

/** Anthropic-shaped usage block for responses we synthesise (translated path). */
export function toAnthropicUsage(u: NormalizedUsage | null): { input_tokens: number; output_tokens: number; cache_read_input_tokens: number; cache_creation_input_tokens: number } {
  return {
    input_tokens: Number(u?.inputUncached ?? 0n),
    output_tokens: Number(totalOutputTokens(u ?? ZERO_USAGE)),
    cache_read_input_tokens: Number(u?.inputCached ?? 0n),
    cache_creation_input_tokens: Number(u?.cacheWrite ?? 0n),
  };
}

export interface ModelPrices {
  inputPriceMicroPerMTok: number;
  outputPriceMicroPerMTok: number;
  cachedInputPriceMicroPerMTok: number | null;
  cacheWritePriceMicroPerMTok: number | null;
}

/**
 * Provider cost from our price list, in micro-USD: each component at its own
 * rate. Cached input defaults to the uncached price (no discount until an
 * admin sets one), cache writes default to free.
 */
export function priceProviderCostMicroUsd(u: NormalizedUsage, m: ModelPrices): bigint {
  const cachedRate = BigInt(m.cachedInputPriceMicroPerMTok ?? m.inputPriceMicroPerMTok);
  const writeRate = BigInt(m.cacheWritePriceMicroPerMTok ?? 0);
  const total =
    u.inputUncached * BigInt(m.inputPriceMicroPerMTok) +
    u.inputCached * cachedRate +
    u.cacheWrite * writeRate +
    totalOutputTokens(u) * BigInt(m.outputPriceMicroPerMTok);
  // Round half up to the nearest micro-USD.
  return (total + 500_000n) / 1_000_000n;
}
