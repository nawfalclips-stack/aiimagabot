/**
 * Loyalty program — pure logic, no database access. Client-safe.
 *
 * The program is data, editable per store in the admin (Loyalty → Program
 * settings) and stored as the `loyalty_program` setting. DEFAULT_LOYALTY_PROGRAM
 * is what every store uses until an admin saves its own.
 *
 * Points per completed purchase (activation or approved recharge):
 *   the highest bracket the amount reaches gives its points, plus
 *   `overflowPercent` % of the dollars above that bracket
 *   (default: $620 → $500 bracket = 100 pts + 120 × 15% = 18 → 118);
 *   a purchase below the smallest bracket earns `basePoints`.
 *
 * Levels are reached by total points. A level with a cash reward above $0 lets
 * the customer REQUEST that reward, which an admin must approve — points are
 * never converted to balance automatically. Each level also tints the
 * customer's dashboard with its colour.
 */

import { z } from "zod";

export interface PurchasePoints {
  basePoints: number;
  extraPoints: number;
  totalPoints: number;
}

export interface LoyaltyBracket {
  /** Purchase amount from which this bracket applies, in cents. */
  minCents: number;
  points: number;
}

export interface LoyaltyTier {
  /** Stable id (kept when renaming; used in reward idempotency keys). */
  id: string;
  name: string;
  /** Points required to reach this level. */
  minPoints: number;
  /** Cash reward credited when a reward request at this level is APPROVED; 0 = no reward. */
  rewardAmountCents: number;
  /** Dashboard accent colour at this level (#rrggbb). */
  colorHex: string;
}

export interface LoyaltyProgram {
  /** Points for a purchase below the smallest bracket. */
  basePoints: number;
  /** Extra points per dollar above the reached bracket, in percent (15 = 0.15 pt per $). */
  overflowPercent: number;
  /** Highest first. */
  brackets: LoyaltyBracket[];
  /** Lowest first; the first level always starts at 0 points. */
  tiers: LoyaltyTier[];
}

export const DEFAULT_LOYALTY_PROGRAM: LoyaltyProgram = {
  basePoints: 25,
  overflowPercent: 15,
  brackets: [
    { minCents: 100_000, points: 250 }, // $1000+
    { minCents: 50_000, points: 100 }, // $500+
    { minCents: 30_000, points: 70 }, // $300+
    { minCents: 20_000, points: 50 }, // $200+
    { minCents: 10_000, points: 35 }, // $100+
  ],
  tiers: [
    { id: "bronze", name: "Bronze · Lvl 1", minPoints: 0, rewardAmountCents: 0, colorHex: "#8d6e63" },
    { id: "silver", name: "Silver · Lvl 2", minPoints: 600, rewardAmountCents: 10_000, colorHex: "#94a3b8" },
    { id: "gold", name: "Gold · Lvl 3", minPoints: 1000, rewardAmountCents: 17_000, colorHex: "#f59e0b" },
    { id: "vip", name: "VIP · Max Level", minPoints: 1500, rewardAmountCents: 22_000, colorHex: "#a855f7" },
  ],
};

// ─── Validation ─────────────────────────────────────────────────────────────

export const MAX_LOYALTY_TIERS = 10;
export const MAX_LOYALTY_BRACKETS = 12;

const tierSchema = z.object({
  id: z.string().trim().min(1).max(40).regex(/^[a-z0-9-]+$/, "Invalid level id"),
  name: z.string().trim().min(1, "Every level needs a name").max(40, "Level names are at most 40 characters"),
  minPoints: z.coerce.number().int().min(0, "Points cannot be negative").max(10_000_000),
  rewardAmountCents: z.coerce.number().int().min(0, "A reward cannot be negative").max(100_000_000),
  colorHex: z.string().trim().regex(/^#[0-9a-fA-F]{6}$/, "Colours must look like #a855f7"),
});

const bracketSchema = z.object({
  minCents: z.coerce.number().int().min(1, "A bracket must start above $0").max(100_000_000),
  points: z.coerce.number().int().min(0).max(1_000_000),
});

export const loyaltyProgramSchema = z
  .object({
    basePoints: z.coerce.number().int().min(0).max(1_000_000),
    overflowPercent: z.coerce.number().min(0).max(1000),
    brackets: z.array(bracketSchema).max(MAX_LOYALTY_BRACKETS, `At most ${MAX_LOYALTY_BRACKETS} brackets`),
    tiers: z.array(tierSchema).min(1, "Keep at least one level").max(MAX_LOYALTY_TIERS, `At most ${MAX_LOYALTY_TIERS} levels`),
  })
  .superRefine((p, ctx) => {
    const points = p.tiers.map((t) => t.minPoints);
    if (!points.includes(0)) ctx.addIssue({ code: "custom", path: ["tiers"], message: "The first level must start at 0 points" });
    if (new Set(points).size !== points.length) ctx.addIssue({ code: "custom", path: ["tiers"], message: "Two levels cannot need the same number of points" });
    const ids = p.tiers.map((t) => t.id);
    if (new Set(ids).size !== ids.length) ctx.addIssue({ code: "custom", path: ["tiers"], message: "Level ids must be unique" });
    const amounts = p.brackets.map((b) => b.minCents);
    if (new Set(amounts).size !== amounts.length) ctx.addIssue({ code: "custom", path: ["brackets"], message: "Two brackets cannot start at the same amount" });
  });

/** Sorted copy: brackets highest first, tiers lowest first. */
function sorted(p: LoyaltyProgram): LoyaltyProgram {
  return {
    ...p,
    brackets: [...p.brackets].sort((a, b) => b.minCents - a.minCents),
    tiers: [...p.tiers].sort((a, b) => a.minPoints - b.minPoints),
  };
}

/** Validate and sort; throws a ZodError with a readable first issue on bad input. */
export function parseLoyaltyProgram(input: unknown): LoyaltyProgram {
  return sorted(loyaltyProgramSchema.parse(input));
}

/** The stored setting (JSON) → program; anything missing or invalid falls back to the default. */
export function loyaltyProgramFromSetting(raw: string | null | undefined): LoyaltyProgram {
  if (!raw) return DEFAULT_LOYALTY_PROGRAM;
  try {
    return parseLoyaltyProgram(JSON.parse(raw));
  } catch {
    return DEFAULT_LOYALTY_PROGRAM;
  }
}

// ─── Points ─────────────────────────────────────────────────────────────────

/** Extra points for the part of a purchase above its bracket. */
export function extraPointsForOverflow(centsAboveBracket: number, overflowPercent = DEFAULT_LOYALTY_PROGRAM.overflowPercent): number {
  if (centsAboveBracket <= 0 || overflowPercent <= 0) return 0;
  return Math.round((centsAboveBracket * (overflowPercent / 100)) / 100);
}

/** Points earned for a single completed purchase of `cents`. */
export function pointsForPurchase(cents: number, program: LoyaltyProgram = DEFAULT_LOYALTY_PROGRAM): PurchasePoints {
  if (!Number.isFinite(cents) || cents <= 0) {
    return { basePoints: 0, extraPoints: 0, totalPoints: 0 };
  }
  const bracket = [...program.brackets].sort((a, b) => b.minCents - a.minCents).find((b) => cents >= b.minCents);
  const basePoints = bracket ? bracket.points : program.basePoints;
  const extraPoints = bracket ? extraPointsForOverflow(cents - bracket.minCents, program.overflowPercent) : 0;
  return { basePoints, extraPoints, totalPoints: basePoints + extraPoints };
}

// ─── Levels ─────────────────────────────────────────────────────────────────

const byPoints = (tiers: LoyaltyTier[]) => [...tiers].sort((a, b) => a.minPoints - b.minPoints);

export function getTierForPoints(points: number, tiers: LoyaltyTier[] = DEFAULT_LOYALTY_PROGRAM.tiers): LoyaltyTier {
  const list = byPoints(tiers);
  let tier = list[0];
  for (const t of list) {
    if (points >= t.minPoints) tier = t;
  }
  return tier;
}

export function getNextTier(points: number, tiers: LoyaltyTier[] = DEFAULT_LOYALTY_PROGRAM.tiers): LoyaltyTier | null {
  return byPoints(tiers).find((t) => t.minPoints > points) ?? null;
}

/** The lowest level that carries a cash reward, or null when no level does. */
export function firstRewardTier(tiers: LoyaltyTier[] = DEFAULT_LOYALTY_PROGRAM.tiers): LoyaltyTier | null {
  return byPoints(tiers).find((t) => t.rewardAmountCents > 0) ?? null;
}

/** A customer may request a cash reward when their current level has one. */
export function canRequestReward(points: number, tiers: LoyaltyTier[] = DEFAULT_LOYALTY_PROGRAM.tiers): boolean {
  return getTierForPoints(points, tiers).rewardAmountCents > 0;
}

/** URL-safe id for a new level, unique among `taken`. */
export function tierIdFromName(name: string, taken: string[]): string {
  const base = name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 30) || "level";
  let id = base;
  for (let n = 2; taken.includes(id); n++) id = `${base}-${n}`;
  return id;
}
