// Public model aliases. Client-safe: no server imports.
//
// A catalog model has an internal identity (slug, display name — admin-only,
// often the provider's own name) and an optional public alias (aliasSlug,
// aliasName). Customers only ever see the public side: /v1/models, API
// responses, the portal, usage history, docs and notifications.

export interface AliasFields {
  slug: string;
  displayName: string;
  aliasSlug?: string | null;
  aliasName?: string | null;
}

/** The model id customers see and type into their tools. */
export function publicModelId(m: AliasFields): string {
  return m.aliasSlug?.trim() || m.slug;
}

/** The model name customers see. With an alias id but no alias name, the alias id is the name (never the internal display name). */
export function publicModelName(m: AliasFields): string {
  const name = m.aliasName?.trim();
  if (name) return name;
  if (m.aliasSlug?.trim()) return m.aliasSlug.trim();
  return m.displayName;
}

export function hasPublicAlias(m: AliasFields): boolean {
  return !!m.aliasSlug?.trim();
}

const norm = (s: string) => s.toLowerCase().replace(/[^a-z0-9]/g, "");

/** Words too generic to identify a model; an alias may use them freely. */
const GENERIC_WORDS = new Set(["latest", "preview", "instruct", "chat", "base", "beta", "free", "fast", "flash", "mini", "pro", "max", "turbo", "large", "small", "medium", "lite", "plus", "exp", "thinking", "online"]);

/**
 * Distinctive words of an upstream id — vendor, full name, and each name word
 * that is not generic: "anthropic/claude-haiku-4.5" → ["anthropic", "claudehaiku45", "claude", "haiku"].
 */
function upstreamTerms(upstreamId: string): string[] {
  const clean = upstreamId.replace(/^~/, "").toLowerCase();
  const [vendor, rest] = clean.includes("/") ? [clean.slice(0, clean.indexOf("/")), clean.slice(clean.indexOf("/") + 1)] : ["", clean];
  const terms = new Set<string>();
  if (vendor) terms.add(norm(vendor));
  terms.add(norm(rest));
  for (const w of rest.split(/[^a-z0-9]+/)) {
    if (w.length >= 3 && !/^v?\d+$/.test(w) && !GENERIC_WORDS.has(w)) terms.add(w);
  }
  return [...terms].filter((t) => t.length >= 3);
}

/**
 * Warnings when the public alias would reveal what really serves the model:
 * missing alias, or an alias that contains the provider's model or vendor name.
 */
export function aliasWarnings(m: AliasFields, upstreamIds: string[]): string[] {
  const out: string[] = [];
  if (!hasPublicAlias(m)) {
    out.push("No public alias: customers see the internal slug and display name.");
    return out;
  }
  const shown = `${norm(publicModelId(m))} ${norm(publicModelName(m))}`;
  const leaked = new Set<string>();
  for (const id of upstreamIds) for (const term of upstreamTerms(id)) if (shown.includes(term)) leaked.add(term);
  if (leaked.size > 0) out.push(`The alias reveals the real model (${[...leaked].join(", ")}).`);
  return out;
}
