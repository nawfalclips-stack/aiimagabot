// All monetary values are stored as integer cents.

export function centsToUsd(cents: number): number {
  return cents / 100;
}

export function usdToCents(usd: number): number {
  return Math.round(usd * 100);
}

export function formatCents(cents: number, currency = "USD"): string {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency,
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  }).format(cents / 100);
}

/** Percentage of `used` relative to `initial`, clamped to [0, 100]. */
export function percentUsed(usedCents: number, initialCents: number): number {
  if (initialCents <= 0) return 0;
  return Math.min(100, Math.max(0, Math.round((usedCents / initialCents) * 100)));
}
