// Smart parser for store offer titles. The title carries the amounts the
// customer purchased, e.g.:
//   "Codex API 300$ + 50$ Bonus"
//   "Claude Code $100 with 20 USD bonus"
//   "GPT API — 300 USD"
// The balance is credited immediately; the bonus is review-gated.

export interface ParsedOffer {
  balanceCents: number | null; // null → nothing recognized, use the default
  bonusCents: number;
  /** The "%" figure when the bonus was expressed as a percentage (e.g. 10). */
  percent: number | null;
}

interface AmountToken {
  cents: number;
  index: number;
  length: number;
}

// Money token: $300 · 300$ · 300 USD · 300.50 — requires $ / usd / dollars
// nearby OR being a standalone number in the title.
const AMOUNT_RE = /(?:\$\s*)?(\d{1,6}(?:[.,]\d{1,2})?)(?:\s*(?:\$|usd|dollars?))?/gi;

// Percentage token: 10% · 10 % · 10 percent — the bonus is a share of the balance.
const PERCENT_RE = /(\d{1,3}(?:[.,]\d{1,2})?)\s*(?:%|percent)/gi;

function toCents(raw: string): number {
  return Math.round(parseFloat(raw.replace(",", ".")) * 100);
}

function spansOverlap(aStart: number, aEnd: number, bStart: number, bEnd: number): boolean {
  return aStart < bEnd && bStart < aEnd;
}

/** The "%" figure in the offer title, e.g. 10 for "300$ + 10% Bonus". */
export function getBonusPercentFromTitle(title: string): number | null {
  const match = PERCENT_RE.exec(title.toLowerCase());
  PERCENT_RE.lastIndex = 0;
  if (!match) return null;
  const value = parseFloat(match[1].replace(",", "."));
  return Number.isFinite(value) && value > 0 && value <= 100 ? value : null;
}

export function parseOfferTitle(title: string): ParsedOffer {
  const text = title.toLowerCase();
  const tokens: AmountToken[] = [];

  // Collect every "%" span first so plain numbers inside them ("10" in "10%")
  // are never mistaken for money amounts.
  const percentSpans: Array<{ start: number; end: number; value: number }> = [];
  for (const match of text.matchAll(PERCENT_RE)) {
    const value = parseFloat(match[1].replace(",", "."));
    if (!Number.isFinite(value) || value <= 0 || value > 100) continue;
    percentSpans.push({ start: match.index ?? 0, end: (match.index ?? 0) + match[0].length, value });
  }

  for (const match of text.matchAll(AMOUNT_RE)) {
    const full = match[0];
    // Only accept tokens that look like money: contain $/usd/dollar, or are
    // plain numbers (offer titles are short; plain numbers are amounts).
    if (!/\d/.test(full)) continue;
    const cents = toCents(match[1]);
    if (!Number.isFinite(cents) || cents <= 0 || cents > 100_000_00) continue;
    const index = match.index ?? 0;
    if (percentSpans.some((p) => spansOverlap(index, index + full.length, p.start, p.end))) continue;
    tokens.push({ cents, index, length: full.length });
  }

  if (tokens.length === 0) return { balanceCents: null, bonusCents: 0, percent: null };

  // Percentage bonuses are computed against the balance: "300$ + 10% Bonus"
  // credits a 30 USD review bonus, not a flat 10 USD. When several percentages
  // appear, the one nearest the word "bonus" wins.
  if (percentSpans.length > 0) {
    const bonusWordMatch = /bonus/g.exec(text);
    let percentSpan = percentSpans[0];
    if (bonusWordMatch) {
      const wordStart = bonusWordMatch.index;
      const wordEnd = wordStart + bonusWordMatch[0].length;
      let best: { span: (typeof percentSpans)[number]; distance: number } | null = null;
      for (const span of percentSpans) {
        const distance = span.end <= wordStart ? wordStart - span.end : span.start - wordEnd;
        if (!best || distance < best.distance) best = { span, distance };
      }
      percentSpan = best!.span;
    }
    // The balance is the largest money token outside the percentages — the
    // purchased amount, e.g. 300 in "300$ + 10% Bonus".
    const balanceToken = tokens.reduce((a, b) => (b.cents > a.cents ? b : a));
    return {
      balanceCents: balanceToken.cents,
      bonusCents: Math.round((balanceToken.cents * percentSpan.value) / 100),
      percent: percentSpan.value,
    };
  }

  // The bonus amount is the token CLOSEST to the word "bonus" — "300$ + 50$
  // Bonus" must pick 50, not 300, even though both are near the word.
  let bonusToken: AmountToken | null = null;
  const bonusWord = /bonus/g.exec(text);
  if (bonusWord) {
    const wordStart = bonusWord.index;
    const wordEnd = wordStart + bonusWord[0].length;
    let best: { token: AmountToken; distance: number } | null = null;
    for (const token of tokens) {
      const tokenEnd = token.index + token.length;
      // Gap between the token span and the word span (0 if adjacent/overlapping).
      const distance = tokenEnd <= wordStart ? wordStart - tokenEnd : token.index - wordEnd;
      if (distance > 24) continue; // too far to belong to "bonus"
      if (!best || distance < best.distance) best = { token, distance };
    }
    bonusToken = best?.token ?? null;
  }

  const balanceToken = tokens.find((t) => t !== bonusToken) ?? null;

  return {
    balanceCents: balanceToken ? balanceToken.cents : null,
    bonusCents: bonusToken ? bonusToken.cents : 0,
    percent: null,
  };
}
