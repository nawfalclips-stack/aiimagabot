// Parses the exact multi-block format exported from the previous website.
//
// Each client block looks like:
//
//   ACCESS-CODE-HERE
//   [Inactive | Cancelled]           ← optional status line
//   API Key:
//   fe_oa_abc123...                  ← partial key (or — / missing)
//
//   Order #: 874007375756005376      ← may have / separating two IDs
//   Expires: 2099-12-31
//   Uses: N
//   Profit:
//   $7.00
//
//   Bonus: $5.00 (2.00 used, 3.00 left)
//   Balance: $125.00 remaining ($35.00 used of $220)
//
//   Bonus: $5.00 remaining ($0.00 used of $5.00)
//
// Blocks are separated by blank lines that contain no fields.

export interface ParsedPastClient {
  // Identity
  accessCode: string; // kept as the original code so the customer can still use it
  apiKey: string; // may be partial — stored as-is
  orderId: string; // first order number found (—/missing → generated placeholder)
  // Status from the source site
  sourceStatus: "active" | "inactive" | "cancelled";
  // Financials (all in cents)
  initialBalanceCents: number; // "of $X" total from the Balance line
  usedBalanceCents: number; // "$X.XX used" from the Balance line
  initialBonusCents: number; // "of $X" from the last Bonus line
  usedBonusCents: number; // "$X.XX used" from the last Bonus line
  profitCents: number;
  // Raw for notes
  raw: string;
}

export interface PastClientsParseResult {
  clients: ParsedPastClient[];
  skipped: { block: string; reason: string }[];
}

// e.g.  $125.00 remaining ($35.00 used of $220)
const BALANCE_RE =
  /\$([+-]?\d+(?:\.\d+)?)\s+remaining\s+\(\$([+-]?\d+(?:\.\d+)?)\s+used\s+of\s+\$(\d+(?:\.\d+)?)\)/i;

// e.g.  Bonus: $5.00 (2.00 used, 3.00 left)
// or    Bonus: $5.00 remaining ($0.00 used of $5.00)
const BONUS_SUMMARY_RE = /Bonus:\s*\$([+-]?\d+(?:\.\d+)?)\s*\(([+-]?\d+(?:\.\d+)?)\s+used/i;

const DOLLAR_RE = /^\$([+-]?\d+(?:\.\d+)?)$/;
const ACCESS_CODE_RE = /^[A-Z0-9]{2,6}-[A-Z0-9]{2,6}-[A-Z0-9]{2,6}$/;
const ORDER_RE = /^(\d{6,20})$/; // pure-numeric, 6-20 digits

function usd(str: string): number {
  return Math.round(Math.abs(parseFloat(str)) * 100);
}

function parseBlock(block: string): ParsedPastClient | null {
  const lines = block.split(/\r?\n/).map((l) => l.trim()).filter(Boolean);
  if (lines.length < 2) return null;

  let accessCode = "";
  let apiKey = "";
  let orderId = "";
  let sourceStatus: ParsedPastClient["sourceStatus"] = "active";
  let initialBalanceCents = 0;
  let usedBalanceCents = 0;
  let initialBonusCents = 0;
  let usedBonusCents = 0;
  let profitCents = 0;
  let expectProfit = false;

  for (let i = 0; i < lines.length; i++) {
    const line = lines[i];
    const lower = line.toLowerCase();

    // Access code — always the first substantial line matching the code pattern
    if (!accessCode && ACCESS_CODE_RE.test(line)) {
      accessCode = line;
      continue;
    }

    // Status modifiers
    if (lower === "inactive") { sourceStatus = "inactive"; continue; }
    if (lower === "cancelled" || lower === "canceled") { sourceStatus = "cancelled"; continue; }

    // API key label — next non-empty line is the key value
    if (/^api key:/i.test(line)) {
      const val = lines[i + 1];
      if (val && val !== "—" && val !== "-" && val !== "") {
        apiKey = val;
        i++;
      }
      continue;
    }

    // Order #: 874007375756005376 / 873777505834766336
    if (/^order #:/i.test(line)) {
      const raw = line.replace(/^order #:\s*/i, "").trim();
      if (raw && raw !== "—" && raw !== "-") {
        // Take the first numeric ID
        const parts = raw.split(/[/\s]+/).map((p) => p.trim()).filter(Boolean);
        const numeric = parts.find((p) => ORDER_RE.test(p));
        orderId = numeric ?? parts[0] ?? "";
      }
      continue;
    }

    // Profit: / $7.00 (profit is on the NEXT line after "Profit:")
    if (/^profit:$/i.test(line)) {
      expectProfit = true;
      continue;
    }
    if (expectProfit) {
      const m = line.match(DOLLAR_RE);
      if (m) profitCents = usd(m[1]);
      expectProfit = false;
      continue;
    }

    // Balance: $125.00 remaining ($35.00 used of $220)
    if (/^balance:/i.test(line)) {
      const m = line.match(BALANCE_RE);
      if (m) {
        // m[3] = "of" total = initial, m[2] = used
        initialBalanceCents = usd(m[3]);
        usedBalanceCents = usd(m[2]);
      }
      continue;
    }

    // Bonus: $5.00 (2.00 used, 3.00 left)  — the SHORT summary line
    // Bonus: $5.00 remaining ($0.00 used of $5.00) — the detailed line
    if (/^bonus:/i.test(line)) {
      // Detailed form
      const mBalance = line.match(BALANCE_RE);
      if (mBalance) {
        initialBonusCents = usd(mBalance[3]);
        usedBonusCents = usd(mBalance[2]);
        continue;
      }
      // Short form
      const mShort = line.match(BONUS_SUMMARY_RE);
      if (mShort) {
        const total = usd(mShort[1]);
        const used = usd(mShort[2]);
        initialBonusCents = total + used; // total shown is remaining, so initial = remaining + used
        // Actually the format is: Bonus: $X.XX (Y.YY used, Z.ZZ left)
        // where X.XX = remaining (not initial). So:
        //   remaining = X.XX, used = Y.YY, initial = X.XX + Y.YY
        usedBonusCents = used;
        initialBonusCents = total + used;
        continue;
      }
      // Plain "Bonus: $0.00" line — no bonus
      continue;
    }
  }

  if (!accessCode) return null;
  // Generate a placeholder order ID if none found
  if (!orderId) orderId = `IMPORT-${accessCode}`;

  return {
    accessCode,
    apiKey,
    orderId,
    sourceStatus,
    initialBalanceCents,
    usedBalanceCents,
    initialBonusCents,
    usedBonusCents,
    profitCents,
    raw: block.trim(),
  };
}

export function parsePastClients(raw: string): PastClientsParseResult {
  const clients: ParsedPastClient[] = [];
  const skipped: { block: string; reason: string }[] = [];

  // Split on blank lines (≥2 consecutive newlines) to get blocks.
  // But ignore blank lines INSIDE a block — we use a state machine instead:
  // a new block starts when we hit an ACCESS_CODE_RE line.
  const lines = raw.split(/\r?\n/);
  const blocks: string[] = [];
  let current: string[] = [];

  for (const line of lines) {
    const trimmed = line.trim();
    if (ACCESS_CODE_RE.test(trimmed) && current.length > 0) {
      // New access code encountered → flush previous block
      blocks.push(current.join("\n"));
      current = [trimmed];
    } else {
      current.push(trimmed);
    }
  }
  if (current.length > 0) blocks.push(current.join("\n"));

  const seenOrders = new Set<string>();
  const seenCodes = new Set<string>();

  for (const block of blocks) {
    if (!block.trim()) continue;
    const parsed = parseBlock(block);
    if (!parsed) {
      if (block.trim().length > 3) {
        skipped.push({ block: block.slice(0, 80), reason: "No access code found in this block" });
      }
      continue;
    }
    if (seenCodes.has(parsed.accessCode)) {
      skipped.push({ block: block.slice(0, 80), reason: `Duplicate access code ${parsed.accessCode}` });
      continue;
    }
    if (seenOrders.has(parsed.orderId)) {
      // Give it a unique placeholder so we don't lose the record
      parsed.orderId = `${parsed.orderId}-${parsed.accessCode}`;
    }
    seenCodes.add(parsed.accessCode);
    seenOrders.add(parsed.orderId);
    clients.push(parsed);
  }

  return { clients, skipped };
}
