// Shared between the server (analytics page) and the client (period
// switcher). Must NOT be a "use client" module — server components need to
// call PERIODS.find(), which is impossible on a client reference.

export const PERIODS = [
  { key: "live", label: "Live" },
  { key: "today", label: "Today" },
  { key: "yesterday", label: "Yesterday" },
  { key: "week", label: "Week" },
  { key: "month", label: "Month" },
] as const;

export type PeriodKey = (typeof PERIODS)[number]["key"];
