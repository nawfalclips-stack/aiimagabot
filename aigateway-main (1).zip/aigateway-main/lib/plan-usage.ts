// Plans and the billing rate they imply. Client-safe: no server imports.
//
// A plan says what a customer's money buys:
//   USD    — a $100 plan is worth $5.00 of real provider usage → every $1 the
//            provider charges deducts $20 from the balance (rate = price / limit).
//   TOKENS — a $100 plan includes 50 M tokens → every token deducts
//            $100 / 50 M, whatever the model; the balance hits zero exactly at
//            the token limit.
// Customers without a plan are billed at provider cost × the store's global
// `usage_cost_multiplier` setting.
//
// All money arithmetic lives in lib/billing/pricing-engine.ts (exact
// integers); this module keeps the plan vocabulary and the display helpers.

import { bonusRateFromPlan, effectivePrices, microPerMTokToCents, rateFromPlan, rateToNumber, type BillingRate, type ModelPrices } from "@/lib/billing/pricing-engine";

export type { BillingRate } from "@/lib/billing/pricing-engine";

export const PLAN_LIMIT_TYPES = ["USD", "TOKENS"] as const;
export type PlanLimitType = (typeof PLAN_LIMIT_TYPES)[number];

export interface PlanLike {
  priceCents: number;
  limitType: string;
  limitUsageCents: number;
  limitMTokens: number;
  /** Bonus credited per purchase and the real usage it is worth (0 = same rate as the balance). */
  bonusCents?: number;
  bonusLimitUsageCents?: number;
  bonusLimitMTokens?: number;
}

/** The rate a plan bills at, or null when the plan is misconfigured (zero limit). */
export function planRate(plan: PlanLike): BillingRate | null {
  return rateFromPlan(plan);
}

/** Customer-facing price per 1M tokens, in cents, for a model with the given provider prices (µ$/MTok). */
export function customerPricePerMTokCents(rate: BillingRate, model: ModelPrices): { input: number; cachedInput: number; output: number } {
  const p = effectivePrices(rate, model);
  return {
    input: microPerMTokToCents(p.inputMicroPerMTok),
    cachedInput: microPerMTokToCents(p.cachedInputMicroPerMTok),
    output: microPerMTokToCents(p.outputMicroPerMTok),
  };
}

/** "×20" or "$2.00 / 1M tokens" — how the admin sees a plan's effective rate. */
export function describePlanRate(plan: PlanLike): string {
  const rate = planRate(plan);
  if (!rate) return "not configured";
  const n = rateToNumber(rate);
  if (rate.kind === "perToken") return `$${(n * 1_000_000 / 1_000_000).toFixed(2)} per 1M tokens`;
  return `×${n.toFixed(2)} — $1 of provider cost deducts $${n.toFixed(2)}`;
}

/**
 * What the plan's bonus is worth in real usage: "$0.50 of real API usage (×20)",
 * "5M tokens ($2.00 per 1M tokens)", or — without a bonus limit — the value at
 * the balance rate: "$0.50 of real API usage (same rate as the balance)".
 * "" when the plan has no bonus.
 */
export function describeBonusWorth(plan: PlanLike): string {
  const bonus = plan.bonusCents ?? 0;
  if (bonus <= 0) return "";
  const bonusRate = bonusRateFromPlan(plan);
  if (bonusRate) {
    const n = rateToNumber(bonusRate);
    if (plan.limitType === "TOKENS") return `${plan.bonusLimitMTokens ?? 0}M tokens ($${n.toFixed(2)} per 1M tokens)`;
    return `$${((plan.bonusLimitUsageCents ?? 0) / 100).toFixed(2)} of real API usage (×${n.toFixed(2)})`;
  }
  if (!planRate(plan)) return "same rate as the balance";
  if (plan.limitType === "TOKENS") {
    const mtok = (bonus * plan.limitMTokens) / plan.priceCents;
    return `${mtok.toFixed(mtok < 10 ? 2 : 0)}M tokens (same rate as the balance)`;
  }
  return `$${((bonus * plan.limitUsageCents) / plan.priceCents / 100).toFixed(2)} of real API usage (same rate as the balance)`;
}

/** "$10.00 bonus = $0.50 of real API usage (×20)" / "No bonus". */
export function describeBonusValue(plan: PlanLike): string {
  const bonus = plan.bonusCents ?? 0;
  if (bonus <= 0) return "No bonus";
  return `$${(bonus / 100).toFixed(2)} bonus = ${describeBonusWorth(plan)}`;
}

/** "$100 · $5.00 real API usage" / "$100 · 50M tokens" */
export function describePlanLimit(plan: PlanLike): string {
  if (plan.limitType === "TOKENS") return `${plan.limitMTokens}M tokens`;
  return `$${(plan.limitUsageCents / 100).toFixed(2)} of real API usage`;
}
