import { PrismaClient } from "@prisma/client";
import { applyEnvAliases } from "@/lib/env-aliases.mjs";

// Supabase added from Vercel → Storage exposes POSTGRES_PRISMA_URL, not DATABASE_URL.
applyEnvAliases();

// One PrismaClient per instance (WS12.2). On Vercel + Supabase the runtime
// DATABASE_URL must be the transaction pooler (port 6543) with a small
// connection_limit; migrations use DIRECT_URL (see docs/runbook.md).
const globalForPrisma = globalThis as unknown as { prisma?: PrismaClient };

function warnAboutPooling(): void {
  const url = process.env.DATABASE_URL ?? "";
  if (!process.env.VERCEL || !/^postgres/.test(url)) return;
  let params: URLSearchParams;
  try {
    params = new URL(url).searchParams;
  } catch {
    return;
  }
  const missing = ["connection_limit", "pgbouncer"].filter((k) => !params.has(k));
  if (missing.length) {
    console.warn(
      `[prisma] DATABASE_URL has no ${missing.join(" / ")} parameter. On Vercel use the pooled URL: ` +
        "…:6543/postgres?pgbouncer=true&connection_limit=1 (docs/runbook.md → Database pooling)."
    );
  }
}

export const prisma =
  globalForPrisma.prisma ??
  (() => {
    warnAboutPooling();
    return new PrismaClient({
      log: process.env.NODE_ENV === "development" ? ["warn", "error"] : ["error"],
    });
  })();

if (process.env.NODE_ENV !== "production") globalForPrisma.prisma = prisma;
