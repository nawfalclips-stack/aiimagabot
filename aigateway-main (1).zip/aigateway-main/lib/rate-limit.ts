import "server-only";
import { checkRateLimit } from "@/lib/gateway/limits";

/**
 * Sliding-window rate limiter for login, activation and redemption forms.
 * Shared across instances through Redis when configured (WS3); otherwise
 * per instance, which still slows brute force on a single box.
 */
export async function rateLimit(
  key: string,
  { limit, windowMs }: { limit: number; windowMs: number }
): Promise<{ ok: boolean; retryAfterSeconds: number }> {
  const r = await checkRateLimit(`form:${key}`, limit, windowMs);
  return { ok: r.ok, retryAfterSeconds: r.retryAfterSeconds };
}
