// Real API usage: what a customer's requests actually cost at the provider,
// before any plan rate or multiplier — the counterpart of the balance they
// were charged. Client-safe: no server imports (the aggregation lives in
// lib/services/real-usage.ts). Admin-only: never render this in the portal.

import type { PlanLike } from "@/lib/plan-usage";

export interface RealUsage {
  requests: number;
  /** Raw provider cost, µ$ (UsageLog.costMicroUsd summed). */
  costMicroUsd: number;
  /** The part of costMicroUsd the bonus paid for (UsageLog.bonusCostMicroUsd summed). */
  bonusCostMicroUsd: number;
  /** Input tokens, cached ones included. */
  inputTokens: number;
  outputTokens: number;
  /** Cached input tokens (already counted in inputTokens). */
  cachedTokens: number;
  lastUsedAt: string | null;
}

export const EMPTY_REAL_USAGE: RealUsage = { requests: 0, costMicroUsd: 0, bonusCostMicroUsd: 0, inputTokens: 0, outputTokens: 0, cachedTokens: 0, lastUsedAt: null };

/**
 * How much real usage the money credited to a customer buys. Plans say it
 * directly (dollars of provider usage, or tokens, per plan price) and that
 * ratio scales with every recharge; customers without a (valid) plan are
 * billed at the store multiplier, so their credit buys credit ÷ multiplier.
 */
export type RealAllowance = { kind: "usd"; microUsd: number } | { kind: "tokens"; tokens: number };

export function realAllowance(creditedCents: number, plan: PlanLike | null, globalMultiplier: number): RealAllowance | null {
  if (creditedCents <= 0) return null;
  if (plan && plan.priceCents > 0) {
    if (plan.limitType === "TOKENS" && plan.limitMTokens > 0) {
      return { kind: "tokens", tokens: Math.round((creditedCents * plan.limitMTokens * 1_000_000) / plan.priceCents) };
    }
    if (plan.limitType !== "TOKENS" && plan.limitUsageCents > 0) {
      return { kind: "usd", microUsd: Math.round((creditedCents * plan.limitUsageCents * 10_000) / plan.priceCents) };
    }
  }
  if (globalMultiplier <= 0) return null;
  return { kind: "usd", microUsd: Math.round((creditedCents * 10_000) / globalMultiplier) };
}

/**
 * How much real usage the bonus credited to a customer buys: at the plan's
 * bonus rate when it has one (bonus limit per bonus amount), else at the same
 * rate as the balance.
 */
export function bonusRealAllowance(bonusCreditedCents: number, plan: PlanLike | null, globalMultiplier: number): RealAllowance | null {
  if (bonusCreditedCents <= 0) return null;
  const bonus = plan?.bonusCents ?? 0;
  if (plan && bonus > 0) {
    if (plan.limitType === "TOKENS" && (plan.bonusLimitMTokens ?? 0) > 0) {
      return { kind: "tokens", tokens: Math.round((bonusCreditedCents * plan.bonusLimitMTokens! * 1_000_000) / bonus) };
    }
    if (plan.limitType !== "TOKENS" && (plan.bonusLimitUsageCents ?? 0) > 0) {
      return { kind: "usd", microUsd: Math.round((bonusCreditedCents * plan.bonusLimitUsageCents! * 10_000) / bonus) };
    }
  }
  return realAllowance(bonusCreditedCents, plan, globalMultiplier);
}

/** Sum of two allowances of the same kind (a plan's balance and bonus always match); the non-null one otherwise. */
export function addAllowances(a: RealAllowance | null, b: RealAllowance | null): RealAllowance | null {
  if (!a) return b;
  if (!b) return a;
  if (a.kind === "usd" && b.kind === "usd") return { kind: "usd", microUsd: a.microUsd + b.microUsd };
  if (a.kind === "tokens" && b.kind === "tokens") return { kind: "tokens", tokens: a.tokens + b.tokens };
  return a;
}

/** Everything a customer's credit buys: the balance at the plan rate plus the bonus at its own rate. */
export function customerRealAllowance(
  c: { initialBalanceCents: number; initialBonusCents: number },
  plan: PlanLike | null,
  globalMultiplier: number
): RealAllowance | null {
  return addAllowances(realAllowance(c.initialBalanceCents, plan, globalMultiplier), bonusRealAllowance(c.initialBonusCents, plan, globalMultiplier));
}

export function totalTokens(u: RealUsage): number {
  return u.inputTokens + u.outputTokens;
}

/** Share of the allowance used, 0–100+ (can pass 100 on uncollected overage); null without an allowance. */
export function realUsedPct(u: RealUsage, allowance: RealAllowance | null): number | null {
  if (!allowance) return null;
  const used = allowance.kind === "tokens" ? totalTokens(u) : u.costMicroUsd;
  const limit = allowance.kind === "tokens" ? allowance.tokens : allowance.microUsd;
  if (limit <= 0) return null;
  return Math.round((used / limit) * 1000) / 10;
}

/** "$0.0042" for sub-cent costs, "$12.34" otherwise. */
export function formatMicroUsd(micro: number): string {
  const usd = micro / 1_000_000;
  if (usd !== 0 && Math.abs(usd) < 0.01) return `$${usd.toFixed(4)}`;
  return `$${usd.toLocaleString("en-US", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
}

/** "1.2M", "34.5K", "812". */
export function formatTokens(n: number): string {
  if (n >= 1_000_000) return `${(n / 1_000_000).toFixed(n >= 10_000_000 ? 0 : 1)}M`;
  if (n >= 1_000) return `${(n / 1_000).toFixed(n >= 10_000 ? 0 : 1)}K`;
  return String(n);
}
