import "server-only";
import { Redis } from "@upstash/redis";
import { applyEnvAliases } from "@/lib/env-aliases.mjs";

/**
 * Shared Redis (Upstash REST) for state that must agree across Vercel
 * instances: rate limits, concurrency leases, circuit breakers, caches.
 *
 * Configuration:
 *   UPSTASH_REDIS_REST_URL / UPSTASH_REDIS_REST_TOKEN — production.
 *   REDIS_DISABLED=true — local development only: every consumer falls back
 *   to an in-process implementation and logs a loud warning once.
 *
 * Consumers must treat `null` as "no shared state" and decide their own
 * fail-open / fail-closed behaviour (documented per feature in docs/gateway.md).
 */

let client: Redis | null | undefined;
let warned = false;

// Upstash added from Vercel → Storage exposes KV_REST_API_URL / KV_REST_API_TOKEN.
applyEnvAliases();

export function redisConfigured(): boolean {
  return Boolean(process.env.UPSTASH_REDIS_REST_URL && process.env.UPSTASH_REDIS_REST_TOKEN);
}

export function redisDisabled(): boolean {
  return (process.env.REDIS_DISABLED ?? "").toLowerCase() === "true";
}

export function getRedis(): Redis | null {
  if (client !== undefined) return client;
  if (redisDisabled() || !redisConfigured()) {
    if (!warned) {
      warned = true;
      const why = redisDisabled() ? "REDIS_DISABLED=true" : "UPSTASH_REDIS_REST_URL / UPSTASH_REDIS_REST_TOKEN not set";
      const level = process.env.NODE_ENV === "production" ? "error" : "warn";
      console[level](
        `[redis] ${why} — rate limits, concurrency caps and circuit breakers are PER INSTANCE (in-process fallback). ` +
          "This is acceptable for local development only."
      );
    }
    client = null;
    return client;
  }
  client = new Redis({
    url: process.env.UPSTASH_REDIS_REST_URL!,
    token: process.env.UPSTASH_REDIS_REST_TOKEN!,
    // Gateway hot path: one quick retry, never a long stall.
    retry: { retries: 1, backoff: () => 50 },
  });
  return client;
}

/** Tests swap the client (e.g. to point two "processes" at the same local Redis). */
export function _setRedisForTests(next: Redis | null | undefined): void {
  client = next;
}
