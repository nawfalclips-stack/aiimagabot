import type { CustomerWithRelations } from "@/lib/services/customers";
import type { CustomerRow } from "@/lib/types";
import { maskKey, poolAssignmentsEnabled } from "@/lib/services/legacy-pool";

export function toCustomerRow(c: CustomerWithRelations): CustomerRow {
  const keyEditable = poolAssignmentsEnabled();
  return {
    id: c.id,
    accessCode: c.accessCode,
    orderNumber: c.order?.orderNumber ?? "",
    apiKey: keyEditable ? (c.apiKey?.key ?? "") : maskKey(c.apiKey?.key),
    apiKeyEditable: keyEditable,
    status: c.status,
    notes: c.notes,
    initialBalanceCents: c.initialBalanceCents,
    usedBalanceCents: c.usedBalanceCents,
    remainingBalanceCents: c.initialBalanceCents - c.usedBalanceCents,
    initialBonusCents: c.initialBonusCents,
    usedBonusCents: c.usedBonusCents,
    remainingBonusCents: c.initialBonusCents - c.usedBonusCents,
    profitCents: c.profitCents,
    purchasedAgain: c.purchasedAgain,
    purchasedAgainAt: c.purchasedAgainAt?.toISOString() ?? null,
    offerTitle: c.offerTitle,
    pendingBonusCents: c.pendingBonusCents,
    reviewBonusStatus: c.reviewBonusStatus,
    reviewClaimedAt: c.reviewClaimedAt?.toISOString() ?? null,
    finishedAt: c.finishedAt?.toISOString() ?? null,
    createdAt: c.createdAt.toISOString(),
    updatedAt: c.updatedAt.toISOString(),
    deletedAt: c.deletedAt?.toISOString() ?? null,
    planId: c.plan?.id ?? null,
    planName: c.plan?.name ?? null,
    isActivated: c.isActivated,
  };
}
