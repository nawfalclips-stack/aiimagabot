import "server-only";
import { prisma } from "@/lib/prisma";
import type { ActivityAction } from "@/lib/constants";
import type { StoreId } from "@/lib/store";

export async function logActivity(params: {
  storeId: StoreId;
  action: ActivityAction;
  description: string;
  adminId?: string | null;
  customerId?: string | null;
}): Promise<void> {
  try {
    await prisma.activityLog.create({
      data: {
        storeId: params.storeId,
        action: params.action,
        description: params.description,
        adminId: params.adminId ?? null,
        customerId: params.customerId ?? null,
      },
    });
  } catch (error) {
    // Activity logging must never break the primary operation.
    console.error("Failed to write activity log:", error);
  }
}
