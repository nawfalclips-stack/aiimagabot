import "server-only";
import { prisma } from "@/lib/prisma";
import { logActivity } from "@/lib/services/activity";
import { formatCents } from "@/lib/money";
import { getReachedMilestone } from "@/lib/affiliate";
import { credit } from "@/lib/billing/balance-service";
import { centsToMicro } from "@/lib/billing/money";
import type { StoreId } from "@/lib/store";

/**
 * Admin approves an affiliate milestone claim — the reward is credited to the
 * referrer's MAIN BALANCE (not the bonus) with a balance-history entry.
 */
export async function approveAffiliateClaim(customerId: string, adminName: string) {
  const customer = await prisma.customer.findUniqueOrThrow({ where: { id: customerId } });
  if (customer.affiliateMilestoneStatus !== "PENDING") {
    throw new Error("There is no pending affiliate claim on this account.");
  }

  // Recompute reached milestone from the referral purchases (activation + approved recharges).
  const referrals = await prisma.customer.findMany({
    where: { referredById: customerId, deletedAt: null },
    select: { id: true, initialBalanceCents: true },
  });
  const purchasesCents: number[] = [];
  for (const r of referrals) {
    purchasesCents.push(r.initialBalanceCents);
    const recharges = await prisma.rechargeRequest.findMany({
      where: { customerId: r.id, status: "APPROVED" },
      select: { balanceCents: true },
    });
    for (const rc of recharges) purchasesCents.push(rc.balanceCents);
  }

  const milestone = getReachedMilestone(purchasesCents);
  if (!milestone) throw new Error("No affiliate milestone is fully completed yet.");

  await prisma.$transaction(async (tx) => {
    const flipped = await tx.customer.updateMany({
      where: { id: customerId, affiliateMilestoneStatus: "PENDING" },
      data: { affiliateMilestoneStatus: "APPROVED" },
    });
    if (flipped.count === 0) throw new Error("This claim was just processed elsewhere.");
    await credit({
      customerId,
      pot: "BALANCE",
      amountMicroUsd: centsToMicro(milestone.rewardCents),
      type: "AFFILIATE_REWARD",
      idempotencyKey: `affiliate-milestone:${customerId}:${milestone.label}`,
      ref: { type: "AffiliateMilestone", id: milestone.label },
      actor: { label: adminName },
      note: `Affiliate milestone reward (${milestone.label}) credited by ${adminName}`,
      tx,
    });
  });

  await logActivity({
    storeId: customer.storeId as StoreId,
    action: "AFFILIATE_MILESTONE_APPROVED",
    description: `${adminName} approved the affiliate milestone reward of ${formatCents(milestone.rewardCents)} for ${customer.accessCode} — added to BALANCE`,
    adminId: adminName,
    customerId,
  });

  return milestone;
}

/** Admin rejects the claim — the customer keeps their earnings but no payout. */
export async function rejectAffiliateClaim(customerId: string, adminName: string, reason: string) {
  const customer = await prisma.customer.findUniqueOrThrow({ where: { id: customerId } });
  if (customer.affiliateMilestoneStatus !== "PENDING") {
    throw new Error("There is no pending affiliate claim on this account.");
  }

  await prisma.customer.update({
    where: { id: customerId },
    data: { affiliateMilestoneStatus: "REJECTED" },
  });

  await logActivity({
    storeId: customer.storeId as StoreId,
    action: "AFFILIATE_MILESTONE_REJECTED",
    description: `${adminName} rejected the affiliate claim of ${customer.accessCode}: ${reason}`,
    adminId: adminName,
    customerId,
  });

  return true;
}
