import "server-only";
import { prisma } from "@/lib/prisma";
import { logActivity } from "@/lib/services/activity";
import { createNotification, NOTIFICATION_TYPES } from "@/lib/services/notifications";
import { formatCents } from "@/lib/money";
import { AFFILIATE, getReachedMilestone } from "@/lib/affiliate";
import type { StoreId } from "@/lib/store";

/** Give every customer a referral code once (idempotent). */
export async function ensureAffiliateCode(customerId: string): Promise<string> {
  const customer = await prisma.customer.findUniqueOrThrow({
    where: { id: customerId },
    select: { id: true, affiliateCode: true },
  });
  if (customer.affiliateCode) return customer.affiliateCode;

  for (let attempt = 0; attempt < 5; attempt++) {
    const { generateAffiliateCode } = await import("@/lib/affiliate");
    const code = generateAffiliateCode();
    const existing = await prisma.customer.findUnique({ where: { affiliateCode: code } });
    if (existing) continue;
    const updated = await prisma.customer.update({
      where: { id: customerId },
      data: { affiliateCode: code },
    });
    return updated.affiliateCode!;
  }
  throw new Error("Could not generate a unique affiliate code.");
}

export interface ReferralCreditResult {
  ok: boolean;
  referrerAccessCode?: string;
  commissionCents?: number;
}

/**
 * Called when a referred customer completes a purchase (activation approval or
 * recharge approval). Credits the inviter AUTOMATICALLY:
 *   cash: flat $5 per purchase (held in affiliateEarnedCents until claimed)
 *   points: half of what the friend earned from THIS purchase, min 15.
 */
export async function creditReferralCommission(referredCustomerId: string, friendPointsEarned = 0): Promise<ReferralCreditResult> {
  const buyer = await prisma.customer.findUnique({
    where: { id: referredCustomerId },
    select: { accessCode: true, referredById: true, initialBalanceCents: true },
  });
  if (!buyer?.referredById) return { ok: false };

  const referrer = await prisma.customer.findUnique({ where: { id: buyer.referredById } });
  if (!referrer || referrer.deletedAt) return { ok: false };

  // Points rule: the referrer earns max(15, friend's points / 2) — e.g. a
  // $100 purchase gives the friend 35 pts and the referrer 17.5 → 18 pts;
  // a first small purchase gives the friend 25 pts and the referrer 15.
  const commissionPoints = Math.max(AFFILIATE.commissionPoints, Math.round(friendPointsEarned / 2));
  const newEarned = referrer.affiliateEarnedCents + AFFILIATE.commissionCents;
  await prisma.$transaction([
    prisma.customer.update({
      where: { id: referrer.id },
      data: {
        affiliateEarnedCents: { increment: AFFILIATE.commissionCents },
        loyaltyPoints: { increment: commissionPoints },
      },
    }),
    // History entry on the REFERRER's bonus trail so admins can audit it.
    prisma.bonusHistory.create({
      data: {
        customerId: referrer.id,
        amountUsedCents: -AFFILIATE.commissionCents,
        remainingAfterCents: referrer.initialBonusCents - referrer.usedBonusCents,
        note: `Affiliate commission — purchase by ${buyer.accessCode} (held for claim)`,
        updatedBy: "Affiliate program",
      },
    }),
  ]);

  // Milestone check needs the friend's PURCHASE LIST (recharges included).
  const purchases = await prisma.rechargeRequest.findMany({
    where: { customerId: referredCustomerId, status: "APPROVED" },
    select: { balanceCents: true },
  });
  const purchaseCents = [buyer.initialBalanceCents ?? 0, ...purchases.map((p) => p.balanceCents)];
  const reached = getReachedMilestone(purchaseCents);

  await createNotification({
    storeId: referrer.storeId as StoreId,
    type: NOTIFICATION_TYPES.AFFILIATE_COMMISSION,
    title: "Affiliate Commission Earned",
    message: `Your friend ${buyer.accessCode} purchased — you earned ${formatCents(AFFILIATE.commissionCents)} + ${commissionPoints} pts${
      reached ? ` · Milestone "${reached.label}" is now claimable!` : ""
    }`,
    customerId: referrer.id,
    relatedId: referrer.id,
  });

  await logActivity({
    storeId: referrer.storeId as StoreId,
    action: "AFFILIATE_COMMISSION_CREDITED",
    description: `Affiliate: ${referrer.accessCode} earned ${formatCents(AFFILIATE.commissionCents)} because ${buyer.accessCode} completed a purchase`,
    customerId: referrer.id,
  });

  return { ok: true, referrerAccessCode: referrer.accessCode, commissionCents: AFFILIATE.commissionCents };
}

/** Stats shown on the customer's affiliate page and in the admin table. */
export async function getAffiliateStats(customerId: string) {
  const referrals = await prisma.customer.findMany({
    where: { referredById: customerId, deletedAt: null },
    select: { id: true, accessCode: true, createdAt: true, initialBalanceCents: true, status: true },
    orderBy: { createdAt: "desc" },
  });
  // Every purchase each referral made (initial activation + approved recharges).
  const purchasesCents: number[] = [];
  for (const r of referrals) {
    purchasesCents.push(r.initialBalanceCents);
    const recharges = await prisma.rechargeRequest.findMany({
      where: { customerId: r.id, status: "APPROVED" },
      select: { balanceCents: true },
    });
    for (const rc of recharges) purchasesCents.push(rc.balanceCents);
  }
  const totalSpendCents = purchasesCents.reduce((sum, c) => sum + c, 0);
  return { referralCount: referrals.length, totalSpendCents, purchasesCents, referrals };
}
