import "server-only";
import {
  startOfDay,
  endOfDay,
  startOfWeek,
  endOfWeek,
  startOfMonth,
  endOfMonth,
  subDays,
  subWeeks,
  subMonths,
  format,
  eachDayOfInterval,
} from "date-fns";
import { prisma } from "@/lib/prisma";
import type { StoreId } from "@/lib/store";

const activeCustomerWhere = (storeId: StoreId) => ({ storeId, deletedAt: null } as const);

async function profitBetween(storeId: StoreId, from: Date, to: Date): Promise<number> {
  const result = await prisma.profitHistory.aggregate({
    _sum: { amountCents: true },
    where: { createdAt: { gte: from, lte: to }, customer: { storeId, deletedAt: null } },
  });
  return result._sum.amountCents ?? 0;
}

export interface DashboardStats {
  totalCustomers: number;
  activeCustomers: number;
  lowBalanceCustomers: number;
  expiredCustomers: number;
  suspendedCustomers: number;
  /** Activated customers billed at the global multiplier because no plan is assigned (WS8). */
  noPlanCustomers: number;
  totalOrders: number;
  totalRevenueCents: number;
  totalProfitCents: number;
  todayProfitCents: number;
  yesterdayProfitCents: number;
  thisWeekProfitCents: number;
  lastWeekProfitCents: number;
  thisMonthProfitCents: number;
  lastMonthProfitCents: number;
}

export async function getDashboardStats(storeId: StoreId): Promise<DashboardStats> {
  const now = new Date();
  const customerWhere = activeCustomerWhere(storeId);

  const [
    totalCustomers,
    activeCustomers,
    lowBalanceCustomers,
    expiredCustomers,
    suspendedCustomers,
    noPlanCustomers,
    totalOrders,
    revenue,
    totalProfit,
    todayProfitCents,
    yesterdayProfitCents,
    thisWeekProfitCents,
    lastWeekProfitCents,
    thisMonthProfitCents,
    lastMonthProfitCents,
  ] = await Promise.all([
    prisma.customer.count({ where: customerWhere }),
    prisma.customer.count({ where: { ...customerWhere, status: "ACTIVE" } }),
    prisma.customer.count({ where: { ...customerWhere, status: "LOW_BALANCE" } }),
    prisma.customer.count({
      where: { ...customerWhere, status: { in: ["BALANCE_FINISHED", "EXPIRED"] } },
    }),
    prisma.customer.count({ where: { ...customerWhere, status: "SUSPENDED" } }),
    prisma.customer.count({ where: { ...customerWhere, isActivated: true, planId: null } }),
    prisma.order.count({ where: { customer: customerWhere } }),
    prisma.customer.aggregate({ _sum: { initialBalanceCents: true }, where: customerWhere }),
    prisma.profitHistory.aggregate({
      _sum: { amountCents: true },
      where: { customer: { storeId, deletedAt: null } },
    }),
    profitBetween(storeId, startOfDay(now), endOfDay(now)),
    profitBetween(storeId, startOfDay(subDays(now, 1)), endOfDay(subDays(now, 1))),
    profitBetween(storeId, startOfWeek(now, { weekStartsOn: 1 }), endOfWeek(now, { weekStartsOn: 1 })),
    profitBetween(
      storeId,
      startOfWeek(subWeeks(now, 1), { weekStartsOn: 1 }),
      endOfWeek(subWeeks(now, 1), { weekStartsOn: 1 })
    ),
    profitBetween(storeId, startOfMonth(now), endOfMonth(now)),
    profitBetween(storeId, startOfMonth(subMonths(now, 1)), endOfMonth(subMonths(now, 1))),
  ]);

  return {
    totalCustomers,
    activeCustomers,
    lowBalanceCustomers,
    expiredCustomers,
    suspendedCustomers,
    noPlanCustomers,
    totalOrders,
    totalRevenueCents: revenue._sum.initialBalanceCents ?? 0,
    totalProfitCents: totalProfit._sum.amountCents ?? 0,
    todayProfitCents,
    yesterdayProfitCents,
    thisWeekProfitCents,
    lastWeekProfitCents,
    thisMonthProfitCents,
    lastMonthProfitCents,
  };
}

export interface PortfolioStats {
  totalBalanceCents: number; // remaining across all customers (can be negative)
  totalUsedCents: number;
  activeUsers: number;
  totalApis: number;
  availableApis: number;
  assignedApis: number;
  notStarted: number; // customers with zero recorded usage
}

/** Aggregate stats for the Statistics page. */
export async function getPortfolioStats(storeId: StoreId): Promise<PortfolioStats> {
  const customerWhere = activeCustomerWhere(storeId);

  const [sums, activeUsers, notStarted, totalApis, availableApis] = await Promise.all([
    prisma.customer.aggregate({
      _sum: { initialBalanceCents: true, usedBalanceCents: true },
      where: customerWhere,
    }),
    prisma.customer.count({ where: { ...customerWhere, status: "ACTIVE" } }),
    prisma.customer.count({ where: { ...customerWhere, usedBalanceCents: 0 } }),
    prisma.apiPoolKey.count({ where: { storeId } }),
    prisma.apiPoolKey.count({ where: { storeId, status: "AVAILABLE" } }),
  ]);

  const initial = sums._sum.initialBalanceCents ?? 0;
  const used = sums._sum.usedBalanceCents ?? 0;

  return {
    totalBalanceCents: initial - used,
    totalUsedCents: used,
    activeUsers,
    totalApis,
    availableApis,
    assignedApis: totalApis - availableApis,
    notStarted,
  };
}

export interface DailyPoint {
  date: string; // yyyy-MM-dd
  label: string; // "Aug 2"
  profitCents: number;
  revenueCents: number;
  customers: number;
  orders: number;
  expired: number;
}

/** Daily series for the last `days` days: profit, revenue, new customers, expired. */
export async function getDailySeries(storeId: StoreId, days = 30): Promise<DailyPoint[]> {
  const now = new Date();
  const from = startOfDay(subDays(now, days - 1));

  const [profits, customers, finished] = await Promise.all([
    prisma.profitHistory.findMany({
      where: { createdAt: { gte: from }, customer: { storeId, deletedAt: null } },
      select: { createdAt: true, amountCents: true },
    }),
    prisma.customer.findMany({
      where: { storeId, createdAt: { gte: from }, deletedAt: null },
      select: { createdAt: true, initialBalanceCents: true },
    }),
    prisma.customer.findMany({
      where: { storeId, finishedAt: { gte: from }, deletedAt: null },
      select: { finishedAt: true },
    }),
  ]);

  const map = new Map<string, DailyPoint>();
  for (const day of eachDayOfInterval({ start: from, end: now })) {
    const key = format(day, "yyyy-MM-dd");
    map.set(key, {
      date: key,
      label: format(day, "MMM d"),
      profitCents: 0,
      revenueCents: 0,
      customers: 0,
      orders: 0,
      expired: 0,
    });
  }

  for (const p of profits) {
    const point = map.get(format(p.createdAt, "yyyy-MM-dd"));
    if (point) point.profitCents += p.amountCents;
  }
  for (const c of customers) {
    const point = map.get(format(c.createdAt, "yyyy-MM-dd"));
    if (point) {
      point.customers += 1;
      point.orders += 1;
      point.revenueCents += c.initialBalanceCents;
    }
  }
  for (const f of finished) {
    if (!f.finishedAt) continue;
    const point = map.get(format(f.finishedAt, "yyyy-MM-dd"));
    if (point) point.expired += 1;
  }

  return Array.from(map.values());
}

/**
 * Hourly series for a single day (offset 0 = today, 1 = yesterday …) —
 * powers the Today / Live / Yesterday views in Analytics.
 */
export async function getHourlySeries(storeId: StoreId, dayOffset = 0): Promise<DailyPoint[]> {
  const day = subDays(new Date(), dayOffset);
  const from = startOfDay(day);
  const to = endOfDay(day);

  const [profits, customers, finished] = await Promise.all([
    prisma.profitHistory.findMany({
      where: { createdAt: { gte: from, lte: to }, customer: { storeId, deletedAt: null } },
      select: { createdAt: true, amountCents: true },
    }),
    prisma.customer.findMany({
      where: { storeId, createdAt: { gte: from, lte: to }, deletedAt: null },
      select: { createdAt: true, initialBalanceCents: true },
    }),
    prisma.customer.findMany({
      where: { storeId, finishedAt: { gte: from, lte: to }, deletedAt: null },
      select: { finishedAt: true },
    }),
  ]);

  const points: DailyPoint[] = Array.from({ length: 24 }, (_, hour) => ({
    date: `${format(from, "yyyy-MM-dd")}T${String(hour).padStart(2, "0")}`,
    label: `${String(hour).padStart(2, "0")}:00`,
    profitCents: 0,
    revenueCents: 0,
    customers: 0,
    orders: 0,
    expired: 0,
  }));

  for (const p of profits) points[p.createdAt.getHours()].profitCents += p.amountCents;
  for (const c of customers) {
    const point = points[c.createdAt.getHours()];
    point.customers += 1;
    point.orders += 1;
    point.revenueCents += c.initialBalanceCents;
  }
  for (const f of finished) {
    if (f.finishedAt) points[f.finishedAt.getHours()].expired += 1;
  }

  return points;
}

export async function getRecentActivity(storeId: StoreId, limit = 15) {
  return prisma.activityLog.findMany({
    where: { storeId },
    orderBy: { createdAt: "desc" },
    take: limit,
    include: {
      admin: { select: { name: true } },
      customer: { select: { accessCode: true, deletedAt: true } },
    },
  });
}

/** Days with the highest revenue from new customers, for "Top Selling Days". */
export async function getTopSellingDays(storeId: StoreId, days = 90, take = 5) {
  const series = await getDailySeries(storeId, days);
  return series
    .filter((d) => d.revenueCents > 0)
    .sort((a, b) => b.revenueCents - a.revenueCents)
    .slice(0, take);
}
