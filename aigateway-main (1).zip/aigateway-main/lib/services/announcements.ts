import "server-only";
import type { Announcement, Prisma } from "@prisma/client";
import { prisma } from "@/lib/prisma";
import { credit, type Tx } from "@/lib/billing/balance-service";
import { centsToMicro } from "@/lib/billing/money";
import { ANNOUNCEMENT_KINDS, promoBonusCents, type AnnouncementKind } from "@/lib/announcements";

// Customer announcements: what an admin tells customers from the portal
// inbox and dashboard banner.
//
//   INFO       plain message
//   PROMO      recharge promotion — a recharge submitted while it runs earns
//              rechargeBonusPct % of the recharged balance as BONUS credit
//   NEW_MODEL  a model was added; names the catalog alias only
//
// The promo is snapshotted on the RechargeRequest when the customer submits
// it (they saw the offer), and credited when the recharge is approved, even
// if the promotion has ended by then. Voucher top-ups credited on the spot
// get it immediately.

export { ANNOUNCEMENT_KINDS, MAX_RECHARGE_BONUS_PCT, promoBonusCents, type AnnouncementKind } from "@/lib/announcements";

/** Announcements a customer can see right now. */
function liveFor(storeId: string, customerId: string, now: Date): Prisma.AnnouncementWhereInput {
  return {
    storeId,
    archivedAt: null,
    startsAt: { lte: now },
    OR: [{ endsAt: null }, { endsAt: { gt: now } }],
    AND: [{ OR: [{ customerId: null }, { customerId }] }],
  };
}

export interface CustomerAnnouncement {
  id: string;
  kind: AnnouncementKind;
  title: string;
  message: string;
  rechargeBonusPct: number;
  startsAt: Date;
  endsAt: Date | null;
  read: boolean;
}

function toCustomerView(a: Announcement & { reads: { id: string }[] }): CustomerAnnouncement {
  return {
    id: a.id,
    kind: (ANNOUNCEMENT_KINDS as readonly string[]).includes(a.kind) ? (a.kind as AnnouncementKind) : "INFO",
    title: a.title,
    message: a.message,
    rechargeBonusPct: a.rechargeBonusPct,
    startsAt: a.startsAt,
    endsAt: a.endsAt,
    read: a.reads.length > 0,
  };
}

/** The customer's inbox: live announcements, newest first, with their read state. */
export async function listCustomerAnnouncements(storeId: string, customerId: string, limit = 50): Promise<CustomerAnnouncement[]> {
  const rows = await prisma.announcement.findMany({
    where: liveFor(storeId, customerId, new Date()),
    include: { reads: { where: { customerId }, select: { id: true } } },
    orderBy: { startsAt: "desc" },
    take: limit,
  });
  return rows.map(toCustomerView);
}

export async function countUnreadAnnouncements(storeId: string, customerId: string): Promise<number> {
  return prisma.announcement.count({
    where: { ...liveFor(storeId, customerId, new Date()), reads: { none: { customerId } } },
  });
}

/** Mark the given announcements (or every live one) read for this customer. Idempotent. */
export async function markAnnouncementsRead(storeId: string, customerId: string, ids?: string[]): Promise<void> {
  const unread = await prisma.announcement.findMany({
    where: {
      ...liveFor(storeId, customerId, new Date()),
      reads: { none: { customerId } },
      ...(ids ? { id: { in: ids } } : {}),
    },
    select: { id: true },
  });
  for (const a of unread) {
    await prisma.announcementRead.upsert({
      where: { announcementId_customerId: { announcementId: a.id, customerId } },
      update: {},
      create: { announcementId: a.id, customerId },
    });
  }
}

/** The best recharge promotion running for this customer now, or null. */
export async function activeRechargePromo(storeId: string, customerId: string, db: Tx | typeof prisma = prisma): Promise<{ id: string; title: string; rechargeBonusPct: number; endsAt: Date | null } | null> {
  const promo = await db.announcement.findFirst({
    where: { ...liveFor(storeId, customerId, new Date()), kind: "PROMO", rechargeBonusPct: { gt: 0 } },
    orderBy: [{ rechargeBonusPct: "desc" }, { startsAt: "desc" }],
    select: { id: true, title: true, rechargeBonusPct: true, endsAt: true },
  });
  return promo;
}

/**
 * Credit a recharge promotion to the BONUS pot, inside the caller's
 * transaction. Idempotent per reference (one promo credit per recharge or
 * voucher). Returns the cents credited (0 when nothing is due).
 */
export async function creditPromoBonus(
  tx: Tx,
  p: {
    customerId: string;
    balanceCents: number;
    pct: number;
    ref: { type: "RechargeRequest" | "Voucher"; id: string };
    actor: { adminId?: string; label: string };
  }
): Promise<number> {
  const cents = promoBonusCents(p.balanceCents, p.pct);
  if (cents <= 0) return 0;
  await credit({
    customerId: p.customerId,
    pot: "BONUS",
    amountMicroUsd: centsToMicro(cents),
    type: "PROMO_BONUS",
    idempotencyKey: `promo:${p.ref.type}:${p.ref.id}`,
    ref: p.ref,
    actor: p.actor,
    note: `Recharge promotion: +${p.pct}% bonus`,
    tx,
  });
  return cents;
}
