import "server-only";
import { prisma } from "@/lib/prisma";
import { publicModelId, publicModelName } from "@/lib/model-alias";

// What a customer sees of their own gateway usage. Only rows written by the
// gateway (requestId set) count. `UsageLog.model` holds the internal catalog
// slug; it is always shown through the model's PUBLIC alias (id + name), so
// neither the internal name nor the provider's model ever reaches the portal.

export interface ModelAlias {
  /** Public model id (the alias customers type). */
  slug: string;
  /** Public model name. */
  name: string;
}

export type AliasIndex = Map<string, ModelAlias>;

/** internal slug → public alias, for every catalog model (enabled or not). */
export async function getModelAliases(): Promise<AliasIndex> {
  const rows = await prisma.gatewayModel.findMany({ select: { slug: true, displayName: true, aliasSlug: true, aliasName: true } });
  return new Map(rows.map((r) => [r.slug, { slug: publicModelId(r), name: publicModelName(r) }]));
}

/** Public alias for a logged model; a model since deleted shows as "Retired model", never its internal slug. */
export function aliasFor(aliases: AliasIndex, slug: string): ModelAlias {
  return aliases.get(slug) ?? { slug: "retired-model", name: "Retired model" };
}

export interface ModelUsageSummary extends ModelAlias {
  requests: number;
  inputTokens: number;
  outputTokens: number;
  /** What the customer was charged, µ$. */
  chargedMicroUsd: bigint;
  lastUsedAt: Date | null;
}

/** Per-model totals since `since`, most expensive first. */
export async function getCustomerUsageByModel(customerId: string, since: Date, aliases?: AliasIndex): Promise<ModelUsageSummary[]> {
  const [groups, names] = await Promise.all([
    prisma.usageLog.groupBy({
      by: ["model"],
      where: { customerId, requestId: { not: null }, happenedAt: { gte: since } },
      _count: { _all: true },
      _sum: { promptTokens: true, completionTokens: true, customerMicroUsd: true },
      _max: { happenedAt: true },
    }),
    aliases ? Promise.resolve(aliases) : getModelAliases(),
  ]);
  // Several internal models can share one public row (e.g. retired models): merge by alias.
  const byAlias = new Map<string, ModelUsageSummary>();
  for (const g of groups) {
    const alias = aliasFor(names, g.model);
    const prev = byAlias.get(alias.slug);
    const last = g._max.happenedAt;
    byAlias.set(alias.slug, {
      ...alias,
      requests: (prev?.requests ?? 0) + g._count._all,
      inputTokens: (prev?.inputTokens ?? 0) + (g._sum.promptTokens ?? 0),
      outputTokens: (prev?.outputTokens ?? 0) + (g._sum.completionTokens ?? 0),
      chargedMicroUsd: (prev?.chargedMicroUsd ?? 0n) + (g._sum.customerMicroUsd ?? 0n),
      lastUsedAt: prev?.lastUsedAt && last ? (prev.lastUsedAt > last ? prev.lastUsedAt : last) : (prev?.lastUsedAt ?? last),
    });
  }
  return [...byAlias.values()]
    .sort((a, b) => (b.chargedMicroUsd > a.chargedMicroUsd ? 1 : b.chargedMicroUsd < a.chargedMicroUsd ? -1 : b.requests - a.requests));
}

export interface RecentRequest {
  id: string;
  happenedAt: Date;
  model: ModelAlias;
  inputTokens: number;
  outputTokens: number;
  chargedMicroUsd: bigint;
  outcome: string;
}

/** The customer's latest gateway requests, newest first. */
export async function getRecentRequests(customerId: string, take = 5, aliases?: AliasIndex): Promise<RecentRequest[]> {
  const [rows, names] = await Promise.all([
    prisma.usageLog.findMany({
      where: { customerId, requestId: { not: null } },
      orderBy: { happenedAt: "desc" },
      take,
      select: { id: true, happenedAt: true, model: true, promptTokens: true, completionTokens: true, customerMicroUsd: true, outcome: true },
    }),
    aliases ? Promise.resolve(aliases) : getModelAliases(),
  ]);
  return rows.map((r) => ({
    id: r.id,
    happenedAt: r.happenedAt,
    model: aliasFor(names, r.model),
    inputTokens: r.promptTokens ?? 0,
    outputTokens: r.completionTokens ?? 0,
    chargedMicroUsd: r.customerMicroUsd ?? 0n,
    outcome: r.outcome,
  }));
}
