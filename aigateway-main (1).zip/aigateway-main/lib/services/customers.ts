import "server-only";
import type { Prisma } from "@prisma/client";
import { prisma } from "@/lib/prisma";
import { logActivity } from "@/lib/services/activity";
import { getLowBalanceThresholdCents } from "@/lib/services/settings";
import type { StoreId } from "@/lib/store";
import { computeStatus, remainingBalanceCents, remainingBonusCents } from "@/lib/services/status";
import { randomUUID } from "node:crypto";
import { adjust, chargeUsage, credit, debit, refund as ledgerRefund, type Tx } from "@/lib/billing/balance-service";
import { centsToMicro, formatMicroUsd, type Pot } from "@/lib/billing/money";
import { generateAccessCode, generateOrderNumber } from "@/lib/services/generators";
import type { PurchasedAgain } from "@/lib/constants";
import { poolAssignmentsEnabled } from "@/lib/services/legacy-pool";

export type CustomerWithRelations = Prisma.CustomerGetPayload<{
  include: { order: true; apiKey: true; plan: { select: { id: true; name: true } } };
}>;

export const customerInclude = { order: true, apiKey: true, plan: { select: { id: true, name: true } } } as const;

export interface CreateCustomerInput {
  accessCode: string;
  orderNumber: string;
  /** Legacy pool key; stored only when LEGACY_API_POOL_MODE=active (WS10). */
  apiKey?: string;
  initialBalanceCents: number;
  initialBonusCents: number;
  profitCents: number;
  status?: string;
  notes?: string;
}

const ADMIN = (adminId: string, adminName: string) => ({ adminId, label: adminName });

/**
 * Create a customer. The opening balance and bonus are credited through the
 * balance service so the ledger starts with OPENING_BALANCE entries; the row
 * itself is created with zero money.
 */
export async function createCustomer(input: CreateCustomerInput, adminId: string, adminName: string, storeId: StoreId) {
  const manualStatus = input.status === "SUSPENDED" || input.status === "EXPIRED" ? input.status : null;

  const created = await prisma.$transaction(async (tx) => {
    const row = await tx.customer.create({
      data: {
        storeId,
        accessCode: input.accessCode,
        status: manualStatus ?? "ACTIVE",
        notes: input.notes ?? "",
        profitCents: input.profitCents,
        suspendedAt: manualStatus === "SUSPENDED" ? new Date() : null,
        order: { create: { orderNumber: input.orderNumber } },
        ...(input.apiKey && poolAssignmentsEnabled() ? { apiKey: { create: { key: input.apiKey } } } : {}),
        ...(input.profitCents > 0
          ? { profitHistory: { create: { amountCents: input.profitCents, note: "Initial profit" } } }
          : {}),
      },
    });
    await creditOpening(tx, row.id, "BALANCE", input.initialBalanceCents, ADMIN(adminId, adminName));
    await creditOpening(tx, row.id, "BONUS", input.initialBonusCents, ADMIN(adminId, adminName));
    // A zero-balance customer is finished from the start (no ledger movement derives it).
    if (!manualStatus && input.initialBalanceCents <= 0 && input.initialBonusCents <= 0) {
      await tx.customer.update({ where: { id: row.id }, data: { status: "BALANCE_FINISHED", finishedAt: new Date() } });
    }
    return tx.customer.findUniqueOrThrow({ where: { id: row.id }, include: customerInclude });
  });

  await logActivity({
    storeId,
    action: "CUSTOMER_CREATED",
    description: `${adminName} created customer ${created.accessCode} (order ${input.orderNumber})`,
    adminId,
    customerId: created.id,
  });

  return created;
}

/** OPENING_BALANCE credit for a brand-new customer (no-op for zero). Shared by imports and seeds. */
export async function creditOpening(
  tx: Tx | undefined,
  customerId: string,
  pot: Pot,
  cents: number,
  actor: { adminId?: string | null; label: string },
  note = "Opening balance"
) {
  if (cents <= 0) return null;
  return credit({
    customerId,
    pot,
    amountMicroUsd: centsToMicro(cents),
    type: "OPENING_BALANCE",
    idempotencyKey: `opening:${customerId}:${pot}`,
    actor,
    note,
    history: "none",
    tx,
  });
}

export interface UpdateCustomerInput {
  accessCode?: string;
  orderNumber?: string;
  apiKey?: string;
  initialBalanceCents?: number;
  initialBonusCents?: number;
  profitCents?: number;
  status?: string;
  notes?: string;
  /** Required whenever initialBalanceCents / initialBonusCents change. */
  balanceChangeReason?: string;
}

export async function updateCustomer(id: string, input: UpdateCustomerInput, adminId: string, adminName: string) {
  // Upstream keys are written only while the legacy pool is active (WS10).
  const keyWritable = !!input.apiKey && poolAssignmentsEnabled();
  const customer = await prisma.customer.findUniqueOrThrow({ where: { id }, select: { storeId: true } });
  const threshold = await getLowBalanceThresholdCents(customer.storeId as StoreId);

  // Interactive transaction with an optimistic-concurrency guard so two
  // concurrent edits can never interleave and desync profit history or
  // silently overwrite each other. Balance changes go through the ledger as
  // ADMIN_ADJUSTMENT entries and therefore need a reason.
  const { customer: updatedCustomer, existing } = await prisma.$transaction(async (tx) => {
    const existing = await tx.customer.findUniqueOrThrow({ where: { id }, include: customerInclude });

    const balanceDelta = (input.initialBalanceCents ?? existing.initialBalanceCents) - existing.initialBalanceCents;
    const bonusDelta = (input.initialBonusCents ?? existing.initialBonusCents) - existing.initialBonusCents;
    const reason = (input.balanceChangeReason ?? "").trim();
    if ((balanceDelta !== 0 || bonusDelta !== 0) && !reason) {
      throw new Error("A reason is required when changing the balance or bonus.");
    }

    const requestedStatus = input.status ?? existing.status;
    const status = computeStatus(remainingBalanceCents(existing), threshold, requestedStatus, remainingBonusCents(existing));
    const profitDelta = (input.profitCents ?? existing.profitCents) - existing.profitCents;

    const claimed = await tx.customer.updateMany({
      where: { id, updatedAt: existing.updatedAt },
      data: {
        accessCode: input.accessCode ?? existing.accessCode,
        notes: input.notes ?? existing.notes,
        profitCents: input.profitCents ?? existing.profitCents,
        status,
        suspendedAt: status === "SUSPENDED" ? (existing.suspendedAt ?? new Date()) : null,
      },
    });
    if (claimed.count === 0) {
      throw new Error("This customer was just modified elsewhere. Refresh and try again.");
    }

    const editKey = randomUUID();
    if (balanceDelta !== 0) {
      await adjust({ customerId: id, pot: "BALANCE", deltaMicroUsd: centsToMicro(balanceDelta), idempotencyKey: `edit:${editKey}:BALANCE`, actor: ADMIN(adminId, adminName), note: reason, tx });
    }
    if (bonusDelta !== 0) {
      await adjust({ customerId: id, pot: "BONUS", deltaMicroUsd: centsToMicro(bonusDelta), idempotencyKey: `edit:${editKey}:BONUS`, actor: ADMIN(adminId, adminName), note: reason, tx });
    }

    if (input.orderNumber !== undefined) {
      await tx.order.update({ where: { customerId: id }, data: { orderNumber: input.orderNumber } });
    }
    if (keyWritable) {
      await tx.apiKey.upsert({ where: { customerId: id }, update: { key: input.apiKey! }, create: { customerId: id, key: input.apiKey! } });
    }
    if (profitDelta !== 0) {
      await tx.profitHistory.create({
        data: { customerId: id, amountCents: profitDelta, note: "Profit adjusted" },
      });
    }

    const customer = await tx.customer.findUniqueOrThrow({ where: { id }, include: customerInclude });
    return { customer, existing };
  });

  const apiChanged = keyWritable && input.apiKey !== existing.apiKey?.key;
  await logActivity({
    storeId: customer.storeId as StoreId,
    action: apiChanged ? "API_KEY_CHANGED" : "CUSTOMER_EDITED",
    description: apiChanged
      ? `${adminName} changed the API key for ${updatedCustomer.accessCode}`
      : `${adminName} edited customer ${updatedCustomer.accessCode}`,
    adminId,
    customerId: id,
  });

  if (input.status && input.status !== existing.status) {
    await logActivity({
      storeId: customer.storeId as StoreId,
      action: "STATUS_CHANGED",
      description: `${adminName} changed status of ${updatedCustomer.accessCode} from ${existing.status} to ${updatedCustomer.status}`,
      adminId,
      customerId: id,
    });
  }

  return updatedCustomer;
}

/**
 * Record balance usage entered by an admin. The pot never goes negative: if
 * the amount exceeds what is left, the remainder is reported as uncollected.
 */
export async function updateBalanceUsage(id: string, amountUsedCents: number, adminId: string, adminName: string, note = "") {
  return adminUsage(id, "BALANCE", amountUsedCents, adminId, adminName, note);
}

/** Record bonus usage, same rules as balance usage. */
export async function updateBonusUsage(id: string, amountUsedCents: number, adminId: string, adminName: string, note = "") {
  return adminUsage(id, "BONUS", amountUsedCents, adminId, adminName, note);
}

async function adminUsage(id: string, pot: Pot, amountUsedCents: number, adminId: string, adminName: string, note: string) {
  if (amountUsedCents <= 0) throw new Error("Amount must be greater than zero");
  const r = await debit({
    customerId: id,
    pot,
    amountMicroUsd: centsToMicro(amountUsedCents),
    type: "USAGE",
    idempotencyKey: `admin-usage:${randomUUID()}`,
    actor: ADMIN(adminId, adminName),
    note,
  });
  const c = r.customer;
  const remaining = pot === "BALANCE" ? remainingBalanceCents(c) : remainingBonusCents(c);
  const uncollected = r.uncollectedMicroUsd > 0n ? `; ${formatMicroUsd(r.uncollectedMicroUsd)} could not be collected (pot is empty)` : "";
  await logActivity({
    storeId: c.storeId as StoreId,
    action: pot === "BALANCE" ? "BALANCE_UPDATED" : "BONUS_UPDATED",
    description: `${adminName} recorded ${(amountUsedCents / 100).toFixed(2)} USD ${pot === "BALANCE" ? "usage" : "bonus usage"} for ${c.accessCode} (remaining ${(remaining / 100).toFixed(2)} USD)${uncollected}`,
    adminId,
    customerId: id,
  });
  return prisma.customer.findUniqueOrThrow({ where: { id }, include: customerInclude });
}

/** Add funds to the balance (manual top-up): an ADMIN_ADJUSTMENT with a reason. */
export async function addBalanceFunds(id: string, amountCents: number, adminId: string, adminName: string, note = "") {
  return adminTopUp(id, "BALANCE", amountCents, adminId, adminName, note);
}

/** Add funds to the bonus, same as addBalanceFunds. */
export async function addBonusFunds(id: string, amountCents: number, adminId: string, adminName: string, note = "") {
  return adminTopUp(id, "BONUS", amountCents, adminId, adminName, note);
}

async function adminTopUp(id: string, pot: Pot, amountCents: number, adminId: string, adminName: string, note: string) {
  if (amountCents <= 0) throw new Error("Amount must be greater than zero");
  const r = await adjust({
    customerId: id,
    pot,
    deltaMicroUsd: centsToMicro(amountCents),
    idempotencyKey: `topup:${randomUUID()}`,
    actor: ADMIN(adminId, adminName),
    note,
  });
  const c = r.customer;
  const remaining = pot === "BALANCE" ? remainingBalanceCents(c) : remainingBonusCents(c);
  await logActivity({
    storeId: c.storeId as StoreId,
    action: pot === "BALANCE" ? "BALANCE_UPDATED" : "BONUS_UPDATED",
    description: `${adminName} added ${(amountCents / 100).toFixed(2)} USD ${pot === "BALANCE" ? "balance" : "bonus"} to ${c.accessCode} (remaining ${(remaining / 100).toFixed(2)} USD): ${note}`,
    adminId,
    customerId: id,
  });
  return prisma.customer.findUniqueOrThrow({ where: { id }, include: customerInclude });
}

export interface AdminUsageResult {
  balanceCents: number;
  bonusCents: number;
  uncollectedCents: number;
}

/**
 * Charge admin-entered usage balance first (bonus only pays what the balance
 * cannot; nothing goes negative). Returns what
 * each pot paid; the caller writes the activity log.
 */
export async function recordAdminUsage(id: string, totalCents: number, adminId: string, adminName: string, note: string): Promise<AdminUsageResult> {
  if (totalCents <= 0) throw new Error("Amount must be greater than zero");
  const r = await chargeUsage({
    customerId: id,
    amountMicroUsd: centsToMicro(totalCents),
    idempotencyKey: `admin-usage:${randomUUID()}`,
    actor: ADMIN(adminId, adminName),
    note,
  });
  return {
    balanceCents: Number(r.balanceMicroUsd / 10_000n),
    bonusCents: Number(r.bonusMicroUsd / 10_000n),
    uncollectedCents: Number(r.uncollectedMicroUsd / 10_000n),
  };
}

/** Give money back to the balance (e.g. a usage log was removed). */
export async function refundBalance(id: string, amountCents: number, adminId: string, adminName: string, note: string, ref?: { type: string; id: string }) {
  if (amountCents <= 0) return null;
  return ledgerRefund({
    customerId: id,
    pot: "BALANCE",
    amountMicroUsd: centsToMicro(amountCents),
    idempotencyKey: ref ? `refund:${ref.type}:${ref.id}` : `refund:${randomUUID()}`,
    ref,
    actor: ADMIN(adminId, adminName),
    note,
  });
}

export async function softDeleteCustomer(id: string, adminId: string, adminName: string) {
  const customer = await prisma.customer.update({ where: { id }, data: { deletedAt: new Date() } });
  await logActivity({
    storeId: customer.storeId as StoreId,
    action: "CUSTOMER_DELETED",
    description: `${adminName} deleted customer ${customer.accessCode} (recoverable)`,
    adminId,
    customerId: id,
  });
  return customer;
}

export async function restoreCustomer(id: string, adminId: string, adminName: string) {
  const customer = await prisma.customer.update({ where: { id }, data: { deletedAt: null } });
  await logActivity({
    storeId: customer.storeId as StoreId,
    action: "CUSTOMER_RESTORED",
    description: `${adminName} restored customer ${customer.accessCode}`,
    adminId,
    customerId: id,
  });
  return customer;
}

export async function permanentlyDeleteCustomer(id: string, adminId: string, adminName: string) {
  const customer = await prisma.customer.delete({ where: { id } });
  await logActivity({
    storeId: customer.storeId as StoreId,
    action: "CUSTOMER_PERMANENTLY_DELETED",
    description: `${adminName} permanently deleted customer ${customer.accessCode}`,
    adminId,
  });
  return customer;
}

/** Duplicate a customer with a fresh access code and order number, zeroed usage. */
export async function duplicateCustomer(id: string, adminId: string, adminName: string) {
  const source = await prisma.customer.findUniqueOrThrow({ where: { id }, include: customerInclude });
  const accessCode = await generateAccessCode();
  const orderNumber = await generateOrderNumber();

  const customer = await createCustomer(
    {
      accessCode,
      orderNumber,
      apiKey: source.apiKey?.key,
      initialBalanceCents: source.initialBalanceCents,
      initialBonusCents: source.initialBonusCents,
      profitCents: source.profitCents,
      notes: source.notes,
    },
    adminId,
    adminName,
    source.storeId as StoreId
  );

  await logActivity({
    storeId: source.storeId as StoreId,
    action: "CUSTOMER_DUPLICATED",
    description: `${adminName} duplicated ${source.accessCode} into ${customer.accessCode}`,
    adminId,
    customerId: customer.id,
  });

  return customer;
}

export async function setPurchasedAgain(id: string, value: PurchasedAgain, adminId: string, adminName: string) {
  const customer = await prisma.customer.update({
    where: { id },
    data: { purchasedAgain: value, purchasedAgainAt: value === "UNKNOWN" ? null : new Date() },
  });
  await logActivity({
    storeId: customer.storeId as StoreId,
    action: "PURCHASED_AGAIN_UPDATED",
    description: `${adminName} marked ${customer.accessCode} as ${value === "YES" ? "purchased again" : value === "NO" ? "did not purchase" : "unknown"}`,
    adminId,
    customerId: id,
  });
  return customer;
}

/** Manual status override (suspend / unsuspend / expire). Re-derives auto statuses. */
export async function setCustomerStatus(id: string, status: string, adminId: string, adminName: string) {
  const existing = await prisma.customer.findUniqueOrThrow({ where: { id } });
  const threshold = await getLowBalanceThresholdCents(existing.storeId as StoreId);
  const finalStatus =
    status === "SUSPENDED" || status === "EXPIRED"
      ? status
      : computeStatus(remainingBalanceCents(existing), threshold, status);

  const customer = await prisma.customer.update({
    where: { id },
    data: {
      status: finalStatus,
      suspendedAt: finalStatus === "SUSPENDED" ? (existing.suspendedAt ?? new Date()) : null,
    },
  });

  await logActivity({
    storeId: existing.storeId as StoreId,
    action: "STATUS_CHANGED",
    description: `${adminName} changed status of ${customer.accessCode} from ${existing.status} to ${finalStatus}`,
    adminId,
    customerId: id,
  });

  return customer;
}
