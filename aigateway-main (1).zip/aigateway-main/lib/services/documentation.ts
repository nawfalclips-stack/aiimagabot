import "server-only";
import { prisma } from "@/lib/prisma";
import { logActivity } from "@/lib/services/activity";
import { BASE_URL_PLACEHOLDER, MODEL_PLACEHOLDER } from "@/lib/constants";
import type { StoreId } from "@/lib/store";

export async function getAllDocs(storeId?: StoreId) {
  const docs = await prisma.documentation.findMany({
    where: storeId ? { storeId } : undefined,
    orderBy: [{ category: "asc" }, { sortOrder: "asc" }],
  });
  return storeId ? preferStoreDocs(docs, storeId) : docs;
}

/**
 * Some stores still hold guides seeded before multi-store support, with slugs
 * like "claude-windows" instead of "aerolink-claude-windows". When both exist
 * for the same category + OS, keep only the store-prefixed one (the one the
 * seed keeps up to date) so portal tabs and the editor never pick the stale copy.
 */
export function preferStoreDocs<T extends { slug: string; category: string; os: string }>(docs: T[], storeId: string): T[] {
  const prefix = `${storeId}-`;
  const managed = new Set(docs.filter((d) => d.slug.startsWith(prefix)).map((d) => `${d.category}|${d.os}`));
  return docs.filter((d) => d.slug.startsWith(prefix) || !managed.has(`${d.category}|${d.os}`));
}

export async function getDocBySlug(slug: string) {
  return prisma.documentation.findUnique({ where: { slug } });
}

/**
 * Update a documentation guide, snapshotting the previous content as a
 * version so the admin can roll back.
 */
export async function updateDoc(id: string, content: string, adminId: string, adminName: string, storeId: StoreId) {
  const existing = await prisma.documentation.findUniqueOrThrow({ where: { id } });

  const doc = await prisma.documentation.update({
    where: { id },
    data: {
      content,
      versions: { create: { content: existing.content, savedBy: adminName } },
    },
  });

  await logActivity({
    storeId,
    action: "DOCUMENTATION_UPDATED",
    description: `${adminName} updated documentation "${existing.title}"`,
    adminId,
  });

  return doc;
}

export async function getDocVersions(documentationId: string) {
  return prisma.documentationVersion.findMany({
    where: { documentationId },
    orderBy: { createdAt: "desc" },
    take: 20,
  });
}

export async function rollbackDoc(versionId: string, adminId: string, adminName: string, storeId: StoreId) {
  const version = await prisma.documentationVersion.findUniqueOrThrow({
    where: { id: versionId },
    include: { documentation: true },
  });
  return updateDoc(version.documentationId, version.content, adminId, adminName, storeId);
}

/**
 * Fill the documentation placeholders for one customer (WS7): this site's
 * origin and an example model from their store's catalog. Customers are never
 * shown an upstream key; YOUR_AEROLINK_API_KEY stays literal and the guides
 * tell them to paste their own gateway token.
 */
export function renderDocForCustomer(content: string, vars: { baseUrl: string; model: string | null }): string {
  return content
    .split(BASE_URL_PLACEHOLDER)
    .join(vars.baseUrl)
    .split(MODEL_PLACEHOLDER)
    .join(vars.model ?? "MODEL_ID");
}
