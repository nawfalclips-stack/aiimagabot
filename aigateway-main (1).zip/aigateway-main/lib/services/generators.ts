import "server-only";
import { randomInt } from "crypto";
import { prisma } from "@/lib/prisma";

// Unambiguous alphabet (no 0/O, 1/I) for human-friendly codes.
const ALPHABET = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";

function randomSegment(length: number): string {
  let out = "";
  for (let i = 0; i < length; i++) out += ALPHABET[randomInt(ALPHABET.length)];
  return out;
}

/** Cryptographically random access code, e.g. AERO-X8KF-93LD-72PQ. Guaranteed unique. */
export async function generateAccessCode(): Promise<string> {
  for (let attempt = 0; attempt < 10; attempt++) {
    const code = `AERO-${randomSegment(4)}-${randomSegment(4)}-${randomSegment(4)}`;
    const exists = await prisma.customer.findUnique({ where: { accessCode: code }, select: { id: true } });
    if (!exists) return code;
  }
  throw new Error("Could not generate a unique access code");
}

/** Unique order number, e.g. ORD-20260802-4X8K2P. */
export async function generateOrderNumber(): Promise<string> {
  const date = new Date();
  const ymd = `${date.getFullYear()}${String(date.getMonth() + 1).padStart(2, "0")}${String(date.getDate()).padStart(2, "0")}`;
  for (let attempt = 0; attempt < 10; attempt++) {
    const orderNumber = `ORD-${ymd}-${randomSegment(6)}`;
    const exists = await prisma.order.findUnique({ where: { orderNumber }, select: { id: true } });
    if (!exists) return orderNumber;
  }
  throw new Error("Could not generate a unique order number");
}
