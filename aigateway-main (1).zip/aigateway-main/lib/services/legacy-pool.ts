import "server-only";
import type { Prisma } from "@prisma/client";
import { prisma } from "@/lib/prisma";

/**
 * Legacy upstream-key pool (WS10).
 *
 * Before the gateway, customers were handed an upstream provider key from the
 * API Pool. Nobody should hold an upstream key any more: sharing them breaks
 * the provider's terms and makes metering and revocation impossible.
 *
 *   active   — old behaviour: activation, recharges and API tickets hand out keys.
 *   readonly — (default) no new assignments; the admin pool page shows history
 *              with keys masked; customers never see a key.
 *   off      — as readonly, and the admin pool page is hidden.
 */
export type LegacyPoolMode = "active" | "readonly" | "off";

export function legacyPoolMode(): LegacyPoolMode {
  const v = (process.env.LEGACY_API_POOL_MODE ?? "readonly").toLowerCase();
  return v === "active" || v === "off" ? v : "readonly";
}

export function poolAssignmentsEnabled(): boolean {
  return legacyPoolMode() === "active";
}

/** `sk-abc…wxyz` → `sk-…wxyz`. Never returns more than the last 4 characters. */
export function maskKey(key: string | null | undefined): string {
  if (!key) return "";
  const tail = key.length > 8 ? key.slice(-4) : "";
  const dash = key.indexOf("-");
  const prefix = dash > 0 && dash <= 8 ? key.slice(0, dash + 1) : "";
  return `${prefix}…${tail}`;
}

/** Shapes of upstream provider keys (Anthropic, OpenRouter, OpenAI, DeepSeek, Google, legacy pool). */
const KEY_SHAPES = /sk-ant-[A-Za-z0-9_-]{20,}|sk-or-v1-[A-Za-z0-9]{32,}|sk-proj-[A-Za-z0-9_-]{20,}|\bsk-[A-Za-z0-9]{32,}\b|AIza[0-9A-Za-z_-]{35}|aero_live_[A-Za-z0-9]{8,}/g;

/**
 * Mask anything in free text that looks like an upstream key — old usage rows
 * used the customer's pool key as their label. No-op while the pool is active.
 */
export function redactKeys(text: string): string {
  if (poolAssignmentsEnabled()) return text;
  return text.replace(KEY_SHAPES, (k) => maskKey(k));
}

type Db = Prisma.TransactionClient | typeof prisma;

/**
 * Hand the customer the oldest AVAILABLE key of *their* store, retiring the
 * key they held as PROBLEMATIC. Returns the new key, or null when assignments
 * are disabled or the store's pool is empty. The claim is conditional so two
 * concurrent callers can never win the same key.
 */
export async function swapPoolKey(
  db: Db,
  input: { customerId: string; storeId: string; orderId: string | null },
): Promise<string | null> {
  if (!poolAssignmentsEnabled()) return null;

  for (let attempt = 0; attempt < 3; attempt++) {
    const candidate = await db.apiPoolKey.findFirst({
      where: { storeId: input.storeId, status: "AVAILABLE" },
      orderBy: { createdAt: "asc" },
      select: { id: true, key: true },
    });
    if (!candidate) return null;

    const claimed = await db.apiPoolKey.updateMany({
      where: { id: candidate.id, status: "AVAILABLE" },
      data: { status: "ASSIGNED", orderId: input.orderId, assignedAt: new Date() },
    });
    if (claimed.count === 0) continue; // lost the race, try the next key

    // Retire the previous key (linked by customerId, or only by value for
    // keys assigned before the link existed) and free the unique customerId slot.
    const current = await db.apiKey.findUnique({ where: { customerId: input.customerId }, select: { key: true } });
    await db.apiPoolKey.updateMany({
      where: {
        NOT: { id: candidate.id },
        OR: [{ customerId: input.customerId }, ...(current ? [{ key: current.key, status: "ASSIGNED" }] : [])],
      },
      data: { status: "PROBLEMATIC", customerId: null },
    });
    await db.apiPoolKey.update({ where: { id: candidate.id }, data: { customerId: input.customerId } });
    await db.apiKey.upsert({
      where: { customerId: input.customerId },
      update: { key: candidate.key },
      create: { customerId: input.customerId, key: candidate.key },
    });
    return candidate.key;
  }
  return null;
}
