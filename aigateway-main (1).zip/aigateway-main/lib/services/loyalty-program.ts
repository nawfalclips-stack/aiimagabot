import "server-only";
import { getSettings, setSetting } from "@/lib/services/settings";
import { SETTING_KEYS } from "@/lib/constants";
import { loyaltyProgramFromSetting, parseLoyaltyProgram, type LoyaltyProgram } from "@/lib/loyalty";
import type { StoreId } from "@/lib/store";

/** The store's loyalty program (its saved one, else the default). Cached with the settings. */
export async function getLoyaltyProgram(storeId: StoreId): Promise<LoyaltyProgram> {
  const settings = await getSettings(storeId);
  return loyaltyProgramFromSetting(settings[SETTING_KEYS.loyaltyProgram]);
}

/** Validate and save a store's loyalty program. Returns what was stored (sorted). */
export async function saveLoyaltyProgram(storeId: StoreId, input: unknown): Promise<LoyaltyProgram> {
  const program = parseLoyaltyProgram(input);
  await setSetting(storeId, SETTING_KEYS.loyaltyProgram, JSON.stringify(program));
  return program;
}
