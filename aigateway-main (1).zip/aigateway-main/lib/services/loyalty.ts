import "server-only";
import { prisma } from "@/lib/prisma";
import { logActivity } from "@/lib/services/activity";
import { createNotification, NOTIFICATION_TYPES } from "@/lib/services/notifications";
import { formatCents } from "@/lib/money";
import { firstRewardTier, getTierForPoints, pointsForPurchase } from "@/lib/loyalty";
import { getLoyaltyProgram } from "@/lib/services/loyalty-program";
import { credit } from "@/lib/billing/balance-service";
import { centsToMicro } from "@/lib/billing/money";
import type { StoreId } from "@/lib/store";

/**
 * Award loyalty points for a completed purchase (self-activation or approved
 * recharge). Also bumps the purchase counter and notifies the admin when a
 * level-up happens. Safe to call for any amount; zero/negative is a no-op.
 */
export async function awardLoyaltyPoints(customerId: string, purchaseCents: number) {
  const customerBefore = await prisma.customer.findUniqueOrThrow({
    where: { id: customerId },
    select: { id: true, storeId: true, accessCode: true, loyaltyPoints: true },
  });
  // The store's own program (admin → Loyalty → Program settings).
  const program = await getLoyaltyProgram(customerBefore.storeId as StoreId);
  const earned = pointsForPurchase(purchaseCents, program);
  if (earned.totalPoints <= 0) return null;
  const tierBefore = getTierForPoints(customerBefore.loyaltyPoints, program.tiers);

  const customerAfter = await prisma.customer.update({
    where: { id: customerId },
    data: {
      loyaltyPoints: { increment: earned.totalPoints },
      purchaseCount: { increment: 1 },
    },
  });
  const tierAfter = getTierForPoints(customerAfter.loyaltyPoints, program.tiers);

  await logActivity({
    storeId: customerAfter.storeId as StoreId,
    action: "LOYALTY_POINTS_AWARDED",
    description: `Customer ${customerAfter.accessCode} earned ${earned.totalPoints} pts ($${(purchaseCents / 100).toFixed(0)} purchase) — total ${customerAfter.loyaltyPoints} pts`,
    customerId,
  });

  // Level-up notification so admins see progression in the bell.
  if (tierAfter.id !== tierBefore.id) {
    await createNotification({
      storeId: customerAfter.storeId as StoreId,
      type: NOTIFICATION_TYPES.LOYALTY_LEVEL_UP,
      title: "Customer Leveled Up",
      message: `Customer ${customerAfter.accessCode} reached ${tierAfter.name} (${customerAfter.loyaltyPoints} pts)`,
      customerId,
      relatedId: customerId,
    });
  }

  return { earned, customer: customerAfter };
}

/**
 * A customer whose current level carries a cash reward asks for it. Nothing
 * touches the balance here — an admin must approve it first.
 */
export async function requestReward(customerId: string) {
  const existing = await prisma.customer.findUniqueOrThrow({ where: { id: customerId } });
  if (existing.rewardRequestStatus === "PENDING") {
    return { ok: false, error: "Your reward request is already waiting for approval." };
  }
  if (existing.rewardRequestStatus === "APPROVED") {
    return { ok: false, error: "You already claimed your reward." };
  }

  const { tiers } = await getLoyaltyProgram(existing.storeId as StoreId);
  const tier = getTierForPoints(existing.loyaltyPoints, tiers);
  if (tier.rewardAmountCents <= 0) {
    const unlock = firstRewardTier(tiers);
    return {
      ok: false,
      error: unlock
        ? `Cash rewards unlock at ${unlock.name} (${unlock.minPoints} pts). You have ${existing.loyaltyPoints} pts.`
        : "The loyalty program has no cash rewards at the moment.",
    };
  }

  await prisma.customer.update({
    where: { id: customerId },
    data: { rewardRequestStatus: "PENDING", rewardRequestedAt: new Date() },
  });

  await createNotification({
    storeId: existing.storeId as StoreId,
    type: NOTIFICATION_TYPES.REWARD_REQUESTED,
    title: "Loyalty Reward Requested",
    message: `Customer ${existing.accessCode} requested their ${formatCents(tier.rewardAmountCents)} ${tier.name} reward`,
    customerId,
    relatedId: customerId,
  });

  return { ok: true };
}

/** Admin approves the pending level reward — only then does cash get credited. */
export async function approveReward(customerId: string, adminName: string) {
  const existing = await prisma.customer.findUniqueOrThrow({ where: { id: customerId } });
  if (existing.rewardRequestStatus !== "PENDING") {
    throw new Error("There is no pending reward request on this account.");
  }
  const { tiers } = await getLoyaltyProgram(existing.storeId as StoreId);
  const tier = getTierForPoints(existing.loyaltyPoints, tiers);
  if (tier.rewardAmountCents <= 0) {
    throw new Error(`${tier.name} has no cash reward in the current loyalty program — reject the request instead.`);
  }

  await prisma.$transaction(async (tx) => {
    const flipped = await tx.customer.updateMany({
      where: { id: customerId, rewardRequestStatus: "PENDING" },
      data: { rewardRequestStatus: "APPROVED", rewardApprovedAt: new Date() },
    });
    if (flipped.count === 0) throw new Error("This reward was just processed elsewhere.");
    await credit({
      customerId,
      pot: "BONUS",
      amountMicroUsd: centsToMicro(tier.rewardAmountCents),
      type: "LOYALTY_REWARD",
      idempotencyKey: `loyalty-reward:${customerId}:${tier.id}:${existing.rewardRequestedAt?.getTime() ?? "na"}`,
      ref: { type: "LoyaltyTier", id: tier.id },
      actor: { label: adminName },
      note: `${tier.name} level reward approved`,
      tx,
    });
  });

  await logActivity({
    storeId: existing.storeId as StoreId,
    action: "REWARD_APPROVED",
    description: `${adminName} approved the ${formatCents(tier.rewardAmountCents)} ${tier.name} reward of ${existing.accessCode}`,
    adminId: adminName,
    customerId,
  });

  return tier;
}

export async function rejectReward(customerId: string, adminName: string, reason: string) {
  const existing = await prisma.customer.findUniqueOrThrow({ where: { id: customerId } });
  if (existing.rewardRequestStatus !== "PENDING") {
    throw new Error("There is no pending reward request on this account.");
  }

  await prisma.customer.update({
    where: { id: customerId },
    data: { rewardRequestStatus: "REJECTED" },
  });

  await logActivity({
    storeId: existing.storeId as StoreId,
    action: "REWARD_REJECTED",
    description: `${adminName} rejected the reward request of ${existing.accessCode}: ${reason}`,
    adminId: adminName,
    customerId,
  });

  return true;
}
