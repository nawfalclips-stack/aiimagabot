import "server-only";
import { prisma } from "@/lib/prisma";
import { invalidateModelRegistry } from "@/lib/gateway/registry";
import { catalogSource, loadProviderCatalog, type CatalogEntry, type CatalogSource } from "@/lib/gateway/providers/catalog";

// Model price sync. A GatewayModel carries ONE price list (provider cost,
// µ$ per 1M tokens); it drives reservation holds, the prices customers see,
// and the fallback charge when a provider reports no cost of its own.
// Providers that publish a catalog (OpenRouter, DeepInfra) are the source of
// truth for it: the model's primary mapping — the enabled mapping tried first
// by dispatch — decides which catalog entry the model follows.

/** GatewayModel price columns filled from a catalog entry (used on import). */
export function catalogPriceFields(c: CatalogEntry) {
  return {
    inputPriceMicroPerMTok: c.inputMicroPerMTok,
    outputPriceMicroPerMTok: c.outputMicroPerMTok,
    cachedInputPriceMicroPerMTok: c.cachedInputMicroPerMTok,
    cacheWritePriceMicroPerMTok: c.cacheWriteMicroPerMTok,
    contextWindow: c.contextWindow,
    ...(c.maxOutputTokens ? { maxOutputTokens: c.maxOutputTokens } : {}),
  };
}

export interface PriceSnapshot {
  input: number;
  output: number;
  cachedInput: number | null;
  cacheWrite: number | null;
}

export interface PriceSyncRow {
  modelId: string;
  slug: string;
  displayName: string;
  providerName: string;
  source: CatalogSource;
  upstreamModelId: string;
  before: PriceSnapshot;
  /** Null when the upstream id is not (or no longer) in the provider's catalog. */
  after: PriceSnapshot | null;
  changed: boolean;
}

export interface PriceSyncReport {
  rows: PriceSyncRow[];
  changed: number;
  unchanged: number;
  missing: number;
  applied: boolean;
}

const same = (a: PriceSnapshot, b: PriceSnapshot) =>
  a.input === b.input && a.output === b.output && a.cachedInput === b.cachedInput && a.cacheWrite === b.cacheWrite;

/**
 * Compare every catalog-backed model with its provider's live list prices,
 * and write the new prices when `apply` is set. Models whose primary provider
 * publishes no catalog (e.g. a relay billed per request) are left alone.
 */
export async function syncModelPrices(opts: { apply: boolean }): Promise<PriceSyncReport> {
  const models = await prisma.gatewayModel.findMany({
    include: { providers: { where: { enabled: true }, include: { provider: true } } },
    orderBy: { slug: "asc" },
  });

  const catalogs = new Map<string, Promise<Map<string, CatalogEntry>>>();
  const catalogFor = (baseUrl: string) => {
    const key = catalogSource(baseUrl) ?? "";
    if (!catalogs.has(key)) catalogs.set(key, loadProviderCatalog(baseUrl, { fresh: true }));
    return catalogs.get(key)!;
  };

  const rows: PriceSyncRow[] = [];
  for (const m of models) {
    const primary = [...m.providers]
      .filter((pm) => pm.provider.enabled && catalogSource(pm.provider.baseUrl))
      .sort((a, b) => a.provider.priority - b.provider.priority || a.priority - b.priority)[0];
    if (!primary) continue;
    const source = catalogSource(primary.provider.baseUrl)!;
    const entry = (await catalogFor(primary.provider.baseUrl)).get(primary.upstreamModelId) ?? null;
    const before: PriceSnapshot = {
      input: m.inputPriceMicroPerMTok,
      output: m.outputPriceMicroPerMTok,
      cachedInput: m.cachedInputPriceMicroPerMTok,
      cacheWrite: m.cacheWritePriceMicroPerMTok,
    };
    const after: PriceSnapshot | null = entry
      ? { input: entry.inputMicroPerMTok, output: entry.outputMicroPerMTok, cachedInput: entry.cachedInputMicroPerMTok, cacheWrite: entry.cacheWriteMicroPerMTok }
      : null;
    rows.push({
      modelId: m.id,
      slug: m.slug,
      displayName: m.displayName,
      providerName: primary.provider.name,
      source,
      upstreamModelId: primary.upstreamModelId,
      before,
      after,
      changed: after !== null && !same(before, after),
    });
  }

  const toApply = rows.filter((r) => r.changed && r.after);
  if (opts.apply && toApply.length > 0) {
    await prisma.$transaction(
      toApply.map((r) =>
        prisma.gatewayModel.update({
          where: { id: r.modelId },
          data: {
            inputPriceMicroPerMTok: r.after!.input,
            outputPriceMicroPerMTok: r.after!.output,
            cachedInputPriceMicroPerMTok: r.after!.cachedInput,
            cacheWritePriceMicroPerMTok: r.after!.cacheWrite,
          },
        })
      )
    );
    await invalidateModelRegistry();
  }

  return {
    rows,
    changed: toApply.length,
    unchanged: rows.filter((r) => r.after && !r.changed).length,
    missing: rows.filter((r) => !r.after).length,
    applied: opts.apply,
  };
}
