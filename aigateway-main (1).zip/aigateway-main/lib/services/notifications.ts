import "server-only";
import { prisma } from "@/lib/prisma";

export const NOTIFICATION_TYPES = {
  REVIEW_CLAIMED: "REVIEW_CLAIMED",
  ACTIVATION_PENDING: "ACTIVATION_PENDING",
  RECHARGE_REQUESTED: "RECHARGE_REQUESTED",
  LOYALTY_LEVEL_UP: "LOYALTY_LEVEL_UP",
  REWARD_REQUESTED: "REWARD_REQUESTED",
  AFFILIATE_COMMISSION: "AFFILIATE_COMMISSION",
  AFFILIATE_MILESTONE_CLAIMED: "AFFILIATE_MILESTONE_CLAIMED",
  RESERVATIONS_SWEPT: "RESERVATIONS_SWEPT",
  PROVIDER_BREAKER_OPEN: "PROVIDER_BREAKER_OPEN",
  VOUCHER_LOW_STOCK: "VOUCHER_LOW_STOCK",
  VOUCHER_REVIEW: "VOUCHER_REVIEW",
  MODEL_PRICES_SYNCED: "MODEL_PRICES_SYNCED",
} as const;

export type NotificationType = typeof NOTIFICATION_TYPES[keyof typeof NOTIFICATION_TYPES];

interface CreateNotificationParams {
  storeId: string;
  type: NotificationType;
  title: string;
  message: string;
  customerId?: string;
  relatedId?: string;
}

/**
 * Create a new notification for admin
 */
export async function createNotification(params: CreateNotificationParams) {
  return prisma.notification.create({
    data: {
      storeId: params.storeId,
      type: params.type,
      title: params.title,
      message: params.message,
      customerId: params.customerId,
      relatedId: params.relatedId,
    },
  });
}

/**
 * Get unread notification count for a store
 */
export async function getUnreadNotificationCount(storeId: string): Promise<number> {
  return prisma.notification.count({
    where: {
      storeId,
      isRead: false,
    },
  });
}

/**
 * Get recent notifications for a store
 */
export async function getNotifications(storeId: string, limit = 20) {
  return prisma.notification.findMany({
    where: { storeId },
    orderBy: { createdAt: "desc" },
    take: limit,
  });
}

/**
 * Mark notification as read
 */
export async function markNotificationAsRead(notificationId: string) {
  return prisma.notification.update({
    where: { id: notificationId },
    data: { isRead: true },
  });
}

/**
 * Mark all notifications as read for a store
 */
export async function markAllNotificationsAsRead(storeId: string) {
  return prisma.notification.updateMany({
    where: { storeId, isRead: false },
    data: { isRead: true },
  });
}
