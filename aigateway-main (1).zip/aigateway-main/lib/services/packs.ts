import "server-only";
import type { Pack, Plan } from "@prisma/client";
import { prisma } from "@/lib/prisma";
import { centsToMicro } from "@/lib/billing/money";
import type { StoreId } from "@/lib/store";

/**
 * Packs (WS8): the thing sold on GamsGo. Each binds exactly one plan to the
 * balance/bonus it grants, so activations, recharges and vouchers never guess
 * a plan from a price again.
 */

export type PackWithPlan = Pack & { plan: Plan };

export async function listPacks(storeId: StoreId, opts: { includeInactive?: boolean } = {}): Promise<PackWithPlan[]> {
  return prisma.pack.findMany({
    where: { storeId, deletedAt: null, ...(opts.includeInactive ? {} : { active: true }) },
    include: { plan: true },
    orderBy: [{ sortOrder: "asc" }, { createdAt: "asc" }],
  });
}

export async function getPack(storeId: StoreId, packId: string): Promise<PackWithPlan | null> {
  return prisma.pack.findFirst({ where: { id: packId, storeId, deletedAt: null }, include: { plan: true } });
}

/** Plain shape for client components (BigInt → cents). */
export interface PackOption {
  id: string;
  name: string;
  planId: string;
  planName: string;
  /** Price of the pack's plan — what an order-ID approval sets the balance to. */
  planPriceCents: number;
  /** Profit recorded when this pack's plan is sold. */
  planProfitCents: number;
  balanceGrantCents: number;
  bonusGrantCents: number;
  listingPriceLabel: string;
  active: boolean;
}

export function toPackOption(p: PackWithPlan): PackOption {
  return {
    id: p.id,
    name: p.name,
    planId: p.planId,
    planName: p.plan.name,
    planPriceCents: p.plan.priceCents,
    planProfitCents: p.plan.profitCents,
    balanceGrantCents: Number(p.balanceGrantMicroUsd / 10_000n),
    bonusGrantCents: Number(p.bonusGrantMicroUsd / 10_000n),
    listingPriceLabel: p.listingPriceLabel,
    active: p.active,
  };
}

/**
 * The pack an approval dialog should pre-select for a purchase of
 * `amountCents`: the unique active pack whose balance grant equals it. Only a
 * suggestion — the admin always confirms (WS8: no assignment by price).
 */
export function suggestPack(packs: PackOption[], amountCents: number): PackOption | null {
  if (amountCents <= 0) return null;
  const matches = packs.filter((p) => p.active && (p.planPriceCents === amountCents || p.balanceGrantCents === amountCents));
  return matches.length === 1 ? matches[0] : null;
}

/** Same as suggestPack for server code working with Prisma rows. */
export async function suggestPackForAmount(storeId: StoreId, amountCents: number): Promise<PackWithPlan | null> {
  if (amountCents <= 0) return null;
  const matches = await prisma.pack.findMany({
    where: { storeId, deletedAt: null, active: true, balanceGrantMicroUsd: centsToMicro(amountCents) },
    include: { plan: true },
    take: 2,
  });
  return matches.length === 1 ? matches[0] : null;
}

/** What a customer picks from when activating or recharging (no internal plan limits). */
export interface PackChoice {
  id: string;
  name: string;
  /** Balance the purchase credits: the price of the pack's plan. */
  priceCents: number;
  /** Shop label shown next to the name, e.g. "$100 on GamsGo". */
  listingPriceLabel: string;
}

const toChoice = (p: PackWithPlan): PackChoice => ({
  id: p.id,
  name: p.name,
  priceCents: p.plan.priceCents,
  listingPriceLabel: p.listingPriceLabel,
});

/** Packs on sale in a store (active pack on an active plan), in display order. */
export async function listPackChoices(storeId: StoreId): Promise<PackChoice[]> {
  return (await listPacks(storeId)).filter((p) => p.plan.isActive).map(toChoice);
}

/** One pack a customer may pick, or null when it is unknown, inactive or from another store. */
export async function getPackChoice(storeId: StoreId, packId: string): Promise<PackChoice | null> {
  const pack = await getPack(storeId, packId);
  return pack && pack.active && pack.plan.isActive ? toChoice(pack) : null;
}
