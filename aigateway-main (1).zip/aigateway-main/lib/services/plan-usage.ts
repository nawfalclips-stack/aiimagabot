import "server-only";
import type { Plan } from "@prisma/client";
import { prisma } from "@/lib/prisma";
import { getSettings, getUsageCostMultiplier } from "@/lib/services/settings";
import { SETTING_KEYS } from "@/lib/constants";
import { planRate, type BillingRate } from "@/lib/plan-usage";
import { bonusConversion, rateFromMultiplier, SAME_RATE, type BonusConversion } from "@/lib/billing/pricing-engine";
import type { StoreId } from "@/lib/store";
import { createTtlCache, ttlFromEnv } from "@/lib/ttl-cache";

export interface CustomerBillingRate {
  rate: BillingRate;
  /** The plan the customer is billed on (their own or the store default), or null when the global multiplier applies. */
  plan: Plan | null;
  /** plan = their own plan; default = the store's default plan; global = the usage cost multiplier. */
  source: "plan" | "default" | "global";
  /** How the BONUS pot is billed relative to `rate` (the plan's bonus rate); 1/1 when it has none. */
  bonusConversion: BonusConversion;
}

/**
 * Default plan per store, cached per instance for PLANS_CACHE_TTL_MS (10 s):
 * every request from a customer without a plan needs it. Plan and
 * default-plan edits call invalidateDefaultPlanCache().
 */
const defaultPlanCache = createTtlCache<StoreId, Plan | null>(ttlFromEnv("PLANS_CACHE_TTL_MS", 10_000));

export function invalidateDefaultPlanCache(storeId?: StoreId): void {
  defaultPlanCache.invalidate(storeId);
}

/** The plan a store bills customers without one at, or null (setting unset, plan gone, inactive or misconfigured). */
export async function getDefaultPlan(storeId: StoreId): Promise<Plan | null> {
  return defaultPlanCache.get(storeId, async () => {
    const id = (await getSettings(storeId))[SETTING_KEYS.defaultPlanId];
    if (!id) return null;
    const plan = await prisma.plan.findFirst({ where: { id, storeId, isActive: true } });
    return plan && planRate(plan) ? plan : null;
  });
}

/**
 * The rate the gateway bills this customer at: their own active plan's, else
 * the store's default plan's, else the store multiplier. Pass `plan` when the
 * caller already holds the customer's plan (the gateway does, from
 * authentication) to save the lookup.
 *
 * USD plans: a $100 plan worth $2 of real usage bills ×50 — a request that
 * costs $0.50 upstream is charged $25.
 */
export async function getCustomerBillingRate(customerId: string, storeId: StoreId, plan?: Plan | null): Promise<CustomerBillingRate> {
  if (plan === undefined) {
    const customer = await prisma.customer.findUnique({ where: { id: customerId }, select: { plan: true } });
    plan = customer?.plan ?? null;
  }
  const fromPlan = plan && plan.isActive ? planRate(plan) : null;
  if (plan && fromPlan) return { rate: fromPlan, plan, source: "plan", bonusConversion: bonusConversion(plan) };
  const fallback = await getDefaultPlan(storeId);
  if (fallback) return { rate: planRate(fallback)!, plan: fallback, source: "default", bonusConversion: bonusConversion(fallback) };
  return { rate: rateFromMultiplier(await getUsageCostMultiplier(storeId)), plan: null, source: "global", bonusConversion: SAME_RATE };
}

export interface CustomerLimits {
  rpm: number;
  maxConcurrent: number;
  storeCeiling: number;
  source: "plan" | "store";
}

type PlanLimits = Pick<Plan, "rpm" | "maxConcurrent" | "isActive">;

/**
 * RPM and concurrency for a customer: their plan's values, else the store
 * defaults (WS3). `plan` may be passed by callers that already hold it.
 */
export async function getCustomerLimits(customerId: string, storeId: StoreId, plan?: PlanLimits | null): Promise<CustomerLimits> {
  const [customer, settings] = await Promise.all([
    plan === undefined
      ? prisma.customer.findUnique({ where: { id: customerId }, select: { plan: { select: { rpm: true, maxConcurrent: true, isActive: true } } } })
      : Promise.resolve({ plan }),
    getSettings(storeId),
  ]);
  const num = (v: string | undefined, fallback: number) => {
    const n = Number(v);
    return Number.isFinite(n) && n > 0 ? Math.floor(n) : fallback;
  };
  const defaultRpm = num(settings[SETTING_KEYS.gatewayDefaultRpm], 20);
  const defaultConc = num(settings[SETTING_KEYS.gatewayDefaultMaxConcurrent], 4);
  const storeCeiling = num(settings[SETTING_KEYS.gatewayStoreMaxConcurrent], 200);
  const own = customer?.plan && customer.plan.isActive ? customer.plan : null;
  // No plan of their own: the store's default plan's limits apply too.
  const active = own ?? (await getDefaultPlan(storeId));
  return {
    rpm: active?.rpm ?? defaultRpm,
    maxConcurrent: active?.maxConcurrent ?? defaultConc,
    storeCeiling,
    source: active && (active.rpm !== null || active.maxConcurrent !== null) ? "plan" : "store",
  };
}

/** Put the customer on a plan (or none). Returns the new plan. */
export async function assignPlan(customerId: string, planId: string | null): Promise<Plan | null> {
  const plan = planId ? await prisma.plan.findUnique({ where: { id: planId } }) : null;
  if (planId && !plan) throw new Error("Plan not found.");
  await prisma.customer.update({
    where: { id: customerId },
    data: { planId: plan?.id ?? null, planAssignedAt: plan ? new Date() : null },
  });
  return plan;
}

/** Tokens consumed through the gateway since the plan was assigned (for TOKENS plans). */
export async function tokensUsedOnPlan(customerId: string, since: Date | null): Promise<number> {
  const agg = await prisma.usageLog.aggregate({
    where: { customerId, gatewayTokenId: { not: null }, ...(since ? { happenedAt: { gte: since } } : {}) },
    _sum: { promptTokens: true, completionTokens: true },
  });
  return (agg._sum.promptTokens ?? 0) + (agg._sum.completionTokens ?? 0);
}
