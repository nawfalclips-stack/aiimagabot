import "server-only";
import { prisma } from "@/lib/prisma";
import { clawback, credit, type Actor, type Tx } from "@/lib/billing/balance-service";
import { centsToMicro } from "@/lib/billing/money";
import type { StoreId } from "@/lib/store";

// Plan profit (not sales). Each plan carries a fixed profit per purchase
// (Plan.profitCents). Every purchase of the plan — an approved activation, an
// approved recharge, or a voucher credited on the spot — records that amount
// in ProfitHistory (source PLAN), so the dashboard and analytics charts, which
// already sum ProfitHistory, include it without any change.
//
//   * The amount is snapshotted at purchase time: editing a plan's profit
//     later never rewrites history.
//   * One row per purchase: the idempotency key is built from the purchase
//     reference (activation, recharge request or voucher), so replays and
//     double clicks are no-ops.
//   * A voucher purchase always uses the voucher as its reference, whether it
//     was credited at once or approved from the review queue — it can never be
//     counted twice. A voucher clawback records the opposite amount.
//   * Customer.profitCents (the per-customer total shown in admin) moves in
//     the same transaction. Manual profit edits on a customer stay available
//     as adjustments (source MANUAL).

export type PurchaseRef =
  | { type: "Activation"; id: string } // customer id — an account is activated once
  | { type: "RechargeRequest"; id: string }
  | { type: "Voucher"; id: string };

const profitKey = (ref: PurchaseRef) => `plan-profit:${ref.type}:${ref.id}`;
const reversalKey = (ref: PurchaseRef) => `plan-profit-reversal:${ref.type}:${ref.id}`;

/** The purchase reference for an approval: the voucher when the purchase came from one. */
export function purchaseRef(fallback: PurchaseRef, voucherId?: string | null): PurchaseRef {
  return voucherId ? { type: "Voucher", id: voucherId } : fallback;
}

/**
 * Record the plan's profit for one purchase, inside the caller's transaction.
 * Returns the cents recorded (0 when the plan has no profit or this purchase
 * was already recorded).
 */
export async function recordPlanProfit(
  tx: Tx,
  p: { customerId: string; plan: { id: string; name: string; profitCents: number }; ref: PurchaseRef }
): Promise<number> {
  const amount = Math.round(p.plan.profitCents);
  if (amount <= 0) return 0;
  const key = profitKey(p.ref);
  if (await tx.profitHistory.findUnique({ where: { idempotencyKey: key }, select: { id: true } })) return 0;
  await tx.profitHistory.create({
    data: {
      customerId: p.customerId,
      amountCents: amount,
      note: `${p.plan.name} plan purchase (${p.ref.type === "RechargeRequest" ? "recharge" : p.ref.type === "Activation" ? "activation" : "voucher"})`,
      source: "PLAN",
      planId: p.plan.id,
      idempotencyKey: key,
    },
  });
  await tx.customer.update({ where: { id: p.customerId }, data: { profitCents: { increment: amount } } });
  return amount;
}

/**
 * Undo the profit recorded for a purchase (voucher clawback), inside the
 * caller's transaction. Reverses exactly what was recorded; idempotent.
 */
export async function reversePlanProfit(tx: Tx, p: { ref: PurchaseRef; reason: string }): Promise<number> {
  const original = await tx.profitHistory.findUnique({ where: { idempotencyKey: profitKey(p.ref) } });
  if (!original || original.amountCents <= 0) return 0;
  const key = reversalKey(p.ref);
  if (await tx.profitHistory.findUnique({ where: { idempotencyKey: key }, select: { id: true } })) return 0;
  await tx.profitHistory.create({
    data: {
      customerId: original.customerId,
      amountCents: -original.amountCents,
      note: `Profit reversed: ${p.reason}`.slice(0, 500),
      source: "PLAN",
      planId: original.planId,
      idempotencyKey: key,
    },
  });
  await tx.customer.update({ where: { id: original.customerId }, data: { profitCents: { decrement: original.amountCents } } });
  return original.amountCents;
}

// Plan bonus: Plan.bonusCents is credited to the BONUS pot on every purchase
// of the plan, keyed by the same purchase reference as the profit, so a
// purchase is credited once whichever path approves it. Editing the plan's
// bonus later only affects future purchases.

const bonusKey = (ref: PurchaseRef) => `plan-bonus:${ref.type}:${ref.id}`;

/**
 * Credit the plan's bonus for one purchase, inside the caller's transaction.
 * Returns the cents credited (0 when the plan has no bonus or this purchase was already credited).
 */
export async function creditPlanBonus(
  tx: Tx,
  p: { customerId: string; plan: { name: string; bonusCents: number }; ref: PurchaseRef; actor: Actor }
): Promise<number> {
  const amount = Math.round(p.plan.bonusCents);
  if (amount <= 0) return 0;
  const r = await credit({
    customerId: p.customerId,
    pot: "BONUS",
    amountMicroUsd: centsToMicro(amount),
    type: "PLAN_BONUS",
    idempotencyKey: bonusKey(p.ref),
    ref: { type: p.ref.type, id: p.ref.id },
    actor: p.actor,
    note: `${p.plan.name} plan bonus`,
    tx,
  });
  return r.replayed ? 0 : amount;
}

/**
 * Take back the plan bonus credited for a purchase (voucher clawback), inside
 * the caller's transaction; never below zero. Returns the µ$ taken back.
 */
export async function reversePlanBonus(tx: Tx, p: { customerId: string; ref: PurchaseRef; actor: Actor; reason: string }): Promise<bigint> {
  const original = await tx.ledgerEntry.findUnique({ where: { idempotencyKey: bonusKey(p.ref) }, select: { amountMicroUsd: true } });
  if (!original || original.amountMicroUsd <= 0n) return 0n;
  const r = await clawback({
    customerId: p.customerId,
    pot: "BONUS",
    amountMicroUsd: original.amountMicroUsd,
    idempotencyKey: `plan-bonus-clawback:${p.ref.type}:${p.ref.id}`,
    ref: { type: p.ref.type, id: p.ref.id },
    actor: p.actor,
    note: `Plan bonus clawed back: ${p.reason}`.slice(0, 500),
    tx,
  });
  return r.appliedMicroUsd < 0n ? -r.appliedMicroUsd : r.appliedMicroUsd;
}

export interface PlanProfitTotal {
  /** Net plan profit recorded (reversals included), cents. */
  profitCents: number;
  /** Purchases that recorded a profit (reversals not counted). */
  purchases: number;
}

/** Plan profit recorded so far, per plan, for one store (deleted customers excluded). */
export async function profitByPlan(storeId: StoreId): Promise<Map<string, PlanProfitTotal>> {
  const where = { source: "PLAN", planId: { not: null }, customer: { storeId, deletedAt: null } } as const;
  const [sums, counts] = await Promise.all([
    prisma.profitHistory.groupBy({ by: ["planId"], where, _sum: { amountCents: true } }),
    prisma.profitHistory.groupBy({ by: ["planId"], where: { ...where, amountCents: { gt: 0 } }, _count: { _all: true } }),
  ]);
  const out = new Map<string, PlanProfitTotal>();
  for (const s of sums) out.set(s.planId!, { profitCents: s._sum.amountCents ?? 0, purchases: 0 });
  for (const c of counts) {
    const row = out.get(c.planId!) ?? { profitCents: 0, purchases: 0 };
    row.purchases = c._count._all;
    out.set(c.planId!, row);
  }
  return out;
}
