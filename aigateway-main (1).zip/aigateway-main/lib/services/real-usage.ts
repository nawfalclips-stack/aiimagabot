import "server-only";
import { prisma } from "@/lib/prisma";
import type { StoreId } from "@/lib/store";
import { EMPTY_REAL_USAGE, type RealUsage } from "@/lib/real-usage";

/**
 * Real (provider-cost) usage per customer, from every usage row — gateway
 * requests and admin-pasted rows alike. One grouped query for the whole list.
 */
export async function getRealUsageByCustomer(storeId: StoreId, customerIds?: string[]): Promise<Record<string, RealUsage>> {
  const groups = await prisma.usageLog.groupBy({
    by: ["customerId"],
    where: { storeId, ...(customerIds ? { customerId: { in: customerIds } } : {}) },
    _count: { _all: true },
    _sum: { costMicroUsd: true, bonusCostMicroUsd: true, promptTokens: true, completionTokens: true, inputCachedTokens: true },
    _max: { happenedAt: true },
  });
  const out: Record<string, RealUsage> = {};
  for (const g of groups) {
    out[g.customerId] = {
      requests: g._count._all,
      costMicroUsd: g._sum.costMicroUsd ?? 0,
      bonusCostMicroUsd: g._sum.bonusCostMicroUsd ?? 0,
      inputTokens: g._sum.promptTokens ?? 0,
      outputTokens: g._sum.completionTokens ?? 0,
      cachedTokens: g._sum.inputCachedTokens ?? 0,
      lastUsedAt: g._max.happenedAt?.toISOString() ?? null,
    };
  }
  return out;
}

export async function getRealUsage(storeId: StoreId, customerId: string): Promise<RealUsage> {
  const map = await getRealUsageByCustomer(storeId, [customerId]);
  return map[customerId] ?? EMPTY_REAL_USAGE;
}
