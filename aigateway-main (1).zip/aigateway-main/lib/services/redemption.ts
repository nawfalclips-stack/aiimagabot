import "server-only";
import { prisma } from "@/lib/prisma";
import { logActivity } from "@/lib/services/activity";
import { getSignupAmounts, getLowBalanceThresholdCents } from "@/lib/services/settings";
import { computeStatus } from "@/lib/services/status";
import { generateAccessCode } from "@/lib/services/generators";
import { parseOfferTitle } from "@/lib/offer-parser";
import { awardLoyaltyPoints } from "@/lib/services/loyalty";
import { createNotification, NOTIFICATION_TYPES } from "@/lib/services/notifications";
import { formatCents } from "@/lib/money";
import type { StoreId } from "@/lib/store";
import { AFFILIATE } from "@/lib/affiliate";
import { credit } from "@/lib/billing/balance-service";
import { centsToMicro } from "@/lib/billing/money";
import { swapPoolKey } from "@/lib/services/legacy-pool";

/** One-time welcome bonus credited automatically to referred newcomers. */
const WELCOME_BONUS_CENTS = AFFILIATE.welcomeBonusCents;

export type RedemptionError = "ALREADY_USED";

export class RedemptionFailed extends Error {
  constructor(public reason: RedemptionError) {
    super(reason);
  }
}

export interface RedemptionResult {
  customerId: string;
  accessCode: string;
  balanceCents: number;
  pendingBonusCents: number;
}

/**
 * Self-service activation: the customer enters the Order ID and the Offer
 * Title from their store purchase. The balance is parsed out of the offer
 * title and credited immediately; the bonus in the title is held back until
 * the customer confirms they wrote a review. We generate an access code and
 * create the account automatically; the customer then creates a gateway token
 * on the API Access page. A legacy pool key is attached only when
 * LEGACY_API_POOL_MODE=active, and an empty pool never blocks activation (WS10).
 * Every Order ID can be redeemed once.
 */
export async function redeemOrder(
  orderId: string,
  offerTitle: string,
  storeId: StoreId,
  affiliateCode?: string,
  /** The pack the customer picked: its plan price is the balance (the admin still confirms the pack on approval). */
  pack?: { id: string; priceCents: number } | null
): Promise<RedemptionResult> {
  const existingOrder = await prisma.order.findUnique({ where: { orderNumber: orderId }, select: { id: true } });
  if (existingOrder) throw new RedemptionFailed("ALREADY_USED");

  // Resolve the inviter from the affiliate code typed in the activation form.
  let referredById: string | null = null;
  if (affiliateCode) {
    const referrer = await prisma.customer.findUnique({
      where: { affiliateCode: affiliateCode.trim().toUpperCase() },
      select: { id: true, deletedAt: true },
    });
    if (referrer && !referrer.deletedAt && referrer.id !== null) referredById = referrer.id;
  }

  const accessCode = await generateAccessCode();
  const parsed = parseOfferTitle(offerTitle);
  const defaults = await getSignupAmounts(storeId);
  // Balance comes from the offer title; fall back to the configured default
  // when the title carries no recognizable amount.
  const balanceCents = pack?.priceCents ?? parsed.balanceCents ?? defaults.balanceCents;
  // Review bonus: ALWAYS 10% of the purchased balance for new signups —
  // independent of what the offer title says. Credited only after the
  // customer confirms they wrote a review (see claimReviewBonus).
  const pendingBonusCents = Math.round(balanceCents * 0.10);
  const threshold = await getLowBalanceThresholdCents(storeId);
  const status = computeStatus(balanceCents, threshold, "ACTIVE");

  const customer = await prisma.$transaction(async (tx) => {
    const created = await tx.customer.create({
      data: {
        storeId,
        accessCode,
        status,
        notes: `Self-activated with order ${orderId}\nOffer: ${offerTitle}`,
        offerTitle,
        // The 10% review bonus is NOT credited yet — it lands in the bonus
        // balance only when the customer confirms they wrote a review.
        pendingBonusCents,
        // Everyone gets the review-bonus banner until they confirm the review.
        reviewBonusStatus: pendingBonusCents > 0 ? "OFFERED" : "NONE",
        referredById,
        // The pack the customer says they bought; pre-selected for the admin at approval.
        packId: pack?.id ?? null,
        order: { create: { orderNumber: orderId } },
      },
    });

    await swapPoolKey(tx, { customerId: created.id, storeId, orderId });

    // The purchased balance, through the ledger (ORDER_ACTIVATION, keyed by the order).
    await credit({
      customerId: created.id,
      pot: "BALANCE",
      amountMicroUsd: centsToMicro(balanceCents),
      type: "ORDER_ACTIVATION",
      idempotencyKey: `order:${orderId}:BALANCE`,
      ref: { type: "Order", id: orderId },
      actor: { label: "Store activation" },
      note: `Order ${orderId}: ${offerTitle}`,
      history: "none",
      tx,
    });

    // Welcome gift for referred newcomers — credited immediately, no review needed.
    if (referredById) {
      await credit({
        customerId: created.id,
        pot: "BONUS",
        amountMicroUsd: centsToMicro(WELCOME_BONUS_CENTS),
        type: "AFFILIATE_REWARD",
        idempotencyKey: `welcome:${created.id}`,
        ref: { type: "Customer", id: referredById },
        actor: { label: "Affiliate program" },
        note: "Welcome gift — invited by a friend ($5)",
        tx,
      });
    }

    return tx.customer.findUniqueOrThrow({ where: { id: created.id } });
  });

  await logActivity({
    storeId,
    action: "CUSTOMER_CREATED",
    description: `Customer ${accessCode} self-activated with order ${orderId} — "${offerTitle}" (balance ${(balanceCents / 100).toFixed(2)} USD${pendingBonusCents > 0 ? `, review bonus ${(pendingBonusCents / 100).toFixed(2)} USD pending` : ""})`,
    customerId: customer.id,
  });

  // Create notification for admin about new pending activation
  await createNotification({
    storeId,
    type: NOTIFICATION_TYPES.ACTIVATION_PENDING,
    title: "New Activation Pending",
    message: `Customer ${accessCode} activated with ${formatCents(balanceCents)} balance`,
    customerId: customer.id,
    relatedId: customer.id,
  });

  // Loyalty: first purchase earns points (25 pts base for offers under $100).
  await awardLoyaltyPoints(customer.id, balanceCents);

  return { customerId: customer.id, accessCode, balanceCents, pendingBonusCents };
}
