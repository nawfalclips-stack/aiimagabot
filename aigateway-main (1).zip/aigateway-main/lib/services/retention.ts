import "server-only";
import { prisma } from "@/lib/prisma";

// Data retention. Every gateway request writes a GatewayReservation and a
// UsageLog (with the provider's raw usage object); nothing removed them, so
// the database grew by ~1.5–2 KB per request forever.
//
//   GatewayReservation  finished rows (SETTLED / RELEASED / EXPIRED) older
//                       than RETENTION_RESERVATION_DAYS (30) are deleted —
//                       they only matter while a request is in flight. HELD
//                       rows are never touched (the sweeper owns them).
//   UsageLog.rawUsage   emptied after RETENTION_RAW_USAGE_DAYS (90); tokens,
//                       costs and every other column stay, so history,
//                       statistics and refunds are unaffected.
//   LedgerEntry         NEVER deleted: balances are rebuilt from it
//                       (verifyCustomerLedger) and it is the money record.
//
// Work is done in batches of BATCH rows so no statement holds locks for long,
// with a per-run cap; a backlog is simply finished by the next daily run.

const BATCH = 2_000;
const MAX_BATCHES_PER_TABLE = 50; // ≤ 100 000 rows per table per run
const DAY_MS = 24 * 60 * 60 * 1000;
const FINISHED_RESERVATION_STATUSES = ["SETTLED", "RELEASED", "EXPIRED"];

function daysFromEnv(name: string, fallback: number): number {
  const n = Number(process.env[name]);
  return Number.isInteger(n) && n >= 1 ? n : fallback;
}

export interface RetentionPolicy {
  reservationDays: number;
  rawUsageDays: number;
}

export function retentionPolicy(): RetentionPolicy {
  return {
    reservationDays: daysFromEnv("RETENTION_RESERVATION_DAYS", 30),
    rawUsageDays: daysFromEnv("RETENTION_RAW_USAGE_DAYS", 90),
  };
}

/** Cut-off dates for a run at `now`: rows strictly older are eligible. */
export function retentionCutoffs(now: Date, policy: RetentionPolicy = retentionPolicy()): { reservationsBefore: Date; rawUsageBefore: Date } {
  return {
    reservationsBefore: new Date(now.getTime() - policy.reservationDays * DAY_MS),
    rawUsageBefore: new Date(now.getTime() - policy.rawUsageDays * DAY_MS),
  };
}

export interface RetentionReport {
  dryRun: boolean;
  reservationsBefore: string;
  rawUsageBefore: string;
  /** Deleted (or, in a dry run, eligible) finished reservations. */
  reservationsDeleted: number;
  /** UsageLog rows whose rawUsage was emptied (or would be). */
  rawUsageCleared: number;
  /** True when a table hit the per-run cap: the next run continues. */
  capped: boolean;
}

/** Apply the retention policy. `dryRun` only counts what would change. */
export async function runRetention(opts: { now?: Date; dryRun?: boolean } = {}): Promise<RetentionReport> {
  const now = opts.now ?? new Date();
  const dryRun = opts.dryRun ?? false;
  const { reservationsBefore, rawUsageBefore } = retentionCutoffs(now);

  const reservationWhere = { status: { in: FINISHED_RESERVATION_STATUSES }, createdAt: { lt: reservationsBefore } };
  const rawUsageWhere = { happenedAt: { lt: rawUsageBefore }, rawUsage: { not: "" } };

  if (dryRun) {
    const [reservations, rawUsage] = await Promise.all([
      prisma.gatewayReservation.count({ where: reservationWhere }),
      prisma.usageLog.count({ where: rawUsageWhere }),
    ]);
    return {
      dryRun,
      reservationsBefore: reservationsBefore.toISOString(),
      rawUsageBefore: rawUsageBefore.toISOString(),
      reservationsDeleted: reservations,
      rawUsageCleared: rawUsage,
      capped: false,
    };
  }

  let reservationsDeleted = 0;
  let rawUsageCleared = 0;
  let capped = false;

  for (let i = 0; ; i++) {
    if (i === MAX_BATCHES_PER_TABLE) {
      capped = true;
      break;
    }
    const ids = (await prisma.gatewayReservation.findMany({ where: reservationWhere, select: { id: true }, take: BATCH })).map((r) => r.id);
    if (ids.length === 0) break;
    // Re-check the status in the delete itself: never remove a row that is (or became) HELD.
    const r = await prisma.gatewayReservation.deleteMany({ where: { id: { in: ids }, status: { in: FINISHED_RESERVATION_STATUSES } } });
    reservationsDeleted += r.count;
    if (ids.length < BATCH) break;
  }

  for (let i = 0; ; i++) {
    if (i === MAX_BATCHES_PER_TABLE) {
      capped = true;
      break;
    }
    const ids = (await prisma.usageLog.findMany({ where: rawUsageWhere, select: { id: true }, take: BATCH })).map((r) => r.id);
    if (ids.length === 0) break;
    const r = await prisma.usageLog.updateMany({ where: { id: { in: ids } }, data: { rawUsage: "" } });
    rawUsageCleared += r.count;
    if (ids.length < BATCH) break;
  }

  return {
    dryRun,
    reservationsBefore: reservationsBefore.toISOString(),
    rawUsageBefore: rawUsageBefore.toISOString(),
    reservationsDeleted,
    rawUsageCleared,
    capped,
  };
}
