import "server-only";
import { prisma } from "@/lib/prisma";
import { logActivity } from "@/lib/services/activity";
import { createNotification, NOTIFICATION_TYPES } from "@/lib/services/notifications";
import { formatCents } from "@/lib/money";
import { clawback, credit } from "@/lib/billing/balance-service";
import { centsToMicro } from "@/lib/billing/money";
import type { StoreId } from "@/lib/store";

/**
 * The customer confirms they wrote a review — credit the pending 10%/15%
 * review bonus into their bonus balance and flag the account for the
 * administrator to verify on the store.
 *
 * THIS is where the bonus money actually moves: nothing is credited before
 * this confirmation.
 */
export async function claimReviewBonus(customerId: string) {
  const credited = await prisma.$transaction(async (tx) => {
    const existing = await tx.customer.findUniqueOrThrow({ where: { id: customerId } });
    if (existing.reviewBonusStatus === "NONE") {
      throw new Error("No review bonus applies to this account.");
    }
    if (existing.reviewBonusStatus !== "OFFERED") {
      return null; // already CLAIMED/VERIFIED/REVOKED — idempotent no-op
    }

    const amount = existing.pendingBonusCents;

    await tx.customer.update({
      where: { id: customerId },
      data: { reviewBonusStatus: "CLAIMED", reviewClaimedAt: new Date() },
    });

    let remaining = existing.initialBonusCents - existing.usedBonusCents;
    if (amount > 0) {
      const r = await credit({
        customerId,
        pot: "BONUS",
        amountMicroUsd: centsToMicro(amount),
        type: "REVIEW_BONUS",
        // One review bonus per offer: keyed by the claim moment's pending amount and offer.
        idempotencyKey: `review-bonus:${customerId}:${existing.offerTitle}:${amount}:${existing.reviewClaimedAt?.getTime() ?? "first"}`,
        actor: { label: "System" },
        note: `Review bonus ${formatCents(amount)} credited — thank you for your review!`,
        tx,
      });
      remaining = r.customer.initialBonusCents - r.customer.usedBonusCents;
    }

    return { amount, remaining };
  });

  // Already claimed earlier — nothing to do.
  if (!credited) {
    const existing = await prisma.customer.findUniqueOrThrow({ where: { id: customerId } });
    return existing;
  }

  const full = await prisma.customer.findUniqueOrThrow({ where: { id: customerId } });

  await logActivity({
    storeId: full.storeId as StoreId,
    action: "REVIEW_BONUS_CLAIMED",
    description: `Customer ${full.accessCode} attests they wrote a review — ${formatCents(credited.amount)} bonus CREDITED. Verify it on the store.`,
    customerId,
  });

  await createNotification({
    storeId: full.storeId as StoreId,
    type: NOTIFICATION_TYPES.REVIEW_CLAIMED,
    title: "Review Bonus Claimed",
    message: `Customer ${full.accessCode} confirmed their review — ${formatCents(credited.amount)} was credited automatically. Verify or revoke.`,
    customerId,
    relatedId: customerId,
  });

  return full;
}

/** Admin checked the store and the review exists — keep the bonus. */
export async function verifyReviewBonus(customerId: string, adminId: string, adminName: string) {
  const existing = await prisma.customer.findUniqueOrThrow({ where: { id: customerId } });
  if (existing.reviewBonusStatus !== "CLAIMED") {
    throw new Error("This bonus is not waiting for verification.");
  }

  const customer = await prisma.customer.update({
    where: { id: customerId },
    data: { reviewBonusStatus: "VERIFIED" },
  });

  await logActivity({
    storeId: existing.storeId as StoreId,
    action: "REVIEW_BONUS_VERIFIED",
    description: `${adminName} verified the review of ${customer.accessCode} — bonus kept`,
    adminId,
    customerId,
  });

  return customer;
}

/**
 * Admin checked the store and found no review — remove the bonus that was
 * credited at claim time. The customer sees why on their dashboard.
 */
export async function revokeReviewBonus(customerId: string, adminId: string, adminName: string) {
  const { customer, amount } = await prisma.$transaction(async (tx) => {
    const existing = await tx.customer.findUniqueOrThrow({ where: { id: customerId } });
    if (
      existing.reviewBonusStatus !== "OFFERED" &&
      existing.reviewBonusStatus !== "CLAIMED" &&
      existing.reviewBonusStatus !== "VERIFIED"
    ) {
      throw new Error("There is no credited review bonus to remove.");
    }

    const amount = existing.pendingBonusCents;

    await tx.customer.update({
      where: { id: customerId },
      data: { reviewBonusStatus: "REVOKED" },
    });

    // Only money that was actually credited (CLAIMED/VERIFIED) can be taken back;
    // an OFFERED bonus was never in the pot. Never below zero.
    if (amount > 0 && existing.reviewBonusStatus !== "OFFERED") {
      await clawback({
        customerId,
        pot: "BONUS",
        amountMicroUsd: centsToMicro(amount),
        idempotencyKey: `review-bonus-revoke:${customerId}:${existing.reviewClaimedAt?.getTime() ?? Date.now()}`,
        actor: { adminId, label: adminName },
        note: "Review bonus removed — review not found",
        tx,
      });
    }

    const customer = await tx.customer.findUniqueOrThrow({ where: { id: customerId } });
    return { customer, amount };
  });

  await logActivity({
    storeId: customer.storeId as StoreId,
    action: "REVIEW_BONUS_REVOKED",
    description: `${adminName} removed the ${(amount / 100).toFixed(2)} USD review bonus from ${customer.accessCode} — no review found`,
    adminId,
    customerId,
  });

  return customer;
}
