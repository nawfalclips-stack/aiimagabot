import "server-only";
import { cache } from "react";
import { prisma } from "@/lib/prisma";
import { DEFAULT_SETTINGS, SETTING_KEYS } from "@/lib/constants";
import type { StoreId } from "@/lib/store";
import { createTtlCache, ttlFromEnv } from "@/lib/ttl-cache";

/**
 * Settings change rarely but are read several times per gateway request
 * (hold margin, limits, charge policy, default plan). A 10 s per-instance
 * cache (SETTINGS_CACHE_TTL_MS) keeps them off the hot path; setSetting()
 * clears this instance at once, other instances follow within the TTL.
 */
const settingsCache = createTtlCache<StoreId, Record<string, string>>(ttlFromEnv("SETTINGS_CACHE_TTL_MS", 10_000));

async function loadSettings(storeId: StoreId): Promise<Record<string, string>> {
  const rows = await prisma.setting.findMany({
    where: { storeId },
  });
  const result: Record<string, string> = { ...DEFAULT_SETTINGS };
  for (const row of rows) result[row.key] = row.value;
  return result;
}

/** All settings as a key/value record, with defaults filled in. Cached per request and for a few seconds per instance. */
export const getSettings = cache(async (storeId: StoreId): Promise<Record<string, string>> => {
  // A copy, so a caller mutating the record can never poison the shared cache.
  return { ...(await settingsCache.get(storeId, () => loadSettings(storeId))) };
});

/** Drop cached settings (all stores when omitted). */
export function invalidateSettingsCache(storeId?: StoreId): void {
  settingsCache.invalidate(storeId);
}

export async function getLowBalanceThresholdCents(storeId: StoreId): Promise<number> {
  const settings = await getSettings(storeId);
  const parsed = parseInt(settings[SETTING_KEYS.lowBalanceThresholdCents], 10);
  return Number.isFinite(parsed) && parsed >= 0 ? parsed : 1000;
}

export async function getUsageCostMultiplier(storeId: StoreId): Promise<number> {
  const settings = await getSettings(storeId);
  const parsed = parseFloat(settings[SETTING_KEYS.usageCostMultiplier]);
  return Number.isFinite(parsed) && parsed > 0 ? parsed : 2.2;
}

export async function getSignupAmounts(storeId: StoreId): Promise<{ balanceCents: number; bonusCents: number }> {
  const settings = await getSettings(storeId);
  const balance = parseInt(settings[SETTING_KEYS.signupBalanceCents], 10);
  const bonus = parseInt(settings[SETTING_KEYS.signupBonusCents], 10);
  return {
    balanceCents: Number.isFinite(balance) && balance >= 0 ? balance : 30000,
    bonusCents: Number.isFinite(bonus) && bonus >= 0 ? bonus : 0,
  };
}

export async function getStoreUrl(storeId: StoreId): Promise<string> {
  const settings = await getSettings(storeId);
  return settings[SETTING_KEYS.storeUrl];
}

export async function setSetting(storeId: StoreId, key: string, value: string): Promise<void> {
  await prisma.setting.upsert({
    where: {
      storeId_key: {
        storeId,
        key,
      },
    },
    update: { value },
    create: { storeId, key, value },
  });
  settingsCache.invalidate(storeId);
}
