import type { CustomerStatus } from "@/lib/constants";

/**
 * Automatic status detection.
 *
 * SUSPENDED and EXPIRED are manual states set by the administrator and are
 * preserved; everything else is derived from what the customer can still spend:
 *   balance = 0 and bonus = 0      → BALANCE_FINISHED
 *   balance = 0 but bonus left     → LOW_BALANCE   (bonus is real, spendable credit)
 *   balance <= threshold           → LOW_BALANCE
 *   otherwise                      → ACTIVE
 */
export function computeStatus(
  remainingBalanceCents: number,
  thresholdCents: number,
  currentStatus: string,
  remainingBonusCents = 0
): CustomerStatus {
  if (currentStatus === "SUSPENDED" || currentStatus === "EXPIRED") {
    return currentStatus;
  }
  if (remainingBalanceCents <= 0) return remainingBonusCents > 0 ? "LOW_BALANCE" : "BALANCE_FINISHED";
  if (remainingBalanceCents <= thresholdCents) return "LOW_BALANCE";
  return "ACTIVE";
}

export function remainingBalanceCents(c: { initialBalanceCents: number; usedBalanceCents: number }): number {
  return c.initialBalanceCents - c.usedBalanceCents;
}

export function remainingBonusCents(c: { initialBonusCents: number; usedBonusCents: number }): number {
  return c.initialBonusCents - c.usedBonusCents;
}
