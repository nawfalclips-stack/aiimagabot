import "server-only";
import { prisma } from "@/lib/prisma";
import { logActivity } from "@/lib/services/activity";
import { getSettings } from "@/lib/services/settings";
import { SETTING_KEYS } from "@/lib/constants";
import type { TicketType } from "@/lib/constants";
import type { StoreId } from "@/lib/store";
import { poolAssignmentsEnabled, swapPoolKey } from "@/lib/services/legacy-pool";

// ─── Bot message templates ────────────────────────────────────────────────────

function botMessages(storeUrl: string) {
  return {
    API_ISSUE_FIXED:
      `🎉 Your API key has been automatically replaced! Your new key is now active on your dashboard.\n\nNeed further help? Contact us through our store:\n${storeUrl}`,
    API_ISSUE_REPEAT:
      `⚠️ A replacement key was already assigned to your account recently. For additional support, please contact us through our store — we'll assist you within 48 hours:\n${storeUrl}`,
    API_ISSUE_NO_KEYS:
      `⚠️ We received your API issue report. Our team is working on it. For faster support, contact us through our store:\n${storeUrl}`,
    API_ISSUE_GATEWAY:
      `✅ We received your API issue report. Quick checks while we look into it: open the API Access page, make sure your tool uses your AeroLink token and the base URL shown there, and that your balance is above zero. If a token may have leaked, revoke it and create a new one.\n\nFor faster support, contact us through our store:\n${storeUrl}`,
    GENERAL_OPEN:
      `✅ We received your request. Please contact us through our store for direct support — max response time is 48 hours (usually much faster):\n${storeUrl}`,
  };
}

// Static messages used by runAutoFix (no settings fetch needed there).
const AUTOFIX_FIXED_MSG =
  "🎉 Your API key has been automatically replaced! Your new key is now active on your dashboard.";
const AUTOFIX_NO_KEYS_MSG =
  "⚠️ We could not fix this automatically. Our team will look into it as soon as possible.";

// ─── Service functions ────────────────────────────────────────────────────────

export async function createTicket(params: {
  customerId: string;
  type: TicketType;
  title: string;
  description: string;
  screenshotUrl?: string;
  storeId: StoreId;
}) {
  const settings = await getSettings(params.storeId);
  const msgs = botMessages(settings[SETTING_KEYS.storeUrl]);

  if (params.type === "API_ISSUE") {
    const [customer, previousFixes] = await Promise.all([
      prisma.customer.findUnique({
        where: { id: params.customerId },
        select: { accessCode: true, order: { select: { orderNumber: true } } },
      }),
      prisma.ticket.count({ where: { customerId: params.customerId, autoFixed: true } }),
    ]);
    const ticketData = {
      customerId: params.customerId,
      storeId: params.storeId,
      type: params.type,
      title: params.title,
      description: params.description,
      screenshotUrl: params.screenshotUrl ?? "",
    };

    // Legacy pool (WS10): swap the upstream key only while the pool is active,
    // only once per customer (later fixes go to manual review), and only from
    // the customer's own store.
    if (customer && previousFixes === 0 && poolAssignmentsEnabled()) {
      const fixed = await prisma.$transaction(async (tx) => {
        const key = await swapPoolKey(tx, {
          customerId: params.customerId,
          storeId: params.storeId,
          orderId: customer.order?.orderNumber ?? null,
        });
        if (!key) return null;
        const ticket = await tx.ticket.create({ data: { ...ticketData, status: "AUTO_RESOLVED", autoFixed: true } });
        await tx.ticketMessage.create({
          data: { ticketId: ticket.id, body: msgs.API_ISSUE_FIXED, fromAdmin: false, isBot: true },
        });
        return ticket;
      });
      if (fixed) {
        await logActivity({
          storeId: params.storeId,
          action: "API_KEY_CHANGED" as const,
          description: `Auto-fix replaced API key for ${customer.accessCode} on ticket creation: "${params.title}"`,
          customerId: params.customerId,
        });
        return fixed;
      }
    }

    const body = !poolAssignmentsEnabled()
      ? msgs.API_ISSUE_GATEWAY
      : previousFixes > 0
        ? msgs.API_ISSUE_REPEAT
        : msgs.API_ISSUE_NO_KEYS;
    const ticket = await prisma.ticket.create({ data: { ...ticketData, status: "OPEN" } });
    await prisma.ticketMessage.create({
      data: { ticketId: ticket.id, body, fromAdmin: false, isBot: true },
    });
    return ticket;
  }

  // All other ticket types.
  const ticket = await prisma.ticket.create({
    data: {
      customerId: params.customerId,
      storeId: params.storeId,
      type: params.type,
      title: params.title,
      description: params.description,
      screenshotUrl: params.screenshotUrl ?? "",
      status: "OPEN",
    },
  });
  await prisma.ticketMessage.create({
    data: { ticketId: ticket.id, body: msgs.GENERAL_OPEN, fromAdmin: false, isBot: true },
  });
  return ticket;
}

export async function replyToTicket(params: {
  ticketId: string;
  body: string;
  fromAdmin: boolean;
  isBot?: boolean;
}) {
  return prisma.ticketMessage.create({
    data: {
      ticketId: params.ticketId,
      body: params.body,
      fromAdmin: params.fromAdmin,
      isBot: params.isBot ?? false,
    },
  });
}

export async function closeTicket(ticketId: string, adminId: string, adminName: string, storeId: StoreId) {
  const ticket = await prisma.ticket.findUnique({
    where: { id: ticketId },
    include: { customer: { select: { accessCode: true, order: { select: { orderNumber: true } } } } },
  });
  if (!ticket) throw new Error("Ticket not found");

  const settings = await getSettings(storeId);
  const msgs = botMessages(settings[SETTING_KEYS.storeUrl]);

  let swapped = false;
  if (ticket.type === "API_ISSUE" && !ticket.autoFixed && poolAssignmentsEnabled()) {
    swapped = await prisma.$transaction(async (tx) => {
      const key = await swapPoolKey(tx, {
        customerId: ticket.customerId,
        storeId: ticket.storeId,
        orderId: ticket.customer.order?.orderNumber ?? null,
      });
      if (!key) return false;
      await tx.ticket.update({ where: { id: ticketId }, data: { status: "RESOLVED", autoFixed: true } });
      await tx.ticketMessage.create({
        data: { ticketId, body: msgs.API_ISSUE_FIXED, fromAdmin: false, isBot: true },
      });
      return true;
    });
  }
  if (!swapped) {
    await prisma.ticket.update({ where: { id: ticketId }, data: { status: "RESOLVED" } });
  }

  await logActivity({
    storeId,
    action: "STATUS_CHANGED" as const,
    description: `${adminName} resolved ticket for ${ticket.customer.accessCode}: "${ticket.title}"`,
    adminId,
    customerId: ticket.customerId,
  });
  return ticket;
}

/**
 * Fallback engine for any legacy AUTO_FIXING tickets.
 */
export async function runAutoFix(): Promise<{ fixed: number; skipped: number }> {
  const due = await prisma.ticket.findMany({
    where: { status: "AUTO_FIXING", autoFixAt: { lte: new Date() }, autoFixed: false },
    include: { customer: { select: { accessCode: true, order: { select: { orderNumber: true } } } } },
  });

  let fixed = 0;
  let skipped = 0;

  for (const ticket of due) {
    const swapped = await prisma.$transaction(async (tx) => {
      const key = await swapPoolKey(tx, {
        customerId: ticket.customerId,
        storeId: ticket.storeId,
        orderId: ticket.customer.order?.orderNumber ?? null,
      });
      if (!key) return false;
      await tx.ticket.update({ where: { id: ticket.id }, data: { status: "AUTO_RESOLVED", autoFixed: true } });
      await tx.ticketMessage.create({
        data: { ticketId: ticket.id, body: AUTOFIX_FIXED_MSG, fromAdmin: false, isBot: true },
      });
      return true;
    });

    if (!swapped) {
      await prisma.$transaction([
        prisma.ticket.update({ where: { id: ticket.id }, data: { status: "OPEN", autoFixAt: null } }),
        prisma.ticketMessage.create({
          data: { ticketId: ticket.id, body: AUTOFIX_NO_KEYS_MSG, fromAdmin: false, isBot: true },
        }),
      ]);
      skipped++;
      continue;
    }

    await logActivity({
      storeId: ticket.storeId as StoreId,
      action: "API_KEY_CHANGED" as const,
      description: `Auto-fix replaced API key for ${ticket.customer.accessCode} (ticket: ${ticket.title})`,
      customerId: ticket.customerId,
    });
    fixed++;
  }

  return { fixed, skipped };
}
