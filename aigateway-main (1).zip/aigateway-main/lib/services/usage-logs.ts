import "server-only";
import { prisma } from "@/lib/prisma";
import { logActivity } from "@/lib/services/activity";
import { getUsageCostMultiplier } from "@/lib/services/settings";
import { recordAdminUsage, refundBalance } from "@/lib/services/customers";
import { customerCostCents, type ParsedUsageRow } from "@/lib/usage-parser";
import { MANUAL_CHARGE_STATUS } from "@/lib/services/usage-quick";
import type { StoreId } from "@/lib/store";

/**
 * Store pasted usage rows for a customer and deduct the multiplied total cost
 * balance first, then bonus. Returns what was recorded.
 */
export async function addUsageLogs(
  customerId: string,
  rows: ParsedUsageRow[],
  adminId: string,
  adminName: string,
  storeId: StoreId,
  multiplierOverride?: number
): Promise<{ added: number; deductedCents: number; multiplier: number }> {
  if (rows.length === 0) throw new Error("No usage rows to add");

  const customer = await prisma.customer.findUniqueOrThrow({ where: { id: customerId } });
  const multiplier = multiplierOverride ?? await getUsageCostMultiplier(storeId);

  await prisma.usageLog.createMany({
    data: rows.map((row) => ({
      customerId,
      storeId,
      happenedAt: new Date(row.happenedAt),
      keyLabel: row.keyLabel,
      model: row.model,
      tokens: row.tokens,
      costMicroUsd: Math.round(row.costUsd * 1_000_000),
      latency: row.latency,
      status: row.status,
      addedBy: adminName,
    })),
  });

  const totalMicro = rows.reduce((sum, row) => sum + Math.round(row.costUsd * 1_000_000), 0);
  const totalCents = customerCostCents(totalMicro, multiplier);

  const requestsLabel = `${rows.length} ${rows.length === 1 ? "request" : "requests"}`;
  const split = await recordAdminUsage(customerId, totalCents, adminId, adminName, `API usage (${requestsLabel})`);

  await logActivity({
    storeId,
    action: "BALANCE_UPDATED",
    description: `${adminName} imported ${rows.length} usage logs for ${customer.accessCode} (deducted ${((split.balanceCents + split.bonusCents) / 100).toFixed(2)} USD: ${(split.balanceCents / 100).toFixed(2)} balance / ${(split.bonusCents / 100).toFixed(2)} bonus${split.uncollectedCents > 0 ? `; ${(split.uncollectedCents / 100).toFixed(2)} uncollected` : ""})`,
    adminId,
    customerId,
  });

  return { added: rows.length, deductedCents: split.balanceCents + split.bonusCents, multiplier };
}

/** Delete a usage row and refund its multiplied cost back to the balance. */
export async function deleteUsageLog(logId: string, adminId: string, adminName: string, storeId: StoreId) {
  const log = await prisma.usageLog.findUniqueOrThrow({ where: { id: logId }, include: { customer: true } });
  // Refund what was actually charged: gateway rows carry it, manual charges
  // were deducted at face value, pasted rows at the store multiplier.
  const refundCents =
    log.customerMicroUsd !== null
      ? Number(log.customerMicroUsd / 10_000n)
      : log.status === MANUAL_CHARGE_STATUS
        ? Math.round(log.costMicroUsd / 10_000)
        : customerCostCents(log.costMicroUsd, await getUsageCostMultiplier(storeId));

  await prisma.usageLog.delete({ where: { id: logId } });
  if (refundCents > 0) {
    await refundBalance(log.customerId, refundCents, adminId, adminName, "Usage log removed", { type: "UsageLog", id: logId });
  }

  await logActivity({
    storeId,
    action: "BALANCE_UPDATED",
    description: `${adminName} removed a usage log for ${log.customer.accessCode} (refunded ${(refundCents / 100).toFixed(2)} USD)`,
    adminId,
    customerId: log.customerId,
  });
}
