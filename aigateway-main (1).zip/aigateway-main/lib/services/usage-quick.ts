import "server-only";
import { prisma } from "@/lib/prisma";
import { logActivity } from "@/lib/services/activity";
import { recordAdminUsage } from "@/lib/services/customers";
import { formatCents } from "@/lib/money";
import type { StoreId } from "@/lib/store";

/** UsageLog.model / status for a charge entered by an admin (never a real request). */
export const MANUAL_CHARGE_MODEL = "Manual charge";
export const MANUAL_CHARGE_STATUS = "manual";

/**
 * Deduct usage from a customer's profile: the admin enters a total amount and
 * an optional note. WS7: this writes ONE honestly labelled row — no invented
 * per-model rows, latencies or statuses — and charges the exact amount through
 * the ledger. Customers see it in their balance history, not as API requests.
 */
export async function recordUsageFromAmount(
  customerId: string,
  note: string,
  totalCents: number,
  adminId: string,
  adminName: string,
  storeId: StoreId
): Promise<{ added: number; deductedCents: number }> {
  if (totalCents <= 0) throw new Error("Enter an amount greater than zero.");
  const label = note.trim().slice(0, 120);

  const customer = await prisma.customer.findUniqueOrThrow({ where: { id: customerId }, select: { accessCode: true } });
  await prisma.usageLog.create({
    data: {
      customerId,
      storeId,
      happenedAt: new Date(),
      keyLabel: label,
      model: MANUAL_CHARGE_MODEL,
      costMicroUsd: totalCents * 10_000,
      status: MANUAL_CHARGE_STATUS,
      addedBy: adminName,
    },
  });

  const split = await recordAdminUsage(customerId, totalCents, adminId, adminName, label ? `Manual usage charge: ${label}` : "Manual usage charge");

  await logActivity({
    storeId,
    action: "BALANCE_UPDATED",
    description: `${adminName} charged ${formatCents(totalCents)} manual usage to ${customer.accessCode}${label ? ` ("${label}")` : ""}. Deducted ${formatCents(split.balanceCents)} balance / ${formatCents(split.bonusCents)} bonus.`,
    adminId,
    customerId,
  });

  return { added: 1, deductedCents: totalCents };
}
