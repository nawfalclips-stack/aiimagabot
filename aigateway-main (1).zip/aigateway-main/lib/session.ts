import { SignJWT, jwtVerify } from "jose";
import { cookies } from "next/headers";

const ADMIN_COOKIE = "aerolink_admin_session";
const CUSTOMER_COOKIE = "aerolink_customer_session";

const ADMIN_MAX_AGE = 60 * 60 * 24 * 7; // 7 days
const CUSTOMER_MAX_AGE = 60 * 60 * 24 * 30; // 30 days

function getSecret(): Uint8Array {
  const secret = process.env.SESSION_SECRET;
  if (!secret || secret.length < 16) {
    throw new Error("SESSION_SECRET must be set to a long random string");
  }
  return new TextEncoder().encode(secret);
}

export type AdminSession = { adminId: string; kind: "admin"; /** issued-at, seconds (JWT `iat`) */ iat?: number };
export type CustomerSession = { customerId: string; kind: "customer" };

async function sign(payload: Record<string, string>, maxAgeSeconds: number): Promise<string> {
  return new SignJWT(payload)
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime(Math.floor(Date.now() / 1000) + maxAgeSeconds)
    .sign(getSecret());
}

export async function verifyToken<T>(token: string, kind: "admin" | "customer"): Promise<T | null> {
  try {
    const { payload } = await jwtVerify(token, getSecret());
    if (payload.kind !== kind) return null;
    return payload as T;
  } catch {
    return null;
  }
}

const cookieOptions = {
  httpOnly: true,
  secure: process.env.NODE_ENV === "production",
  sameSite: "lax" as const,
  path: "/",
};

export async function createAdminSession(adminId: string): Promise<void> {
  const token = await sign({ adminId, kind: "admin" }, ADMIN_MAX_AGE);
  (await cookies()).set(ADMIN_COOKIE, token, { ...cookieOptions, maxAge: ADMIN_MAX_AGE });
}

export async function createCustomerSession(customerId: string): Promise<void> {
  const token = await sign({ customerId, kind: "customer" }, CUSTOMER_MAX_AGE);
  (await cookies()).set(CUSTOMER_COOKIE, token, { ...cookieOptions, maxAge: CUSTOMER_MAX_AGE });
}

export async function getAdminSession(): Promise<AdminSession | null> {
  const token = (await cookies()).get(ADMIN_COOKIE)?.value;
  if (!token) return null;
  return verifyToken<AdminSession>(token, "admin");
}

export async function getCustomerSession(): Promise<CustomerSession | null> {
  const token = (await cookies()).get(CUSTOMER_COOKIE)?.value;
  if (!token) return null;
  return verifyToken<CustomerSession>(token, "customer");
}

export async function destroyAdminSession(): Promise<void> {
  (await cookies()).delete(ADMIN_COOKIE);
}

export async function destroyCustomerSession(): Promise<void> {
  (await cookies()).delete(CUSTOMER_COOKIE);
}

export const SESSION_COOKIES = { ADMIN_COOKIE, CUSTOMER_COOKIE };
