// Social / contact links the admin configures in Settings. Stored as one JSON
// setting per store; every footer renders them (and renders nothing when the
// list is empty). Client-safe: no server imports.

export interface SocialLink {
  label: string;
  url: string;
}

export type SocialKind =
  | "x"
  | "telegram"
  | "discord"
  | "whatsapp"
  | "instagram"
  | "youtube"
  | "facebook"
  | "tiktok"
  | "github"
  | "linkedin"
  | "email"
  | "website";

/** Quick-add buttons in the admin editor. */
export const SOCIAL_PRESETS: Array<{ kind: SocialKind; label: string; placeholder: string }> = [
  { kind: "x", label: "X", placeholder: "https://x.com/yourhandle" },
  { kind: "telegram", label: "Telegram", placeholder: "https://t.me/yourchannel" },
  { kind: "discord", label: "Discord", placeholder: "https://discord.gg/invite" },
  { kind: "whatsapp", label: "WhatsApp", placeholder: "https://wa.me/1234567890" },
  { kind: "instagram", label: "Instagram", placeholder: "https://instagram.com/yourhandle" },
  { kind: "youtube", label: "YouTube", placeholder: "https://youtube.com/@yourchannel" },
  { kind: "facebook", label: "Facebook", placeholder: "https://facebook.com/yourpage" },
  { kind: "tiktok", label: "TikTok", placeholder: "https://tiktok.com/@yourhandle" },
  { kind: "github", label: "GitHub", placeholder: "https://github.com/yourorg" },
  { kind: "linkedin", label: "LinkedIn", placeholder: "https://linkedin.com/company/yourorg" },
  { kind: "email", label: "Email", placeholder: "mailto:support@example.com" },
  { kind: "website", label: "Website", placeholder: "https://example.com" },
];

export const MAX_SOCIAL_LINKS = 12;

/** Which icon to draw — matched on the URL host first, then on the label. */
export function detectSocialKind(link: SocialLink): SocialKind {
  const url = link.url.trim().toLowerCase();
  const label = link.label.trim().toLowerCase();
  if (url.startsWith("mailto:") || label === "email" || label === "mail") return "email";
  let host = "";
  try {
    host = new URL(url).hostname.replace(/^www\./, "");
  } catch {
    host = "";
  }
  const hay = `${host} ${label}`;
  const rules: Array<[SocialKind, RegExp]> = [
    ["x", /(^|\s|\.)(x\.com|twitter\.com|twitter)(\s|$)|^x$|\sx$/],
    ["telegram", /t\.me|telegram/],
    ["discord", /discord/],
    ["whatsapp", /wa\.me|whatsapp/],
    ["instagram", /instagram/],
    ["youtube", /youtu\.?be/],
    ["facebook", /facebook|fb\.com|fb\.me/],
    ["tiktok", /tiktok/],
    ["github", /github/],
    ["linkedin", /linkedin/],
  ];
  for (const [kind, re] of rules) if (re.test(hay)) return kind;
  return "website";
}

function isSafeUrl(url: string): boolean {
  if (/^mailto:[^\s@]+@[^\s@]+$/i.test(url)) return true;
  try {
    const u = new URL(url);
    return u.protocol === "https:" || u.protocol === "http:";
  } catch {
    return false;
  }
}

/** Parse the stored JSON; malformed input or bad entries are dropped silently. */
export function parseSocialLinks(raw: string | null | undefined): SocialLink[] {
  if (!raw) return [];
  let data: unknown;
  try {
    data = JSON.parse(raw);
  } catch {
    return [];
  }
  if (!Array.isArray(data)) return [];
  const out: SocialLink[] = [];
  for (const item of data) {
    if (!item || typeof item !== "object") continue;
    const label = String((item as { label?: unknown }).label ?? "").trim().slice(0, 40);
    const url = String((item as { url?: unknown }).url ?? "").trim().slice(0, 500);
    if (!label || !isSafeUrl(url)) continue;
    out.push({ label, url });
    if (out.length >= MAX_SOCIAL_LINKS) break;
  }
  return out;
}

/** Validate a list from the admin form. Returns an error message or null. */
export function validateSocialLinks(links: SocialLink[]): string | null {
  if (links.length > MAX_SOCIAL_LINKS) return `At most ${MAX_SOCIAL_LINKS} links.`;
  for (const l of links) {
    if (!l.label.trim()) return "Every social link needs a label.";
    if (l.label.trim().length > 40) return "Social link labels must be 40 characters or fewer.";
    if (!isSafeUrl(l.url.trim())) return `"${l.label}" needs a valid http(s) or mailto: link.`;
  }
  return null;
}
