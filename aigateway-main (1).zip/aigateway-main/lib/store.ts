/**
 * Store utilities for multi-store support
 */

import { cookies } from 'next/headers';
import { prisma } from './prisma';

export const STORE_IDS = {
  AEROLINK: 'aerolink',
  CHEFAPI: 'chefapi',
} as const;

export type StoreId = typeof STORE_IDS[keyof typeof STORE_IDS];

/**
 * Get the current store ID from the URL path or cookie
 * - /chefapi/* routes → 'chefapi'
 * - All other routes → 'aerolink'
 */
export function getStoreIdFromPath(pathname: string): StoreId {
  if (pathname.startsWith('/chefapi')) {
    return STORE_IDS.CHEFAPI;
  }
  return STORE_IDS.AEROLINK;
}

/**
 * Get the current admin's selected store ID from cookie
 */
export async function getAdminStoreId(): Promise<StoreId> {
  const cookieStore = await cookies();
  const storeId = cookieStore.get('admin_store_id')?.value;

  if (storeId && (storeId === STORE_IDS.AEROLINK || storeId === STORE_IDS.CHEFAPI)) {
    return storeId as StoreId;
  }

  return STORE_IDS.AEROLINK;
}

/**
 * Set the admin's selected store ID in cookie
 */
export async function setAdminStoreId(storeId: StoreId) {
  const cookieStore = await cookies();
  cookieStore.set('admin_store_id', storeId, {
    httpOnly: true,
    secure: process.env.NODE_ENV === 'production',
    sameSite: 'lax',
    maxAge: 60 * 60 * 24 * 365, // 1 year
  });
}

/**
 * Get store data by ID
 */
export async function getStore(storeId: StoreId) {
  const store = await prisma.store.findUnique({
    where: { id: storeId },
  });

  if (!store) {
    throw new Error(`Store not found: ${storeId}`);
  }

  return store;
}

/**
 * Get all stores that an admin has access to
 */
export async function getAdminStores(adminId: string) {
  const access = await prisma.adminStoreAccess.findMany({
    where: { adminId },
    include: { store: true },
  });

  return access.map(a => a.store);
}

/**
 * Check if admin has access to a store
 */
export async function hasStoreAccess(adminId: string, storeId: StoreId): Promise<boolean> {
  const access = await prisma.adminStoreAccess.findUnique({
    where: {
      adminId_storeId: {
        adminId,
        storeId,
      },
    },
  });

  return !!access;
}

/**
 * Helper to add storeId filter to Prisma queries
 */
export function withStoreFilter<T extends object>(
  storeId: StoreId,
  where?: T
): T & { storeId: StoreId } {
  return { ...where, storeId } as T & { storeId: StoreId };
}

/**
 * Store for a public (unauthenticated) page: the request host's first label
 * (chefapi.example.com → chefapi), then the path prefix, else AeroLink. The
 * Store table has no domain column today, so the host rule is by id.
 */
export async function resolvePublicStoreId(): Promise<StoreId> {
  const { headers } = await import("next/headers");
  const h = await headers();
  const host = (h.get("x-forwarded-host") ?? h.get("host") ?? "").toLowerCase().split(":")[0];
  if (host.startsWith(`${STORE_IDS.CHEFAPI}.`)) return STORE_IDS.CHEFAPI;
  return getStoreIdFromPath(h.get("x-pathname") ?? "/");
}
