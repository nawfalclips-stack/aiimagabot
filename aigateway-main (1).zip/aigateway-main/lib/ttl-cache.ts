// Tiny per-instance cache with a time-to-live, for hot-path reads that change
// rarely (store settings, the default plan). Concurrent misses for the same key
// share one load. Writers on this instance call invalidate(); other instances
// pick the change up when their entry expires (at most `ttlMs` later).
//
// ttlFromEnv() returns 0 (no caching) under Vitest unless the variable is set,
// because integration tests write rows directly and expect the next read to see them.

export interface TtlCache<K, V> {
  get(key: K, load: () => Promise<V>): Promise<V>;
  /** Drop one key, or everything when called without a key. */
  invalidate(key?: K): void;
}

export function createTtlCache<K, V>(ttlMs: number): TtlCache<K, V> {
  const ttl = Math.max(0, ttlMs);
  const entries = new Map<K, { at: number; value: Promise<V> }>();
  return {
    get(key, load) {
      if (ttl === 0) return load();
      const hit = entries.get(key);
      if (hit && Date.now() - hit.at < ttl) return hit.value;
      const value = load();
      entries.set(key, { at: Date.now(), value });
      // A failed load must not be cached.
      value.catch(() => {
        if (entries.get(key)?.value === value) entries.delete(key);
      });
      return value;
    },
    invalidate(key) {
      if (key === undefined) entries.clear();
      else entries.delete(key);
    },
  };
}

/** TTL from an env var (milliseconds), else the default — 0 under Vitest unless set explicitly. */
export function ttlFromEnv(name: string, fallbackMs: number): number {
  const raw = process.env[name];
  const n = Number(raw);
  if (raw !== undefined && raw !== "" && Number.isFinite(n) && n >= 0) return n;
  return process.env.VITEST ? 0 : fallbackMs;
}
