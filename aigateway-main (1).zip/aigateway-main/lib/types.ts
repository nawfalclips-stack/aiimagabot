// Plain serializable shapes passed from server components to client components.

/** Customers list: real provider cost and share of the credit's real allowance used (admin only). */
export interface RealUsageCell {
  costMicroUsd: number;
  requests: number;
  pct: number | null;
}

export interface CustomerRow {
  id: string;
  accessCode: string;
  orderNumber: string;
  /** Legacy pool key — masked unless LEGACY_API_POOL_MODE=active (WS10). */
  apiKey: string;
  /** True only in LEGACY_API_POOL_MODE=active; forms hide the key field otherwise. */
  apiKeyEditable: boolean;
  status: string;
  notes: string;
  initialBalanceCents: number;
  usedBalanceCents: number;
  remainingBalanceCents: number;
  initialBonusCents: number;
  usedBonusCents: number;
  remainingBonusCents: number;
  profitCents: number;
  purchasedAgain: string;
  purchasedAgainAt: string | null;
  offerTitle: string;
  pendingBonusCents: number;
  reviewBonusStatus: string;
  reviewClaimedAt: string | null;
  finishedAt: string | null;
  createdAt: string;
  updatedAt: string;
  deletedAt: string | null;
  /** Assigned plan, or null when billed at the global multiplier (WS8 "No plan" badge). */
  planId: string | null;
  planName: string | null;
  isActivated: boolean;
}
