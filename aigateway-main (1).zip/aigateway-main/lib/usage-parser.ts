// Parses usage rows pasted from the API gateway dashboard. Shared by the
// admin preview (client) and the server action (revalidation).
//
// Expected shape per record — a time line followed by a tab-separated data
// line (tolerates 2+ spaces instead of tabs, and a leading inline time):
//
//   01:07:46 AM
//   me	claude-fable-5	in2 out1 540 read0 w5m410 687 w1h0	$5.2200	35.9s	200

export interface ParsedUsageRow {
  /** ISO timestamp — the pasted time-of-day applied to today's date. */
  happenedAt: string;
  keyLabel: string;
  model: string;
  tokens: string;
  /** Raw cost in USD as shown by the provider (before the customer multiplier). */
  costUsd: number;
  latency: string;
  status: string;
}

const TIME_RE = /^(\d{1,2}):(\d{2})(?::(\d{2}))?\s*(AM|PM)?$/i;
const COST_RE = /^\$([\d,]+(?:\.\d+)?)$/;
const LATENCY_RE = /^[\d.,]+\s*(?:s|ms)$/i;
const STATUS_RE = /^\d{3}$/;

function timeToDate(raw: string): Date | null {
  const match = raw.trim().match(TIME_RE);
  if (!match) return null;
  let hours = parseInt(match[1], 10);
  const minutes = parseInt(match[2], 10);
  const seconds = match[3] ? parseInt(match[3], 10) : 0;
  const meridiem = match[4]?.toUpperCase();
  if (meridiem === "PM" && hours < 12) hours += 12;
  if (meridiem === "AM" && hours === 12) hours = 0;
  if (hours > 23 || minutes > 59 || seconds > 59) return null;
  const date = new Date();
  date.setHours(hours, minutes, seconds, 0);
  return date;
}

export function parseUsageLogs(raw: string): ParsedUsageRow[] {
  const rows: ParsedUsageRow[] = [];
  let pendingTime: Date | null = null;

  for (const rawLine of raw.split(/\r?\n/)) {
    const line = rawLine.trim();
    if (!line) continue;

    // A standalone time line sets the timestamp for the next data line.
    const asTime = timeToDate(line);
    if (asTime) {
      pendingTime = asTime;
      continue;
    }

    if (!line.includes("$")) continue;

    // Data line: split on tabs or runs of 2+ spaces so the tokens summary
    // ("in2 out1 540 …") survives as a single field.
    let fields = line.split(/\t+| {2,}/).map((f) => f.trim()).filter(Boolean);

    // Tolerate an inline leading time ("01:07:46 AM me claude …").
    if (fields.length > 0) {
      const inlineTime = timeToDate(fields[0]);
      if (inlineTime) {
        pendingTime = inlineTime;
        fields = fields.slice(1);
      }
    }
    if (fields.length < 3) continue;

    const costIndex = fields.findIndex((f) => COST_RE.test(f));
    if (costIndex === -1) continue;
    const costUsd = parseFloat(fields[costIndex].replace(/[$,]/g, ""));
    if (!Number.isFinite(costUsd) || costUsd < 0) continue;

    const after = fields.slice(costIndex + 1);
    const latency = after.find((f) => LATENCY_RE.test(f)) ?? "";
    const status = after.find((f) => STATUS_RE.test(f)) ?? "";

    const keyLabel = fields[0] ?? "";
    const model = fields[1] ?? "";
    const tokens = fields.slice(2, costIndex).join(" ");

    rows.push({
      happenedAt: (pendingTime ?? new Date()).toISOString(),
      keyLabel,
      model,
      tokens,
      costUsd,
      latency,
      status,
    });
    pendingTime = null;
  }

  return rows;
}

/** Customer-facing cost in cents: raw µUSD × multiplier, rounded to the cent. */
export function customerCostCents(costMicroUsd: number, multiplier: number): number {
  return Math.round((costMicroUsd * multiplier) / 10_000);
}
