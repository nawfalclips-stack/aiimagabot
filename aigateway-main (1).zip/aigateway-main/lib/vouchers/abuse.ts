import "server-only";
import { getRedis } from "@/lib/redis";

/**
 * Redemption abuse controls (WS9): failed-attempt counters per IP (for the
 * optional Turnstile step-up) — shared through Redis when configured, per
 * instance otherwise. Rate limits themselves use lib/rate-limit.ts.
 */

const WINDOW_S = 60 * 60;
const memory = new Map<string, { count: number; expiresAt: number }>();

const key = (ipHash: string) => `voucher:fail:${ipHash}`;

export async function recordRedeemFailure(ipHash: string): Promise<number> {
  const redis = getRedis();
  if (redis) {
    try {
      const n = await redis.incr(key(ipHash));
      if (n === 1) await redis.expire(key(ipHash), WINDOW_S);
      return n;
    } catch {
      /* fall through to memory */
    }
  }
  const now = Date.now();
  const cur = memory.get(ipHash);
  const next = cur && cur.expiresAt > now ? { count: cur.count + 1, expiresAt: cur.expiresAt } : { count: 1, expiresAt: now + WINDOW_S * 1000 };
  memory.set(ipHash, next);
  return next.count;
}

export async function redeemFailuresLastHour(ipHash: string): Promise<number> {
  const redis = getRedis();
  if (redis) {
    try {
      const n = await redis.get<number>(key(ipHash));
      return Number(n ?? 0) || 0;
    } catch {
      /* fall through */
    }
  }
  const cur = memory.get(ipHash);
  return cur && cur.expiresAt > Date.now() ? cur.count : 0;
}

/** Verify a Cloudflare Turnstile token. False when unconfigured or invalid. */
export async function verifyTurnstile(token: string | null | undefined, ip: string): Promise<boolean> {
  const secret = process.env.TURNSTILE_SECRET_KEY;
  if (!secret || !token) return false;
  try {
    const res = await fetch("https://challenges.cloudflare.com/turnstile/v0/siteverify", {
      method: "POST",
      headers: { "content-type": "application/x-www-form-urlencoded" },
      body: new URLSearchParams({ secret, response: token, remoteip: ip }),
    });
    const json = (await res.json()) as { success?: boolean };
    return json.success === true;
  } catch {
    return false;
  }
}

export function turnstileConfigured(): boolean {
  return Boolean(process.env.TURNSTILE_SECRET_KEY && process.env.NEXT_PUBLIC_TURNSTILE_SITE_KEY);
}

export function _resetAbuseForTests(): void {
  memory.clear();
}
