import "server-only";
import { createHmac, randomBytes } from "node:crypto";
import { checkChar, normaliseVoucherCode, VOUCHER_ALPHABET, VOUCHER_BODY_LENGTH } from "@/lib/vouchers/format";

export * from "@/lib/vouchers/format";

/**
 * Voucher code generation and hashing (WS9). Codes are single-use secrets
 * that live on GamsGo as Automatic Delivery inventory, so:
 *   - 100 bits of entropy from crypto.randomBytes (no PRNG, no timestamps);
 *   - the database stores only HMAC-SHA256(VOUCHER_PEPPER, normalised code)
 *     and the last 4 characters — a leaked table cannot be redeemed.
 */

function pepper(): Buffer {
  const raw = process.env.VOUCHER_PEPPER;
  if (!raw || raw.length < 16) {
    throw new Error("VOUCHER_PEPPER must be set to 32 random bytes, base64 (openssl rand -base64 32), before vouchers can be used.");
  }
  return Buffer.from(raw, "base64");
}

export function voucherPepperConfigured(): boolean {
  const raw = process.env.VOUCHER_PEPPER;
  return Boolean(raw && raw.length >= 16);
}

/** A fresh normalised code (20 data chars + check char), never formatted here. */
export function generateVoucherCode(): string {
  // 20 chars × 5 bits = 100 bits → 13 random bytes, rejection-free since 256 % 32 == 0.
  const bytes = randomBytes(VOUCHER_BODY_LENGTH);
  let body = "";
  for (let i = 0; i < VOUCHER_BODY_LENGTH; i++) body += VOUCHER_ALPHABET[bytes[i] % 32];
  return body + checkChar(body);
}

export function hmacVoucherCode(normalised: string): string {
  return createHmac("sha256", pepper()).update(normalised).digest("hex");
}

/** Normalise + hash in one step; null when the input is not a well-formed code. */
export function hashTypedCode(raw: string): { normalised: string; hmac: string } | null {
  const normalised = normaliseVoucherCode(raw);
  if (!normalised) return null;
  return { normalised, hmac: hmacVoucherCode(normalised) };
}
