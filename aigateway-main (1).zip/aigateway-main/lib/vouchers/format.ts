// Voucher code format (WS9). Client-safe: used by the redeem form for the
// typo pre-check and by the server for normalisation before hashing.
//
//   ALK-7Q3WX-9M2KD-5H8RB-V4N6T-C
//   └┬┘ └────────── 20 data chars ──────────┘ └ check char
//   store prefix (display only)
//
// Alphabet: Crockford base32 (no I, L, O, U). 20 chars = 100 bits of entropy.
// The check character is Σ value(i) × (i+1) mod 31 encoded in the same
// alphabet: it catches every single-character substitution and every
// adjacent transposition before a server round-trip.

export const VOUCHER_ALPHABET = "0123456789ABCDEFGHJKMNPQRSTVWXYZ";
export const VOUCHER_BODY_LENGTH = 20;
const GROUP = 5;

export const STORE_CODE_PREFIX: Record<string, string> = { aerolink: "ALK", chefapi: "CHF" };

export function checkChar(body: string): string {
  let sum = 0;
  for (let i = 0; i < body.length; i++) {
    const v = VOUCHER_ALPHABET.indexOf(body[i]);
    if (v < 0) throw new Error("checkChar: invalid character");
    sum += v * (i + 1);
  }
  return VOUCHER_ALPHABET[sum % 31];
}

/**
 * Canonical form of whatever the customer typed: uppercase, separators and
 * whitespace removed, O→0 and I/L→1, store prefix dropped. Returns null when
 * the result cannot be a voucher code (wrong length, bad character, bad
 * check char) — so callers never hash garbage.
 */
export function normaliseVoucherCode(raw: string): string | null {
  let s = raw.toUpperCase().replace(/[^A-Z0-9]/g, "");
  const expected = VOUCHER_BODY_LENGTH + 1;
  // The prefix is matched before the confusion mapping ("ALK" contains an L).
  if (s.length === expected + 3 && Object.values(STORE_CODE_PREFIX).includes(s.slice(0, 3))) s = s.slice(3);
  s = s.replace(/O/g, "0").replace(/[IL]/g, "1");
  if (s.length !== expected) return null;
  for (const ch of s) if (!VOUCHER_ALPHABET.includes(ch)) return null;
  if (checkChar(s.slice(0, VOUCHER_BODY_LENGTH)) !== s[VOUCHER_BODY_LENGTH]) return null;
  return s;
}

/** Display form with prefix and dashes, from a normalised code. */
export function formatVoucherCode(normalised: string, storeId: string): string {
  const prefix = STORE_CODE_PREFIX[storeId] ?? "VCH";
  const body = normalised.slice(0, VOUCHER_BODY_LENGTH);
  const groups: string[] = [];
  for (let i = 0; i < body.length; i += GROUP) groups.push(body.slice(i, i + GROUP));
  return `${prefix}-${groups.join("-")}-${normalised[VOUCHER_BODY_LENGTH]}`;
}

export function voucherLast4(normalised: string): string {
  return normalised.slice(VOUCHER_BODY_LENGTH - 4, VOUCHER_BODY_LENGTH);
}
