import "server-only";
import { headers } from "next/headers";
import type { Customer } from "@prisma/client";
import { rateLimit } from "@/lib/rate-limit";
import { SETTING_KEYS } from "@/lib/constants";
import { getSettings } from "@/lib/services/settings";
import { recordRedeemFailure, redeemFailuresLastHour, turnstileConfigured, verifyTurnstile } from "@/lib/vouchers/abuse";
import { hashRedeemIp, redeemVoucher, REDEEM_FAILURE_MESSAGE, type RedeemResult } from "@/lib/vouchers/service";
import { voucherPepperConfigured } from "@/lib/vouchers/code";
import type { StoreId } from "@/lib/store";

export type RedeemOutcome =
  | { ok: true; result: Extract<RedeemResult, { ok: true }> }
  | { ok: false; message: string; requiresCaptcha?: boolean; retryAfterSeconds?: number };

export interface PerformRedemptionInput {
  storeId: StoreId;
  rawCode: string;
  gamsgoOrderId?: string;
  turnstileToken?: string | null;
  /** Session key for the per-session limit: customer id or a cookie-derived id. */
  sessionKey: string;
  customer?: Pick<Customer, "id" | "accessCode" | "status" | "deletedAt"> | null;
  affiliateCode?: string;
}

/** VOUCHERS_ENABLED flag (default on). Off = redemption refused, admin pages unaffected. */
export function vouchersEnabled(): boolean {
  return (process.env.VOUCHERS_ENABLED ?? "true").toLowerCase() !== "false";
}

/**
 * Everything around `redeemVoucher` that both entry points share (WS9):
 * rate limits per IP and per session (10 / 10 min), the optional Turnstile
 * step-up after repeated failures, uniform failure text, failure counting.
 */
export async function performRedemption(input: PerformRedemptionInput): Promise<RedeemOutcome> {
  if (!vouchersEnabled()) return { ok: false, message: "Code redemption is currently disabled. Please contact support." };
  if (!voucherPepperConfigured()) {
    console.error("[vouchers] VOUCHER_PEPPER is not configured; redemption refused");
    return { ok: false, message: "Code redemption is not available right now. Please contact support." };
  }
  const h = await headers();
  const ip = (h.get("x-forwarded-for") ?? "local").split(",")[0].trim();
  const ipHash = hashRedeemIp(ip);

  const [byIp, bySession] = await Promise.all([
    rateLimit(`redeem:ip:${ipHash}`, { limit: 10, windowMs: 10 * 60 * 1000 }),
    rateLimit(`redeem:session:${input.sessionKey}`, { limit: 10, windowMs: 10 * 60 * 1000 }),
  ]);
  if (!byIp.ok || !bySession.ok) {
    const retry = Math.max(byIp.retryAfterSeconds, bySession.retryAfterSeconds);
    return { ok: false, message: "Too many attempts. Please wait a few minutes and try again.", retryAfterSeconds: retry };
  }

  const settings = await getSettings(input.storeId);
  const captchaAfter = Number(settings[SETTING_KEYS.voucherTurnstileAfterFailures]) || 0;
  if (captchaAfter > 0 && turnstileConfigured()) {
    const failures = await redeemFailuresLastHour(ipHash);
    if (failures >= captchaAfter && !(await verifyTurnstile(input.turnstileToken, ip))) {
      return { ok: false, message: "Please complete the verification and try again.", requiresCaptcha: true };
    }
  }

  const result = await redeemVoucher({
    storeId: input.storeId,
    rawCode: input.rawCode,
    ip,
    gamsgoOrderId: input.gamsgoOrderId,
    customer: input.customer,
    affiliateCode: input.affiliateCode,
  });
  if (!result.ok) {
    const n = await recordRedeemFailure(ipHash);
    const requiresCaptcha = captchaAfter > 0 && turnstileConfigured() && n >= captchaAfter;
    return { ok: false, message: REDEEM_FAILURE_MESSAGE, requiresCaptcha };
  }
  return { ok: true, result };
}
