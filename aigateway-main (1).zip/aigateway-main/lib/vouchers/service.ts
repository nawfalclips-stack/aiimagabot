import "server-only";
import { createHmac } from "node:crypto";
import type { Customer, Pack, Plan, Prisma, Voucher, VoucherBatch } from "@prisma/client";
import { prisma } from "@/lib/prisma";
import { clawback, credit, TX_OPTIONS, type Tx } from "@/lib/billing/balance-service";
import { centsToMicro } from "@/lib/billing/money";
import { formatCents } from "@/lib/money";
import { AFFILIATE } from "@/lib/affiliate";
import { SETTING_KEYS } from "@/lib/constants";
import { logActivity } from "@/lib/services/activity";
import { generateAccessCode } from "@/lib/services/generators";
import { awardLoyaltyPoints } from "@/lib/services/loyalty";
import { activeRechargePromo, creditPromoBonus } from "@/lib/services/announcements";
import { creditPlanBonus, recordPlanProfit, reversePlanBonus, reversePlanProfit } from "@/lib/services/profit";
import { createNotification, NOTIFICATION_TYPES } from "@/lib/services/notifications";
import { getLowBalanceThresholdCents, getSettings } from "@/lib/services/settings";
import { computeStatus } from "@/lib/services/status";
import { formatVoucherCode, generateVoucherCode, hashTypedCode, hmacVoucherCode, voucherLast4 } from "@/lib/vouchers/code";
import type { StoreId } from "@/lib/store";

/**
 * Vouchers (WS9): single-use codes sold through GamsGo Automatic Delivery.
 * Generation → one-time export → upload to GamsGo → the buyer redeems here.
 *
 * Invariants:
 *   - a code's plaintext exists only in the batch export returned once by
 *     createVoucherBatch(); tables, logs and errors carry the last 4 at most;
 *   - redemption claims the row with `WHERE status = 'ISSUED'`, so N parallel
 *     redemptions of one code yield exactly one success;
 *   - every failure (unknown, used, revoked, expired, malformed) returns the
 *     same message through the same code path.
 */

export const REDEEM_FAILURE_MESSAGE = "This code is invalid or has already been used.";

export type VoucherWithRelations = Voucher & { batch: VoucherBatch; pack: Pack & { plan: Plan } };

// ─── Batches ────────────────────────────────────────────────────────────────

export const MAX_BATCH_QUANTITY = 1000;

export interface CreateBatchInput {
  storeId: StoreId;
  packId: string;
  quantity: number;
  note?: string;
  /** Null = never expires. */
  expiresAt: Date | null;
  adminId: string;
  adminName: string;
}

export interface CreatedBatch {
  batch: VoucherBatch;
  /** Formatted plaintext codes — shown exactly once, never stored. */
  codes: string[];
}

export async function createVoucherBatch(input: CreateBatchInput): Promise<CreatedBatch> {
  if (!Number.isInteger(input.quantity) || input.quantity < 1 || input.quantity > MAX_BATCH_QUANTITY) {
    throw new Error(`Quantity must be between 1 and ${MAX_BATCH_QUANTITY}.`);
  }
  const pack = await prisma.pack.findFirst({ where: { id: input.packId, storeId: input.storeId, deletedAt: null } });
  if (!pack) throw new Error("Pack not found.");
  if (!pack.active) throw new Error("This pack is inactive; activate it before generating codes.");

  const normalised: string[] = [];
  const rows: { codeHmac: string; codeLast4: string }[] = [];
  const seen = new Set<string>();
  while (normalised.length < input.quantity) {
    const code = generateVoucherCode();
    const hmac = hmacVoucherCode(code);
    if (seen.has(hmac)) continue;
    seen.add(hmac);
    normalised.push(code);
    rows.push({ codeHmac: hmac, codeLast4: voucherLast4(code) });
  }

  const batch = await prisma.$transaction(async (tx) => {
    const b = await tx.voucherBatch.create({
      data: {
        storeId: input.storeId,
        packId: pack.id,
        quantity: input.quantity,
        note: (input.note ?? "").slice(0, 200),
        expiresAt: input.expiresAt,
        createdByAdminId: input.adminId,
        exportedAt: new Date(),
      },
    });
    await tx.voucher.createMany({
      data: rows.map((r) => ({ storeId: input.storeId, batchId: b.id, packId: pack.id, codeHmac: r.codeHmac, codeLast4: r.codeLast4 })),
    });
    return b;
  }, TX_OPTIONS);

  await logActivity({
    storeId: input.storeId,
    action: "VOUCHER_BATCH_CREATED",
    description: `${input.adminName} generated ${input.quantity} voucher codes for pack "${pack.name}" (batch ${batch.id.slice(-6)})${input.expiresAt ? `, expiring ${input.expiresAt.toISOString().slice(0, 10)}` : ""}`,
    adminId: input.adminId,
  });

  return { batch, codes: normalised.map((c) => formatVoucherCode(c, input.storeId)) };
}

export async function markBatchUploaded(storeId: StoreId, batchId: string, adminId: string, adminName: string): Promise<VoucherBatch> {
  const batch = await prisma.voucherBatch.findFirst({ where: { id: batchId, storeId } });
  if (!batch) throw new Error("Batch not found.");
  const updated = await prisma.voucherBatch.update({ where: { id: batchId }, data: { markedUploadedAt: batch.markedUploadedAt ?? new Date() } });
  await logActivity({ storeId, action: "VOUCHER_BATCH_UPLOADED", description: `${adminName} marked batch ${batchId.slice(-6)} as uploaded to GamsGo`, adminId });
  return updated;
}

export async function updateBatchExpiry(storeId: StoreId, batchId: string, expiresAt: Date | null): Promise<VoucherBatch> {
  const batch = await prisma.voucherBatch.findFirst({ where: { id: batchId, storeId } });
  if (!batch) throw new Error("Batch not found.");
  return prisma.voucherBatch.update({ where: { id: batchId }, data: { expiresAt } });
}

/** Compromise: every unredeemed code in the batch stops working at once. */
export async function revokeBatch(storeId: StoreId, batchId: string, reason: string, adminId: string, adminName: string): Promise<number> {
  const batch = await prisma.voucherBatch.findFirst({ where: { id: batchId, storeId } });
  if (!batch) throw new Error("Batch not found.");
  const cleanReason = reason.trim();
  if (!cleanReason) throw new Error("A reason is required.");
  const n = await prisma.$transaction(async (tx) => {
    const r = await tx.voucher.updateMany({
      where: { batchId, status: "ISSUED" },
      data: { status: "REVOKED", revokedReason: cleanReason, revokedByAdminId: adminId },
    });
    await tx.voucherBatch.update({ where: { id: batchId }, data: { compromisedAt: new Date() } });
    return r.count;
  });
  await logActivity({ storeId, action: "VOUCHER_BATCH_REVOKED", description: `${adminName} revoked ${n} unredeemed codes in batch ${batchId.slice(-6)}: ${cleanReason}`, adminId });
  return n;
}

// ─── Single-voucher admin actions ───────────────────────────────────────────

export async function revokeVoucher(storeId: StoreId, voucherId: string, reason: string, adminId: string, adminName: string): Promise<void> {
  const cleanReason = reason.trim();
  if (!cleanReason) throw new Error("A reason is required.");
  const r = await prisma.voucher.updateMany({
    where: { id: voucherId, storeId, status: "ISSUED" },
    data: { status: "REVOKED", revokedReason: cleanReason, revokedByAdminId: adminId },
  });
  if (r.count === 0) throw new Error("Only an unredeemed (ISSUED) voucher can be revoked.");
  const v = await prisma.voucher.findUniqueOrThrow({ where: { id: voucherId } });
  await logActivity({ storeId, action: "VOUCHER_REVOKED", description: `${adminName} revoked voucher …${v.codeLast4}: ${cleanReason}`, adminId });
}

/** Idempotency key of the grant a voucher credited; also how we know it was credited. */
export const voucherGrantKey = (voucherId: string, pot: "BALANCE" | "BONUS") => `voucher:${voucherId}:${pot}`;

export async function voucherWasCredited(voucherId: string): Promise<boolean> {
  const e = await prisma.ledgerEntry.findUnique({ where: { idempotencyKey: voucherGrantKey(voucherId, "BALANCE") }, select: { id: true } });
  return e !== null;
}

/**
 * Refund/dispute after redemption: take back min(grant, remaining) from each
 * pot through the ledger (CLAWBACK, reason required), never below zero;
 * optionally suspend the customer.
 */
export async function clawbackVoucher(
  storeId: StoreId,
  voucherId: string,
  input: { reason: string; suspendCustomer: boolean; adminId: string; adminName: string }
): Promise<{ balanceMicroUsd: bigint; bonusMicroUsd: bigint }> {
  const reason = input.reason.trim();
  if (!reason) throw new Error("A reason is required.");
  const v = await prisma.voucher.findFirst({ where: { id: voucherId, storeId }, include: { pack: true } });
  if (!v) throw new Error("Voucher not found.");
  if (v.status !== "REDEEMED" || !v.redeemedByCustomerId) throw new Error("Only a redeemed voucher can be clawed back.");
  if (v.clawedBackAt) throw new Error("This voucher was already clawed back.");
  if (!(await voucherWasCredited(voucherId))) throw new Error("This redemption is still waiting for approval — reject it from the queue instead.");

  const customerId = v.redeemedByCustomerId;
  const result = await prisma.$transaction(async (tx) => {
    let balance = 0n;
    let bonus = 0n;
    if (v.pack.balanceGrantMicroUsd > 0n) {
      const r = await clawback({
        customerId,
        pot: "BALANCE",
        amountMicroUsd: v.pack.balanceGrantMicroUsd,
        idempotencyKey: `voucher-clawback:${voucherId}:BALANCE`,
        ref: { type: "Voucher", id: voucherId },
        actor: { adminId: input.adminId, label: input.adminName },
        note: `Voucher …${v.codeLast4} clawed back: ${reason}`,
        tx,
      });
      balance = r.appliedMicroUsd < 0n ? -r.appliedMicroUsd : r.appliedMicroUsd; // debits apply negatively
    }
    if (v.pack.bonusGrantMicroUsd > 0n) {
      const r = await clawback({
        customerId,
        pot: "BONUS",
        amountMicroUsd: v.pack.bonusGrantMicroUsd,
        idempotencyKey: `voucher-clawback:${voucherId}:BONUS`,
        ref: { type: "Voucher", id: voucherId },
        actor: { adminId: input.adminId, label: input.adminName },
        note: `Voucher …${v.codeLast4} bonus clawed back: ${reason}`,
        tx,
      });
      bonus = r.appliedMicroUsd < 0n ? -r.appliedMicroUsd : r.appliedMicroUsd;
    }
    await tx.voucher.update({ where: { id: voucherId }, data: { clawedBackAt: new Date(), revokedReason: reason, revokedByAdminId: input.adminId } });
    // The sale is undone: so is its plan profit.
    await reversePlanProfit(tx, { ref: { type: "Voucher", id: voucherId }, reason: `voucher …${v.codeLast4} clawed back — ${reason}` });
    bonus += await reversePlanBonus(tx, {
      customerId,
      ref: { type: "Voucher", id: voucherId },
      actor: { adminId: input.adminId, label: input.adminName },
      reason: `voucher …${v.codeLast4} clawed back — ${reason}`,
    });
    if (input.suspendCustomer) {
      await tx.customer.update({ where: { id: customerId }, data: { status: "SUSPENDED", suspendedAt: new Date() } });
    }
    return { balanceMicroUsd: balance, bonusMicroUsd: bonus };
  }, TX_OPTIONS);

  const c = await prisma.customer.findUnique({ where: { id: customerId }, select: { accessCode: true } });
  await logActivity({
    storeId,
    action: "VOUCHER_CLAWBACK",
    description: `${input.adminName} clawed back voucher …${v.codeLast4} from ${c?.accessCode ?? customerId}: ${formatCents(Number(result.balanceMicroUsd / 10_000n))} balance${result.bonusMicroUsd > 0n ? ` + ${formatCents(Number(result.bonusMicroUsd / 10_000n))} bonus` : ""}${input.suspendCustomer ? ", customer suspended" : ""} — ${reason}`,
    adminId: input.adminId,
    customerId,
  });
  return result;
}

// ─── Redemption ─────────────────────────────────────────────────────────────

export function hashRedeemIp(ip: string): string {
  const raw = process.env.VOUCHER_PEPPER ?? "";
  return createHmac("sha256", Buffer.from(raw, "base64")).update(`ip:${ip}`).digest("hex").slice(0, 32);
}

export interface RedeemInput {
  storeId: StoreId;
  rawCode: string;
  ip: string;
  gamsgoOrderId?: string;
  /** Signed-in customer topping up; undefined = new buyer. */
  customer?: Pick<Customer, "id" | "accessCode" | "status" | "deletedAt"> | null;
  affiliateCode?: string;
}

export type RedeemResult =
  | { ok: true; kind: "new"; customerId: string; accessCode: string; credited: boolean; balanceCents: number; bonusCents: number; planName: string }
  | { ok: true; kind: "existing"; customerId: string; credited: boolean; balanceCents: number; bonusCents: number; planName: string }
  | { ok: false; message: string };

const FAIL: RedeemResult = { ok: false, message: REDEEM_FAILURE_MESSAGE };

/** Why a redemption goes to the review queue instead of being credited at once. */
export type ReviewReason = "AUTO_APPROVE_OFF" | "IP_VELOCITY" | "BATCH_COMPROMISED" | "CUSTOMER_FLAGGED";

async function reviewReason(storeId: StoreId, v: VoucherWithRelations, ipHash: string, customer: RedeemInput["customer"]): Promise<ReviewReason | null> {
  const settings = await getSettings(storeId);
  if (settings[SETTING_KEYS.voucherAutoApprove] !== "true") return "AUTO_APPROVE_OFF";
  if (v.batch.compromisedAt) return "BATCH_COMPROMISED";
  if (customer && customer.status === "SUSPENDED") return "CUSTOMER_FLAGGED";
  const max = Math.max(0, Number(settings[SETTING_KEYS.voucherMaxRedemptionsPerIpDay] ?? 3) || 0);
  const since = new Date(Date.now() - 24 * 60 * 60 * 1000);
  const fromIp = await prisma.voucher.count({ where: { storeId, redeemIpHash: ipHash, redeemedAt: { gte: since } } });
  if (fromIp >= max) return "IP_VELOCITY";
  return null;
}

/** Credit a redeemed voucher's grants (immediately, or from the review queue at approval). Idempotent per voucher. */
export async function creditVoucherGrants(
  tx: Tx,
  v: { id: string; codeLast4: string; pack: Pick<Pack, "name" | "balanceGrantMicroUsd" | "bonusGrantMicroUsd"> },
  customerId: string,
  actor: { adminId?: string; label: string }
): Promise<void> {
  if (v.pack.balanceGrantMicroUsd > 0n) {
    await credit({
      customerId,
      pot: "BALANCE",
      amountMicroUsd: v.pack.balanceGrantMicroUsd,
      type: "VOUCHER_REDEMPTION",
      idempotencyKey: voucherGrantKey(v.id, "BALANCE"),
      ref: { type: "Voucher", id: v.id },
      actor,
      note: `Voucher …${v.codeLast4}: ${v.pack.name}`,
      history: "none",
      tx,
    });
  }
  if (v.pack.bonusGrantMicroUsd > 0n) {
    await credit({
      customerId,
      pot: "BONUS",
      amountMicroUsd: v.pack.bonusGrantMicroUsd,
      type: "VOUCHER_REDEMPTION",
      idempotencyKey: voucherGrantKey(v.id, "BONUS"),
      ref: { type: "Voucher", id: v.id },
      actor,
      note: `Voucher …${v.codeLast4}: ${v.pack.name} bonus`,
      history: "none",
      tx,
    });
  }
}

/**
 * Redeem a code. New buyer → account + plan + grants; signed-in customer →
 * top-up with the returning-customer review-bonus rules. Claim, account
 * creation and ledger writes share one transaction.
 */
export async function redeemVoucher(input: RedeemInput): Promise<RedeemResult> {
  const hashed = hashTypedCode(input.rawCode);
  if (!hashed) return FAIL;
  const ipHash = hashRedeemIp(input.ip);
  const gamsgoOrderId = (input.gamsgoOrderId ?? "").trim().slice(0, 64) || null;

  const v = await prisma.voucher.findUnique({ where: { codeHmac: hashed.hmac }, include: { batch: true, pack: { include: { plan: true } } } });
  if (!v || v.storeId !== input.storeId || v.status !== "ISSUED") return FAIL;
  if (v.batch.expiresAt && v.batch.expiresAt.getTime() < Date.now()) {
    await prisma.voucher.updateMany({ where: { id: v.id, status: "ISSUED" }, data: { status: "EXPIRED" } });
    return FAIL;
  }
  if (input.customer?.deletedAt) return FAIL;

  const review = await reviewReason(input.storeId, v, ipHash, input.customer);
  const credited = review === null;
  const balanceCents = Number(v.pack.balanceGrantMicroUsd / 10_000n);
  const bonusCents = Number(v.pack.bonusGrantMicroUsd / 10_000n);
  const threshold = await getLowBalanceThresholdCents(input.storeId);

  // Referral (new buyers only).
  let referredById: string | null = null;
  if (!input.customer && input.affiliateCode) {
    const referrer = await prisma.customer.findUnique({ where: { affiliateCode: input.affiliateCode.trim().toUpperCase() }, select: { id: true, deletedAt: true } });
    if (referrer && !referrer.deletedAt) referredById = referrer.id;
  }
  const accessCode = input.customer ? null : await generateAccessCode();

  const outcome = await prisma.$transaction(async (tx) => {
    const claimed = await tx.voucher.updateMany({
      where: { id: v.id, status: "ISSUED" },
      data: { status: "REDEEMED", redeemedAt: new Date(), redeemIpHash: ipHash, gamsgoOrderId },
    });
    if (claimed.count === 0) return null;

    if (!input.customer) {
      // ── New buyer ───────────────────────────────────────────────────
      const pendingBonusCents = Math.round(balanceCents * 0.1); // review bonus rule for new signups
      const created = await tx.customer.create({
        data: {
          storeId: input.storeId,
          accessCode: accessCode!,
          status: computeStatus(credited ? balanceCents : 0, threshold, "ACTIVE", credited ? bonusCents : 0),
          notes: `Redeemed voucher …${v.codeLast4} (pack ${v.pack.name})${gamsgoOrderId ? `\nGamsGo order ${gamsgoOrderId}` : ""}`,
          offerTitle: v.pack.name,
          pendingBonusCents,
          reviewBonusStatus: pendingBonusCents > 0 ? "OFFERED" : "NONE",
          referredById,
          isActivated: credited,
          activationSource: "VOUCHER",
          activationVoucherId: v.id,
          packId: v.pack.id,
          planId: v.pack.plan.isActive ? v.pack.plan.id : null,
          planAssignedAt: v.pack.plan.isActive ? new Date() : null,
        },
      });
      await tx.voucher.update({ where: { id: v.id }, data: { redeemedByCustomerId: created.id } });
      if (credited) {
        await creditVoucherGrants(tx, v, created.id, { label: "Voucher redemption" });
        await recordPlanProfit(tx, { customerId: created.id, plan: v.pack.plan, ref: { type: "Voucher", id: v.id } });
        await creditPlanBonus(tx, { customerId: created.id, plan: v.pack.plan, ref: { type: "Voucher", id: v.id }, actor: { label: "Voucher redemption" } });
        if (referredById) {
          await credit({
            customerId: created.id,
            pot: "BONUS",
            amountMicroUsd: centsToMicro(AFFILIATE.welcomeBonusCents),
            type: "AFFILIATE_REWARD",
            idempotencyKey: `welcome:${created.id}`,
            ref: { type: "Customer", id: referredById },
            actor: { label: "Affiliate program" },
            note: "Welcome gift — invited by a friend ($5)",
            tx,
          });
        }
      }
      return { customerId: created.id, accessCode: created.accessCode, rechargeRequestId: null as string | null };
    }

    // ── Existing customer top-up ──────────────────────────────────────
    const customerId = input.customer.id;
    await tx.voucher.update({ where: { id: v.id }, data: { redeemedByCustomerId: customerId } });
    if (credited) {
      const pendingBonusCents = Math.round(balanceCents * 0.15); // returning-customer review bonus
      await tx.customer.update({
        where: { id: customerId },
        data: {
          offerTitle: v.pack.name,
          reviewBonusStatus: pendingBonusCents > 0 ? "OFFERED" : undefined,
          pendingBonusCents,
          reviewClaimedAt: null,
          packId: v.pack.id,
          ...(v.pack.plan.isActive ? { planId: v.pack.plan.id, planAssignedAt: new Date() } : {}),
        },
      });
      await creditVoucherGrants(tx, v, customerId, { label: "Voucher redemption" });
      await recordPlanProfit(tx, { customerId, plan: v.pack.plan, ref: { type: "Voucher", id: v.id } });
      await creditPlanBonus(tx, { customerId, plan: v.pack.plan, ref: { type: "Voucher", id: v.id }, actor: { label: "Voucher redemption" } });
      const promo = await activeRechargePromo(input.storeId, customerId, tx);
      if (promo) {
        await creditPromoBonus(tx, {
          customerId,
          balanceCents,
          pct: promo.rechargeBonusPct,
          ref: { type: "Voucher", id: v.id },
          actor: { label: "Recharge promotion" },
        });
      }
      return { customerId, accessCode: input.customer.accessCode, rechargeRequestId: null as string | null };
    }
    const promo = await activeRechargePromo(input.storeId, customerId, tx);
    const req = await tx.rechargeRequest.create({
      data: {
        storeId: input.storeId,
        customerId,
        promoAnnouncementId: promo?.id ?? null,
        promoBonusPct: promo?.rechargeBonusPct ?? 0,
        orderNumber: gamsgoOrderId && !(await tx.rechargeRequest.findUnique({ where: { orderNumber: gamsgoOrderId } })) ? gamsgoOrderId : `VCH-${v.id}`,
        offerTitle: v.pack.name,
        balanceCents,
        bonusCents,
        status: "PENDING",
        source: "VOUCHER",
        voucherId: v.id,
        packId: v.pack.id,
      },
    });
    return { customerId, accessCode: input.customer.accessCode, rechargeRequestId: req.id };
  }, TX_OPTIONS);

  if (!outcome) return FAIL; // lost the race: someone else redeemed it first

  await logActivity({
    storeId: input.storeId,
    action: "VOUCHER_REDEEMED",
    description: `Customer ${outcome.accessCode} redeemed voucher …${v.codeLast4} (${v.pack.name}: ${formatCents(balanceCents)}${bonusCents ? ` + ${formatCents(bonusCents)} bonus` : ""})${credited ? "" : ` — sent to review (${review})`}`,
    customerId: outcome.customerId,
  });

  if (credited) {
    // Same side effects as an approved activation / recharge.
    const award = await awardLoyaltyPoints(outcome.customerId, balanceCents);
    const { creditReferralCommission } = await import("@/lib/services/affiliate");
    await creditReferralCommission(outcome.customerId, award?.earned?.totalPoints ?? 0);
  } else {
    await createNotification({
      storeId: input.storeId,
      type: NOTIFICATION_TYPES.VOUCHER_REVIEW,
      title: input.customer ? "Voucher recharge needs review" : "Voucher activation needs review",
      message: `${outcome.accessCode} redeemed a ${v.pack.name} voucher (${formatCents(balanceCents)}); held for review: ${REVIEW_LABEL[review!]}.`,
      customerId: outcome.customerId,
      relatedId: outcome.rechargeRequestId ?? outcome.customerId,
    });
  }

  const common = { credited, balanceCents, bonusCents, planName: v.pack.plan.name };
  return input.customer
    ? { ok: true, kind: "existing", customerId: outcome.customerId, ...common }
    : { ok: true, kind: "new", customerId: outcome.customerId, accessCode: outcome.accessCode, ...common };
}

export const REVIEW_LABEL: Record<ReviewReason, string> = {
  AUTO_APPROVE_OFF: "auto-approve is off",
  IP_VELOCITY: "too many redemptions from one IP today",
  BATCH_COMPROMISED: "batch marked compromised",
  CUSTOMER_FLAGGED: "customer is suspended",
};

// ─── Stock, lookup, expiry ──────────────────────────────────────────────────

export interface PackStock {
  packId: string;
  packName: string;
  /** ISSUED codes in uploaded, non-compromised, unexpired batches. */
  uploadedUnredeemed: number;
  /** ISSUED codes in batches not yet marked as uploaded. */
  generatedNotUploaded: number;
  redeemedLast7Days: number;
  /** null when nothing was redeemed in the last 7 days. */
  daysOfStockLeft: number | null;
  low: boolean;
}

export async function packStock(storeId: StoreId): Promise<PackStock[]> {
  const [packs, settings] = await Promise.all([
    prisma.pack.findMany({ where: { storeId, deletedAt: null }, orderBy: [{ sortOrder: "asc" }, { createdAt: "asc" }] }),
    getSettings(storeId),
  ]);
  const lowCount = Number(settings[SETTING_KEYS.voucherLowStockCount] ?? 10) || 10;
  const lowDays = Number(settings[SETTING_KEYS.voucherLowStockDays] ?? 7) || 7;
  const now = new Date();
  const weekAgo = new Date(now.getTime() - 7 * 24 * 60 * 60 * 1000);
  const out: PackStock[] = [];
  for (const p of packs) {
    const liveBatch = (): Prisma.VoucherBatchWhereInput => ({ compromisedAt: null, OR: [{ expiresAt: null }, { expiresAt: { gt: now } }] });
    const [uploaded, notUploaded, redeemed7] = await Promise.all([
      prisma.voucher.count({ where: { packId: p.id, status: "ISSUED", batch: { ...liveBatch(), markedUploadedAt: { not: null } } } }),
      prisma.voucher.count({ where: { packId: p.id, status: "ISSUED", batch: { ...liveBatch(), markedUploadedAt: null } } }),
      prisma.voucher.count({ where: { packId: p.id, status: "REDEEMED", redeemedAt: { gte: weekAgo } } }),
    ]);
    const rate = redeemed7 / 7;
    const days = rate > 0 ? Math.floor(uploaded / rate) : null;
    out.push({
      packId: p.id,
      packName: p.name,
      uploadedUnredeemed: uploaded,
      generatedNotUploaded: notUploaded,
      redeemedLast7Days: redeemed7,
      daysOfStockLeft: days,
      low: p.active && (uploaded < lowCount || (days !== null && days < lowDays)),
    });
  }
  return out;
}

/** Daily: raise one VOUCHER_LOW_STOCK notification per low pack (at most once a day). */
export async function notifyLowStock(storeId: StoreId): Promise<string[]> {
  const stock = await packStock(storeId);
  const dayAgo = new Date(Date.now() - 24 * 60 * 60 * 1000);
  const notified: string[] = [];
  for (const s of stock) {
    if (!s.low) continue;
    const recent = await prisma.notification.findFirst({ where: { storeId, type: NOTIFICATION_TYPES.VOUCHER_LOW_STOCK, relatedId: s.packId, createdAt: { gte: dayAgo } } });
    if (recent) continue;
    await createNotification({
      storeId,
      type: NOTIFICATION_TYPES.VOUCHER_LOW_STOCK,
      title: "Voucher stock low",
      message: `Pack "${s.packName}" has ${s.uploadedUnredeemed} uploaded codes left${s.daysOfStockLeft !== null ? ` (~${s.daysOfStockLeft} days at the current rate)` : ""}. Generate a batch and upload it to GamsGo.`,
      relatedId: s.packId,
    });
    notified.push(s.packName);
  }
  return notified;
}

/** Cron: ISSUED codes past their batch expiry become EXPIRED. */
export async function expireVouchers(): Promise<number> {
  const r = await prisma.voucher.updateMany({
    where: { status: "ISSUED", batch: { expiresAt: { lt: new Date() } } },
    data: { status: "EXPIRED" },
  });
  return r.count;
}

export type VoucherLookupRow = Voucher & { batch: VoucherBatch; pack: Pack; customer: { accessCode: string } | null };

/** Lookup by full code, last 4, GamsGo order id or customer access code. */
export async function lookupVouchers(storeId: StoreId, query: string): Promise<VoucherLookupRow[]> {
  const q = query.trim();
  if (!q) return [];
  const where: Record<string, unknown>[] = [];
  const hashed = hashTypedCode(q);
  if (hashed) where.push({ codeHmac: hashed.hmac });
  const compact = q.toUpperCase().replace(/[^A-Z0-9]/g, "");
  if (compact.length === 4) where.push({ codeLast4: compact.replace(/O/g, "0").replace(/[IL]/g, "1") });
  where.push({ gamsgoOrderId: q });
  const customer = await prisma.customer.findFirst({ where: { storeId, accessCode: q.toUpperCase() }, select: { id: true } });
  if (customer) where.push({ redeemedByCustomerId: customer.id });
  const rows = await prisma.voucher.findMany({ where: { storeId, OR: where }, include: { batch: true, pack: true }, orderBy: { createdAt: "desc" }, take: 50 });
  const ids = [...new Set(rows.map((r) => r.redeemedByCustomerId).filter((x): x is string => !!x))];
  const customers = ids.length ? await prisma.customer.findMany({ where: { id: { in: ids } }, select: { id: true, accessCode: true } }) : [];
  const byId = new Map(customers.map((c) => [c.id, { accessCode: c.accessCode }]));
  return rows.map((r) => ({ ...r, customer: r.redeemedByCustomerId ? (byId.get(r.redeemedByCustomerId) ?? null) : null }));
}

// ─── Listing text helper ────────────────────────────────────────────────────

export interface ListingInput {
  pack: Pick<Pack, "name" | "balanceGrantMicroUsd" | "bonusGrantMicroUsd" | "listingPriceLabel">;
  planName: string;
  models: string[];
  supportEmail: string;
  redeemUrl: string;
  expiryMonths: number | null;
}

/**
 * A truthful GamsGo title + description from pack data. Follows GamsGo's
 * title rules: no "official", "lifetime", "never banned", no keyword stuffing.
 */
export function listingText(i: ListingInput): { title: string; description: string } {
  const balance = formatCents(Number(i.pack.balanceGrantMicroUsd / 10_000n));
  const bonus = Number(i.pack.bonusGrantMicroUsd / 10_000n);
  const title = `${i.pack.name} — ${balance} API credit${bonus > 0 ? ` + ${formatCents(bonus)} bonus` : ""} (instant code)`;
  const models = i.models.length ? i.models.slice(0, 8).join(", ") + (i.models.length > 8 ? ", …" : "") : "the models listed on the site";
  const description = [
    `What you get: a single-use activation code worth ${balance} of API credit${bonus > 0 ? ` plus ${formatCents(bonus)} bonus credit` : ""} on the ${i.planName} plan.`,
    `Models served: ${models}. Works with Claude Code, Codex CLI and any OpenAI- or Anthropic-compatible client.`,
    `How to redeem: after checkout, GamsGo shows your code instantly. Open ${i.redeemUrl}, paste the code, and your account and API key are ready in under a minute — no waiting for manual delivery.`,
    i.expiryMonths ? `The code must be redeemed within ${i.expiryMonths} months of purchase; credit does not expire once redeemed.` : "Credit does not expire once redeemed.",
    `This is a usage right on our API gateway, not a subscription or account from any model provider. Support: ${i.supportEmail}.`,
  ].join("\n\n");
  return { title, description };
}
