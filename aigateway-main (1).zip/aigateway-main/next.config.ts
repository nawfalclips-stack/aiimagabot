import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Dev server only: let a Cloudflare quick tunnel (`cloudflared tunnel --url
  // http://localhost:3000`) load dev assets. Ignored by production builds.
  allowedDevOrigins: ["*.trycloudflare.com"],
};

export default nextConfig;
