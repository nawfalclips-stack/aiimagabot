# More agents — Windows

Most AI coding tools can use AeroLink. If a tool lets you set a custom **OpenAI-compatible** (or **Anthropic-compatible**) provider, it works with the same token and balance as Claude Code and Codex.

## The four values every tool needs

| Setting | Value |
|---|---|
| Base URL (OpenAI-compatible) | `{{BASE_URL}}/v1` |
| Base URL (Anthropic-compatible) | `{{BASE_URL}}` |
| API key | your `al_…` token |
| Model | a model id from the API Access page, e.g. `{{MODEL}}` |

> Agents need a model that supports **tool calling** (reading files, running commands). If a tool says the model can't use tools, pick a different model from your list.

## 01 — Create your AeroLink API token

Open **API Access** in your dashboard and press **Create token**. Copy the token — it starts with `al_` — and use it wherever the steps below say `YOUR_AEROLINK_API_KEY`.

> Treat the token like a password: anyone who has it can spend your balance. If it leaks, revoke it on the API Access page and create a new one.

## 02 — Check your token works

Run this before configuring any tool. A list of models means your token and connection are working — every `id` in it is a model name you can use.

```powershell
curl.exe {{BASE_URL}}/v1/models -H "Authorization: Bearer YOUR_AEROLINK_API_KEY"
```

## Cline (VS Code)

1. Open Cline and click the **⚙️ settings** icon.
2. **API Provider:** choose **OpenAI Compatible**.
3. **Base URL:** `{{BASE_URL}}/v1`
4. **API Key:** your `al_…` token.
5. **Model ID:** `{{MODEL}}`
6. Optional — under **Model Configuration**, set the context window and max output tokens for the model.

## Roo Code (VS Code)

1. Open Roo Code settings.
2. **API Provider:** choose **OpenAI Compatible**.
3. **Base URL:** `{{BASE_URL}}/v1`
4. **API Key:** your `al_…` token.
5. **Model:** `{{MODEL}}`

## Kilo Code (VS Code)

1. Open **Settings → Providers** and click **Custom provider** at the bottom.
2. **Provider ID:** `aerolink` · **Display name:** `AeroLink`
3. **Provider API:** **OpenAI Compatible**
4. **Base URL:** `{{BASE_URL}}/v1` · **API key:** your `al_…` token.
5. Kilo loads your models automatically from AeroLink — pick `{{MODEL}}`, then **Submit**.

## Continue (VS Code / JetBrains)

Add this to `C:\Users\YOUR_USERNAME\.continue\config.yaml`:

```yaml
name: AeroLink
version: 0.0.1
schema: v1

models:
  - name: AeroLink {{MODEL}}
    provider: openai
    model: {{MODEL}}
    apiBase: {{BASE_URL}}/v1
    apiKey: YOUR_AEROLINK_API_KEY
```

If the file already has a `models:` list, add only the entry (the lines starting at `- name:`).

## Aider (terminal)

Install Aider:

```powershell
python -m pip install aider-install
aider-install
```

Point it at AeroLink:

```powershell
setx OPENAI_API_BASE "{{BASE_URL}}/v1"
setx OPENAI_API_KEY "YOUR_AEROLINK_API_KEY"
```

Open a **new** PowerShell window afterwards so the variables are picked up.

Start it inside your project. The `openai/` prefix tells Aider to use the OpenAI-compatible endpoint:

```powershell
cd path-to-your-project
aider --model openai/{{MODEL}}
```

## Qwen Code (terminal)

Install it (needs Node.js 22 or newer):

```powershell
npm install -g @qwen-code/qwen-code@latest
```

Create `C:\Users\YOUR_USERNAME\.qwen\.env` with:

```bash
OPENAI_API_KEY=YOUR_AEROLINK_API_KEY
OPENAI_BASE_URL={{BASE_URL}}/v1
OPENAI_MODEL={{MODEL}}
```

Run `qwen` inside your project. If it asks how to sign in, choose the **OpenAI**-compatible option (you can change it later with `/auth`).

## Crush (terminal)

Save the token as the `AEROLINK_API_KEY` environment variable:

Store the token in a user environment variable, then open a **new** PowerShell window so it is picked up.

```powershell
setx AEROLINK_API_KEY "YOUR_AEROLINK_API_KEY"
```

Then add these lines to `C:\Users\YOUR_USERNAME\.config\crush\crushrc`:

```bash
provider add aerolink --type openai-compat \
  --base-url "{{BASE_URL}}/v1" \
  --api-key "$AEROLINK_API_KEY"

model add aerolink/{{MODEL}} \
  --name "{{MODEL}}" \
  --context-window 128000 \
  --default-max-tokens 8192
```

## Zed (editor)

Add a provider to Zed's `settings.json` (**Zed → Settings → Open Settings**):

```json
{
  "language_models": {
    "openai_compatible": {
      "aerolink": {
        "api_url": "{{BASE_URL}}/v1",
        "available_models": [
          { "name": "{{MODEL}}", "display_name": "AeroLink {{MODEL}}", "max_tokens": 128000 }
        ]
      }
    }
  }
}
```

Don't put the token in `settings.json`. Either enter it in the Agent panel (**agent: open settings → LLM Providers → aerolink**), or save it as the `AEROLINK_API_KEY` environment variable — Zed looks for `<PROVIDER_ID>_API_KEY`:

Store the token in a user environment variable, then open a **new** PowerShell window so it is picked up.

```powershell
setx AEROLINK_API_KEY "YOUR_AEROLINK_API_KEY"
```

## Any other tool

Look for a setting called **OpenAI-compatible**, **Custom provider**, **Custom base URL** or **OpenAI API base**, then use the four values at the top of this page. Tools built on the Anthropic API use the Anthropic base URL instead (no `/v1`).

## Troubleshooting

| Error | What it means | What to do |
|---|---|---|
| `401` Invalid or missing token | The token is wrong, revoked, or not loaded in this terminal | Copy it again from API Access. If you saved it as an environment variable, open a new terminal. |
| `402` Balance exhausted | Your balance can't cover the request | Recharge from your dashboard. |
| `403` Account not active | Your account is suspended or still waiting for activation | Contact us through the store. |
| `404` Model not available | That model name is not on your plan | Use a model `id` from the API Access page (or from `/v1/models`). |
| `429` Too many requests | You hit your plan's per-minute or parallel-request limit | Wait a few seconds. Agents retry automatically. |
| `5xx` Upstream error | The model provider failed | Retry after a few seconds. |

Every response carries an `x-request-id` header (it starts with `req_`). Include it when you contact support — it lets us find your exact request.

## FAQ

**Which model should I use?**

The API Access page lists every model available on your plan with its price per million tokens. `{{MODEL}}` is used in this guide as an example; replace it with any model from that list.

**Is my tool supported if it isn't listed here?**

Very likely. AeroLink speaks the same API as OpenAI (Chat Completions) and Anthropic (Messages). Anything that lets you change the base URL for either one will work.

**Where does my usage show up?**

Every request is metered by the AeroLink gateway. **Activity Logs** shows each request with its model, tokens and cost, and your balance history on the dashboard lists every charge.
