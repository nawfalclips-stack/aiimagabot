# API & SDKs — Windows

## What is this?

You do not need a coding agent to use AeroLink. Any OpenAI-compatible or Anthropic-compatible SDK, or plain HTTP, works with the same token and balance.

- OpenAI-compatible base URL: `{{BASE_URL}}/v1`
- Anthropic-compatible base URL: `{{BASE_URL}}`

## 01 — Create your AeroLink API token

Open **API Access** in your dashboard and press **Create token**. Copy the token — it starts with `al_` — and use it wherever the steps below say `YOUR_AEROLINK_API_KEY`.

> Treat the token like a password: anyone who has it can spend your balance. If it leaks, revoke it on the API Access page and create a new one.

## 02 — List the models on your plan

```bash
curl.exe {{BASE_URL}}/v1/models -H "Authorization: Bearer YOUR_AEROLINK_API_KEY"
```

Use any `id` from the response as the model. `{{MODEL}}` is used below as an example.

## 03 — OpenAI-compatible (Chat Completions)

**Python**

```python
from openai import OpenAI

client = OpenAI(api_key="YOUR_AEROLINK_API_KEY", base_url="{{BASE_URL}}/v1")

response = client.chat.completions.create(
    model="{{MODEL}}",
    messages=[{"role": "user", "content": "Hello!"}],
)
print(response.choices[0].message.content)
```

**Node.js / TypeScript**

```typescript
import OpenAI from "openai";

const client = new OpenAI({ apiKey: "YOUR_AEROLINK_API_KEY", baseURL: "{{BASE_URL}}/v1" });

const response = await client.chat.completions.create({
  model: "{{MODEL}}",
  messages: [{ role: "user", content: "Hello!" }],
});
console.log(response.choices[0].message.content);
```

**Streaming (Python)**

```python
stream = client.chat.completions.create(
    model="{{MODEL}}",
    messages=[{"role": "user", "content": "Write a haiku about APIs."}],
    stream=True,
)
for chunk in stream:
    if chunk.choices and chunk.choices[0].delta.content:
        print(chunk.choices[0].delta.content, end="", flush=True)
```

**cURL**

```bash
curl {{BASE_URL}}/v1/chat/completions \
  -H "Authorization: Bearer YOUR_AEROLINK_API_KEY" \
  -H "Content-Type: application/json" \
  -d '{"model": "{{MODEL}}", "messages": [{"role": "user", "content": "Hello!"}]}'
```

## 04 — Anthropic-compatible (Messages)

**Python**

```python
import anthropic

client = anthropic.Anthropic(api_key="YOUR_AEROLINK_API_KEY", base_url="{{BASE_URL}}")

message = client.messages.create(
    model="{{MODEL}}",
    max_tokens=1024,
    messages=[{"role": "user", "content": "Hello!"}],
)
print(message.content[0].text)
```

**Node.js / TypeScript**

```typescript
import Anthropic from "@anthropic-ai/sdk";

const client = new Anthropic({ apiKey: "YOUR_AEROLINK_API_KEY", baseURL: "{{BASE_URL}}" });

const message = await client.messages.create({
  model: "{{MODEL}}",
  max_tokens: 1024,
  messages: [{ role: "user", content: "Hello!" }],
});
console.log(message.content[0].text);
```

**cURL**

```bash
curl {{BASE_URL}}/v1/messages \
  -H "x-api-key: YOUR_AEROLINK_API_KEY" \
  -H "anthropic-version: 2023-06-01" \
  -H "content-type: application/json" \
  -d '{"model": "{{MODEL}}", "max_tokens": 1024, "messages": [{"role": "user", "content": "Hello!"}]}'
```

> Keep your token out of source code you share. Read it from an environment variable, e.g. `os.environ["AEROLINK_API_KEY"]` in Python or `process.env.AEROLINK_API_KEY` in Node.js.

## Troubleshooting

| Error | What it means | What to do |
|---|---|---|
| `401` Invalid or missing token | The token is wrong, revoked, or not loaded in this terminal | Copy it again from API Access. If you saved it as an environment variable, open a new terminal. |
| `402` Balance exhausted | Your balance can't cover the request | Recharge from your dashboard. |
| `403` Account not active | Your account is suspended or still waiting for activation | Contact us through the store. |
| `404` Model not available | That model name is not on your plan | Use a model `id` from the API Access page (or from `/v1/models`). |
| `429` Too many requests | You hit your plan's per-minute or parallel-request limit | Wait a few seconds. Agents retry automatically. |
| `5xx` Upstream error | The model provider failed | Retry after a few seconds. |

Every response carries an `x-request-id` header (it starts with `req_`). Include it when you contact support — it lets us find your exact request.

## FAQ

**Which model should I use?**

The API Access page lists every model available on your plan with its price per million tokens. `{{MODEL}}` is used in this guide as an example; replace it with any model from that list.

**Where does my usage show up?**

Every request is metered by the AeroLink gateway. **Activity Logs** shows each request with its model, tokens and cost, and your balance history on the dashboard lists every charge.
