# Claude Desktop — Linux

## What is this?

Claude Desktop, the Claude app that can send its chats, Cowork and Code sessions through AeroLink, is published for **Windows and macOS only**. There is no official Linux version.

On Linux, use one of these instead — they all run on your AeroLink token and balance:

- **Claude Code** — Anthropic's coding agent in the terminal. See the **Claude Code** guide, Linux tab.
- **OpenCode** or another agent — see the **OpenCode** and **More agents** guides.
- **Your own code** — see **API & SDKs** (base URL `{{BASE_URL}}`, model `{{MODEL}}`).

## Using Claude Desktop from another computer

If you also have a Windows PC or a Mac, open this guide's **Windows** or **macOS** tab and connect Claude Desktop there. Create the token on the **API Access** page; you can use the same AeroLink token on several devices; they all spend the same balance, and every request is listed under **Activity Logs**.

> Unofficial Linux repackages of Claude Desktop exist. We don't support them: they may not include the third-party inference settings this setup needs.
