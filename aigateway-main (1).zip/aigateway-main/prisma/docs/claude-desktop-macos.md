# Claude Desktop — macOS

## What is this?

Claude Desktop (the Claude app for macOS) can send its chats, Cowork and Code sessions through AeroLink instead of a Claude subscription. You connect it once with your AeroLink token; every message is billed to your AeroLink balance and listed under **Activity Logs**.

Claude Desktop calls this **third-party inference** with an **LLM gateway**. AeroLink is that gateway.

- Gateway base URL: `{{BASE_URL}}`
- Model used as the example below: `{{MODEL}}`

> While Claude Desktop is connected to AeroLink it runs in third-party mode: you do not sign in with a Claude account, and your claude.ai conversations and subscription features are not available in the app.

## 01 — Install Claude Desktop

Download Claude for macOS from [claude.ai/download](https://claude.ai/download) and drag it into **Applications**. Open it once so it reaches the sign-in screen — **do not sign in**.

## 02 — Create your AeroLink API token

Open **API Access** in your dashboard and press **Create token**. Copy the token — it starts with `al_` — and use it wherever the steps below say `YOUR_AEROLINK_API_KEY`.

> Treat the token like a password: anyone who has it can spend your balance. If it leaks, revoke it on the API Access page and create a new one.

## 03 — Turn on Developer Mode

1. With Claude in front, open the **Help** menu in the macOS menu bar.
2. Go to **Help → Troubleshooting → Enable Developer Mode**.

A **Developer** menu appears in the menu bar.

## 04 — Connect Claude Desktop to AeroLink

1. Open **Developer → Configure Third-Party Inference…** in the menu bar.
2. In the **Connection** section, set **Inference provider** to **Gateway**.
3. Fill in the **Gateway credentials** card:

| Field | Value |
|---|---|
| Gateway base URL | `{{BASE_URL}}` |
| Gateway API key | `YOUR_AEROLINK_API_KEY` |
| Credential kind | **Static API key** |
| Gateway auth scheme | **Bearer** (the default — `x-api-key` works too) |

4. Use the window's connection test if it offers one, then press **Apply Changes**. Claude Desktop writes the configuration to this Mac and relaunches into it.

> The base URL has **no** `/v1` at the end. Claude Desktop adds `/v1/messages` itself.

## 05 — Pick a model

Claude Desktop reads the models on your plan from AeroLink automatically (`{{BASE_URL}}/v1/models`) and lists them in the model picker. Choose one — for example `{{MODEL}}` — and send a message.

If the picker is empty, open **Developer → Configure Third-Party Inference…** again, go to the **Models** section and add the model id by hand, exactly as it is written on the API Access page (for example `{{MODEL}}`). The first model in the list is the default.

## 06 — Check that it works

Send a short message such as "Reply with the single word: pong". Then open **Activity Logs** in your AeroLink dashboard: the request appears with its model, tokens and cost.

## Troubleshooting

| Problem | What it means | What to do |
|---|---|---|
| No **Developer** menu | Developer Mode is off | Repeat step 03 from the **Help** menu. |
| `401` / "authentication failed" | Wrong, revoked or incomplete token | Copy the token again from API Access and paste it into **Gateway API key**. |
| `402` / balance error | Your balance can't cover the request | Recharge from your dashboard. |
| `404` on every message | The base URL is wrong | Use `{{BASE_URL}}` exactly — no `/v1`, no trailing path. |
| `404` model not available | The model id is not on your plan | Pick a model id from the API Access page. |
| `429` Too many requests | Your plan's per-minute or parallel-request limit | Wait a few seconds; the app retries. Cowork runs several requests at once, so it reaches the limit sooner. |
| The window opens read-only | Your organisation manages Claude Desktop | A managed profile overrides local settings — ask your IT team. |

Every AeroLink response carries an `x-request-id` header (it starts with `req_`). Include it when you contact support.

## FAQ

**How do I go back to my Claude account?**

Open **Developer → Configure Third-Party Inference…**, clear the **Connection** settings, and press **Apply Changes**. The app relaunches to the normal sign-in screen.

**Is prompt caching supported?**

When the model's provider caches repeated input, the cached part of each request is billed at the lower cached price and shows in **Activity Logs** as "cached". Long sessions on the same model benefit most.

**Where do I see what it costs?**

**Activity Logs** lists each request with the model and the amount charged; your dashboard shows the latest ones under **Recent usage**.
