# Claude Code — macOS

## 01 — Install Claude Code

Recommended method: native installer. Alternative: Homebrew cask.

```bash
curl -fsSL https://claude.ai/install.sh | bash
# or
brew install --cask claude-code
```

## 02 — Create your AeroLink API token

Open **API Access** in your dashboard and press **Create token**. Copy the token — it starts with `al_` — and use it wherever the steps below say `YOUR_AEROLINK_API_KEY`.

> Treat the token like a password: anyone who has it can spend your balance. If it leaks, revoke it on the API Access page and create a new one.

## 03 — Create settings.json

Save this file at ~/.claude/settings.json.

```bash
mkdir -p ~/.claude
```

```json
{
  "env": {
    "ANTHROPIC_API_KEY": "YOUR_AEROLINK_API_KEY",
    "ANTHROPIC_BASE_URL": "{{BASE_URL}}",
    "ANTHROPIC_MODEL": "{{MODEL}}",
    "ANTHROPIC_DEFAULT_SONNET_MODEL": "{{MODEL}}",
    "ANTHROPIC_DEFAULT_OPUS_MODEL": "{{MODEL}}",
    "ANTHROPIC_DEFAULT_HAIKU_MODEL": "{{MODEL}}",
    "CLAUDE_CODE_DISABLE_NONESSENTIAL_TRAFFIC": "1"
  },
  "permissions": {
    "allow": [],
    "deny": []
  },
  "apiKeyHelper": "echo 'YOUR_AEROLINK_API_KEY'"
}
```

Replace both `YOUR_AEROLINK_API_KEY` values with your token. Claude Code sends every request to the AeroLink gateway, which serves the model named in `ANTHROPIC_MODEL` — pick it from the list on the API Access page. The three `ANTHROPIC_DEFAULT_*` lines point Claude Code's built-in Sonnet, Opus and Haiku choices at that same model, so switching with `/model` inside Claude Code does not change which model you are billed for.

## 04 — Check your token works

Run this before configuring any tool. A list of models means your token and connection are working — every `id` in it is a model name you can use.

```bash
curl {{BASE_URL}}/v1/models -H "Authorization: Bearer YOUR_AEROLINK_API_KEY"
```

## 05 — Verify and start

```bash
claude --version
claude doctor
cd path-to-your-project
claude
```

## Troubleshooting

| Error | What it means | What to do |
|---|---|---|
| `401` Invalid or missing token | The token is wrong, revoked, or not loaded in this terminal | Copy it again from API Access. If you saved it as an environment variable, open a new terminal. |
| `402` Balance exhausted | Your balance can't cover the request | Recharge from your dashboard. |
| `403` Account not active | Your account is suspended or still waiting for activation | Contact us through the store. |
| `404` Model not available | That model name is not on your plan | Use a model `id` from the API Access page (or from `/v1/models`). |
| `429` Too many requests | You hit your plan's per-minute or parallel-request limit | Wait a few seconds. Agents retry automatically. |
| `5xx` Upstream error | The model provider failed | Retry after a few seconds. |

Every response carries an `x-request-id` header (it starts with `req_`). Include it when you contact support — it lets us find your exact request.

## FAQ

**Which model should I use?**

The API Access page lists every model available on your plan with its price per million tokens. `{{MODEL}}` is used in this guide as an example; replace it with any model from that list.

**Why does `/model` not change what I'm billed for?**

The three `ANTHROPIC_DEFAULT_*` lines map Claude Code's built-in Sonnet, Opus and Haiku choices to the model you set. To use a different model, change all four `{{MODEL}}` values in settings.json and restart Claude Code.

**Which tool should I pick?**

Every tool works with the same AeroLink token and balance, so pick the one you like. Claude Code uses the Anthropic Messages API (`{{BASE_URL}}`). Codex, OpenCode and most other agents use the OpenAI Chat Completions API (`{{BASE_URL}}/v1`). The **More agents** guide covers Cline, Roo Code, Kilo Code, Continue, Aider, Qwen Code, Crush and Zed.

**Why does the guide mention Git?**

Git is not required for every command, but real projects use it for history, undo, branches, collaboration, and deployment. Agents also use Git status and diffs to avoid mixing unrelated work.

**Where does my usage show up?**

Every request is metered by the AeroLink gateway. **Activity Logs** shows each request with its model, tokens and cost, and your balance history on the dashboard lists every charge.
