# Codex CLI — macOS

## 01 — Install Codex CLI

Install Node.js LTS, then install Codex globally with npm.

```bash
npm install -g @openai/codex@0.80.0
```

> **Install exactly version 0.80.0.** Codex releases from February 2026 onwards only talk to providers that support OpenAI's newer Responses API. AeroLink uses the Chat Completions API, which Codex 0.80.0 supports. If Codex ever shows `wire_api = "chat" is no longer supported`, reinstall with the command above.

## 02 — Create your AeroLink API token

Open **API Access** in your dashboard and press **Create token**. Copy the token — it starts with `al_` — and use it wherever the steps below say `YOUR_AEROLINK_API_KEY`.

> Treat the token like a password: anyone who has it can spend your balance. If it leaks, revoke it on the API Access page and create a new one.

## 03 — Save the token for Codex

Add the token to your shell profile, then open a new terminal.

```bash
echo 'export AEROLINK_API_KEY="YOUR_AEROLINK_API_KEY"' >> ~/.zshrc
source ~/.zshrc
```

## 04 — Create the Codex settings folder

```bash
mkdir -p ~/.codex
```

## 05 — Create config.toml

Save this file at ~/.codex/config.toml. If the file already exists, replace the provider settings with these.

```toml
model_provider = "aerolink"
model = "{{MODEL}}"
disable_response_storage = true
preferred_auth_method = "apikey"

[model_providers.aerolink]
name = "aerolink"
base_url = "{{BASE_URL}}/v1"
wire_api = "chat"
env_key = "AEROLINK_API_KEY"
```

This routes Codex to the AeroLink gateway over the OpenAI Chat Completions API. To switch models, change `model` to any slug listed on the API Access page.

## 06 — Verify and start

```bash
codex --version   # should print 0.80.0
cd path-to-your-project
codex
```

The official VS Code extension reads the same config.toml.

## Troubleshooting

| Error | What it means | What to do |
|---|---|---|
| `401` Invalid or missing token | The token is wrong, revoked, or not loaded in this terminal | Copy it again from API Access. If you saved it as an environment variable, open a new terminal. |
| `402` Balance exhausted | Your balance can't cover the request | Recharge from your dashboard. |
| `403` Account not active | Your account is suspended or still waiting for activation | Contact us through the store. |
| `404` Model not available | That model name is not on your plan | Use a model `id` from the API Access page (or from `/v1/models`). |
| `429` Too many requests | You hit your plan's per-minute or parallel-request limit | Wait a few seconds. Agents retry automatically. |
| `5xx` Upstream error | The model provider failed | Retry after a few seconds. |
| `wire_api = "chat" is no longer supported` | A newer Codex version is installed | Reinstall with `npm install -g @openai/codex@0.80.0`. |

Every response carries an `x-request-id` header (it starts with `req_`). Include it when you contact support — it lets us find your exact request.

## FAQ

**Which model should I use?**

The API Access page lists every model available on your plan with its price per million tokens. `{{MODEL}}` is used in this guide as an example; replace it with any model from that list.

**Can I update Codex?**

Not yet — stay on 0.80.0. Newer releases dropped support for the Chat Completions API that AeroLink uses. This guide will be updated as soon as a newer version works.

**Which tool should I pick?**

Every tool works with the same AeroLink token and balance, so pick the one you like. Claude Code uses the Anthropic Messages API (`{{BASE_URL}}`). Codex, OpenCode and most other agents use the OpenAI Chat Completions API (`{{BASE_URL}}/v1`). The **More agents** guide covers Cline, Roo Code, Kilo Code, Continue, Aider, Qwen Code, Crush and Zed.

**Why does the guide mention Git?**

Git is not required for every command, but real projects use it for history, undo, branches, collaboration, and deployment. Agents also use Git status and diffs to avoid mixing unrelated work.

**Where does my usage show up?**

Every request is metered by the AeroLink gateway. **Activity Logs** shows each request with its model, tokens and cost, and your balance history on the dashboard lists every charge.
