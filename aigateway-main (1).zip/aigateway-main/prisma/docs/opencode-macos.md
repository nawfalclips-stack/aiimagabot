# OpenCode — macOS

OpenCode is an open-source coding agent for the terminal. It connects to AeroLink as an OpenAI-compatible provider.

## 01 — Install OpenCode

```bash
brew install anomalyco/tap/opencode
# or
curl -fsSL https://opencode.ai/install | bash
# or
npm install -g opencode-ai
```

Check it installed:

```bash
opencode --version
```

## 02 — Create your AeroLink API token

Open **API Access** in your dashboard and press **Create token**. Copy the token — it starts with `al_` — and use it wherever the steps below say `YOUR_AEROLINK_API_KEY`.

> Treat the token like a password: anyone who has it can spend your balance. If it leaks, revoke it on the API Access page and create a new one.

## 03 — Save the token

Add the token to your shell profile so every new terminal has it.

```bash
echo 'export AEROLINK_API_KEY="YOUR_AEROLINK_API_KEY"' >> ~/.zshrc
source ~/.zshrc
```

## 04 — Check your token works

Run this before configuring any tool. A list of models means your token and connection are working — every `id` in it is a model name you can use.

```bash
curl {{BASE_URL}}/v1/models -H "Authorization: Bearer YOUR_AEROLINK_API_KEY"
```

## 05 — Create opencode.json

Open (or create) the global config file at `~/.config/opencode/opencode.json`:

```bash
mkdir -p ~/.config/opencode
open -e ~/.config/opencode/opencode.json 2>/dev/null || nano ~/.config/opencode/opencode.json
```

Paste this configuration and save:

```json
{
  "$schema": "https://opencode.ai/config.json",
  "provider": {
    "aerolink": {
      "npm": "@ai-sdk/openai-compatible",
      "name": "AeroLink",
      "options": {
        "baseURL": "{{BASE_URL}}/v1",
        "apiKey": "{env:AEROLINK_API_KEY}"
      },
      "models": {
        "{{MODEL}}": {
          "name": "{{MODEL}}",
          "limit": { "context": 128000, "output": 8192 }
        }
      }
    }
  },
  "model": "aerolink/{{MODEL}}",
  "small_model": "aerolink/{{MODEL}}"
}
```

OpenCode reads the token from the `AEROLINK_API_KEY` environment variable you saved in step 03, so the config file itself contains no secret.

- **More models:** add one entry per model under `"models"`, using the model ids from the API Access page.
- **`small_model`** is what OpenCode uses in the background (for example to name sessions). Pointing it at AeroLink keeps those requests on your AeroLink balance too.
- **`limit`** tells OpenCode how much text the model accepts (`context`) and can write (`output`). OpenCode uses it to decide when to compact long conversations.

> Already have an `opencode.json` with other providers? Don't replace it — add the `"aerolink"` block inside your existing `"provider"` object.

## 06 — Start OpenCode

```bash
cd path-to-your-project
opencode
```

Type `/models` and pick **AeroLink → {{MODEL}}** if it isn't already selected. For a quick one-shot test without the full interface:

```bash
opencode run -m aerolink/{{MODEL}} "list the files in this folder"
```

## Troubleshooting

| Error | What it means | What to do |
|---|---|---|
| `401` Invalid or missing token | The token is wrong, revoked, or not loaded in this terminal | Copy it again from API Access. If you saved it as an environment variable, open a new terminal. |
| `402` Balance exhausted | Your balance can't cover the request | Recharge from your dashboard. |
| `403` Account not active | Your account is suspended or still waiting for activation | Contact us through the store. |
| `404` Model not available | That model name is not on your plan | Use a model `id` from the API Access page (or from `/v1/models`). |
| `429` Too many requests | You hit your plan's per-minute or parallel-request limit | Wait a few seconds. Agents retry automatically. |
| `5xx` Upstream error | The model provider failed | Retry after a few seconds. |

Every response carries an `x-request-id` header (it starts with `req_`). Include it when you contact support — it lets us find your exact request.

## FAQ

**Which model should I use?**

The API Access page lists every model available on your plan with its price per million tokens. `{{MODEL}}` is used in this guide as an example; replace it with any model from that list.

**Can I keep a separate config per project?**

Yes. An `opencode.json` in a project folder is merged with the global one, and the project file wins where they overlap.

**Which tool should I pick?**

Every tool works with the same AeroLink token and balance, so pick the one you like. Claude Code uses the Anthropic Messages API (`{{BASE_URL}}`). Codex, OpenCode and most other agents use the OpenAI Chat Completions API (`{{BASE_URL}}/v1`). The **More agents** guide covers Cline, Roo Code, Kilo Code, Continue, Aider, Qwen Code, Crush and Zed.

**Where does my usage show up?**

Every request is metered by the AeroLink gateway. **Activity Logs** shows each request with its model, tokens and cost, and your balance history on the dashboard lists every charge.
