# Skills — macOS

## What are skills?

A **skill** is a folder with a `SKILL.md` file: written instructions — sometimes with small scripts or templates — that teach your coding agent how to do one job well, such as building a polished interface, testing a web app, or writing a Word document. The agent reads the short description of every installed skill and loads the full instructions only when a task needs them.

Skills are an **open format**: the same folder works in Claude Code, Codex CLI, OpenCode and many other agents. They run inside your tool, so **they work with every model on your AeroLink plan** — nothing to configure on our side.

> Before you start, make sure your tool is already connected to AeroLink (base URL `{{BASE_URL}}`, token from **API Access**). See the guide for your tool.

## Where each tool looks for skills

Personal skills are available in every project on this computer; project skills live in the repository and can be shared with your team.

| Tool | Personal skills | Project skills | How to use one |
|---|---|---|---|
| Claude Code | `~/.claude/skills` | `.claude/skills` | automatic, or type `/skill-name` |
| Codex CLI | `~/.agents/skills` | `.agents/skills` | automatic, or type `$skill-name` · `/skills` lists them |
| OpenCode | `~/.config/opencode/skills` | `.opencode/skills` | automatic (OpenCode also reads the Claude Code and `.agents` folders) |

Each skill is its own folder: `<skills folder>/<skill-name>/SKILL.md`.

## 01 — Install the official Anthropic skills (Claude Code)

Anthropic publishes a free collection of skills. Inside Claude Code, run:

```text
/plugin marketplace add anthropics/skills
/plugin install example-skills@anthropic-agent-skills
/plugin install document-skills@anthropic-agent-skills
```

`example-skills` brings design, development and writing skills; `document-skills` adds Word, Excel, PowerPoint and PDF. Restart Claude Code, then ask naturally — for example *"Use the PDF skill to extract the form fields from invoice.pdf"*.

## 02 — Install any skill for any tool (one command)

The open `skills` installer (run by Vercel, directory at [skills.sh](https://skills.sh)) copies a skill into the right folder for the agents you use. It needs Node.js — Install Node.js 18 or newer — `brew install node`, or the installer from [nodejs.org](https://nodejs.org).

```bash
npx skills add anthropics/skills
```

Replace `anthropics/skills` with the GitHub repository of the skill you want (see the list below). The installer asks which skills and which agents to install for.

In **Codex CLI** you can also use the built-in installer: type `$skill-installer` followed by the skill name.

## 03 — Install a skill by hand

Every skill is just a folder, so copying it works everywhere. Example in Terminal — the `frontend-design` skill for Claude Code:

```bash
git clone --depth 1 https://github.com/anthropics/skills.git /tmp/anthropic-skills
mkdir -p ~/.claude/skills
cp -R /tmp/anthropic-skills/skills/frontend-design ~/.claude/skills/
ls ~/.claude/skills/frontend-design
```

For Codex CLI copy it into `~/.agents/skills` instead; for OpenCode into `~/.config/opencode/skills`. Restart the tool afterwards.

## Recommended skills

| Skill | What it does | Where to get it |
|---|---|---|
| **frontend-design** | Distinctive, production-grade interfaces instead of generic-looking pages | `anthropics/skills` |
| **webapp-testing** | Tests your web app in a real browser (Playwright) and reports what breaks | `anthropics/skills` |
| **mcp-builder** | Guides you through building an MCP server that connects the agent to an API | `anthropics/skills` |
| **skill-creator** | Helps you write, test and improve your own skills | `anthropics/skills` |
| **docx · xlsx · pptx · pdf** | Create and edit Word, Excel, PowerPoint and PDF files | `anthropics/skills` (document skills) |
| **doc-coauthoring** | Co-writes specs, proposals and other documents with you step by step | `anthropics/skills` |
| **Superpowers** | A full workflow: brainstorming, planning, test-driven development, systematic debugging, git worktrees | `obra/superpowers` |
| **find-skills** | Searches the skills directory and installs what fits your task | `vercel-labs/skills` |
| **agent-browser** | Lets the agent drive a browser: open pages, click, fill forms, take screenshots | `vercel-labs/agent-browser` |
| **react-best-practices** | React and Next.js performance and code-quality rules | `vercel-labs/agent-skills` |

**Superpowers** installs as a Claude Code plugin:

```text
/plugin marketplace add obra/superpowers-marketplace
/plugin install superpowers@superpowers-marketplace
```

Browse thousands more at [skills.sh](https://skills.sh) or in the [anthropics/skills](https://github.com/anthropics/skills) repository.

## Write your own skill

A skill needs only a name, a description that says **when** to use it, and the instructions. Create the folder and file:

```bash
mkdir -p ~/.claude/skills/release-notes
open -e ~/.claude/skills/release-notes/SKILL.md 2>/dev/null || nano ~/.claude/skills/release-notes/SKILL.md
```

Put this in `SKILL.md`:

```markdown
---
name: release-notes
description: Write release notes from the git log. Use when the user asks for release notes, a changelog or "what changed".
---

1. Run `git log --oneline` since the last tag.
2. Group the commits into Added, Changed and Fixed.
3. Write one plain sentence per change, for customers, not developers.
```

Restart your tool and ask *"write the release notes"* — or in Claude Code type `/release-notes`.

## Good to know

- **Skills cost tokens.** The descriptions of all installed skills are sent with each request, and a skill's full instructions when it is used. Install the ones you actually use; your cost per request is always visible in **Activity Logs**.
- **Only install skills you trust.** A skill can tell the agent to run scripts on your computer. Prefer well-known repositories and read the `SKILL.md` first.
- **Pick a model that supports tool calling.** Skills that run scripts or edit files need it — choose one from your **API Access** page.

## Troubleshooting

| Problem | What to check |
|---|---|
| The skill is never used | Restart the tool. Check the folder is `<skills folder>/<skill-name>/SKILL.md` and the `description` says when to use it. |
| `/skill-name` is not found (Claude Code) | The folder name is the command. List your skills: `ls ~/.claude/skills` |
| `npx skills` fails | Install Node.js 18+ and open a new terminal. |
| A skill's script fails | The skill may need extra tools (Python, Playwright…). Its `SKILL.md` lists them. |

## FAQ

**Do skills work with every model on my plan?**

Yes. Skills are instructions your tool gives the model; any model on your plan can follow them. Larger models follow long skills more reliably.

**Do I pay for skills?**

The skills in this guide are free. You only pay for the tokens they add to your requests, like any other text.
