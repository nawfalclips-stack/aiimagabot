-- Add role column to Admin table
ALTER TABLE "Admin" ADD COLUMN IF NOT EXISTS "role" TEXT NOT NULL DEFAULT 'FULL_ACCESS';

-- Add comment for role field
COMMENT ON COLUMN "Admin"."role" IS 'Admin role: FULL_ACCESS, API_VIEWER, or STATISTICS_ONLY';

-- Update existing admins based on isReadOnly flag
UPDATE "Admin"
SET "role" = CASE
  WHEN "isReadOnly" = true THEN 'API_VIEWER'
  ELSE 'FULL_ACCESS'
END
WHERE "role" = 'FULL_ACCESS';
