-- Migration: Add subdomain to Store and role to Admin
-- Run this on your production database

-- 1. Add subdomain to Store
ALTER TABLE "Store" ADD COLUMN IF NOT EXISTS "subdomain" TEXT;

-- 2. Make subdomain unique
CREATE UNIQUE INDEX IF NOT EXISTS "Store_subdomain_key" ON "Store"("subdomain");

-- 3. Set default subdomains for existing stores
UPDATE "Store" SET "subdomain" = LOWER(id) WHERE "subdomain" IS NULL;

-- 4. Make subdomain NOT NULL now that we have values
ALTER TABLE "Store" ALTER COLUMN "subdomain" SET NOT NULL;

-- 5. Add role to Admin
ALTER TABLE "Admin" ADD COLUMN IF NOT EXISTS "role" TEXT NOT NULL DEFAULT 'FULL_ACCESS';

-- 6. Update existing admins based on isReadOnly
UPDATE "Admin"
SET "role" = CASE
  WHEN "isReadOnly" = true THEN 'API_VIEWER'
  ELSE 'FULL_ACCESS'
END
WHERE "role" = 'FULL_ACCESS';

-- Verify the changes
SELECT id, name, subdomain FROM "Store";
SELECT email, name, role, "isReadOnly" FROM "Admin";
