-- AlterTable
ALTER TABLE "Customer" ADD COLUMN     "balanceCarryMicroUsd" BIGINT NOT NULL DEFAULT 0,
ADD COLUMN     "bonusCarryMicroUsd" BIGINT NOT NULL DEFAULT 0,
ADD COLUMN     "reservedMicroUsd" BIGINT NOT NULL DEFAULT 0;

-- AlterTable
ALTER TABLE "UsageLog" ADD COLUMN     "customerMicroUsd" BIGINT,
ADD COLUMN     "requestId" TEXT,
ADD COLUMN     "reservationId" TEXT,
ADD COLUMN     "uncollectedMicroUsd" BIGINT NOT NULL DEFAULT 0;

-- CreateTable
CREATE TABLE "LedgerEntry" (
    "id" TEXT NOT NULL,
    "storeId" TEXT NOT NULL,
    "customerId" TEXT NOT NULL,
    "pot" TEXT NOT NULL,
    "type" TEXT NOT NULL,
    "amountMicroUsd" BIGINT NOT NULL,
    "balanceAfterMicroUsd" BIGINT NOT NULL,
    "refType" TEXT NOT NULL DEFAULT '',
    "refId" TEXT NOT NULL DEFAULT '',
    "idempotencyKey" TEXT NOT NULL,
    "actorAdminId" TEXT,
    "actorLabel" TEXT NOT NULL DEFAULT '',
    "note" TEXT NOT NULL DEFAULT '',
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "LedgerEntry_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "GatewayReservation" (
    "id" TEXT NOT NULL,
    "storeId" TEXT NOT NULL,
    "customerId" TEXT NOT NULL,
    "amountMicroUsd" BIGINT NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'HELD',
    "mode" TEXT NOT NULL DEFAULT 'enforce',
    "model" TEXT NOT NULL DEFAULT '',
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "expiresAt" TIMESTAMP(3) NOT NULL,
    "settledAt" TIMESTAMP(3),
    "chargedMicroUsd" BIGINT,

    CONSTRAINT "GatewayReservation_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "LedgerEntry_idempotencyKey_key" ON "LedgerEntry"("idempotencyKey");

-- CreateIndex
CREATE INDEX "LedgerEntry_storeId_customerId_createdAt_idx" ON "LedgerEntry"("storeId", "customerId", "createdAt");

-- CreateIndex
CREATE INDEX "LedgerEntry_refType_refId_idx" ON "LedgerEntry"("refType", "refId");

-- CreateIndex
CREATE INDEX "GatewayReservation_status_expiresAt_idx" ON "GatewayReservation"("status", "expiresAt");

-- CreateIndex
CREATE INDEX "GatewayReservation_customerId_createdAt_idx" ON "GatewayReservation"("customerId", "createdAt");

-- CreateIndex
CREATE UNIQUE INDEX "UsageLog_requestId_key" ON "UsageLog"("requestId");

-- AddForeignKey
ALTER TABLE "LedgerEntry" ADD CONSTRAINT "LedgerEntry_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES "Customer"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "GatewayReservation" ADD CONSTRAINT "GatewayReservation_customerId_fkey" FOREIGN KEY ("customerId") REFERENCES "Customer"("id") ON DELETE CASCADE ON UPDATE CASCADE;


-- Data: the single gateway carry becomes the balance pot's carry. The old
-- column stays (unused) for one release per the expand/contract rule.
UPDATE "Customer" SET "balanceCarryMicroUsd" = "gatewayCarryMicroUsd" WHERE "gatewayCarryMicroUsd" <> 0;
