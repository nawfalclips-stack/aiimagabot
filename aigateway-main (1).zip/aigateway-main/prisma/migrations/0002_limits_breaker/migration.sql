-- AlterTable
ALTER TABLE "Plan" ADD COLUMN     "maxConcurrent" INTEGER,
ADD COLUMN     "rpm" INTEGER;

-- AlterTable
ALTER TABLE "Provider" ADD COLUMN     "breakerFailureThreshold" INTEGER,
ADD COLUMN     "breakerOpenMs" INTEGER,
ADD COLUMN     "breakerWindowMs" INTEGER,
ADD COLUMN     "totalTimeoutMs" INTEGER,
ADD COLUMN     "ttfbTimeoutMs" INTEGER;

-- AlterTable
ALTER TABLE "GatewayModel" ADD COLUMN     "isReasoning" BOOLEAN NOT NULL DEFAULT false;

-- AlterTable
ALTER TABLE "ProviderModel" ADD COLUMN     "ttfbTimeoutMs" INTEGER;

-- Data: decision #3 limits for the seeded plan names (only where unset).
UPDATE "Plan" SET "rpm" = 20, "maxConcurrent" = 4  WHERE "name" = 'Starter'  AND "rpm" IS NULL;
UPDATE "Plan" SET "rpm" = 30, "maxConcurrent" = 8  WHERE "name" = 'Plus'     AND "rpm" IS NULL;
UPDATE "Plan" SET "rpm" = 40, "maxConcurrent" = 16 WHERE "name" = 'Pro'      AND "rpm" IS NULL;
UPDATE "Plan" SET "rpm" = 50, "maxConcurrent" = 32 WHERE "name" = 'Ultimate' AND "rpm" IS NULL;
