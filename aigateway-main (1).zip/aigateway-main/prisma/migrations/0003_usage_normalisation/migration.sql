-- AlterTable
ALTER TABLE "UsageLog" ADD COLUMN     "cacheWriteTokens" INTEGER,
ADD COLUMN     "inputCachedTokens" INTEGER,
ADD COLUMN     "outcome" TEXT NOT NULL DEFAULT '',
ADD COLUMN     "rawUsage" TEXT NOT NULL DEFAULT '',
ADD COLUMN     "reasoningTokens" INTEGER,
ADD COLUMN     "usageSource" TEXT NOT NULL DEFAULT '';

-- AlterTable
ALTER TABLE "Plan" ADD COLUMN     "cachedTokenWeightPct" INTEGER NOT NULL DEFAULT 100;

-- AlterTable
ALTER TABLE "Provider" ADD COLUMN     "supportsStreamUsage" BOOLEAN NOT NULL DEFAULT true,
ADD COLUMN     "usageDialect" TEXT NOT NULL DEFAULT 'openai';

-- AlterTable
ALTER TABLE "GatewayModel" ADD COLUMN     "cacheWritePriceMicroPerMTok" INTEGER,
ADD COLUMN     "cachedInputPriceMicroPerMTok" INTEGER;


-- Data: providers on deepinfra.com report usage in the DeepInfra dialect.
UPDATE "Provider" SET "usageDialect" = 'deepinfra' WHERE "baseUrl" LIKE '%deepinfra.com%';
