-- Phase 5 (WS8/WS9): packs, vouchers, activation/recharge sources. Additive only.

-- AlterTable
ALTER TABLE "Customer" ADD COLUMN     "activationSource" TEXT NOT NULL DEFAULT 'ORDER_ID',
ADD COLUMN     "activationVoucherId" TEXT,
ADD COLUMN     "packId" TEXT;

-- AlterTable
ALTER TABLE "RechargeRequest" ADD COLUMN     "packId" TEXT,
ADD COLUMN     "source" TEXT NOT NULL DEFAULT 'ORDER_ID',
ADD COLUMN     "voucherId" TEXT;

-- CreateTable
CREATE TABLE "Pack" (
    "id" TEXT NOT NULL,
    "storeId" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "planId" TEXT NOT NULL,
    "balanceGrantMicroUsd" BIGINT NOT NULL DEFAULT 0,
    "bonusGrantMicroUsd" BIGINT NOT NULL DEFAULT 0,
    "listingPriceLabel" TEXT NOT NULL DEFAULT '',
    "gamsgoOfferRef" TEXT,
    "active" BOOLEAN NOT NULL DEFAULT true,
    "sortOrder" INTEGER NOT NULL DEFAULT 0,
    "deletedAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Pack_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "VoucherBatch" (
    "id" TEXT NOT NULL,
    "storeId" TEXT NOT NULL,
    "packId" TEXT NOT NULL,
    "quantity" INTEGER NOT NULL,
    "channel" TEXT NOT NULL DEFAULT 'GAMSGO',
    "createdByAdminId" TEXT,
    "note" TEXT NOT NULL DEFAULT '',
    "exportedAt" TIMESTAMP(3),
    "markedUploadedAt" TIMESTAMP(3),
    "expiresAt" TIMESTAMP(3),
    "compromisedAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "VoucherBatch_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "Voucher" (
    "id" TEXT NOT NULL,
    "storeId" TEXT NOT NULL,
    "batchId" TEXT NOT NULL,
    "packId" TEXT NOT NULL,
    "codeHmac" TEXT NOT NULL,
    "codeLast4" TEXT NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'ISSUED',
    "redeemedByCustomerId" TEXT,
    "redeemedAt" TIMESTAMP(3),
    "redeemIpHash" TEXT,
    "gamsgoOrderId" TEXT,
    "revokedReason" TEXT,
    "revokedByAdminId" TEXT,
    "clawedBackAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Voucher_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "Pack_storeId_sortOrder_idx" ON "Pack"("storeId", "sortOrder");

-- CreateIndex
CREATE INDEX "VoucherBatch_storeId_createdAt_idx" ON "VoucherBatch"("storeId", "createdAt");

-- CreateIndex
CREATE INDEX "VoucherBatch_packId_idx" ON "VoucherBatch"("packId");

-- CreateIndex
CREATE UNIQUE INDEX "Voucher_codeHmac_key" ON "Voucher"("codeHmac");

-- CreateIndex
CREATE INDEX "Voucher_storeId_status_idx" ON "Voucher"("storeId", "status");

-- CreateIndex
CREATE INDEX "Voucher_batchId_status_idx" ON "Voucher"("batchId", "status");

-- CreateIndex
CREATE INDEX "Voucher_codeLast4_idx" ON "Voucher"("codeLast4");

-- CreateIndex
CREATE INDEX "Voucher_redeemedByCustomerId_idx" ON "Voucher"("redeemedByCustomerId");

-- CreateIndex
CREATE INDEX "Voucher_gamsgoOrderId_idx" ON "Voucher"("gamsgoOrderId");

-- AddForeignKey
ALTER TABLE "Customer" ADD CONSTRAINT "Customer_packId_fkey" FOREIGN KEY ("packId") REFERENCES "Pack"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "RechargeRequest" ADD CONSTRAINT "RechargeRequest_packId_fkey" FOREIGN KEY ("packId") REFERENCES "Pack"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Pack" ADD CONSTRAINT "Pack_planId_fkey" FOREIGN KEY ("planId") REFERENCES "Plan"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "VoucherBatch" ADD CONSTRAINT "VoucherBatch_packId_fkey" FOREIGN KEY ("packId") REFERENCES "Pack"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Voucher" ADD CONSTRAINT "Voucher_batchId_fkey" FOREIGN KEY ("batchId") REFERENCES "VoucherBatch"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "Voucher" ADD CONSTRAINT "Voucher_packId_fkey" FOREIGN KEY ("packId") REFERENCES "Pack"("id") ON DELETE RESTRICT ON UPDATE CASCADE;


-- Data step: one pack per existing active plan so approvals can pick one
-- right away. Grants default to the plan's price; the admin edits from
-- /admin/packs. Idempotent (fixed ids derived from the plan id).
INSERT INTO "Pack" ("id", "storeId", "name", "planId", "balanceGrantMicroUsd", "bonusGrantMicroUsd", "listingPriceLabel", "active", "sortOrder", "createdAt", "updatedAt")
SELECT 'pack_' || p."id", p."storeId", p."name", p."id", CAST(p."priceCents" AS BIGINT) * 10000, 0,
       '$' || (p."priceCents" / 100) || ' on GamsGo', p."isActive", p."sortOrder", NOW(), NOW()
FROM "Plan" p
WHERE NOT EXISTS (SELECT 1 FROM "Pack" k WHERE k."id" = 'pack_' || p."id");
