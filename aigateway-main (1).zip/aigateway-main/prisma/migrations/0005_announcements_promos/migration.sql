-- Customer announcements (inbox + recharge promotions + new-model notices). Additive only.

-- AlterTable
ALTER TABLE "RechargeRequest" ADD COLUMN     "promoAnnouncementId" TEXT,
ADD COLUMN     "promoBonusPct" INTEGER NOT NULL DEFAULT 0;

-- CreateTable
CREATE TABLE "Announcement" (
    "id" TEXT NOT NULL,
    "storeId" TEXT NOT NULL,
    "kind" TEXT NOT NULL DEFAULT 'INFO',
    "title" TEXT NOT NULL,
    "message" TEXT NOT NULL,
    "rechargeBonusPct" INTEGER NOT NULL DEFAULT 0,
    "modelSlug" TEXT,
    "customerId" TEXT,
    "startsAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "endsAt" TIMESTAMP(3),
    "archivedAt" TIMESTAMP(3),
    "createdByAdminId" TEXT,
    "createdByLabel" TEXT NOT NULL DEFAULT '',
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "Announcement_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "AnnouncementRead" (
    "id" TEXT NOT NULL,
    "announcementId" TEXT NOT NULL,
    "customerId" TEXT NOT NULL,
    "readAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "AnnouncementRead_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "Announcement_storeId_startsAt_idx" ON "Announcement"("storeId", "startsAt");

-- CreateIndex
CREATE INDEX "Announcement_customerId_idx" ON "Announcement"("customerId");

-- CreateIndex
CREATE INDEX "AnnouncementRead_customerId_idx" ON "AnnouncementRead"("customerId");

-- CreateIndex
CREATE UNIQUE INDEX "AnnouncementRead_announcementId_customerId_key" ON "AnnouncementRead"("announcementId", "customerId");

-- AddForeignKey
ALTER TABLE "AnnouncementRead" ADD CONSTRAINT "AnnouncementRead_announcementId_fkey" FOREIGN KEY ("announcementId") REFERENCES "Announcement"("id") ON DELETE CASCADE ON UPDATE CASCADE;
