-- Public model alias shown to customers instead of the internal slug / display name. Additive only.

-- AlterTable
ALTER TABLE "GatewayModel" ADD COLUMN     "aliasName" TEXT NOT NULL DEFAULT '',
ADD COLUMN     "aliasSlug" TEXT;

-- CreateIndex
CREATE UNIQUE INDEX "GatewayModel_aliasSlug_key" ON "GatewayModel"("aliasSlug");
