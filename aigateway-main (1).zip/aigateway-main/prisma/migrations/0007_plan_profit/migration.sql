-- Profit per plan, recorded automatically on every purchase. Additive only.

-- AlterTable
ALTER TABLE "Plan" ADD COLUMN     "profitCents" INTEGER NOT NULL DEFAULT 0;

-- AlterTable
ALTER TABLE "ProfitHistory" ADD COLUMN     "idempotencyKey" TEXT,
ADD COLUMN     "planId" TEXT,
ADD COLUMN     "source" TEXT NOT NULL DEFAULT 'MANUAL';

-- CreateIndex
CREATE UNIQUE INDEX "ProfitHistory_idempotencyKey_key" ON "ProfitHistory"("idempotencyKey");

-- CreateIndex
CREATE INDEX "ProfitHistory_planId_idx" ON "ProfitHistory"("planId");
