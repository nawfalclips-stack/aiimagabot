-- Admin password changes log out other sessions. Additive only.

-- AlterTable
ALTER TABLE "Admin" ADD COLUMN     "passwordChangedAt" TIMESTAMP(3);
