-- Plan bonus and the real usage it is worth; bonus share of real cost per usage row. Additive only.

-- AlterTable
ALTER TABLE "Plan" ADD COLUMN     "bonusCents" INTEGER NOT NULL DEFAULT 0,
ADD COLUMN     "bonusLimitMTokens" INTEGER NOT NULL DEFAULT 0,
ADD COLUMN     "bonusLimitUsageCents" INTEGER NOT NULL DEFAULT 0;

-- AlterTable
ALTER TABLE "UsageLog" ADD COLUMN     "bonusCostMicroUsd" INTEGER NOT NULL DEFAULT 0;
