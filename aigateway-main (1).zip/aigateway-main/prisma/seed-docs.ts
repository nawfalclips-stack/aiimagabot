import { readFileSync } from "fs";
import { join } from "path";
import type { PrismaClient } from "@prisma/client";

// The documentation source of truth lives in prisma/docs/*.md. {{BASE_URL}}
// and {{MODEL}} are filled in at render time in the customer portal (WS7).
const DOCS: { slug: string; category: string; os: string; title: string; file: string; sortOrder: number }[] = [
  { slug: "claude-windows", category: "CLAUDE", os: "WINDOWS", title: "Claude Code — Windows", file: "claude-windows.md", sortOrder: 0 },
  { slug: "claude-macos", category: "CLAUDE", os: "MACOS", title: "Claude Code — macOS", file: "claude-macos.md", sortOrder: 1 },
  { slug: "claude-linux", category: "CLAUDE", os: "LINUX", title: "Claude Code — Linux", file: "claude-linux.md", sortOrder: 2 },
  { slug: "claude-desktop-windows", category: "DESKTOP", os: "WINDOWS", title: "Claude Desktop — Windows", file: "claude-desktop-windows.md", sortOrder: 0 },
  { slug: "claude-desktop-macos", category: "DESKTOP", os: "MACOS", title: "Claude Desktop — macOS", file: "claude-desktop-macos.md", sortOrder: 1 },
  { slug: "claude-desktop-linux", category: "DESKTOP", os: "LINUX", title: "Claude Desktop — Linux", file: "claude-desktop-linux.md", sortOrder: 2 },
  { slug: "codex-windows", category: "CODEX", os: "WINDOWS", title: "Codex CLI — Windows", file: "codex-windows.md", sortOrder: 0 },
  { slug: "codex-macos", category: "CODEX", os: "MACOS", title: "Codex CLI — macOS", file: "codex-macos.md", sortOrder: 1 },
  { slug: "codex-linux", category: "CODEX", os: "LINUX", title: "Codex CLI — Linux", file: "codex-linux.md", sortOrder: 2 },
  { slug: "opencode-windows", category: "OPENCODE", os: "WINDOWS", title: "OpenCode — Windows", file: "opencode-windows.md", sortOrder: 0 },
  { slug: "opencode-macos", category: "OPENCODE", os: "MACOS", title: "OpenCode — macOS", file: "opencode-macos.md", sortOrder: 1 },
  { slug: "opencode-linux", category: "OPENCODE", os: "LINUX", title: "OpenCode — Linux", file: "opencode-linux.md", sortOrder: 2 },
  { slug: "agents-windows", category: "AGENTS", os: "WINDOWS", title: "More agents — Windows", file: "agents-windows.md", sortOrder: 0 },
  { slug: "agents-macos", category: "AGENTS", os: "MACOS", title: "More agents — macOS", file: "agents-macos.md", sortOrder: 1 },
  { slug: "agents-linux", category: "AGENTS", os: "LINUX", title: "More agents — Linux", file: "agents-linux.md", sortOrder: 2 },
  { slug: "skills-windows", category: "SKILLS", os: "WINDOWS", title: "Skills — Windows", file: "skills-windows.md", sortOrder: 0 },
  { slug: "skills-macos", category: "SKILLS", os: "MACOS", title: "Skills — macOS", file: "skills-macos.md", sortOrder: 1 },
  { slug: "skills-linux", category: "SKILLS", os: "LINUX", title: "Skills — Linux", file: "skills-linux.md", sortOrder: 2 },
  // Slugs keep their historical "claude-cowork" name so existing rows are updated in place.
  { slug: "claude-cowork-windows", category: "SDK", os: "WINDOWS", title: "API & SDKs — Windows", file: "claude-cowork-windows.md", sortOrder: 0 },
  { slug: "claude-cowork-macos", category: "SDK", os: "MACOS", title: "API & SDKs — macOS", file: "claude-cowork-macos.md", sortOrder: 1 },
  { slug: "claude-cowork-linux", category: "SDK", os: "LINUX", title: "API & SDKs — Linux", file: "claude-cowork-linux.md", sortOrder: 2 },
];

/** Markers of the pre-gateway guides (legacy proxies, pool keys, "FreeModel"). */
const LEGACY_DOC_MARKERS = ["capi.aerolink.lat", "cgapi.aerolink.lat", "already assigned to you", "FreeModel"];

/** `savedBy` labels written by seeding, as opposed to an admin saving in the dashboard. */
const SEED_AUTHORS = ["Gateway docs migration (WS7)", "Docs refresh (seed)"];

async function seedDoc(prisma: PrismaClient, storeId: string, doc: (typeof DOCS)[number], content: string) {
  const slug = `${storeId}-${doc.slug}`;
  const meta = { category: doc.category, os: doc.os, title: doc.title, sortOrder: doc.sortOrder };
  const existing = await prisma.documentation.findUnique({
    where: { slug },
    select: { id: true, content: true, category: true, os: true, title: true, sortOrder: true, versions: { select: { savedBy: true } } },
  });
  if (!existing) {
    await prisma.documentation.create({ data: { storeId, slug, ...meta, content } });
    console.log(`  + ${slug}`);
    return;
  }

  // Category / title / order are not editable in the dashboard, so they always follow the code.
  const metaChanged =
    existing.category !== meta.category ||
    existing.os !== meta.os ||
    existing.title !== meta.title ||
    existing.sortOrder !== meta.sortOrder;

  // Content: replace legacy guides, and refresh guides no admin has ever edited.
  // An admin's save leaves a version with their name, so their text is kept.
  const legacy = LEGACY_DOC_MARKERS.some((m) => existing.content.includes(m));
  const adminEdited = existing.versions.some((v) => !SEED_AUTHORS.includes(v.savedBy));
  const refreshContent = existing.content !== content && (legacy || !adminEdited);

  if (existing.content !== content && !refreshContent) console.log(`  = ${slug}: kept admin-edited content`);
  if (!metaChanged && !refreshContent) return;
  await prisma.documentation.update({
    where: { id: existing.id },
    data: {
      ...meta,
      ...(refreshContent
        ? {
            content,
            versions: {
              create: { content: existing.content, savedBy: legacy ? SEED_AUTHORS[0] : SEED_AUTHORS[1] },
            },
          }
        : {}),
    },
  });
  console.log(`  ↻ ${slug}${refreshContent ? " (content refreshed, old text kept as a version)" : " (metadata)"}`);
}

/** Creates or refreshes every guide for the given stores. Safe to run repeatedly. */
export async function seedDocumentation(prisma: PrismaClient, storeIds: string[]) {
  for (const doc of DOCS) {
    const content = readFileSync(join(__dirname, "docs", doc.file), "utf8");
    for (const storeId of storeIds) await seedDoc(prisma, storeId, doc, content);
  }
  return DOCS.length;
}
