import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";
import { seedDocumentation } from "./seed-docs";
import { applyEnvAliases } from "../lib/env-aliases.mjs";

// Supabase added from Vercel → Storage exposes POSTGRES_PRISMA_URL, not DATABASE_URL.
applyEnvAliases();
const prisma = new PrismaClient();

const AEROLINK_SETTINGS: Record<string, string> = {
  site_name: "AeroLink API Portal",
  logo_text: "AeroLink",
  support_email: "support@aerolink.lat",
  brand_color: "#2563EB",
  footer_text: "© AeroLink. All rights reserved.",
  low_balance_threshold_cents: "1000",
  default_currency: "USD",
  timezone: "UTC",
  usage_cost_multiplier: "2.2",
  signup_balance_cents: "30000",
  signup_bonus_cents: "0",
  store_url: "https://www.gamsgo.com/shop-store/ab3a9d0e-937f-e93e-1b66-5dca973aa779",
};

const CHEFAPI_SETTINGS: Record<string, string> = {
  site_name: "ChefAPI Portal",
  logo_text: "ChefAPI",
  support_email: "support@chefapi.com",
  brand_color: "#f97316",
  footer_text: "© ChefAPI. All rights reserved.",
  low_balance_threshold_cents: "1000",
  default_currency: "USD",
  timezone: "UTC",
  usage_cost_multiplier: "2.2",
  signup_balance_cents: "30000",
  signup_bonus_cents: "0",
  store_url: "https://www.gamsgo.com/shop-store/3dcf9b33-e8d1-b908-8069-d6603ca4ab78?category_id=e994486e-b21a-fcfc-8844-360b39ae878e",
};

async function main() {
  console.log("🌱 Seeding database for multi-store setup...\n");

  // 1. Ensure stores exist
  console.log("1. Creating stores...");
  await prisma.store.upsert({
    where: { id: "aerolink" },
    update: {},
    create: {
      id: "aerolink",
      name: "AeroLink API",
      logoText: "AeroLink",
      storeUrl: "https://www.gamsgo.com/shop-store/ab3a9d0e-937f-e93e-1b66-5dca973aa779",
      primaryColor: "#0ea5e9",
      fontFamily: "Inter",
    },
  });

  await prisma.store.upsert({
    where: { id: "chefapi" },
    update: {},
    create: {
      id: "chefapi",
      name: "ChefAPI",
      logoText: "ChefAPI",
      storeUrl: "https://www.gamsgo.com/shop-store/3dcf9b33-e8d1-b908-8069-d6603ca4ab78?category_id=e994486e-b21a-fcfc-8844-360b39ae878e",
      primaryColor: "#f97316",
      fontFamily: "Plus Jakarta Sans",
    },
  });
  console.log("✓ Stores created\n");

  // 2. Admin accounts
  console.log("2. Creating admin accounts...");
  const email = process.env.ADMIN_EMAIL ?? "admin@aerolink.lat";
  const password = process.env.ADMIN_PASSWORD ?? "ChangeMe123!";
  const resetPassword = (process.env.ADMIN_PASSWORD_RESET ?? "").toLowerCase() === "true";
  const name = process.env.ADMIN_NAME ?? "Administrator";

  // Optional read-only GamsGo inspector: created only when both variables are
  // set (no password in the code). Deleting it in the admin keeps it deleted
  // unless the variables stay set.
  const gamsgoEmail = (process.env.GAMSGO_ADMIN_EMAIL ?? "").trim().toLowerCase();
  const gamsgoPassword = process.env.GAMSGO_ADMIN_PASSWORD ?? "";
  const gamsgoName = process.env.GAMSGO_ADMIN_NAME ?? "GamsGo Inspector";
  const withGamsgo = Boolean(gamsgoEmail && gamsgoPassword);

  const passwordHash = await bcrypt.hash(password, 12);

  const mainAdmin = await prisma.admin.upsert({
    where: { email },
    // The password is set when the account is created. Afterwards the admin
    // changes it in the panel (My account); the seed only overwrites it when
    // ADMIN_PASSWORD_RESET=true — the recovery path for a forgotten password.
    update: { name, isReadOnly: false, ...(resetPassword ? { passwordHash, passwordChangedAt: new Date() } : {}) },
    create: { email, name, passwordHash, isReadOnly: false },
  });

  // Like the main admin, its password is set on creation only.
  const gamsgoAdmin = withGamsgo
    ? await prisma.admin.upsert({
        where: { email: gamsgoEmail },
        update: { name: gamsgoName, isReadOnly: true },
        create: { email: gamsgoEmail, name: gamsgoName, passwordHash: await bcrypt.hash(gamsgoPassword, 12), isReadOnly: true },
      })
    : null;

  // Other admin accounts are left alone: the seed only creates what is missing.
  console.log(`✓ Admin ready: ${email}`);
  if (resetPassword) {
    console.log("  ↻ Password reset from ADMIN_PASSWORD (ADMIN_PASSWORD_RESET=true); other sessions signed out.");
    console.log("  ! Remove ADMIN_PASSWORD_RESET after signing in, or every deploy resets the password again.");
  } else {
    console.log("  Password unchanged (set on creation; change it in the admin under My account, or reset with ADMIN_PASSWORD_RESET=true).");
  }
  console.log(gamsgoAdmin ? `✓ GamsGo inspector ready: ${gamsgoEmail}\n` : "  GamsGo inspector not configured (GAMSGO_ADMIN_EMAIL / GAMSGO_ADMIN_PASSWORD unset)\n");

  // 3. Give admins access to both stores
  console.log("3. Setting up admin store access...");
  for (const admin of gamsgoAdmin ? [mainAdmin, gamsgoAdmin] : [mainAdmin]) {
    await prisma.adminStoreAccess.upsert({
      where: {
        adminId_storeId: {
          adminId: admin.id,
          storeId: "aerolink",
        },
      },
      update: {},
      create: {
        adminId: admin.id,
        storeId: "aerolink",
      },
    });

    await prisma.adminStoreAccess.upsert({
      where: {
        adminId_storeId: {
          adminId: admin.id,
          storeId: "chefapi",
        },
      },
      update: {},
      create: {
        adminId: admin.id,
        storeId: "chefapi",
      },
    });
  }
  console.log("✓ Admin store access configured\n");

  // 3b. Default plans — only for a store that has none yet, so plans the
  // owner edited or deleted in the dashboard are never re-created.
  // Each plan's "real API usage" starts at price / 2.2 (the historical
  // multiplier) so billing is unchanged until the owner tunes it.
  const DEFAULT_PLANS = [
    { name: "Starter", priceCents: 10000, rpm: 20, maxConcurrent: 4 },
    { name: "Plus", priceCents: 20000, rpm: 30, maxConcurrent: 8 },
    { name: "Pro", priceCents: 50000, rpm: 40, maxConcurrent: 16 },
    { name: "Ultimate", priceCents: 100000, rpm: 50, maxConcurrent: 32 },
  ];
  for (const storeId of ["aerolink", "chefapi"]) {
    const existing = await prisma.plan.count({ where: { storeId } });
    if (existing > 0) continue;
    await prisma.plan.createMany({
      data: DEFAULT_PLANS.map((p, i) => ({
        storeId,
        name: p.name,
        priceCents: p.priceCents,
        limitType: "USD",
        limitUsageCents: Math.round(p.priceCents / 2.2),
        rpm: p.rpm,
        maxConcurrent: p.maxConcurrent,
        sortOrder: i,
      })),
    });
  }
  console.log("✓ Default plans in place\n");

  // 3c. One pack per plan (WS8) — only for a store that has no packs yet.
  // A pack is what is sold on GamsGo; it binds the plan to the credit granted.
  for (const storeId of ["aerolink", "chefapi"]) {
    const existingPacks = await prisma.pack.count({ where: { storeId } });
    if (existingPacks > 0) continue;
    const plans = await prisma.plan.findMany({ where: { storeId }, orderBy: { sortOrder: "asc" } });
    for (const plan of plans) {
      await prisma.pack.create({
        data: {
          storeId,
          name: plan.name,
          planId: plan.id,
          balanceGrantMicroUsd: BigInt(plan.priceCents) * 10_000n,
          bonusGrantMicroUsd: 0n,
          listingPriceLabel: `$${Math.round(plan.priceCents / 100)} on GamsGo`,
          active: plan.isActive,
          sortOrder: plan.sortOrder,
        },
      });
    }
  }
  console.log("✓ Default packs in place\n");

  // 4. Seed settings for both stores
  console.log("4. Seeding settings...");

  // AeroLink settings
  for (const [key, value] of Object.entries(AEROLINK_SETTINGS)) {
    await prisma.setting.upsert({
      where: {
        storeId_key: {
          storeId: "aerolink",
          key,
        },
      },
      update: {},
      create: { storeId: "aerolink", key, value },
    });
  }
  console.log("✓ AeroLink settings seeded");

  // ChefAPI settings
  for (const [key, value] of Object.entries(CHEFAPI_SETTINGS)) {
    await prisma.setting.upsert({
      where: {
        storeId_key: {
          storeId: "chefapi",
          key,
        },
      },
      update: {},
      create: { storeId: "chefapi", key, value },
    });
  }
  console.log("✓ ChefAPI settings seeded\n");

  // 5. Seed documentation for both stores
  console.log("5. Seeding documentation...");

  const guideCount = await seedDocumentation(prisma, ["aerolink", "chefapi"]);
  console.log(`✓ Documentation seeded (${guideCount} guides × 2 stores)
`);

  console.log("🎉 Seeding completed successfully!");
  console.log("\nStores:");
  console.log("  - AeroLink: https://aerolink-portal.vercel.app");
  console.log("  - ChefAPI: https://aerolink-portal.vercel.app/chefapi");
  console.log("\nAdmin Panel:");
  console.log("  - Login: https://aerolink-portal.vercel.app/admin/login");
  console.log(`  - Email: ${email}`);
  console.log("  - Can switch between stores in the admin panel");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
