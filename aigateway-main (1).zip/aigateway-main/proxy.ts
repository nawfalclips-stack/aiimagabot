import { NextResponse, type NextRequest } from "next/server";
import { jwtVerify } from "jose";

const ADMIN_COOKIE = "aerolink_admin_session";
const CUSTOMER_COOKIE = "aerolink_customer_session";

async function verify(token: string | undefined, kind: "admin" | "customer"): Promise<boolean> {
  if (!token) return false;
  try {
    const secret = new TextEncoder().encode(process.env.SESSION_SECRET);
    const { payload } = await jwtVerify(token, secret);
    return payload.kind === kind;
  } catch {
    return false;
  }
}

export default async function proxy(request: NextRequest) {
  const { pathname } = request.nextUrl;

  // LLM gateway endpoints authenticate with bearer tokens in their handlers;
  // nothing here (cookies, affiliate capture, browser headers) applies to them.
  if (pathname.startsWith("/v1/")) {
    return NextResponse.next();
  }

  // Affiliate referral capture: /affiliate/CODE → landing with ?ref=CODE AND a
  // long-lived cookie, so the code survives navigation, refreshes and cached
  // pages. The activation action prefers the cookie when the field is missing.
  let refCode: string | null = null;
  const affiliateMatch = pathname.match(/^\/affiliate\/([A-Za-z0-9_-]{3,32})$/);
  if (affiliateMatch) {
    refCode = decodeURIComponent(affiliateMatch[1]).trim().toUpperCase();
  }
  if (!refCode) {
    const q = request.nextUrl.searchParams.get("ref");
    if (q && /^[A-Za-z0-9_-]{3,32}$/.test(q)) refCode = q.trim().toUpperCase();
  }

  if (pathname === "/") {
    const existingCookie = request.cookies.get("aerolink_ref")?.value ?? null;
    const response = NextResponse.next();
    if (refCode && refCode !== existingCookie) {
      // Remember the referral for 30 days.
      response.cookies.set("aerolink_ref", refCode, {
        maxAge: 60 * 60 * 24 * 30,
        path: "/",
        sameSite: "lax",
      });
      response.headers.set("x-affiliate-ref", refCode);
    } else if (existingCookie) {
      response.headers.set("x-affiliate-ref", existingCookie);
    }
    // Security headers are set again below for every other path.
    response.headers.set("X-Frame-Options", "DENY");
    response.headers.set("X-Content-Type-Options", "nosniff");
    response.headers.set("Referrer-Policy", "strict-origin-when-cross-origin");
    response.headers.set("Permissions-Policy", "camera=(), microphone=(), geolocation=()");
    return response;
  }

  // Admin area — everything under /admin except the login page.
  if (pathname.startsWith("/admin") && pathname !== "/admin/login") {
    const ok = await verify(request.cookies.get(ADMIN_COOKIE)?.value, "admin");
    if (!ok) {
      const url = request.nextUrl.clone();
      url.pathname = "/admin/login";
      url.search = "";
      return NextResponse.redirect(url);
    }
  }

  // NOTE: /admin/login intentionally has no redirect here. The proxy can only
  // check the JWT, not whether the admin still exists in the database — a
  // stale cookie for a deleted admin would bounce between /admin (layout
  // rejects it) and /admin/login (proxy bounces it back) forever. The login
  // page itself redirects signed-in admins after a real database check.

  // Customer portal — requires a customer session. Returning customers go
  // straight to the access-code sign-in page.
  if (pathname.startsWith("/portal")) {
    const ok = await verify(request.cookies.get(CUSTOMER_COOKIE)?.value, "customer");
    if (!ok) {
      const url = request.nextUrl.clone();
      url.pathname = "/login";
      url.search = "";
      return NextResponse.redirect(url);
    }
  }

  const response = NextResponse.next();
  // Baseline security headers.
  response.headers.set("X-Frame-Options", "DENY");
  response.headers.set("X-Content-Type-Options", "nosniff");
  response.headers.set("Referrer-Policy", "strict-origin-when-cross-origin");
  response.headers.set("Permissions-Policy", "camera=(), microphone=(), geolocation=()");
  return response;
}

export const config = {
  matcher: ["/((?!_next/static|_next/image|favicon.ico|.*\\.(?:svg|png|jpg|jpeg|gif|webp|ico|txt|xml|webmanifest)$).*)"],
};
