/**
 * Quick script to add chefapi admin account
 * Usage: npx tsx scripts/add-chefapi-admin.ts
 */

import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function main() {
  console.log("Creating chefapi admin account...\n");

  const email = "chefapi@aerolink.com";
  const password = "chefapi123"; // Change this!
  const name = "Chef API";

  // Check if admin already exists
  const existing = await prisma.admin.findUnique({
    where: { email },
  });

  if (existing) {
    console.log("❌ Admin with this email already exists!");
    console.log(`ID: ${existing.id}`);
    console.log(`Email: ${existing.email}`);
    console.log(`Role: ${existing.role}`);
    return;
  }

  // Hash password
  const passwordHash = await bcrypt.hash(password, 12);

  // Get all stores
  const stores = await prisma.store.findMany();

  if (stores.length === 0) {
    console.log("❌ No stores found! Create a store first.");
    return;
  }

  // Create admin with API_VIEWER role
  const admin = await prisma.admin.create({
    data: {
      email,
      name,
      passwordHash,
      role: "API_VIEWER",
      isReadOnly: true,
      storeAccess: {
        create: stores.map((store) => ({
          storeId: store.id,
        })),
      },
    },
    include: {
      storeAccess: {
        include: {
          store: true,
        },
      },
    },
  });

  console.log("✅ Admin created successfully!\n");
  console.log(`Email: ${admin.email}`);
  console.log(`Password: ${password}`);
  console.log(`Role: ${admin.role} (API Viewer - Read Only)`);
  console.log(`\nAccess to stores:`);
  admin.storeAccess.forEach((access) => {
    console.log(`  - ${access.store.name}`);
  });

  console.log("\n📋 Can view:");
  console.log("  - Dashboard");
  console.log("  - Customers (read only)");
  console.log("  - API Pool (read only)");
  console.log("  - Usage Logs");
  console.log("  - Activity");

  console.log("\n🚫 Cannot access:");
  console.log("  - Settings");
  console.log("  - Statistics");
  console.log("  - Analytics");
  console.log("  - Orders, Activations, Recharges, etc.");
  console.log("  - Cannot create, edit, or delete anything");
}

main()
  .catch((error) => {
    console.error("Error:", error);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
