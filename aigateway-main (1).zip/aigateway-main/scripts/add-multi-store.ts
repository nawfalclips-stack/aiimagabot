/**
 * Migration script to add multi-store support
 *
 * This script:
 * 1. Creates the two stores (aerolink and chefapi)
 * 2. Adds storeId to all existing data (defaults to 'aerolink')
 * 3. Creates admin store access for existing admins
 */

import { PrismaClient } from '@prisma/client';

const prisma = new PrismaClient();

async function main() {
  console.log('Starting multi-store migration...');

  // Step 1: Create stores
  console.log('\n1. Creating stores...');

  const aerolink = await prisma.store.upsert({
    where: { id: 'aerolink' },
    create: {
      id: 'aerolink',
      name: 'AeroLink API',
      logoText: 'AeroLink',
      subdomain: 'aerolink',
      storeUrl: 'https://www.gamsgo.com/shop-store/ab3a9d0e-937f-e93e-1b66-5dca973aa779',
      primaryColor: '#0ea5e9',
      fontFamily: 'Inter',
    },
    update: {},
  });
  console.log('✓ AeroLink store created');

  const chefapi = await prisma.store.upsert({
    where: { id: 'chefapi' },
    create: {
      id: 'chefapi',
      name: 'ChefAPI',
      logoText: 'ChefAPI',
      subdomain: 'chefapi',
      storeUrl: 'https://www.gamsgo.com/shop-store/3dcf9b33-e8d1-b908-8069-d6603ca4ab78?category_id=e994486e-b21a-fcfc-8844-360b39ae878e',
      primaryColor: '#f97316', // Orange
      fontFamily: 'Plus Jakarta Sans',
    },
    update: {},
  });
  console.log('✓ ChefAPI store created');

  // Step 2: Give all existing admins access to both stores
  console.log('\n2. Setting up admin store access...');

  const admins = await prisma.admin.findMany();

  for (const admin of admins) {
    // Access to AeroLink
    await prisma.adminStoreAccess.upsert({
      where: {
        adminId_storeId: {
          adminId: admin.id,
          storeId: 'aerolink',
        },
      },
      create: {
        adminId: admin.id,
        storeId: 'aerolink',
      },
      update: {},
    });

    // Access to ChefAPI
    await prisma.adminStoreAccess.upsert({
      where: {
        adminId_storeId: {
          adminId: admin.id,
          storeId: 'chefapi',
        },
      },
      create: {
        adminId: admin.id,
        storeId: 'chefapi',
      },
      update: {},
    });

    console.log(`✓ Admin ${admin.email} has access to both stores`);
  }

  console.log('\n✅ Multi-store migration completed successfully!');
  console.log('\nNext steps:');
  console.log('1. Run: npm run prisma:generate');
  console.log('2. The code changes will handle store filtering automatically');
}

main()
  .catch((e) => {
    console.error('❌ Migration failed:', e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
