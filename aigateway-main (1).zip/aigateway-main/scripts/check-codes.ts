/**
 * ROOT CAUSE CHECK: the friend's activation must carry referredById.
 * Simulate exactly what happens on PROD:
 *  1. Friend opens /affiliate/CODE → redirected to /?ref=CODE → field prefilled
 *  2. redeemOrder resolves the referrer by affiliateCode
 *
 * The suspect: on prod, customers were created BEFORE ensureAffiliateCode ran
 * for them, so findUnique by affiliateCode returns null → referral lost.
 * Also: if the friend's session/cookie already existed (re-visiting), Next may
 * serve a CACHED landing page without the ref param → field hidden.
 */
import { prisma } from "../lib/prisma";

async function main() {
  // Check: are there prod-style customers with NULL affiliateCode?
  const noCode = await prisma.customer.findMany({
    where: { affiliateCode: null, deletedAt: null },
    select: { accessCode: true },
  });
  console.log(`customers WITHOUT affiliate code: ${noCode.length}`);
  for (const c of noCode) console.log("  -", c.accessCode);

  const withCode = await prisma.customer.count({ where: { affiliateCode: { not: null } } });
  console.log(`customers WITH code: ${withCode}`);

  await prisma.$disconnect();
}
main().catch((e) => { console.error(e); process.exit(1); });
