// Check production pages with a session minted from the PROD secret.
import { SignJWT } from "jose";
import fs from "node:fs";

function envVal(name) {
  // Vercel CLI masked the pulled file, so read from local .env (same SESSION_SECRET was set in Vercel 16d ago — verify by testing).
  for (const f of [".env", ".env.production.local"]) {
    try {
      const m = fs.readFileSync(f, "utf8").match(new RegExp(`^\\s*${name}\\s*=\\s*"?(.*?)"?\\s*$`, "m"));
      if (m) return m[1];
    } catch {}
  }
  return null;
}

async function main() {
  const base = "https://www.aerolink.ink";
  const secrets = [...new Set([envVal("SESSION_SECRET"), envVal("SESSION_SECRET")])].filter(Boolean);
  let ok = false;
  for (const secret of secrets) {
    const token = await new SignJWT({ adminId: "probe", kind: "admin" })
      .setProtectedHeader({ alg: "HS256" }).setIssuedAt()
      .setExpirationTime(Math.floor(Date.now() / 1000) + 60)
      .sign(new TextEncoder().encode(secret));
    // A fake adminId should bounce to login (307) if signature is VALID.
    // If signature is INVALID it also bounces — so check a valid-shaped response instead:
    // hit /admin/login with the cookie: login page redirects signed-in users only after DB check,
    // simplest reliable probe: signature validity shows as 307 (not 200-with-form) on /admin.
    const res = await fetch(`${base}/admin`, { headers: { cookie: `aerolink_admin_session=${token}` }, redirect: "manual" });
    console.log(`/admin with ${secret.length}-char secret: ${res.status}`);
    if (res.status === 404 || res.status === 500) ok = true; // passed proxy but bad admin = secret works
  }
  console.log(ok ? "✅ prod accepts our SESSION_SECRET (proxy verified token)" : "⚠️ could not confirm which secret prod uses");
}
main().catch((e) => { console.error("FAIL:", e.message); process.exit(1); });
