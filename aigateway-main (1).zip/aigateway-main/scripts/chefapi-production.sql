-- ChefAPI Production Setup
-- Run this on Vercel Postgres: Dashboard > Storage > Postgres > Query

-- 1. Create ChefAPI Store
INSERT INTO "Store" (id, name, "logoText", "storeUrl", subdomain, "primaryColor", "fontFamily", "createdAt", "updatedAt")
VALUES (
  'chefapi',
  'ChefAPI',
  'ChefAPI',
  'https://www.gamsgo.com/shop-store/3dcf9b33-e8d1-b908-8069-d6603ca4ab78?category_id=e994486e-b21a-fcfc-8844-360b39ae878e',
  'chefapi',
  '#10b981',
  'Roboto',
  NOW(),
  NOW()
)
ON CONFLICT (id) DO UPDATE SET
  name = EXCLUDED.name,
  "logoText" = EXCLUDED."logoText",
  "storeUrl" = EXCLUDED."storeUrl",
  "primaryColor" = EXCLUDED."primaryColor",
  "fontFamily" = EXCLUDED."fontFamily",
  "updatedAt" = NOW();

-- 2. Create Admin Account
-- Password: chefapi2024
-- Hash generated with bcrypt (12 rounds)
INSERT INTO "Admin" (id, email, name, "passwordHash", "isReadOnly", role, "createdAt", "updatedAt")
VALUES (
  'chefapi_admin_001',
  'admin@chefapi.com',
  'ChefAPI Admin',
  '$2b$12$GsEGFA/ZZEquuL01FxwDxe6ASZJKaRaWF0PZfExRjQ6Gwy/G7Zv5K',
  false,
  'FULL_ACCESS',
  NOW(),
  NOW()
)
ON CONFLICT (email) DO UPDATE SET
  "passwordHash" = EXCLUDED."passwordHash",
  role = EXCLUDED.role,
  "updatedAt" = NOW();

-- 3. Link Admin to ChefAPI Store
INSERT INTO "AdminStoreAccess" (id, "adminId", "storeId", "createdAt", "updatedAt")
SELECT
  'access_chefapi_001',
  (SELECT id FROM "Admin" WHERE email = 'admin@chefapi.com'),
  'chefapi',
  NOW(),
  NOW()
WHERE NOT EXISTS (
  SELECT 1 FROM "AdminStoreAccess"
  WHERE "adminId" = (SELECT id FROM "Admin" WHERE email = 'admin@chefapi.com')
  AND "storeId" = 'chefapi'
);

-- 4. Create Default Settings for ChefAPI
INSERT INTO "Setting" ("storeId", key, value, "createdAt", "updatedAt")
VALUES
  ('chefapi', 'storeName', 'ChefAPI', NOW(), NOW()),
  ('chefapi', 'storeContact', '', NOW(), NOW()),
  ('chefapi', 'enableSelfActivation', 'true', NOW(), NOW()),
  ('chefapi', 'requireReview', 'false', NOW(), NOW()),
  ('chefapi', 'reviewBonusPercentage', '0', NOW(), NOW()),
  ('chefapi', 'activationInstruction', '', NOW(), NOW())
ON CONFLICT ("storeId", key) DO UPDATE SET
  value = EXCLUDED.value,
  "updatedAt" = NOW();

-- Done! ✅
-- Login: admin@chefapi.com
-- Password: chefapi2024
-- URL: https://aerolink-portal.vercel.app/admin
