/**
 * Cleanup script to remove temporary tables
 */

import Database from 'better-sqlite3';
import path from 'path';

const DB_PATH = path.join(process.cwd(), 'prisma', 'dev.db');
const db = new Database(DB_PATH);

try {
  console.log('Cleaning up temporary tables...');

  db.exec(`DROP TABLE IF EXISTS "Customer_new"`);
  db.exec(`DROP TABLE IF EXISTS "ActivityLog_new"`);
  db.exec(`DROP TABLE IF EXISTS "Setting_new"`);
  db.exec(`DROP TABLE IF EXISTS "Documentation_new"`);
  db.exec(`DROP TABLE IF EXISTS "ApiPoolKey_new"`);
  db.exec(`DROP TABLE IF EXISTS "UsageLog_new"`);
  db.exec(`DROP TABLE IF EXISTS "Ticket_new"`);
  db.exec(`DROP TABLE IF EXISTS "RechargeRequest_new"`);

  console.log('✓ Cleanup completed');
} catch (error) {
  console.error('Error:', error);
} finally {
  db.close();
}
