/**
 * Script to create a new admin account with specific role
 *
 * Usage:
 *   npx tsx scripts/create-admin.ts
 */

import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";
import readline from "readline";

const prisma = new PrismaClient();

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

function question(prompt: string): Promise<string> {
  return new Promise((resolve) => {
    rl.question(prompt, resolve);
  });
}

async function main() {
  console.log("=== Create Admin Account ===\n");

  const email = await question("Email: ");
  const name = await question("Name: ");
  const password = await question("Password: ");

  console.log("\nAvailable roles:");
  console.log("1. FULL_ACCESS - Full access to all features");
  console.log("2. API_VIEWER - View customers, API pool, usage logs");
  console.log("3. STATISTICS_ONLY - View statistics and analytics only");

  const roleChoice = await question("\nSelect role (1-3): ");

  let role = "FULL_ACCESS";
  let isReadOnly = false;

  switch (roleChoice.trim()) {
    case "1":
      role = "FULL_ACCESS";
      isReadOnly = false;
      break;
    case "2":
      role = "API_VIEWER";
      isReadOnly = true;
      break;
    case "3":
      role = "STATISTICS_ONLY";
      isReadOnly = true;
      break;
    default:
      console.log("Invalid choice, using FULL_ACCESS");
      role = "FULL_ACCESS";
      isReadOnly = false;
  }

  // Ask for stores
  console.log("\nFetching available stores...");
  const stores = await prisma.store.findMany();

  if (stores.length === 0) {
    console.log("No stores found! Please create a store first.");
    rl.close();
    await prisma.$disconnect();
    return;
  }

  console.log("\nAvailable stores:");
  stores.forEach((store, index) => {
    console.log(`${index + 1}. ${store.name} (${store.id})`);
  });

  const storeChoice = await question("\nSelect store numbers (comma-separated, e.g., 1,2): ");
  const storeIndices = storeChoice.split(",").map((s) => parseInt(s.trim()) - 1);
  const selectedStores = storeIndices
    .filter((i) => i >= 0 && i < stores.length)
    .map((i) => stores[i]);

  if (selectedStores.length === 0) {
    console.log("No valid stores selected!");
    rl.close();
    await prisma.$disconnect();
    return;
  }

  console.log("\n=== Summary ===");
  console.log(`Email: ${email}`);
  console.log(`Name: ${name}`);
  console.log(`Role: ${role}`);
  console.log(`Read Only: ${isReadOnly}`);
  console.log(`Stores: ${selectedStores.map((s) => s.name).join(", ")}`);

  const confirm = await question("\nCreate this admin? (yes/no): ");

  if (confirm.toLowerCase() !== "yes") {
    console.log("Cancelled.");
    rl.close();
    await prisma.$disconnect();
    return;
  }

  // Hash password
  const passwordHash = await bcrypt.hash(password, 12);

  // Create admin
  const admin = await prisma.admin.create({
    data: {
      email,
      name,
      passwordHash,
      role,
      isReadOnly,
      storeAccess: {
        create: selectedStores.map((store) => ({
          storeId: store.id,
        })),
      },
    },
    include: {
      storeAccess: {
        include: {
          store: true,
        },
      },
    },
  });

  console.log("\n✅ Admin created successfully!");
  console.log(`ID: ${admin.id}`);
  console.log(`Email: ${admin.email}`);
  console.log(`Role: ${admin.role}`);
  console.log(`Access to: ${admin.storeAccess.map((a) => a.store.name).join(", ")}`);

  rl.close();
  await prisma.$disconnect();
}

main().catch((error) => {
  console.error("Error:", error);
  rl.close();
  prisma.$disconnect();
  process.exit(1);
});
