/**
 * Creates the owner + GamsGo inspector admin accounts in the PRODUCTION DB.
 * Run once:  node scripts/create-admins.mjs
 */
import bcrypt from "bcryptjs";
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();

async function main() {
  // ── Owner account ──────────────────────────────────────────────────────────
  const ownerHash = await bcrypt.hash("2001", 12);
  const owner = await prisma.admin.upsert({
    where:  { email: "elnawfaldaoudi@aerolink.com" },
    update: { passwordHash: ownerHash, name: "Administrator" },
    create: { email: "elnawfaldaoudi@aerolink.com", name: "Administrator", passwordHash: ownerHash },
  });
  console.log(`✅  Owner:    ${owner.email}`);

  // ── GamsGo inspector account ───────────────────────────────────────────────
  const gamsgoHash = await bcrypt.hash("aerolink2026", 12);
  const gamsgo = await prisma.admin.upsert({
    where:  { email: "sellerjoin@gamsgo.com" },
    update: { passwordHash: gamsgoHash, name: "GamsGo Inspector" },
    create: { email: "sellerjoin@gamsgo.com", name: "GamsGo Inspector", passwordHash: gamsgoHash },
  });
  console.log(`✅  GamsGo:   ${gamsgo.email}  password: aerolink2026`);
}

main()
  .catch((e) => { console.error(e); process.exit(1); })
  .finally(() => prisma.$disconnect());
