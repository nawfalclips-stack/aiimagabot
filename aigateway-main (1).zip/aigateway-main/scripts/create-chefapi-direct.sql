-- Run this SQL directly on your Vercel Postgres database
-- Go to: Vercel Dashboard > Your Project > Storage > Your Database > Query

-- 1. First, add subdomain column if not exists
ALTER TABLE "Store" ADD COLUMN IF NOT EXISTS "subdomain" TEXT;

-- 2. Add role column to Admin if not exists
ALTER TABLE "Admin" ADD COLUMN IF NOT EXISTS "role" TEXT NOT NULL DEFAULT 'FULL_ACCESS';

-- 3. Update existing stores with subdomain
UPDATE "Store" SET "subdomain" = 'aerolink' WHERE id = 'store_1' AND "subdomain" IS NULL;

-- 4. Create ChefAPI Store
INSERT INTO "Store" (id, name, "logoText", "storeUrl", subdomain, "primaryColor", "fontFamily", "createdAt", "updatedAt")
VALUES (
  'chefapi',
  'ChefAPI',
  'ChefAPI',
  'https://www.gamsgo.com/shop-store/3dcf9b33-e8d1-b908-8069-d6603ca4ab78?category_id=e994486e-b21a-fcfc-8844-360b39ae878e',
  'chefapi',
  '#10b981',
  'Roboto',
  NOW(),
  NOW()
)
ON CONFLICT (id) DO NOTHING;

-- 5. Create ChefAPI Admin (password: chefapi2024)
-- Password hash for "chefapi2024" using bcrypt rounds=12
INSERT INTO "Admin" (id, email, name, "passwordHash", "isReadOnly", role, "createdAt", "updatedAt")
VALUES (
  'admin_chefapi_' || substr(md5(random()::text), 0, 12),
  'admin@chefapi.com',
  'ChefAPI Admin',
  '$2a$12$LQ3p5Lq3Z8Y0X9K4mK1W0eBzY8RGXvN6qH.HYW7KmZ9hJ8tQ1YW9G',
  false,
  'FULL_ACCESS',
  NOW(),
  NOW()
)
ON CONFLICT (email) DO NOTHING
RETURNING id;

-- 6. Link admin to ChefAPI store
-- Replace 'ADMIN_ID_FROM_STEP_5' with the actual ID returned above
INSERT INTO "AdminStoreAccess" (id, "adminId", "storeId", "createdAt", "updatedAt")
SELECT
  'access_' || substr(md5(random()::text), 0, 12),
  a.id,
  'chefapi',
  NOW(),
  NOW()
FROM "Admin" a
WHERE a.email = 'admin@chefapi.com'
ON CONFLICT DO NOTHING;

-- 7. Create default settings for ChefAPI
INSERT INTO "Setting" ("storeId", key, value, "createdAt", "updatedAt")
VALUES
  ('chefapi', 'SITE_NAME', 'ChefAPI', NOW(), NOW()),
  ('chefapi', 'LOGO_TEXT', 'ChefAPI', NOW(), NOW()),
  ('chefapi', 'SUPPORT_EMAIL', 'support@chefapi.com', NOW(), NOW()),
  ('chefapi', 'BRAND_COLOR', '#10b981', NOW(), NOW()),
  ('chefapi', 'FOOTER_TEXT', '© 2024 ChefAPI. All rights reserved.', NOW(), NOW()),
  ('chefapi', 'LOW_BALANCE_THRESHOLD_CENTS', '500', NOW(), NOW()),
  ('chefapi', 'DEFAULT_CURRENCY', 'USD', NOW(), NOW()),
  ('chefapi', 'TIMEZONE', 'America/New_York', NOW(), NOW()),
  ('chefapi', 'USAGE_COST_MULTIPLIER', '2.2', NOW(), NOW()),
  ('chefapi', 'SIGNUP_BALANCE_CENTS', '0', NOW(), NOW()),
  ('chefapi', 'SIGNUP_BONUS_CENTS', '0', NOW(), NOW()),
  ('chefapi', 'STORE_URL', 'https://www.gamsgo.com/shop-store/3dcf9b33-e8d1-b908-8069-d6603ca4ab78?category_id=e994486e-b21a-fcfc-8844-360b39ae878e', NOW(), NOW())
ON CONFLICT ("storeId", key) DO NOTHING;

-- Verify everything was created
SELECT * FROM "Store" WHERE id = 'chefapi';
SELECT email, name, role FROM "Admin" WHERE email = 'admin@chefapi.com';
SELECT COUNT(*) as setting_count FROM "Setting" WHERE "storeId" = 'chefapi';
