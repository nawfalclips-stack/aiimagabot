/**
 * Script to create a new store with admin account
 * Usage: npx tsx scripts/create-store.ts
 */

import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";
import readline from "readline";

const prisma = new PrismaClient();

const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout,
});

function question(prompt: string): Promise<string> {
  return new Promise((resolve) => {
    rl.question(prompt, resolve);
  });
}

async function main() {
  console.log("=== Create New Store with Admin ===\n");

  // Store info
  const storeId = await question("Store ID (lowercase, no spaces, e.g., 'chefapi'): ");
  const storeName = await question("Store Name (e.g., 'ChefAPI'): ");
  const logoText = await question("Logo Text (e.g., 'ChefAPI'): ");
  const subdomain = await question("Subdomain (e.g., 'chefapi' for chefapi.aerolink.com): ");
  const storeUrl = await question("GamsGo Store URL: ");

  // Admin info
  console.log("\n--- Admin Account ---");
  const adminEmail = await question("Admin Email: ");
  const adminName = await question("Admin Name: ");
  const adminPassword = await question("Admin Password: ");

  console.log("\n=== Summary ===");
  console.log(`\nStore:`);
  console.log(`  ID: ${storeId}`);
  console.log(`  Name: ${storeName}`);
  console.log(`  Subdomain: ${subdomain}.aerolink.com`);
  console.log(`  Store URL: ${storeUrl}`);
  console.log(`\nAdmin:`);
  console.log(`  Email: ${adminEmail}`);
  console.log(`  Name: ${adminName}`);
  console.log(`  Role: FULL_ACCESS`);

  const confirm = await question("\nCreate this store and admin? (yes/no): ");

  if (confirm.toLowerCase() !== "yes") {
    console.log("Cancelled.");
    rl.close();
    await prisma.$disconnect();
    return;
  }

  // Check if store exists
  const existingStore = await prisma.store.findUnique({
    where: { id: storeId },
  });

  if (existingStore) {
    console.log("\n❌ Store ID already exists!");
    rl.close();
    await prisma.$disconnect();
    return;
  }

  // Check if subdomain exists
  const existingSubdomain = await prisma.store.findUnique({
    where: { subdomain },
  });

  if (existingSubdomain) {
    console.log("\n❌ Subdomain already taken!");
    rl.close();
    await prisma.$disconnect();
    return;
  }

  // Check if admin email exists
  const existingAdmin = await prisma.admin.findUnique({
    where: { email: adminEmail },
  });

  if (existingAdmin) {
    console.log("\n❌ Admin email already exists!");
    rl.close();
    await prisma.$disconnect();
    return;
  }

  // Hash password
  const passwordHash = await bcrypt.hash(adminPassword, 12);

  // Create store and admin in transaction
  const result = await prisma.$transaction(async (tx) => {
    // Create store
    const store = await tx.store.create({
      data: {
        id: storeId,
        name: storeName,
        logoText,
        subdomain,
        storeUrl,
      },
    });

    // Create admin
    const admin = await tx.admin.create({
      data: {
        email: adminEmail,
        name: adminName,
        passwordHash,
        role: "FULL_ACCESS",
        isReadOnly: false,
        storeAccess: {
          create: {
            storeId: store.id,
          },
        },
      },
    });

    // Create default settings for the store
    const defaultSettings = [
      { key: "SITE_NAME", value: storeName },
      { key: "LOGO_TEXT", value: logoText },
      { key: "SUPPORT_EMAIL", value: adminEmail },
      { key: "BRAND_COLOR", value: "#0EA5E9" },
      { key: "FOOTER_TEXT", value: `© ${new Date().getFullYear()} ${storeName}` },
      { key: "LOW_BALANCE_THRESHOLD_CENTS", value: "500" },
      { key: "DEFAULT_CURRENCY", value: "USD" },
      { key: "TIMEZONE", value: "America/New_York" },
      { key: "USAGE_COST_MULTIPLIER", value: "2.2" },
      { key: "SIGNUP_BALANCE_CENTS", value: "0" },
      { key: "SIGNUP_BONUS_CENTS", value: "0" },
      { key: "STORE_URL", value: storeUrl },
    ];

    await tx.setting.createMany({
      data: defaultSettings.map((s) => ({
        storeId: store.id,
        key: s.key,
        value: s.value,
      })),
    });

    return { store, admin };
  });

  console.log("\n✅ Store and Admin created successfully!\n");
  console.log(`Store ID: ${result.store.id}`);
  console.log(`Store Name: ${result.store.name}`);
  console.log(`Subdomain: https://${result.store.subdomain}.aerolink.com`);
  console.log(`\nAdmin Email: ${result.admin.email}`);
  console.log(`Admin Password: ${adminPassword}`);
  console.log(`\nAdmin Panel: https://admin.aerolink.com`);
  console.log(`Customer Portal: https://${result.store.subdomain}.aerolink.com`);

  rl.close();
  await prisma.$disconnect();
}

main().catch((error) => {
  console.error("Error:", error);
  rl.close();
  prisma.$disconnect();
  process.exit(1);
});
