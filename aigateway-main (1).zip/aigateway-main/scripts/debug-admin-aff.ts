// Check whether the proxy is the thing 404ing: hit with NO auth header vs valid.
// Also test a NON-admin route that works (portal) and /admin/login.
import { SignJWT } from "jose";
import { PrismaClient } from "@prisma/client";
import fs from "node:fs";

async function main() {
  const m = fs.readFileSync(".env", "utf8").match(/^\s*SESSION_SECRET\s*=\s*"?([^"\r\n]+)"?/m);
  const secret = m[1].trim();
  const prisma = new PrismaClient();
  const admin = await prisma.admin.findFirst({ where: { email: "admin@aerolink.lat" } });
  await prisma.$disconnect();
  const token = await new SignJWT({ adminId: admin.id, kind: "admin" })
    .setProtectedHeader({ alg: "HS256" }).setIssuedAt()
    .setExpirationTime(Math.floor(Date.now() / 1000) + 3600)
    .sign(new TextEncoder().encode(secret));

  // Follow redirects to see final destination
  for (const p of ["/admin/statistics", "/admin/loyalty", "/admin/affiliate"]) {
    const res = await fetch(`http://localhost:3000${p}`, {
      headers: { cookie: `aerolink_admin_session=${token}` }, redirect: "follow",
    });
    console.log(`${p}: final=${res.url} status=${res.status}`);
  }
}
main().catch((e) => { console.error("FAIL:", e.message); process.exit(1); });
