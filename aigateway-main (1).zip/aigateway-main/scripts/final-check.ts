// Final page check: all admin pages + new portal/loyalty page.
import { SignJWT } from "jose";
import { PrismaClient } from "@prisma/client";
import fs from "node:fs";

async function main() {
  const m = fs.readFileSync(".env", "utf8").match(/^\s*SESSION_SECRET\s*=\s*"?([^"\r\n]+)"?/m);
  const secret = m[1].trim();
  const prisma = new PrismaClient();
  const admin = await prisma.admin.findFirst({ where: { email: "admin@aerolink.lat" } });
  await prisma.$disconnect();

  // Admin pages
  const token = await new SignJWT({ adminId: admin.id, kind: "admin" })
    .setProtectedHeader({ alg: "HS256" }).setIssuedAt()
    .setExpirationTime(Math.floor(Date.now() / 1000) + 3600)
    .sign(new TextEncoder().encode(secret));
  for (const p of ["/admin", "/admin/customers", "/admin/loyalty", "/admin/affiliate", "/admin/recharges"]) {
    const res = await fetch(`http://localhost:3000${p}`, { headers: { cookie: `aerolink_admin_session=${token}` }, redirect: "manual" });
    console.log(`${p}: ${res.status === 200 ? "✅" : "❌ " + res.status}`);
  }

  // Portal loyalty page (redirect = auth required, expected without session)
  const portal = await fetch("http://localhost:3000/portal/loyalty", { redirect: "manual" });
  console.log(`/portal/loyalty (no session): ${portal.status === 307 || portal.status === 200 ? "✅ " + portal.status : "❌ " + portal.status}`);
}
main().catch((e) => { console.error("FAIL:", e.message); process.exit(1); });
