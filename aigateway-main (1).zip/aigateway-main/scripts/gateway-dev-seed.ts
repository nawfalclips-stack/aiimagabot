/**
 * Local-only helper: registers two mock providers, one catalog model mapped to
 * both, and prints a fresh gateway token for the first activated AeroLink
 * customer. Pair with scratchpad/mock-provider.mjs on ports 4010/4011.
 *
 *   npx tsx scripts/gateway-dev-seed.ts
 */
import { PrismaClient } from "@prisma/client";
import { createHash, randomBytes } from "node:crypto";

const prisma = new PrismaClient();

async function main() {
  const providers = [
    { slug: "mock-primary", name: "Mock Primary", baseUrl: "http://127.0.0.1:4010", priority: 10 },
    { slug: "mock-secondary", name: "Mock Secondary", baseUrl: "http://127.0.0.1:4011", priority: 20 },
  ];
  const rows = [];
  for (const p of providers) {
    rows.push(
      await prisma.provider.upsert({
        where: { slug: p.slug },
        update: { baseUrl: p.baseUrl, priority: p.priority, enabled: true },
        // Plaintext key is tolerated by decryptSecret() for dev rows.
        create: { ...p, apiKeyEnc: "mock-key" },
      })
    );
  }

  const model = await prisma.gatewayModel.upsert({
    where: { slug: "mock-chat" },
    update: {},
    create: {
      slug: "mock-chat",
      displayName: "Mock Chat Model",
      inputPriceMicroPerMTok: 400_000, // $0.40 / M
      outputPriceMicroPerMTok: 1_600_000, // $1.60 / M
      contextWindow: 128_000,
      maxOutputTokens: 8192,
    },
  });
  for (const [i, prov] of rows.entries()) {
    await prisma.providerModel.upsert({
      where: { providerId_modelId: { providerId: prov.id, modelId: model.id } },
      update: { upstreamModelId: `mock-org/mock-model-${i + 1}`, priority: i + 1 },
      create: { providerId: prov.id, modelId: model.id, upstreamModelId: `mock-org/mock-model-${i + 1}`, priority: i + 1 },
    });
  }

  let customer = await prisma.customer.findFirst({ where: { storeId: "aerolink", deletedAt: null }, orderBy: { createdAt: "asc" } });
  if (!customer) {
    customer = await prisma.customer.create({
      data: { storeId: "aerolink", accessCode: "GWTEST-0001", isActivated: true },
    });
  } else if (!customer.isActivated) {
    customer = await prisma.customer.update({ where: { id: customer.id }, data: { isActivated: true } });
  }
  if (customer.initialBalanceCents - customer.usedBalanceCents <= 0) {
    // $100 of dev credit, through the ledger like every other movement.
    const r = await credit({
      customerId: customer.id,
      pot: "BALANCE",
      amountMicroUsd: centsToMicro(10_000),
      type: "ADMIN_ADJUSTMENT",
      idempotencyKey: `dev-seed:${customer.id}:${Date.now()}`,
      actor: { label: "Dev seed" },
      note: "Local gateway development credit",
    });
    customer = r.customer;
  }

  const token = "al_" + randomBytes(30).toString("base64url").replace(/[^A-Za-z0-9]/g, "a").slice(0, 40);
  await prisma.gatewayToken.create({
    data: {
      customerId: customer.id,
      storeId: customer.storeId,
      name: "dev-seed",
      prefix: token.slice(0, 12),
      tokenHash: createHash("sha256").update(token).digest("hex"),
    },
  });

  console.log(JSON.stringify({ customerId: customer.id, accessCode: customer.accessCode, token }, null, 2));
}

main().finally(() => prisma.$disconnect());
