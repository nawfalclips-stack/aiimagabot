/**
 * One-shot DeepInfra setup for the LLM gateway — the same thing the admin UI
 * does (Providers → DeepInfra preset → Import models), from the terminal:
 *
 *   DEEPINFRA_API_KEY=... npm run gateway:deepinfra
 *   npm run gateway:deepinfra -- --key ... --models deepseek-ai/DeepSeek-V3.2,moonshotai/Kimi-K2.6
 *
 * Creates/updates the `deepinfra` provider (key encrypted like the UI does),
 * imports the chosen models with prices + context size from DeepInfra's public
 * catalog, maps them to the provider and enables them for every store.
 * Without --models a curated set of coding-friendly, non-deprecated models is
 * picked. Re-running is safe.
 */
import "./_lib/env";
import { PrismaClient } from "@prisma/client";
import fs from "node:fs";
import { encryptSecret } from "@/lib/gateway/crypto";

const prisma = new PrismaClient();
const BASE_URL = "https://api.deepinfra.com/v1/openai";
const CATALOG_URL = "https://api.deepinfra.com/models/list";
const CURATED = /deepseek-v3|deepseek-r1|kimi-k2|qwen3-coder|qwen3-235b|glm-4\.6|glm-5|gpt-oss|llama-4|claude|gemini|mistral-large|devstral/i;
const CURATED_MAX = 12;

function readEnv(name: string): string | undefined {
  if (process.env[name]) return process.env[name];
  for (const file of [".env.local", ".env"]) {
    if (!fs.existsSync(file)) continue;
    const m = fs.readFileSync(file, "utf8").match(new RegExp(`^\\s*${name}\\s*=\\s*"?([^"\\r\\n]+)"?`, "m"));
    if (m) return m[1].trim();
  }
  return undefined;
}

function arg(name: string): string | undefined {
  const i = process.argv.indexOf(`--${name}`);
  return i >= 0 ? process.argv[i + 1] : undefined;
}

function slugFromUpstream(id: string): string {
  const tail = id.includes("/") ? id.slice(id.lastIndexOf("/") + 1) : id;
  return tail.toLowerCase().replace(/[^a-z0-9.]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 48);
}

interface RawEntry {
  model_name: string;
  type?: string;
  max_tokens?: number | null;
  deprecated?: number | null;
  pricing?: { type?: string; cents_per_input_token?: number | null; cents_per_output_token?: number | null } | null;
}

async function main() {
  const apiKey = arg("key") ?? readEnv("DEEPINFRA_API_KEY");
  if (!apiKey) {
    console.error("Missing key. Pass --key <DeepInfra API key> or set DEEPINFRA_API_KEY in .env");
    process.exit(1);
  }

  // 1. Check the key works and see what the account can call.
  const modelsRes = await fetch(`${BASE_URL}/models`, { headers: { Authorization: `Bearer ${apiKey}` } });
  if (!modelsRes.ok) {
    console.error(`DeepInfra rejected the key: ${modelsRes.status} ${modelsRes.statusText}`);
    process.exit(1);
  }
  const available = new Set(((await modelsRes.json()) as { data?: Array<{ id: string }> }).data?.map((m) => m.id) ?? []);

  // 2. Public catalog → prices and context sizes.
  const catalog = new Map<string, RawEntry>();
  for (const m of (await (await fetch(CATALOG_URL)).json()) as RawEntry[]) {
    if (m?.model_name && m.type === "text-generation") catalog.set(m.model_name, m);
  }

  const wanted = arg("models")
    ? arg("models")!.split(",").map((s) => s.trim()).filter(Boolean)
    : [...catalog.values()]
        .filter((m) => !m.deprecated && available.has(m.model_name) && CURATED.test(m.model_name))
        .map((m) => m.model_name)
        .sort()
        .slice(0, CURATED_MAX);
  if (wanted.length === 0) {
    console.error("No models selected. Pass --models a,b,c (ids from https://deepinfra.com/models).");
    process.exit(1);
  }

  // 3. Provider row.
  const provider = await prisma.provider.upsert({
    where: { slug: "deepinfra" },
    update: { baseUrl: BASE_URL, apiKeyEnc: await encryptSecret(apiKey), enabled: true, healthStatus: "UP", lastCheckedAt: new Date(), lastError: "" },
    create: { slug: "deepinfra", name: "DeepInfra", baseUrl: BASE_URL, apiKeyEnc: await encryptSecret(apiKey), priority: 10, healthStatus: "UP", lastCheckedAt: new Date() },
  });
  console.log(`Provider "${provider.name}" ready (${provider.id})`);

  // 4. Models + mappings.
  for (const upstreamId of wanted) {
    const c = catalog.get(upstreamId);
    if (!available.has(upstreamId)) console.warn(`  ! ${upstreamId} is not in the account's /models list — importing anyway`);
    const priced = c
      ? {
          inputPriceMicroPerMTok: Math.round((c.pricing?.cents_per_input_token ?? 0) * 1e10),
          outputPriceMicroPerMTok: Math.round((c.pricing?.cents_per_output_token ?? 0) * 1e10),
          contextWindow: c.max_tokens && c.max_tokens > 0 ? c.max_tokens : null,
        }
      : {};
    const slug = slugFromUpstream(upstreamId);
    const model = await prisma.gatewayModel.upsert({
      where: { slug },
      update: { enabled: true, ...priced },
      create: { slug, displayName: upstreamId.split("/").pop() ?? upstreamId, enabled: true, ...priced },
    });
    await prisma.providerModel.upsert({
      where: { providerId_modelId: { providerId: provider.id, modelId: model.id } },
      update: { upstreamModelId: upstreamId, enabled: true },
      create: { providerId: provider.id, modelId: model.id, upstreamModelId: upstreamId },
    });
    const inUsd = (model.inputPriceMicroPerMTok / 1e6).toFixed(2);
    const outUsd = (model.outputPriceMicroPerMTok / 1e6).toFixed(2);
    console.log(`  ✓ ${slug.padEnd(40)} ← ${upstreamId}  ($${inUsd} / $${outUsd} per 1M${model.contextWindow ? `, ${Math.round(model.contextWindow / 1000)}k ctx` : ""})`);
  }

  console.log(`\nDone. Customers can now pick these model ids on /portal/api-access.`);
  console.log(`Quick test (replace TOKEN with a portal token and MODEL with a slug above):`);
  console.log(`  curl http://localhost:3000/v1/chat/completions -H "Authorization: Bearer TOKEN" -H "Content-Type: application/json" -d '{"model":"MODEL","messages":[{"role":"user","content":"Say hi"}]}'`);
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
