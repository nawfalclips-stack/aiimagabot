/**
 * Simple script to hash password and show SQL
 * Run: npx tsx scripts/hash-password.ts
 */

import bcrypt from "bcryptjs";

async function main() {
  const password = "chefapi2024";
  const hash = await bcrypt.hash(password, 12);

  console.log("Password:", password);
  console.log("Hash:", hash);
  console.log("\n=== Copy this SQL to Vercel Postgres ===\n");

  const sql = `
-- 1. Add columns if not exist
ALTER TABLE "Store" ADD COLUMN IF NOT EXISTS "subdomain" TEXT;
ALTER TABLE "Admin" ADD COLUMN IF NOT EXISTS "role" TEXT DEFAULT 'FULL_ACCESS';

-- 2. Create ChefAPI Store
INSERT INTO "Store" (id, name, "logoText", "storeUrl", subdomain, "primaryColor", "fontFamily", "createdAt", "updatedAt")
VALUES (
  'chefapi',
  'ChefAPI',
  'ChefAPI',
  'https://www.gamsgo.com/shop-store/3dcf9b33-e8d1-b908-8069-d6603ca4ab78',
  'chefapi',
  '#10b981',
  'Roboto',
  NOW(),
  NOW()
)
ON CONFLICT (id) DO NOTHING;

-- 3. Create ChefAPI Admin
INSERT INTO "Admin" (id, email, name, "passwordHash", "isReadOnly", role, "createdAt", "updatedAt")
VALUES (
  gen_random_uuid()::text,
  'admin@chefapi.com',
  'ChefAPI Admin',
  '${hash}',
  false,
  'FULL_ACCESS',
  NOW(),
  NOW()
)
ON CONFLICT (email) DO UPDATE SET "passwordHash" = EXCLUDED."passwordHash"
RETURNING id;

-- 4. Link admin to store (run after seeing the ID above)
INSERT INTO "AdminStoreAccess" (id, "adminId", "storeId", "createdAt", "updatedAt")
SELECT
  gen_random_uuid()::text,
  a.id,
  'chefapi',
  NOW(),
  NOW()
FROM "Admin" a
WHERE a.email = 'admin@chefapi.com'
ON CONFLICT DO NOTHING;

-- 5. Settings
INSERT INTO "Setting" ("storeId", key, value, "createdAt", "updatedAt")
VALUES
  ('chefapi', 'SITE_NAME', 'ChefAPI', NOW(), NOW()),
  ('chefapi', 'LOGO_TEXT', 'ChefAPI', NOW(), NOW()),
  ('chefapi', 'SUPPORT_EMAIL', 'support@chefapi.com', NOW(), NOW()),
  ('chefapi', 'BRAND_COLOR', '#10b981', NOW(), NOW()),
  ('chefapi', 'STORE_URL', 'https://www.gamsgo.com/shop-store/3dcf9b33-e8d1-b908-8069-d6603ca4ab78', NOW(), NOW())
ON CONFLICT ("storeId", key) DO NOTHING;
`;

  console.log(sql);
}

main();
