/**
 * Re-encrypt every stored secret under PROVIDER_KEY_SECRET (WS12.4).
 *
 *   npm run keys:reencrypt            # apply
 *   npm run keys:reencrypt -- --dry   # report only
 *
 * Covers Provider.apiKeyEnc and GatewayToken.tokenEnc. Rows already at v2 are
 * skipped, so re-running is a no-op. Needs SESSION_SECRET (to decrypt v1) and
 * PROVIDER_KEY_SECRET (to encrypt v2) in the environment / .env.
 * Exit code 2 when any row could not be decrypted (the value is left as is).
 */
import "./_lib/env";
import { prisma } from "@/lib/prisma";
import { cipherVersion, keySecretConfigured, reencryptSecret } from "@/lib/gateway/crypto";

const dry = process.argv.includes("--dry");

interface Report {
  migrated: number;
  alreadyV2: number;
  failed: string[];
}

async function run<T extends { id: string }>(
  label: string,
  rows: T[],
  read: (row: T) => string,
  write: (id: string, value: string) => Promise<unknown>
): Promise<Report> {
  const report: Report = { migrated: 0, alreadyV2: 0, failed: [] };
  for (const row of rows) {
    const stored = read(row);
    if (!stored) continue;
    if (cipherVersion(stored) === "v2") {
      report.alreadyV2++;
      continue;
    }
    try {
      const next = await reencryptSecret(stored);
      if (next === null) continue;
      if (!dry) await write(row.id, next);
      report.migrated++;
    } catch (e) {
      report.failed.push(`${label} ${row.id}: ${e instanceof Error ? e.message : String(e)}`);
    }
  }
  console.log(`[keys:reencrypt] ${label}: ${dry ? "would migrate" : "migrated"} ${report.migrated}, already v2 ${report.alreadyV2}, failed ${report.failed.length}`);
  return report;
}

async function main() {
  if (!keySecretConfigured()) {
    console.error("[keys:reencrypt] PROVIDER_KEY_SECRET is not set. Generate one with `openssl rand -base64 32`.");
    process.exit(1);
  }
  const providers = await run(
    "Provider.apiKeyEnc",
    await prisma.provider.findMany({ select: { id: true, apiKeyEnc: true } }),
    (r) => r.apiKeyEnc,
    (id, apiKeyEnc) => prisma.provider.update({ where: { id }, data: { apiKeyEnc } })
  );
  const tokens = await run(
    "GatewayToken.tokenEnc",
    await prisma.gatewayToken.findMany({ select: { id: true, tokenEnc: true } }),
    (r) => r.tokenEnc,
    (id, tokenEnc) => prisma.gatewayToken.update({ where: { id }, data: { tokenEnc } })
  );
  const failed = [...providers.failed, ...tokens.failed];
  for (const f of failed) console.error(`  FAILED ${f}`);
  if (failed.length > 0) process.exitCode = 2;
  else if (!dry) console.log("[keys:reencrypt] done. Once every row is v2, v1 support can be dropped (docs/runbook.md).");
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
