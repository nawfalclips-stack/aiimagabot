/**
 * One-off, idempotent ledger backfill (WS1). See lib/billing/backfill.ts.
 *
 *   npm run ledger:backfill            # apply
 *   npm run ledger:backfill -- --dry   # report only
 *
 * Safe to re-run: existing keys are skipped (unique `opening:{id}:{pot}`).
 */
import { prisma } from "@/lib/prisma";
import { backfillLedger } from "@/lib/billing/backfill";

const dry = process.argv.includes("--dry");

async function main() {
  const r = await backfillLedger({ dry });
  if (r.carried > 0) console.log(`[ledger:backfill] copied gateway carry to balance carry for ${r.carried} customer(s)`);
  console.log(`[ledger:backfill] ${dry ? "would create" : "created"} ${r.created} opening entries; ${r.verified} pots already in balance; ${r.drift.length} with drift`);
  for (const d of r.drift) console.log(`  DRIFT ${d}`);
  if (r.drift.length > 0) process.exitCode = 2;
}

main()
  .catch((e) => {
    console.error(e);
    process.exit(1);
  })
  .finally(() => prisma.$disconnect());
