#!/usr/bin/env node
// Applies Prisma migrations to the Postgres database in DATABASE_URL.
// Replaces the old `prisma db push --accept-data-loss` on Vercel builds.
//
//   node scripts/migrate-deploy.mjs
//
// Behaviour:
//   • Refuses to run against SQLite (local dev keeps `npm run db:push`).
//   • On Vercel:
//       production → migrate deploy.
//       preview    → requires its OWN database: fails loudly when DATABASE_URL
//                    is missing or when its host equals PRODUCTION_DB_HOST.
//   • First run on a database created by `db push` (no `_prisma_migrations`
//     table yet, but the app tables exist): marks `0000_baseline` as applied
//     so `migrate deploy` starts from there instead of trying to recreate tables.
//   • Never drops or rewrites anything on its own — that is what migrations
//     under prisma/migrations/ are for (additive only; see docs/gateway.md).

import { spawnSync } from "node:child_process";
import { existsSync, readFileSync } from "node:fs";
import { applyEnvAliases } from "../lib/env-aliases.mjs";

function loadEnvFile(path) {
  if (!existsSync(path)) return;
  for (const line of readFileSync(path, "utf8").split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)\s*$/);
    if (!m) continue;
    let v = m[2].trim();
    if (v.startsWith('"') && v.endsWith('"')) v = v.slice(1, -1);
    if (!(m[1] in process.env)) process.env[m[1]] = v;
  }
}
loadEnvFile(".env");
applyEnvAliases();

const SCHEMA = "prisma/schema.prisma";
// The schema declares directUrl = env("DIRECT_URL") for migrations; default it to the runtime URL.
if (!process.env.DIRECT_URL && process.env.DATABASE_URL) process.env.DIRECT_URL = process.env.DATABASE_URL;
const BASELINE = "0000_baseline";
const url = process.env.DATABASE_URL ?? "";
const vercelEnv = process.env.VERCEL_ENV ?? "";

function fail(msg) {
  console.error(`\n[migrate-deploy] ${msg}\n`);
  process.exit(1);
}

function hostOf(u) {
  try {
    return new URL(u).hostname.toLowerCase();
  } catch {
    return "";
  }
}

function prisma(args, { capture = false } = {}) {
  const r = spawnSync("npx", ["prisma", ...args, "--schema", SCHEMA], {
    stdio: capture ? ["ignore", "pipe", "pipe"] : "inherit",
    shell: process.platform === "win32",
    env: process.env,
    encoding: "utf8",
  });
  return { status: r.status ?? 1, out: `${r.stdout ?? ""}${r.stderr ?? ""}` };
}

// ── guards ──────────────────────────────────────────────────────────────
if (!url) {
  if (vercelEnv === "preview") {
    fail(
      "DATABASE_URL is not set for the Preview environment.\n" +
        "Previews must use their own database (e.g. a separate Supabase project or branch).\n" +
        "Add DATABASE_URL under Settings → Environment Variables → Preview, then redeploy."
    );
  }
  fail("DATABASE_URL is not set.");
}
if (url.startsWith("file:")) {
  console.log("[migrate-deploy] SQLite detected — nothing to do (use `npm run db:push` locally).");
  process.exit(0);
}
if (!/^postgres(ql)?:/.test(url)) fail(`Unsupported DATABASE_URL scheme: ${url.split(":")[0]}`);

const prodHost = (process.env.PRODUCTION_DB_HOST ?? "").toLowerCase();
if (vercelEnv === "preview") {
  if (!prodHost) {
    console.warn(
      "[migrate-deploy] WARNING: PRODUCTION_DB_HOST is not set, so this preview cannot prove it is not pointing at production.\n" +
        "               Set PRODUCTION_DB_HOST (all environments) to the production database hostname."
    );
  } else if (hostOf(url) === prodHost) {
    fail(
      `Refusing to migrate: this Preview deployment's DATABASE_URL points at the production host (${prodHost}).\n` +
        "Give previews their own database."
    );
  }
}
if (vercelEnv && vercelEnv !== "production" && vercelEnv !== "preview") {
  console.log(`[migrate-deploy] VERCEL_ENV=${vercelEnv} — skipping migrations.`);
  process.exit(0);
}

if (vercelEnv === "production" && process.env.DIRECT_URL === url && /pgbouncer=true|:6543\//.test(url)) {
  console.warn(
    "[migrate-deploy] WARNING: DIRECT_URL is not set, so migrations run through the connection pooler. " +
      "Set DIRECT_URL to the direct connection (port 5432) — see docs/runbook.md → Database pooling."
  );
}
console.log(`[migrate-deploy] target host: ${hostOf(url)} (${vercelEnv || "local"}); migrations via ${hostOf(process.env.DIRECT_URL)}`);

// ── baseline detection ──────────────────────────────────────────────────
// Probe tables with `prisma db execute` (exit code ≠ 0 when the relation is
// missing). This avoids importing @prisma/client, which locally may have been
// generated for SQLite and would refuse a Postgres URL.
function tableExists(qualifiedName) {
  const r = spawnSync("npx", ["prisma", "db", "execute", "--schema", SCHEMA, "--stdin"], {
    input: `SELECT 1 FROM ${qualifiedName} LIMIT 1;`,
    stdio: ["pipe", "pipe", "pipe"],
    shell: process.platform === "win32",
    env: process.env,
    encoding: "utf8",
  });
  if (r.status === 0) return true;
  const text = `${r.stdout ?? ""}${r.stderr ?? ""}`;
  if (/does not exist|relation .* not found|42P01/i.test(text)) return false;
  fail(`Could not probe ${qualifiedName}:
${text.trim()}`);
}

const state = {
  migrations: tableExists('"_prisma_migrations"'),
  customers: tableExists('"Customer"'),
};
if (!state.migrations && state.customers) {
  console.log(`[migrate-deploy] Existing schema without migration history — marking ${BASELINE} as applied.`);
  const r = prisma(["migrate", "resolve", "--applied", BASELINE]);
  if (r.status !== 0) fail(`migrate resolve failed (exit ${r.status}).`);
}

// ── deploy ──────────────────────────────────────────────────────────────
const r = prisma(["migrate", "deploy"]);
if (r.status !== 0) fail(`migrate deploy failed (exit ${r.status}).`);
console.log("[migrate-deploy] ✅ migrations applied.");
