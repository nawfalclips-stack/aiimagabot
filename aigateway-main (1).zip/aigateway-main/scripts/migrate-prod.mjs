/**
 * LEGACY — no longer part of `vercel-build`. One-off fixes from the move to
 * multi-store (its Store inserts reference a `subdomain` column that no longer
 * exists). Kept for history; run by hand only if you know you need it.
 *
 * v5 — The failing row shows the Store INSERT itself fails. The row has 9
 * values: id, name, logoText, storeUrl, subdomain, primaryColor, fontFamily,
 * createdAt, updatedAt=null. "updatedAt" is NULL because @updatedAt is a
 * Prisma-level feature — raw SQL bypasses it! Fix: set updatedAt explicitly.
 */
import { readFileSync } from "node:fs";

function loadEnv() {
  try {
    for (const line of readFileSync(".env", "utf8").split(/\r?\n/)) {
      const m = line.match(/^\s*([A-Z_]+)\s*=\s*"?(.*?)"?\s*$/);
      if (m && !(m[1] in process.env)) process.env[m[1]] = m[2];
    }
  } catch {}
}
loadEnv();
// Vercel Storage integrations (Supabase) use their own variable names.
const { applyEnvAliases } = await import("../lib/env-aliases.mjs");
applyEnvAliases();

const url = process.env.DATABASE_URL ?? "";
// The schema declares directUrl = env("DIRECT_URL") for migrations; default it to the runtime URL.
if (!process.env.DIRECT_URL && process.env.DATABASE_URL) process.env.DIRECT_URL = process.env.DATABASE_URL;
if (!url.startsWith("postgres")) {
  console.error("[migrate-prod] DATABASE_URL must be the production Postgres URL.");
  process.exit(1);
}

const { execSync } = await import("node:child_process");

function sql(query, label) {
  try {
    execSync(`npx prisma db execute --schema prisma/schema.prisma --stdin`, {
      input: query,
      stdio: ["pipe", "inherit", "inherit"],
      env: process.env,
      shell: true,
    });
    console.log(`  ok: ${label}`);
  } catch (e) {
    console.log(`  skip: ${label}`);
  }
}

console.log("[migrate-prod] Store upserts with explicit timestamps…");
sql(`
INSERT INTO "Store" ("id","name","logoText","storeUrl","subdomain","primaryColor","fontFamily","createdAt","updatedAt")
VALUES ('aerolink','AeroLink API','AeroLink','https://www.gamsgo.com/shop-store/ab3a9d0e-937f-e93e-1b66-5dca973aa779','aerolink','#0ea5e9','Inter',NOW(),NOW())
ON CONFLICT ("id") DO UPDATE SET "subdomain" = EXCLUDED."subdomain", "updatedAt" = NOW();
`, "upsert aerolink");
sql(`
UPDATE "Store" SET "subdomain" = 'old-' || "id" WHERE "subdomain" = 'aerolink' AND "id" <> 'aerolink';
`, "free aerolink subdomain");
sql(`
INSERT INTO "Store" ("id","name","logoText","storeUrl","subdomain","primaryColor","fontFamily","createdAt","updatedAt")
VALUES ('chefapi','ChefAPI','ChefAPI','https://www.gamsgo.com/shop-store/3dcf9b33-e8d1-b908-8069-d6603ca4ab78','chefapi','#f97316','Plus Jakarta Sans',NOW(),NOW())
ON CONFLICT ("id") DO UPDATE SET "subdomain" = EXCLUDED."subdomain", "updatedAt" = NOW();
`, "upsert chefapi");

console.log("[migrate-prod] Stores for unknown referenced ids…");
sql(`
INSERT INTO "Store" ("id","name","logoText","storeUrl","subdomain","createdAt","updatedAt")
SELECT s."storeId", s."storeId", s."storeId",
       'https://www.gamsgo.com/shop-store/ab3a9d0e-937f-e93e-1b66-5dca973aa779',
       'store-' || s."storeId", NOW(), NOW()
FROM (SELECT DISTINCT "storeId" FROM "Customer" WHERE "storeId" IS NOT NULL) s
WHERE NOT EXISTS (SELECT 1 FROM "Store" st WHERE st."id" = s."storeId");
`, "create stores for unknown ids");

console.log("[migrate-prod] Backfill NULL storeIds…");
for (const table of [
  "ActivityLog", "ApiPoolKey", "Customer", "Documentation",
  "RechargeRequest", "Setting", "Ticket", "UsageLog",
]) {
  sql(
    `UPDATE "${table}" SET "storeId"='aerolink' WHERE "storeId" IS NULL OR "storeId" NOT IN (SELECT "id" FROM "Store");`,
    `backfill ${table}`
  );
}

// The Customer table's own new columns may also need updatedAt when db push alters rows — not needed for ADD COLUMN.
console.log("[migrate-prod] ✅ Done.");
