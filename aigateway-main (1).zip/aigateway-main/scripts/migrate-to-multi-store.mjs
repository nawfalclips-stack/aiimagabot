/**
 * Safe migration: Check current schema and migrate accordingly
 */

import Database from 'better-sqlite3';
import fs from 'fs';
import path from 'path';

const DB_PATH = path.join(process.cwd(), 'prisma', 'dev.db');
const BACKUP_PATH = path.join(process.cwd(), 'prisma', `dev.db.backup-${Date.now()}`);

console.log('🔄 Starting safe multi-store migration...\n');

// Step 1: Backup
console.log('1. Creating backup...');
if (fs.existsSync(DB_PATH)) {
  fs.copyFileSync(DB_PATH, BACKUP_PATH);
  console.log(`✓ Backup created: ${BACKUP_PATH}\n`);
}

const db = new Database(DB_PATH);

try {
  db.pragma('foreign_keys = OFF');

  // Get current Customer columns
  console.log('2. Checking current schema...');
  const columns = db.prepare("PRAGMA table_info(Customer)").all();
  const columnNames = columns.map(c => c.name);
  console.log('  Current Customer columns:', columnNames.join(', '));

  // Check if isActivated exists
  const hasIsActivated = columnNames.includes('isActivated');
  const hasRejectedAt = columnNames.includes('rejectedAt');
  const hasRejectionReason = columnNames.includes('rejectionReason');

  console.log(`  - isActivated: ${hasIsActivated ? 'YES' : 'NO'}`);
  console.log(`  - rejectedAt: ${hasRejectedAt ? 'YES' : 'NO'}`);
  console.log(`  - rejectionReason: ${hasRejectionReason ? 'YES' : 'NO'}\n`);

  // Build the INSERT SELECT based on available columns
  let selectColumns = `
    id, 'aerolink' as storeId, accessCode, status, notes,
    initialBalanceCents, usedBalanceCents, initialBonusCents, usedBonusCents, profitCents,
    purchasedAgain, purchasedAgainAt, offerTitle, pendingBonusCents, reviewBonusStatus,
    reviewClaimedAt, finishedAt, suspendedAt
  `;

  if (hasIsActivated) {
    selectColumns += ', isActivated';
  } else {
    selectColumns += ', 0 as isActivated';
  }

  if (hasRejectedAt) {
    selectColumns += ', rejectedAt';
  } else {
    selectColumns += ', NULL as rejectedAt';
  }

  if (hasRejectionReason) {
    selectColumns += ', rejectionReason';
  } else {
    selectColumns += ", '' as rejectionReason";
  }

  selectColumns += ', deletedAt, createdAt, updatedAt';

  console.log('3. Creating Store table...');
  db.exec(`
    CREATE TABLE IF NOT EXISTS "Store" (
      "id" TEXT NOT NULL PRIMARY KEY,
      "name" TEXT NOT NULL,
      "logoText" TEXT NOT NULL,
      "storeUrl" TEXT NOT NULL,
      "primaryColor" TEXT NOT NULL DEFAULT '#0ea5e9',
      "fontFamily" TEXT NOT NULL DEFAULT 'Inter',
      "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      "updatedAt" DATETIME NOT NULL
    );
  `);
  console.log('✓ Store table created\n');

  console.log('4. Creating AdminStoreAccess table...');
  db.exec(`
    CREATE TABLE IF NOT EXISTS "AdminStoreAccess" (
      "id" TEXT NOT NULL PRIMARY KEY,
      "adminId" TEXT NOT NULL,
      "storeId" TEXT NOT NULL,
      "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      "updatedAt" DATETIME NOT NULL,
      FOREIGN KEY ("adminId") REFERENCES "Admin"("id") ON DELETE CASCADE,
      FOREIGN KEY ("storeId") REFERENCES "Store"("id") ON DELETE CASCADE
    );

    CREATE UNIQUE INDEX IF NOT EXISTS "AdminStoreAccess_adminId_storeId_key" ON "AdminStoreAccess"("adminId", "storeId");
    CREATE INDEX IF NOT EXISTS "AdminStoreAccess_adminId_idx" ON "AdminStoreAccess"("adminId");
    CREATE INDEX IF NOT EXISTS "AdminStoreAccess_storeId_idx" ON "AdminStoreAccess"("storeId");
  `);
  console.log('✓ AdminStoreAccess table created\n');

  console.log('5. Inserting stores...');
  const now = new Date().toISOString();

  db.prepare(`
    INSERT OR IGNORE INTO "Store" ("id", "name", "logoText", "storeUrl", "primaryColor", "fontFamily", "createdAt", "updatedAt")
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `).run('aerolink', 'AeroLink API', 'AeroLink',
    'https://www.gamsgo.com/shop-store/ab3a9d0e-937f-e93e-1b66-5dca973aa779',
    '#0ea5e9', 'Inter', now, now);

  db.prepare(`
    INSERT OR IGNORE INTO "Store" ("id", "name", "logoText", "storeUrl", "primaryColor", "fontFamily", "createdAt", "updatedAt")
    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
  `).run('chefapi', 'ChefAPI', 'ChefAPI',
    'https://www.gamsgo.com/shop-store/3dcf9b33-e8d1-b908-8069-d6603ca4ab78?category_id=e994486e-b21a-fcfc-8844-360b39ae878e',
    '#f97316', 'Plus Jakarta Sans', now, now);

  console.log('✓ Stores inserted\n');

  console.log('6. Migrating Customer table...');
  db.exec(`
    CREATE TABLE "Customer_new" (
      "id" TEXT NOT NULL PRIMARY KEY,
      "storeId" TEXT NOT NULL DEFAULT 'aerolink',
      "accessCode" TEXT NOT NULL,
      "status" TEXT NOT NULL DEFAULT 'ACTIVE',
      "notes" TEXT NOT NULL DEFAULT '',
      "initialBalanceCents" INTEGER NOT NULL DEFAULT 0,
      "usedBalanceCents" INTEGER NOT NULL DEFAULT 0,
      "initialBonusCents" INTEGER NOT NULL DEFAULT 0,
      "usedBonusCents" INTEGER NOT NULL DEFAULT 0,
      "profitCents" INTEGER NOT NULL DEFAULT 0,
      "purchasedAgain" TEXT NOT NULL DEFAULT 'UNKNOWN',
      "purchasedAgainAt" DATETIME,
      "offerTitle" TEXT NOT NULL DEFAULT '',
      "pendingBonusCents" INTEGER NOT NULL DEFAULT 0,
      "reviewBonusStatus" TEXT NOT NULL DEFAULT 'NONE',
      "reviewClaimedAt" DATETIME,
      "finishedAt" DATETIME,
      "suspendedAt" DATETIME,
      "isActivated" INTEGER NOT NULL DEFAULT 0,
      "rejectedAt" DATETIME,
      "rejectionReason" TEXT NOT NULL DEFAULT '',
      "deletedAt" DATETIME,
      "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      "updatedAt" DATETIME NOT NULL,
      FOREIGN KEY ("storeId") REFERENCES "Store"("id") ON DELETE CASCADE
    );

    INSERT INTO "Customer_new" SELECT ${selectColumns} FROM "Customer";

    DROP TABLE "Customer";
    ALTER TABLE "Customer_new" RENAME TO "Customer";

    CREATE UNIQUE INDEX "Customer_accessCode_key" ON "Customer"("accessCode");
    CREATE INDEX "Customer_status_idx" ON "Customer"("status");
    CREATE INDEX "Customer_deletedAt_idx" ON "Customer"("deletedAt");
    CREATE INDEX "Customer_createdAt_idx" ON "Customer"("createdAt");
    CREATE INDEX "Customer_storeId_idx" ON "Customer"("storeId");
    CREATE INDEX "Customer_storeId_status_idx" ON "Customer"("storeId", "status");
  `);
  console.log('✓ Customer migrated\n');

  // Migrate other tables...
  console.log('7. Migrating ActivityLog...');
  db.exec(`
    CREATE TABLE "ActivityLog_new" (
      "id" TEXT NOT NULL PRIMARY KEY,
      "storeId" TEXT NOT NULL DEFAULT 'aerolink',
      "action" TEXT NOT NULL,
      "description" TEXT NOT NULL,
      "adminId" TEXT,
      "customerId" TEXT,
      "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      "updatedAt" DATETIME NOT NULL,
      FOREIGN KEY ("adminId") REFERENCES "Admin"("id") ON DELETE SET NULL,
      FOREIGN KEY ("customerId") REFERENCES "Customer"("id") ON DELETE CASCADE
    );

    INSERT INTO "ActivityLog_new" SELECT
      id, 'aerolink', action, description, adminId, customerId, createdAt, updatedAt
    FROM "ActivityLog";

    DROP TABLE "ActivityLog";
    ALTER TABLE "ActivityLog_new" RENAME TO "ActivityLog";

    CREATE INDEX "ActivityLog_createdAt_idx" ON "ActivityLog"("createdAt");
    CREATE INDEX "ActivityLog_customerId_idx" ON "ActivityLog"("customerId");
    CREATE INDEX "ActivityLog_storeId_idx" ON "ActivityLog"("storeId");
    CREATE INDEX "ActivityLog_storeId_createdAt_idx" ON "ActivityLog"("storeId", "createdAt");
  `);
  console.log('✓ ActivityLog migrated\n');

  console.log('8. Migrating Setting...');
  db.exec(`
    CREATE TABLE "Setting_new" (
      "id" TEXT NOT NULL PRIMARY KEY,
      "storeId" TEXT NOT NULL DEFAULT 'aerolink',
      "key" TEXT NOT NULL,
      "value" TEXT NOT NULL,
      "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      "updatedAt" DATETIME NOT NULL,
      FOREIGN KEY ("storeId") REFERENCES "Store"("id") ON DELETE CASCADE
    );

    INSERT INTO "Setting_new" SELECT
      id, 'aerolink', key, value, createdAt, updatedAt
    FROM "Setting";

    DROP TABLE "Setting";
    ALTER TABLE "Setting_new" RENAME TO "Setting";

    CREATE UNIQUE INDEX "Setting_storeId_key_key" ON "Setting"("storeId", "key");
    CREATE INDEX "Setting_storeId_idx" ON "Setting"("storeId");
  `);
  console.log('✓ Setting migrated\n');

  console.log('9. Migrating Documentation...');
  db.exec(`
    CREATE TABLE "Documentation_new" (
      "id" TEXT NOT NULL PRIMARY KEY,
      "storeId" TEXT NOT NULL DEFAULT 'aerolink',
      "slug" TEXT NOT NULL,
      "category" TEXT NOT NULL,
      "os" TEXT NOT NULL,
      "title" TEXT NOT NULL,
      "content" TEXT NOT NULL,
      "sortOrder" INTEGER NOT NULL DEFAULT 0,
      "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
      "updatedAt" DATETIME NOT NULL
    );

    INSERT INTO "Documentation_new" SELECT
      id, 'aerolink', slug, category, os, title, content, sortOrder, createdAt, updatedAt
    FROM "Documentation";

    DROP TABLE "Documentation";
    ALTER TABLE "Documentation_new" RENAME TO "Documentation";

    CREATE UNIQUE INDEX "Documentation_slug_key" ON "Documentation"("slug");
    CREATE INDEX "Documentation_category_os_idx" ON "Documentation"("category", "os");
    CREATE INDEX "Documentation_storeId_idx" ON "Documentation"("storeId");
  `);
  console.log('✓ Documentation migrated\n');

  // Check if ApiPoolKey, UsageLog, Ticket, RechargeRequest exist
  const tables = db.prepare("SELECT name FROM sqlite_master WHERE type='table'").all();
  const tableNames = tables.map(t => t.name);

  if (tableNames.includes('ApiPoolKey')) {
    console.log('10. Migrating ApiPoolKey...');
    db.exec(`
      CREATE TABLE "ApiPoolKey_new" (
        "id" TEXT NOT NULL PRIMARY KEY,
        "storeId" TEXT NOT NULL DEFAULT 'aerolink',
        "key" TEXT NOT NULL,
        "status" TEXT NOT NULL DEFAULT 'AVAILABLE',
        "customerId" TEXT,
        "orderId" TEXT,
        "assignedAt" DATETIME,
        "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        "updatedAt" DATETIME NOT NULL,
        FOREIGN KEY ("customerId") REFERENCES "Customer"("id") ON DELETE SET NULL
      );

      INSERT INTO "ApiPoolKey_new" SELECT
        id, 'aerolink', key, status, customerId, orderId, assignedAt, createdAt, updatedAt
      FROM "ApiPoolKey";

      DROP TABLE "ApiPoolKey";
      ALTER TABLE "ApiPoolKey_new" RENAME TO "ApiPoolKey";

      CREATE UNIQUE INDEX "ApiPoolKey_key_key" ON "ApiPoolKey"("key");
      CREATE UNIQUE INDEX "ApiPoolKey_customerId_key" ON "ApiPoolKey"("customerId");
      CREATE INDEX "ApiPoolKey_status_idx" ON "ApiPoolKey"("status");
      CREATE INDEX "ApiPoolKey_storeId_idx" ON "ApiPoolKey"("storeId");
      CREATE INDEX "ApiPoolKey_storeId_status_idx" ON "ApiPoolKey"("storeId", "status");
    `);
    console.log('✓ ApiPoolKey migrated\n');
  }

  if (tableNames.includes('UsageLog')) {
    console.log('11. Migrating UsageLog...');
    db.exec(`
      CREATE TABLE "UsageLog_new" (
        "id" TEXT NOT NULL PRIMARY KEY,
        "storeId" TEXT NOT NULL DEFAULT 'aerolink',
        "customerId" TEXT NOT NULL,
        "happenedAt" DATETIME NOT NULL,
        "keyLabel" TEXT NOT NULL DEFAULT '',
        "model" TEXT NOT NULL DEFAULT '',
        "tokens" TEXT NOT NULL DEFAULT '',
        "costMicroUsd" INTEGER NOT NULL DEFAULT 0,
        "latency" TEXT NOT NULL DEFAULT '',
        "status" TEXT NOT NULL DEFAULT '',
        "addedBy" TEXT NOT NULL DEFAULT 'Administrator',
        "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        "updatedAt" DATETIME NOT NULL,
        FOREIGN KEY ("customerId") REFERENCES "Customer"("id") ON DELETE CASCADE
      );

      INSERT INTO "UsageLog_new" SELECT
        id, 'aerolink', customerId, happenedAt, keyLabel, model, tokens, costMicroUsd,
        latency, status, addedBy, createdAt, updatedAt
      FROM "UsageLog";

      DROP TABLE "UsageLog";
      ALTER TABLE "UsageLog_new" RENAME TO "UsageLog";

      CREATE INDEX "UsageLog_customerId_happenedAt_idx" ON "UsageLog"("customerId", "happenedAt");
      CREATE INDEX "UsageLog_storeId_idx" ON "UsageLog"("storeId");
    `);
    console.log('✓ UsageLog migrated\n');
  }

  if (tableNames.includes('Ticket')) {
    console.log('12. Migrating Ticket...');
    db.exec(`
      CREATE TABLE "Ticket_new" (
        "id" TEXT NOT NULL PRIMARY KEY,
        "storeId" TEXT NOT NULL DEFAULT 'aerolink',
        "customerId" TEXT NOT NULL,
        "type" TEXT NOT NULL DEFAULT 'OTHER',
        "status" TEXT NOT NULL DEFAULT 'OPEN',
        "title" TEXT NOT NULL,
        "description" TEXT NOT NULL,
        "screenshotUrl" TEXT NOT NULL DEFAULT '',
        "autoFixAt" DATETIME,
        "autoFixed" INTEGER NOT NULL DEFAULT 0,
        "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        "updatedAt" DATETIME NOT NULL,
        FOREIGN KEY ("customerId") REFERENCES "Customer"("id") ON DELETE CASCADE
      );

      INSERT INTO "Ticket_new" SELECT
        id, 'aerolink', customerId, type, status, title, description, screenshotUrl,
        autoFixAt, autoFixed, createdAt, updatedAt
      FROM "Ticket";

      DROP TABLE "Ticket";
      ALTER TABLE "Ticket_new" RENAME TO "Ticket";

      CREATE INDEX "Ticket_customerId_idx" ON "Ticket"("customerId");
      CREATE INDEX "Ticket_status_autoFixAt_idx" ON "Ticket"("status", "autoFixAt");
      CREATE INDEX "Ticket_storeId_idx" ON "Ticket"("storeId");
    `);
    console.log('✓ Ticket migrated\n');
  }

  if (tableNames.includes('RechargeRequest')) {
    console.log('13. Migrating RechargeRequest...');
    db.exec(`
      CREATE TABLE "RechargeRequest_new" (
        "id" TEXT NOT NULL PRIMARY KEY,
        "storeId" TEXT NOT NULL DEFAULT 'aerolink',
        "customerId" TEXT NOT NULL,
        "orderNumber" TEXT NOT NULL,
        "offerTitle" TEXT NOT NULL,
        "balanceCents" INTEGER NOT NULL,
        "bonusCents" INTEGER NOT NULL DEFAULT 0,
        "status" TEXT NOT NULL DEFAULT 'PENDING',
        "rejectedReason" TEXT NOT NULL DEFAULT '',
        "processedAt" DATETIME,
        "createdAt" DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
        "updatedAt" DATETIME NOT NULL,
        FOREIGN KEY ("customerId") REFERENCES "Customer"("id") ON DELETE CASCADE
      );

      INSERT INTO "RechargeRequest_new" SELECT
        id, 'aerolink', customerId, orderNumber, offerTitle, balanceCents, bonusCents,
        status, rejectedReason, processedAt, createdAt, updatedAt
      FROM "RechargeRequest";

      DROP TABLE "RechargeRequest";
      ALTER TABLE "RechargeRequest_new" RENAME TO "RechargeRequest";

      CREATE UNIQUE INDEX "RechargeRequest_orderNumber_key" ON "RechargeRequest"("orderNumber");
      CREATE INDEX "RechargeRequest_customerId_idx" ON "RechargeRequest"("customerId");
      CREATE INDEX "RechargeRequest_status_createdAt_idx" ON "RechargeRequest"("status", "createdAt");
      CREATE INDEX "RechargeRequest_storeId_idx" ON "RechargeRequest"("storeId");
    `);
    console.log('✓ RechargeRequest migrated\n');
  }

  console.log('14. Creating admin store access...');
  const admins = db.prepare('SELECT id, email FROM Admin').all();

  for (const admin of admins) {
    db.prepare(`
      INSERT OR IGNORE INTO "AdminStoreAccess" ("id", "adminId", "storeId", "createdAt", "updatedAt")
      VALUES (?, ?, ?, ?, ?)
    `).run(`asa_${admin.id}_aerolink`, admin.id, 'aerolink', now, now);

    db.prepare(`
      INSERT OR IGNORE INTO "AdminStoreAccess" ("id", "adminId", "storeId", "createdAt", "updatedAt")
      VALUES (?, ?, ?, ?, ?)
    `).run(`asa_${admin.id}_chefapi`, admin.id, 'chefapi', now, now);

    console.log(`  ✓ Admin ${admin.email} has access to both stores`);
  }

  db.pragma('foreign_keys = ON');

  console.log('\n✅ Migration completed successfully!');
  console.log('\nNext steps:');
  console.log('1. Run: node scripts/prisma.mjs generate');
  console.log('2. Test the application');
  console.log(`3. If everything works, delete backup: ${BACKUP_PATH}`);

} catch (error) {
  console.error('\n❌ Migration failed:', error);
  console.log(`\n⚠️  Restore from backup: ${BACKUP_PATH}`);
  process.exit(1);
} finally {
  db.close();
}
