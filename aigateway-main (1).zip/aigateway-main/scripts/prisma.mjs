#!/usr/bin/env node
// Runs a Prisma CLI command against the schema that matches DATABASE_URL:
//   file:...        → prisma/schema.sqlite.prisma  (local development)
//   postgres(ql)... → prisma/schema.prisma         (production / Vercel)
//
// Usage: node scripts/prisma.mjs generate | db push | ...

import { spawnSync } from "node:child_process";
import { existsSync, readFileSync } from "node:fs";
import { applyEnvAliases } from "../lib/env-aliases.mjs";

function loadEnvFile(path) {
  if (!existsSync(path)) return;
  for (const line of readFileSync(path, "utf8").split(/\r?\n/)) {
    const match = line.match(/^\s*([A-Za-z_][A-Za-z0-9_]*)\s*=\s*(.*)\s*$/);
    if (!match) continue;
    const key = match[1];
    let value = match[2].trim();
    if (value.startsWith('"') && value.endsWith('"')) value = value.slice(1, -1);
    if (!(key in process.env)) process.env[key] = value;
  }
}

loadEnvFile(".env");
// Vercel Storage integrations (Supabase, Upstash) use their own variable names.
applyEnvAliases();

const url = process.env.DATABASE_URL ?? "";
// The schema declares directUrl = env("DIRECT_URL") for migrations; default it to the runtime URL.
if (!process.env.DIRECT_URL && process.env.DATABASE_URL) process.env.DIRECT_URL = process.env.DATABASE_URL;

if (!url) {
  if (process.env.VERCEL) {
    console.error(
      "\n[prisma] DATABASE_URL is not set.\n" +
        "Add a Postgres database to this Vercel project (Storage → Create Database → Postgres/Neon/Prisma Postgres)\n" +
        "or set DATABASE_URL in Project Settings → Environment Variables, then redeploy.\n"
    );
    process.exit(1);
  }
  console.error("[prisma] DATABASE_URL is not set. Create a .env file (see .env.example).");
  process.exit(1);
}

const isSqlite = url.startsWith("file:");
const schema = isSqlite ? "prisma/schema.sqlite.prisma" : "prisma/schema.prisma";
const args = process.argv.slice(2);

console.log(`[prisma] ${args.join(" ")} → ${schema} (${isSqlite ? "SQLite" : "PostgreSQL"})`);

// "db push" on production needs --accept-data-loss (adds new columns safely);
// other commands (generate, migrate diff, ...) must NOT receive it.
const extraArgs = args[0] === "db" && args[1] === "push" ? ["--accept-data-loss"] : [];

const result = spawnSync("npx", ["prisma", ...args, "--schema", schema, ...extraArgs], {
  stdio: "inherit",
  shell: process.platform === "win32",
});

process.exit(result.status ?? 0);
