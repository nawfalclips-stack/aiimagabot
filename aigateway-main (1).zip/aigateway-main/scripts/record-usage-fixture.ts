/**
 * Record a provider's real usage object as a test fixture (WS6).
 *
 *   npm run usage:record -- <dialect> <baseUrl> <model> [--anthropic]
 *
 *   npm run usage:record -- deepinfra https://api.deepinfra.com/v1/openai deepseek-ai/DeepSeek-V3
 *   npm run usage:record -- deepseek  https://api.deepseek.com/v1          deepseek-chat
 *   npm run usage:record -- openrouter https://openrouter.ai/api/v1        deepseek/deepseek-chat
 *   npm run usage:record -- anthropic https://api.deepseek.com/anthropic   deepseek-chat --anthropic
 *
 * The key is read from RECORD_API_KEY (never written anywhere). Two tiny
 * requests are made (non-streaming and streaming, ~20 tokens each); only the
 * usage objects are saved to test/fixtures/usage/<dialect>.json, with the
 * normaliser's output as the `expect` block for the test to pin.
 */
import { writeFileSync } from "node:fs";
import { normalizeUsage } from "@/lib/gateway/usage";

const [dialect, baseUrl, model] = process.argv.slice(2);
const anthropic = process.argv.includes("--anthropic");
const key = process.env.RECORD_API_KEY;

async function main() {
  if (!dialect || !baseUrl || !model || !key) {
    console.error("usage: RECORD_API_KEY=… npm run usage:record -- <dialect> <baseUrl> <model> [--anthropic]");
    process.exit(1);
  }
  const url = `${baseUrl.replace(/\/+$/, "")}/${anthropic ? "messages" : "chat/completions"}`;
  const headers: Record<string, string> = { "content-type": "application/json" };
  if (anthropic) {
    headers["x-api-key"] = key;
    headers["anthropic-version"] = "2023-06-01";
  } else headers.authorization = `Bearer ${key}`;

  const body = (stream: boolean) =>
    anthropic
      ? { model, max_tokens: 16, stream, messages: [{ role: "user", content: "Reply with the single word: pong" }] }
      : { model, max_tokens: 16, stream, ...(stream ? { stream_options: { include_usage: true } } : {}), messages: [{ role: "user", content: "Reply with the single word: pong" }] };

  // Non-streaming
  const r1 = await fetch(url, { method: "POST", headers, body: JSON.stringify(body(false)) });
  if (!r1.ok) throw new Error(`non-streaming request failed: ${r1.status} ${await r1.text()}`);
  const j1 = (await r1.json()) as { usage?: unknown };
  const usage = j1.usage;

  // Streaming: take the last usage-bearing event (Anthropic: merge message_start + message_delta).
  const r2 = await fetch(url, { method: "POST", headers, body: JSON.stringify(body(true)) });
  if (!r2.ok) throw new Error(`streaming request failed: ${r2.status} ${await r2.text()}`);
  const text = await r2.text();
  let streamUsage: Record<string, unknown> | null = null;
  for (const block of text.split(/\r?\n\r?\n/)) {
    const data = block
      .split(/\r?\n/)
      .filter((l) => l.startsWith("data:"))
      .map((l) => l.slice(5).trim())
      .join("\n");
    if (!data || data === "[DONE]") continue;
    try {
      const j = JSON.parse(data) as Record<string, unknown>;
      const u = (j.usage ?? (j.message as Record<string, unknown> | undefined)?.usage) as Record<string, unknown> | undefined;
      if (u) streamUsage = { ...(streamUsage ?? {}), ...u };
    } catch {
      /* not JSON */
    }
  }

  const norm = normalizeUsage(dialect, usage);
  const out = {
    source: "recorded",
    recordedAt: new Date().toISOString(),
    provider: new URL(baseUrl).hostname,
    model,
    usage,
    streamingUsage: streamUsage,
    expect: norm ? Object.fromEntries(Object.entries(norm).map(([k, v]) => [k, v === null ? null : Number(v)])) : null,
  };
  const path = `test/fixtures/usage/${dialect}.json`;
  writeFileSync(path, JSON.stringify(out, null, 2) + "\n");
  console.log(`wrote ${path}`);
  console.log(JSON.stringify(out, null, 2));
}

main().catch((e) => {
  console.error(e);
  process.exit(1);
});
