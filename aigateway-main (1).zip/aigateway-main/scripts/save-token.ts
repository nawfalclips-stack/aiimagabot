// KEY INSIGHT TEST: with a FAKE cookie everything 307s to login (proxy blocks).
// With a VALID token we get 404 — meaning the request PASSES the proxy but the
// page 404s. /admin root (same group!) works with valid token. Difference?
// Root = app/admin/(dashboard)/page.tsx. Children = .../(dashboard)/<seg>/page.tsx.
// Hypothesis: Turbopack dev route manifest is stale for nested segments after
// new folders were added while running. Restart dev server and retest.
import { SignJWT } from "jose";
import { PrismaClient } from "@prisma/client";
import fs from "node:fs";

async function main() {
  const m = fs.readFileSync(".env", "utf8").match(/^\s*SESSION_SECRET\s*=\s*"?([^"\r\n]+)"?/m);
  const secret = m[1].trim();
  const prisma = new PrismaClient();
  const admin = await prisma.admin.findFirst({ where: { email: "admin@aerolink.lat" } });
  await prisma.$disconnect();
  const token = await new SignJWT({ adminId: admin.id, kind: "admin" })
    .setProtectedHeader({ alg: "HS256" }).setIssuedAt()
    .setExpirationTime(Math.floor(Date.now() / 1000) + 3600)
    .sign(new TextEncoder().encode(secret));
  fs.writeFileSync(".dev-admin-token", token);
  console.log("token saved for post-restart test");
}
main().catch((e) => { console.error("FAIL:", e.message); process.exit(1); });
