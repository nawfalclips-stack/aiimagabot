import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function main() {
  console.log("🚀 Setting up ChefAPI...");

  // 1. Create ChefAPI store
  const store = await prisma.store.upsert({
    where: { id: "chefapi" },
    update: {},
    create: {
      id: "chefapi",
      name: "ChefAPI",
      logoText: "ChefAPI",
      storeUrl: "https://www.gamsgo.com/shop-store/3dcf9b33-e8d1-b908-8069-d6603ca4ab78?category_id=e994486e-b21a-fcfc-8844-360b39ae878e",
      subdomain: "chefapi",
      primaryColor: "#10b981",
      fontFamily: "Roboto",
    },
  });
  console.log("✅ ChefAPI store created:", store.id);

  // 2. Create admin account
  const passwordHash = await bcrypt.hash("chefapi2024", 12);
  const admin = await prisma.admin.upsert({
    where: { email: "admin@chefapi.com" },
    update: {
      passwordHash,
      name: "ChefAPI Admin",
      role: "FULL_ACCESS",
    },
    create: {
      email: "admin@chefapi.com",
      name: "ChefAPI Admin",
      passwordHash,
      role: "FULL_ACCESS",
      isReadOnly: false,
    },
  });
  console.log("✅ Admin account created:", admin.email);

  // 3. Link admin to store
  await prisma.adminStoreAccess.upsert({
    where: {
      adminId_storeId: {
        adminId: admin.id,
        storeId: store.id,
      },
    },
    update: {},
    create: {
      adminId: admin.id,
      storeId: store.id,
    },
  });
  console.log("✅ Admin linked to ChefAPI store");

  // 4. Create default settings
  const settings = [
    { key: "storeName", value: "ChefAPI" },
    { key: "storeContact", value: "" },
    { key: "enableSelfActivation", value: "true" },
    { key: "requireReview", value: "false" },
    { key: "reviewBonusPercentage", value: "0" },
    { key: "activationInstruction", value: "" },
  ];

  for (const setting of settings) {
    await prisma.setting.upsert({
      where: {
        storeId_key: {
          storeId: store.id,
          key: setting.key,
        },
      },
      update: { value: setting.value },
      create: {
        storeId: store.id,
        key: setting.key,
        value: setting.value,
      },
    });
  }
  console.log("✅ Default settings created");

  console.log("\n🎉 ChefAPI setup complete!");
  console.log("\n📋 Account Details:");
  console.log("   Email: admin@chefapi.com");
  console.log("   Password: chefapi2024");
  console.log("   Admin URL: https://aerolink-portal.vercel.app/chefapi-admin");
  console.log("\n✨ Next: Push code to deploy the /chefapi-admin route");
}

main()
  .catch((e) => {
    console.error("❌ Error:", e);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
