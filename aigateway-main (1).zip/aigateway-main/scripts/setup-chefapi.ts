/**
 * Create ChefAPI Store with admin account and custom branding
 * Usage: npx tsx scripts/setup-chefapi.ts
 */

import { PrismaClient } from "@prisma/client";
import bcrypt from "bcryptjs";

const prisma = new PrismaClient();

async function main() {
  console.log("🍳 Setting up ChefAPI Store...\n");

  const storeId = "chefapi";
  const subdomain = "chefapi";
  const storeName = "ChefAPI";
  const logoText = "ChefAPI";
  const storeUrl = "https://www.gamsgo.com/shop-store/3dcf9b33-e8d1-b908-8069-d6603ca4ab78?category_id=e994486e-b21a-fcfc-8844-360b39ae878e";
  const primaryColor = "#10b981"; // Green instead of blue
  const fontFamily = "Roboto"; // Different font

  const adminEmail = "admin@chefapi.com";
  const adminName = "ChefAPI Admin";
  const adminPassword = "chefapi2024"; // Change this!

  // Check if store already exists
  const existingStore = await prisma.store.findUnique({
    where: { id: storeId },
  });

  if (existingStore) {
    console.log("❌ ChefAPI store already exists!");
    console.log(`Store ID: ${existingStore.id}`);
    console.log(`Subdomain: ${existingStore.subdomain}`);
    return;
  }

  // Check if admin email exists
  const existingAdmin = await prisma.admin.findUnique({
    where: { email: adminEmail },
  });

  if (existingAdmin) {
    console.log("❌ Admin email already exists!");
    return;
  }

  // Hash password
  const passwordHash = await bcrypt.hash(adminPassword, 12);

  // Create store and admin in transaction
  const result = await prisma.$transaction(async (tx) => {
    // 1. Create ChefAPI store
    const store = await tx.store.create({
      data: {
        id: storeId,
        name: storeName,
        logoText,
        subdomain,
        storeUrl,
        primaryColor,
        fontFamily,
      },
    });

    // 2. Create admin account
    const admin = await tx.admin.create({
      data: {
        email: adminEmail,
        name: adminName,
        passwordHash,
        role: "FULL_ACCESS",
        isReadOnly: false,
        storeAccess: {
          create: {
            storeId: store.id,
          },
        },
      },
    });

    // 3. Create default settings
    const defaultSettings = [
      { key: "SITE_NAME", value: "ChefAPI" },
      { key: "LOGO_TEXT", value: "ChefAPI" },
      { key: "SUPPORT_EMAIL", value: "support@chefapi.com" },
      { key: "BRAND_COLOR", value: primaryColor },
      { key: "FOOTER_TEXT", value: `© ${new Date().getFullYear()} ChefAPI. All rights reserved.` },
      { key: "LOW_BALANCE_THRESHOLD_CENTS", value: "500" },
      { key: "DEFAULT_CURRENCY", value: "USD" },
      { key: "TIMEZONE", value: "America/New_York" },
      { key: "USAGE_COST_MULTIPLIER", value: "2.2" },
      { key: "SIGNUP_BALANCE_CENTS", value: "0" },
      { key: "SIGNUP_BONUS_CENTS", value: "0" },
      { key: "STORE_URL", value: storeUrl },
    ];

    await tx.setting.createMany({
      data: defaultSettings.map((s) => ({
        storeId: store.id,
        key: s.key,
        value: s.value,
      })),
    });

    return { store, admin };
  });

  console.log("✅ ChefAPI Store created successfully!\n");
  console.log("📦 Store Details:");
  console.log(`   ID: ${result.store.id}`);
  console.log(`   Name: ${result.store.name}`);
  console.log(`   Subdomain: ${result.store.subdomain}`);
  console.log(`   Primary Color: ${result.store.primaryColor}`);
  console.log(`   Font: ${result.store.fontFamily}`);
  console.log(`   GamsGo URL: ${result.store.storeUrl}`);

  console.log("\n👤 Admin Account:");
  console.log(`   Email: ${result.admin.email}`);
  console.log(`   Password: ${adminPassword}`);
  console.log(`   Role: ${result.admin.role}`);

  console.log("\n🔗 URLs:");
  console.log(`   Admin Panel: https://aerolink-portal.vercel.app/admin`);
  console.log(`   Customer Portal: https://chefapi.aerolink-portal.vercel.app`);
  console.log(`                    (or https://aerolink-portal.vercel.app when subdomain is configured)`);

  console.log("\n⚠️  Next Steps:");
  console.log("   1. Configure custom domain/subdomain in Vercel");
  console.log("   2. Login to admin panel and switch to ChefAPI store");
  console.log("   3. Customize settings in Settings page");
}

main()
  .catch((error) => {
    console.error("❌ Error:", error);
    process.exit(1);
  })
  .finally(async () => {
    await prisma.$disconnect();
  });
