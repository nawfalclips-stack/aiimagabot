-- Test Script for Review Bonus & Notification System
-- Run these queries in Vercel Postgres dashboard or your local database

-- 1. Verify Notification table was created
SELECT * FROM "Notification" LIMIT 5;

-- 2. Check existing customers with review bonuses
SELECT
  "accessCode",
  "reviewBonusStatus",
  "pendingBonusCents",
  "offerTitle"
FROM "Customer"
WHERE "pendingBonusCents" > 0
ORDER BY "createdAt" DESC
LIMIT 10;

-- 3. Check if ChefAPI store exists
SELECT * FROM "Store" WHERE id = 'chefapi';

-- 4. Set ChefAPI store URL (if ChefAPI exists)
INSERT INTO "Setting" ("storeId", key, value, "createdAt", "updatedAt")
VALUES ('chefapi', 'storeUrl', 'https://www.gamsgo.com/shop-store/ab3a9d0e-937f-e93e-1b66-5dca973aa779', NOW(), NOW())
ON CONFLICT ("storeId", key) DO UPDATE SET value = EXCLUDED.value;

-- 5. Check recent notifications
SELECT
  type,
  title,
  message,
  "isRead",
  "createdAt"
FROM "Notification"
WHERE "storeId" = 'aerolink'
ORDER BY "createdAt" DESC
LIMIT 10;

-- 6. Get unread notification count
SELECT COUNT(*) as unread_count
FROM "Notification"
WHERE "storeId" = 'aerolink' AND "isRead" = false;
