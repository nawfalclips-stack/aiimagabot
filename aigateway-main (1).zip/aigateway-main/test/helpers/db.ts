// Database access for integration tests. Points the shared Prisma client at
// TEST_DATABASE_URL *before* the app code imports `@/lib/prisma`.
import { describe } from "vitest";

export const TEST_DATABASE_URL = process.env.TEST_DATABASE_URL ?? "";
export const hasTestDb = /^postgres(ql)?:/.test(TEST_DATABASE_URL);

if (hasTestDb) process.env.DATABASE_URL = TEST_DATABASE_URL;

/** `describe` that is skipped (not failed) when no Postgres is configured. */
export const describeIntegration = hasTestDb ? describe : describe.skip;

/** Lazy import so the env var above is set first. */
export async function getPrisma() {
  const { prisma } = await import("@/lib/prisma");
  return prisma;
}

/** Wipe every table that tests write to. Order respects foreign keys via CASCADE. */
export async function truncateAll() {
  const prisma = await getPrisma();
  const tables = await prisma.$queryRaw<Array<{ tablename: string }>>`
    SELECT tablename FROM pg_tables WHERE schemaname = 'public' AND tablename <> '_prisma_migrations'`;
  const list = tables.map((t) => `"${t.tablename}"`).join(", ");
  if (list) await prisma.$executeRawUnsafe(`TRUNCATE TABLE ${list} RESTART IDENTITY CASCADE`);
}
