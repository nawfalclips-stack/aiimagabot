// Database fixtures for integration tests. Everything goes through the same
// code paths production uses (the balance service for money), so a fixture
// customer's ledger is consistent from the first row.
import { createHash, randomBytes } from "node:crypto";
import { getPrisma } from "./db";

export const STORE_ID = "aerolink";

export async function ensureStore(id = STORE_ID) {
  const prisma = await getPrisma();
  return prisma.store.upsert({
    where: { id },
    update: {},
    create: { id, name: "AeroLink API", logoText: "AeroLink", storeUrl: "https://example.com/store" },
  });
}

export async function createCustomer(opts: { balanceCents?: number; bonusCents?: number; accessCode?: string; storeId?: string } = {}) {
  const prisma = await getPrisma();
  const { credit } = await import("@/lib/billing/balance-service");
  const storeId = opts.storeId ?? STORE_ID;
  await ensureStore(storeId);
  const customer = await prisma.customer.create({
    data: { storeId, accessCode: opts.accessCode ?? `T-${randomBytes(4).toString("hex").toUpperCase()}`, isActivated: true, status: "ACTIVE" },
  });
  if (opts.balanceCents) {
    await credit({ customerId: customer.id, pot: "BALANCE", amountMicroUsd: BigInt(opts.balanceCents) * 10_000n, type: "OPENING_BALANCE", idempotencyKey: `opening:${customer.id}:BALANCE`, actor: { label: "Test" }, history: "none" });
  }
  if (opts.bonusCents) {
    await credit({ customerId: customer.id, pot: "BONUS", amountMicroUsd: BigInt(opts.bonusCents) * 10_000n, type: "OPENING_BALANCE", idempotencyKey: `opening:${customer.id}:BONUS`, actor: { label: "Test" }, history: "none" });
  }
  return prisma.customer.findUniqueOrThrow({ where: { id: customer.id } });
}

export async function createGatewayToken(customerId: string, storeId = STORE_ID) {
  const prisma = await getPrisma();
  const token = `al_${randomBytes(30).toString("base64url").replace(/[^A-Za-z0-9]/g, "a").slice(0, 40)}`;
  await prisma.gatewayToken.create({
    data: { customerId, storeId, name: "test", prefix: token.slice(0, 12), tokenHash: createHash("sha256").update(token).digest("hex") },
  });
  return token;
}

/** Register a mock provider serving `slug` at the given base URL with the given prices (µ$/MTok). */
export async function createMockModel(opts: { baseUrl: string; slug?: string; inputMicroPerMTok?: number; outputMicroPerMTok?: number; maxOutputTokens?: number | null; providerSlug?: string; priority?: number }) {
  const prisma = await getPrisma();
  const { invalidateModelRegistry } = await import("@/lib/gateway/registry");
  const providerSlug = opts.providerSlug ?? `mock-${randomBytes(3).toString("hex")}`;
  const provider = await prisma.provider.create({
    data: { slug: providerSlug, name: providerSlug, baseUrl: opts.baseUrl, apiKeyEnc: "mock-key", priority: opts.priority ?? 10 },
  });
  const slug = opts.slug ?? "mock-model";
  const model = await prisma.gatewayModel.upsert({
    where: { slug },
    update: {},
    create: {
      slug,
      displayName: "Mock Model",
      inputPriceMicroPerMTok: opts.inputMicroPerMTok ?? 400_000,
      outputPriceMicroPerMTok: opts.outputMicroPerMTok ?? 1_600_000,
      maxOutputTokens: opts.maxOutputTokens === undefined ? 4096 : opts.maxOutputTokens,
    },
  });
  await prisma.providerModel.create({ data: { providerId: provider.id, modelId: model.id, upstreamModelId: `upstream/${slug}`, priority: opts.priority ?? 10 } });
  invalidateModelRegistry();
  return { provider, model };
}

export async function customerState(id: string) {
  const prisma = await getPrisma();
  const c = await prisma.customer.findUniqueOrThrow({ where: { id } });
  const { potAvailableMicroUsd } = await import("@/lib/billing/money");
  return {
    ...c,
    balanceMicroUsd: potAvailableMicroUsd(c, "BALANCE"),
    bonusMicroUsd: potAvailableMicroUsd(c, "BONUS"),
  };
}
