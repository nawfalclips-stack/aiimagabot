// Global setup for the integration project.
//
// 1. Generates a Postgres-flavoured Prisma client into node_modules/.prisma/client-test
//    (postinstall generates the SQLite one for local dev; a generated client is
//    bound to one provider). vitest.config.ts aliases `@prisma/client` to it for
//    this project only, so the dev client is left untouched.
// 2. Resets the test database to the committed migrations.
//
// Requires Postgres from docker-compose.test.yml. When TEST_DATABASE_URL is
// missing, integration tests are skipped (each file guards with `describeIntegration`).
import { spawnSync } from "node:child_process";
import { readFileSync, writeFileSync } from "node:fs";

export const TEST_CLIENT_DIR = "node_modules/.prisma/client-test";
const TEMP_SCHEMA = "prisma/.schema.test.prisma";

function prisma(args: string[], env: NodeJS.ProcessEnv) {
  const r = spawnSync("npx", ["prisma", ...args], { stdio: "inherit", shell: process.platform === "win32", env });
  if (r.status !== 0) throw new Error(`prisma ${args[0]} ${args[1] ?? ""} failed (exit ${r.status})`);
}

export default function setup() {
  const url = process.env.TEST_DATABASE_URL;
  if (!url) {
    console.warn(
      "\n[integration] TEST_DATABASE_URL is not set — integration tests will be skipped.\n" +
        "             docker compose -f docker-compose.test.yml up -d && export TEST_DATABASE_URL=postgresql://aerolink:aerolink@localhost:55432/aerolink_test\n"
    );
    return;
  }
  if (!/^postgres(ql)?:/.test(url)) throw new Error("TEST_DATABASE_URL must be a Postgres URL (SQLite hides the races these tests exist for).");
  // Belt and braces: never let this point at anything that isn't obviously local.
  const host = new URL(url).hostname;
  if (!["localhost", "127.0.0.1", "postgres"].includes(host)) {
    throw new Error(`Refusing to reset a non-local database (${host}). Integration tests only run against docker-compose.test.yml.`);
  }
  const env = { ...process.env, DATABASE_URL: url, DIRECT_URL: url };

  // Same schema, different client output. The temp file sits next to
  // schema.prisma so relative paths (migrations, output) resolve identically.
  const schema = readFileSync("prisma/schema.prisma", "utf8").replace(
    /generator client \{\s*provider = "prisma-client-js"/,
    `generator client {\n  provider = "prisma-client-js"\n  output   = "../${TEST_CLIENT_DIR}"`
  );
  if (!schema.includes(TEST_CLIENT_DIR)) throw new Error("Could not inject the test client output into schema.prisma");
  writeFileSync(TEMP_SCHEMA, schema);

  prisma(["generate", "--schema", TEMP_SCHEMA], env);
  prisma(["migrate", "reset", "--force", "--skip-seed", "--skip-generate", "--schema", "prisma/schema.prisma"], env);
}
