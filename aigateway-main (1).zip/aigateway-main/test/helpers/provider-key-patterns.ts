// Shapes of upstream provider credentials (WS10). A customer-facing response
// must never contain a string matching any of these.
export const PROVIDER_KEY_PATTERNS: ReadonlyArray<{ name: string; re: RegExp }> = [
  { name: "Anthropic", re: /sk-ant-[A-Za-z0-9_-]{20,}/ },
  { name: "OpenRouter", re: /sk-or-v1-[A-Za-z0-9]{32,}/ },
  { name: "OpenAI project", re: /sk-proj-[A-Za-z0-9_-]{20,}/ },
  { name: "OpenAI / DeepSeek", re: /\bsk-[A-Za-z0-9]{32,}\b/ },
  { name: "Google", re: /AIza[0-9A-Za-z_-]{35}/ },
  { name: "Legacy pool", re: /aero_live_[A-Za-z0-9]{8,}/ },
];

/** Names of the patterns that match somewhere in `text`. */
export function findProviderKeys(text: string): string[] {
  return PROVIDER_KEY_PATTERNS.filter((p) => p.re.test(text)).map((p) => p.name);
}

/** One realistic sample per pattern, for seeding test data. */
export const SAMPLE_PROVIDER_KEYS = {
  anthropic: `sk-ant-api03-${"A".repeat(40)}`,
  openrouter: `sk-or-v1-${"b".repeat(64)}`,
  openaiProject: `sk-proj-${"C".repeat(48)}`,
  deepseek: `sk-${"d".repeat(32)}`,
  google: `AIza${"E".repeat(35)}`,
  legacyPool: "aero_live_E7OMTW3xKpqZ9876",
} as const;
