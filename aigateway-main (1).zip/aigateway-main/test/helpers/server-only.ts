// Vitest stand-in for the `server-only` package: in tests everything is the
// server, so importing it must be a no-op instead of throwing.
export {};
