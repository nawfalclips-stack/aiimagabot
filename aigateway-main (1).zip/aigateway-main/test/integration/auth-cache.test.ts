import { afterAll, beforeAll, beforeEach, expect, it } from "vitest";
import { Redis } from "@upstash/redis";
import { describeIntegration, getPrisma, truncateAll } from "../helpers/db";
import { createCustomer, createGatewayToken, createMockModel, ensureStore } from "../helpers/fixtures";
import { startMockUpstream, type MockUpstream } from "../mock-upstream/server";

// WS12.3 acceptance: the token → customer binding is served from Redis after
// the first request, revocation is immediate, unknown tokens are
// negative-cached, customer state is never stale, and a catalog edit on one
// instance invalidates the copy held by another.
const REDIS_URL = process.env.TEST_REDIS_REST_URL ?? "http://localhost:58079";
const REDIS_TOKEN = process.env.TEST_REDIS_REST_TOKEN ?? "test-token";

describeIntegration("auth cache and catalog version (WS12.3)", () => {
  let mock: MockUpstream;
  let redis: Redis;
  let auth: typeof import("@/lib/gateway/tokens");
  let cache: typeof import("@/lib/gateway/auth-cache");
  let registry: typeof import("@/lib/gateway/registry");

  beforeAll(async () => {
    process.env.SESSION_SECRET = "test-secret-test-secret-test-secret";
    process.env.REDIS_DISABLED = "false";
    process.env.UPSTASH_REDIS_REST_URL = REDIS_URL;
    process.env.UPSTASH_REDIS_REST_TOKEN = REDIS_TOKEN;
    redis = new Redis({ url: REDIS_URL, token: REDIS_TOKEN });
    await redis.flushall();
    await truncateAll();
    await ensureStore();
    mock = await startMockUpstream();
    auth = await import("@/lib/gateway/tokens");
    cache = await import("@/lib/gateway/auth-cache");
    registry = await import("@/lib/gateway/registry");
  });
  beforeEach(async () => {
    await redis.flushall();
    const prisma = await getPrisma();
    await prisma.customer.deleteMany({});
    await prisma.provider.deleteMany({});
    await prisma.gatewayModel.deleteMany({});
    (await import("@/lib/redis"))._setRedisForTests(undefined);
    cache._resetAuthCacheStatsForTests();
    await registry.invalidateModelRegistry();
  });
  afterAll(async () => {
    await mock.close();
    await (await getPrisma()).$disconnect();
  });

  const headers = (token: string) => new Headers({ authorization: `Bearer ${token}` });

  it("serves the second request from the cache and the customer row stays fresh", async () => {
    const c = await createCustomer({ balanceCents: 100 });
    const token = await createGatewayToken(c.id);

    const first = await auth.authenticateGatewayRequest(headers(token));
    expect(first.ok && first.cached).toBe(false);
    const second = await auth.authenticateGatewayRequest(headers(token));
    expect(second.ok && second.cached).toBe(true);
    expect(cache.authCacheStats).toMatchObject({ hits: 1, misses: 1 });
    if (!second.ok) throw new Error("expected ok");
    expect(second.token.customerId).toBe(c.id);
    expect(second.customer.plan).toBeNull();

    // Suspend the customer: the very next request is refused although the token is cached.
    const prisma = await getPrisma();
    await prisma.customer.update({ where: { id: c.id }, data: { status: "SUSPENDED" } });
    const third = await auth.authenticateGatewayRequest(headers(token));
    expect(third).toEqual({ ok: false, reason: "SUSPENDED" });
    expect(cache.authCacheStats.hits).toBe(2);
  });

  it("revocation invalidates the cache immediately", async () => {
    const c = await createCustomer({ balanceCents: 100 });
    const token = await createGatewayToken(c.id);
    const prisma = await getPrisma();
    const row = await prisma.gatewayToken.findFirstOrThrow({ where: { customerId: c.id } });

    expect((await auth.authenticateGatewayRequest(headers(token))).ok).toBe(true);
    expect((await auth.authenticateGatewayRequest(headers(token))).ok).toBe(true);
    expect(await redis.exists(`gw:auth:${row.tokenHash}`)).toBe(1);

    expect(await auth.revokeGatewayToken(c.id, row.id)).toBe(true);
    expect(await redis.exists(`gw:auth:${row.tokenHash}`)).toBe(0);
    const after = await auth.authenticateGatewayRequest(headers(token));
    expect(after).toEqual({ ok: false, reason: "REVOKED" });
    // …and the revoked token is now negative-cached: no more DB lookups for it.
    const again = await auth.authenticateGatewayRequest(headers(token));
    expect(again).toEqual({ ok: false, reason: "INVALID" });
    expect(cache.authCacheStats.negativeHits).toBe(1);
  });

  it("negative-caches unknown tokens for 10 s", async () => {
    const bogus = "al_" + "x".repeat(40);
    expect(await auth.authenticateGatewayRequest(headers(bogus))).toEqual({ ok: false, reason: "INVALID" });
    expect(await auth.authenticateGatewayRequest(headers(bogus))).toEqual({ ok: false, reason: "INVALID" });
    expect(cache.authCacheStats).toMatchObject({ misses: 1, negativeHits: 1 });
    const { hashToken } = auth;
    const ttl = await redis.ttl(`gw:auth:neg:${hashToken(bogus)}`);
    expect(ttl).toBeGreaterThan(0);
    expect(ttl).toBeLessThanOrEqual(cache.AUTH_NEG_CACHE_TTL_S);
  });

  it("a catalog edit on another instance invalidates this instance's copy", async () => {
    await createMockModel({ baseUrl: mock.url, slug: "model-a" });
    expect(await registry.resolveModel("model-a", "aerolink")).not.toBeNull();
    expect(await registry.resolveModel("model-b", "aerolink")).toBeNull();

    // Another instance adds model-b and bumps the version; this instance's
    // memory cache is still warm (< 60 s old) but must notice.
    const prisma = await getPrisma();
    const provider = await prisma.provider.findFirstOrThrow();
    const model = await prisma.gatewayModel.create({
      data: { slug: "model-b", displayName: "B", inputPriceMicroPerMTok: 1, outputPriceMicroPerMTok: 1, enabledStoreIds: "" },
    });
    await prisma.providerModel.create({ data: { providerId: provider.id, modelId: model.id, upstreamModelId: "b" } });
    expect(await registry.resolveModel("model-b", "aerolink")).toBeNull(); // still cached
    await redis.incr("gw:catalog:ver"); // what invalidateModelRegistry() does elsewhere
    expect(await registry.resolveModel("model-b", "aerolink")).not.toBeNull();
  });
});
