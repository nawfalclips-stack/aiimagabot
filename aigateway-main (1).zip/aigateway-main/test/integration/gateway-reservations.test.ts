import { afterAll, beforeAll, beforeEach, expect, it, vi } from "vitest";
import { describeIntegration, getPrisma, truncateAll } from "../helpers/db";
import { createCustomer, createGatewayToken, createMockModel, customerState, ensureStore } from "../helpers/fixtures";
import { startMockUpstream, type MockUpstream } from "../mock-upstream/server";

// `after()` needs a Next request scope; in tests we run the callback right
// away and keep the promise so the test can wait for every settlement.
const pendingAfter: Promise<unknown>[] = [];
vi.mock("next/server", () => ({
  after: (fn: () => unknown) => {
    pendingAfter.push(Promise.resolve().then(fn));
  },
}));
const settled = async () => {
  while (pendingAfter.length) await Promise.allSettled(pendingAfter.splice(0));
};

// End-to-end through handleGateway: the reservation gate refuses what the
// balance cannot cover, fit-to-balance shrinks max_tokens when it can, and
// every hold is settled or released so `reserved` ends at zero.
describeIntegration("gateway reservations end-to-end (WS2)", () => {
  let mock: MockUpstream;
  let handleGateway: typeof import("@/lib/gateway/handler").handleGateway;

  beforeAll(async () => {
    process.env.SESSION_SECRET = "test-secret-test-secret-test-secret";
    process.env.GATEWAY_RESERVATIONS = "enforce";
    process.env.GATEWAY_MIN_OUTPUT_TOKENS = "64";
    // WS2 in isolation: the concurrency cap (WS3) has its own tests.
    process.env.GATEWAY_RATE_LIMITS = "false";
    await truncateAll();
    await ensureStore();
    mock = await startMockUpstream();
    // $0.40 / $1.60 per MTok at provider; store multiplier default ×2.2.
    await createMockModel({ baseUrl: mock.url, slug: "mock-model", maxOutputTokens: 4096 });
    ({ handleGateway } = await import("@/lib/gateway/handler"));
  });
  beforeEach(async () => {
    mock.reset();
    const prisma = await getPrisma();
    await prisma.customer.deleteMany({});
  });
  afterAll(async () => {
    await mock.close();
    await (await getPrisma()).$disconnect();
  });

  const call = (token: string, body: Record<string, unknown>) =>
    handleGateway(
      new Request("http://gateway.test/v1/chat/completions", {
        method: "POST",
        headers: { "content-type": "application/json", authorization: `Bearer ${token}` },
        body: JSON.stringify({ model: "mock-model", messages: [{ role: "user", content: "hello" }], ...body }),
      }),
      "openai"
    );

  it("serves at most what the balance covers under 50 parallel requests", async () => {
    // Hold per request: (~10 in × 0.40 + 1000 out × 1.60) µ$ × 2.2 × 1.05 ≈ 3 700 µ$ → floor $0.01.
    // Balance $0.035 covers 3 holds of $0.01 (plus a little), never 50.
    const c = await createCustomer({ balanceCents: 4 });
    const token = await createGatewayToken(c.id);
    mock.setScenario({ usage: { prompt: 10, completion: 1000 } });

    const responses = await Promise.all(Array.from({ length: 50 }, () => call(token, { max_tokens: 1000 })));
    await settled();

    const ok = responses.filter((r) => r.status === 200).length;
    const refused = responses.filter((r) => r.status === 402).length;
    expect(ok + refused).toBe(50);
    expect(ok).toBeGreaterThanOrEqual(1);
    expect(ok).toBeLessThanOrEqual(4);
    expect(mock.requests).toHaveLength(ok);

    const s = await customerState(c.id);
    expect(s.reservedMicroUsd).toBe(0n);
    expect(s.balanceMicroUsd).toBeGreaterThanOrEqual(0n);
    const prisma = await getPrisma();
    expect(await prisma.usageLog.count({ where: { customerId: c.id } })).toBe(ok);
    expect(await prisma.gatewayReservation.count({ where: { customerId: c.id, status: "HELD" } })).toBe(0);
    const { verifyCustomerLedger } = await import("@/lib/billing/balance-service");
    expect((await verifyCustomerLedger(c.id)).ok).toBe(true);

    const body = (await responses.find((r) => r.status === 402)!.json()) as { error: { type: string; code: string } };
    expect(body.error.code).toBe("insufficient_quota");
  });

  it("fits max_tokens to the balance instead of refusing", async () => {
    // 4096 out × $1.60/M × 2.2 × 1.05 ≈ $0.0151 > $0.01, but ~2 700 tokens fit.
    const c = await createCustomer({ balanceCents: 1 });
    const token = await createGatewayToken(c.id);
    mock.setScenario({ usage: { prompt: 10, completion: 50 } });

    const r = await call(token, { max_tokens: 4096 });
    await settled();
    expect(r.status).toBe(200);
    const sent = mock.lastRequest()!.body as { max_tokens: number };
    expect(sent.max_tokens).toBeLessThan(4096);
    expect(sent.max_tokens).toBeGreaterThanOrEqual(64);
    expect((await customerState(c.id)).reservedMicroUsd).toBe(0n);
  });

  it("releases the hold when the upstream fails before the first byte", async () => {
    const c = await createCustomer({ balanceCents: 100 });
    const token = await createGatewayToken(c.id);
    mock.setScenario({ failBeforeFirstByte: { status: 500 } });
    const r = await call(token, { max_tokens: 100 });
    await settled();
    expect(r.status).toBe(503);
    const s = await customerState(c.id);
    expect(s.reservedMicroUsd).toBe(0n);
    expect(s.balanceMicroUsd).toBe(1_000_000n);
    const prisma = await getPrisma();
    expect((await prisma.gatewayReservation.findFirst({ where: { customerId: c.id } }))?.status).toBe("RELEASED");
  });

  it("settles a streamed response from the final usage chunk", async () => {
    const c = await createCustomer({ balanceCents: 100 });
    const token = await createGatewayToken(c.id);
    mock.setScenario({ usage: { prompt: 1000, completion: 500 }, chunkCount: 3 });
    const r = await call(token, { max_tokens: 500, stream: true });
    expect(r.status).toBe(200);
    await r.text(); // drain the stream so `done` resolves
    await settled();
    // provider cost = 1000×0.40 + 500×1.60 = 1 200 µ$ → ×2.2 = 2 640 µ$
    const s = await customerState(c.id);
    expect(s.balanceMicroUsd).toBe(1_000_000n - 2_640n);
    expect(s.reservedMicroUsd).toBe(0n);
    const prisma = await getPrisma();
    const log = await prisma.usageLog.findFirstOrThrow({ where: { customerId: c.id } });
    expect(log.customerMicroUsd).toBe(2_640n);
    expect(log.status).toBe("200");
    expect(log.outcome).toBe("COMPLETED");
  });

  it("honours GATEWAY_RESERVATIONS=off (no hold, still charged)", async () => {
    process.env.GATEWAY_RESERVATIONS = "off";
    try {
      const c = await createCustomer({ balanceCents: 100 });
      const token = await createGatewayToken(c.id);
      mock.setScenario({ usage: { prompt: 1000, completion: 500 } });
      const r = await call(token, { max_tokens: 500 });
      await settled();
      expect(r.status).toBe(200);
      const prisma = await getPrisma();
      expect(await prisma.gatewayReservation.count({ where: { customerId: c.id } })).toBe(0);
      expect((await customerState(c.id)).balanceMicroUsd).toBe(1_000_000n - 2_640n);
    } finally {
      process.env.GATEWAY_RESERVATIONS = "enforce";
    }
  });
});
