import { afterAll, beforeAll, beforeEach, expect, it } from "vitest";
import { describeIntegration, getPrisma, truncateAll } from "../helpers/db";
import { createCustomer, customerState, ensureStore } from "../helpers/fixtures";

// WS1 acceptance: every movement is ledgered, the ledger reconciles with the
// cached fields, replays are idempotent, nothing goes negative, and the
// backfill can run twice.
describeIntegration("ledger (WS1)", () => {
  beforeAll(async () => {
    process.env.SESSION_SECRET ??= "test-secret-test-secret-test-secret";
    await truncateAll();
    await ensureStore();
  });
  beforeEach(async () => {
    const prisma = await getPrisma();
    await prisma.customer.deleteMany({});
  });
  afterAll(async () => (await getPrisma()).$disconnect());

  it("credits and debits with matching ledger entries and cached fields", async () => {
    const { credit, debit, verifyCustomerLedger } = await import("@/lib/billing/balance-service");
    const c = await createCustomer({ balanceCents: 1000 });

    const r1 = await credit({ customerId: c.id, pot: "BALANCE", amountMicroUsd: 500_000n, type: "RECHARGE", idempotencyKey: "t:recharge:1", actor: { label: "Test" } });
    expect(r1.entry?.amountMicroUsd).toBe(500_000n);
    expect(r1.customer.initialBalanceCents).toBe(1050);

    // 12.3456 cents: 12 cents hit `used`, 0.3456 cent sits in the carry.
    const r2 = await debit({ customerId: c.id, pot: "BALANCE", amountMicroUsd: 123_456n, type: "USAGE", idempotencyKey: "t:usage:1", actor: { label: "Gateway" } });
    expect(r2.customer.usedBalanceCents).toBe(12);
    expect(r2.customer.balanceCarryMicroUsd).toBe(3_456n);
    expect(r2.entry?.balanceAfterMicroUsd).toBe(10_500_000n - 123_456n);

    const check = await verifyCustomerLedger(c.id);
    expect(check.ok, JSON.stringify(check.pots, (_, v) => (typeof v === "bigint" ? v.toString() : v))).toBe(true);
  });

  it("rejects fractional credits and requires a reason for adjustments", async () => {
    const { credit, adjust } = await import("@/lib/billing/balance-service");
    const c = await createCustomer({ balanceCents: 100 });
    await expect(credit({ customerId: c.id, pot: "BALANCE", amountMicroUsd: 5n, type: "RECHARGE", idempotencyKey: "t:frac", actor: { label: "Test" } })).rejects.toThrow(/whole cents/);
    await expect(adjust({ customerId: c.id, pot: "BALANCE", deltaMicroUsd: 10_000n, idempotencyKey: "t:adj", actor: { label: "Admin" }, note: "  " })).rejects.toThrow(/reason/i);
  });

  it("replays an idempotency key without moving money twice", async () => {
    const { credit } = await import("@/lib/billing/balance-service");
    const c = await createCustomer({ balanceCents: 0 });
    const a = await credit({ customerId: c.id, pot: "BONUS", amountMicroUsd: 50_000n, type: "REVIEW_BONUS", idempotencyKey: "t:bonus:1", actor: { label: "System" } });
    const b = await credit({ customerId: c.id, pot: "BONUS", amountMicroUsd: 50_000n, type: "REVIEW_BONUS", idempotencyKey: "t:bonus:1", actor: { label: "System" } });
    expect(a.replayed).toBe(false);
    expect(b.replayed).toBe(true);
    expect(b.entry?.id).toBe(a.entry?.id);
    expect((await customerState(c.id)).bonusMicroUsd).toBe(50_000n);
  });

  it("never takes a pot below zero and reports the shortfall", async () => {
    const { debit } = await import("@/lib/billing/balance-service");
    const c = await createCustomer({ balanceCents: 10 });
    const r = await debit({ customerId: c.id, pot: "BALANCE", amountMicroUsd: 250_000n, type: "USAGE", idempotencyKey: "t:over", actor: { label: "Gateway" } });
    expect(r.appliedMicroUsd).toBe(-100_000n);
    expect(r.uncollectedMicroUsd).toBe(150_000n);
    const s = await customerState(c.id);
    expect(s.balanceMicroUsd).toBe(0n);
    expect(s.status).toBe("BALANCE_FINISHED");
    expect(s.finishedAt).not.toBeNull();
  });

  it("charges usage balance first, keeps LOW_BALANCE while bonus remains", async () => {
    const { chargeUsage, verifyCustomerLedger } = await import("@/lib/billing/balance-service");
    const c = await createCustomer({ balanceCents: 100, bonusCents: 100 });
    const r = await chargeUsage({ customerId: c.id, amountMicroUsd: 800_000n, idempotencyKey: "t:charge:1", actor: { label: "Gateway" } });
    expect(r.balanceMicroUsd).toBe(800_000n);
    expect(r.bonusMicroUsd).toBe(0n);
    expect(r.entries).toHaveLength(1);

    // Drain the balance: the shortfall comes from bonus, status is LOW_BALANCE not FINISHED.
    const r2 = await chargeUsage({ customerId: c.id, amountMicroUsd: 700_000n, idempotencyKey: "t:charge:2", actor: { label: "Gateway" } });
    expect(r2.balanceMicroUsd).toBe(200_000n);
    expect(r2.bonusMicroUsd).toBe(500_000n);
    expect(r2.entries).toHaveLength(2);
    const s = await customerState(c.id);
    expect(s.balanceMicroUsd).toBe(0n);
    expect(s.bonusMicroUsd).toBe(500_000n);
    expect(s.status).toBe("LOW_BALANCE");
    expect((await verifyCustomerLedger(c.id)).ok).toBe(true);
  });

  it("stays consistent under 30 parallel charges", async () => {
    const { chargeUsage, verifyCustomerLedger } = await import("@/lib/billing/balance-service");
    const c = await createCustomer({ balanceCents: 1000, bonusCents: 100 });
    await Promise.all(
      Array.from({ length: 30 }, (_, i) => chargeUsage({ customerId: c.id, amountMicroUsd: 123_457n, idempotencyKey: `t:par:${i}`, actor: { label: "Gateway" } }))
    );
    const s = await customerState(c.id);
    expect(s.balanceMicroUsd + s.bonusMicroUsd).toBe(11_000_000n - 30n * 123_457n);
    expect((await verifyCustomerLedger(c.id)).ok).toBe(true);
  });

  it("backfills legacy customers once, verifies them afterwards", async () => {
    const prisma = await getPrisma();
    const { backfillLedger } = await import("@/lib/billing/backfill");
    const { verifyCustomerLedger } = await import("@/lib/billing/balance-service");
    // A pre-ledger row: cached values only, old single carry column.
    const legacy = await prisma.customer.create({ data: { storeId: "aerolink", accessCode: "LEGACY-1", isActivated: true } });
    await prisma.$executeRaw`UPDATE "Customer" SET "initialBalanceCents" = 30000, "usedBalanceCents" = 1234, "initialBonusCents" = 500, "usedBonusCents" = 500, "gatewayCarryMicroUsd" = 777 WHERE "id" = ${legacy.id}`;

    const first = await backfillLedger();
    expect(first.carried).toBe(1);
    expect(first.created).toBe(1); // bonus pot is empty → no entry
    expect(first.drift).toEqual([]);

    const second = await backfillLedger();
    expect(second.created).toBe(0);
    expect(second.verified).toBe(1);
    expect(second.drift).toEqual([]);

    const entries = await prisma.ledgerEntry.findMany({ where: { customerId: legacy.id } });
    expect(entries).toHaveLength(1);
    expect(entries[0].amountMicroUsd).toBe(28_766n * 10_000n - 777n);
    expect((await verifyCustomerLedger(legacy.id)).ok).toBe(true);
  });
});
