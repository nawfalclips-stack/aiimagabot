import { afterAll, afterEach, beforeAll, beforeEach, expect, it } from "vitest";
import { describeIntegration, getPrisma, truncateAll } from "../helpers/db";
import { createCustomer, ensureStore } from "../helpers/fixtures";
import { findProviderKeys, SAMPLE_PROVIDER_KEYS } from "../helpers/provider-key-patterns";

// WS10 acceptance: activation never depends on the pool; outside "active"
// nothing is assigned and admin rows are masked; in "active" keys come only
// from the customer's own store. WS7: manual usage is one honest row, and
// deleting it refunds exactly what was charged.
describeIntegration("legacy API pool (WS10) and manual usage (WS7)", () => {
  const original = process.env.LEGACY_API_POOL_MODE;

  beforeAll(async () => {
    process.env.SESSION_SECRET = "test-secret-test-secret-test-secret";
    process.env.REDIS_DISABLED = "true";
    await truncateAll();
    await ensureStore("aerolink");
    await ensureStore("chefapi");
  });
  beforeEach(async () => {
    const prisma = await getPrisma();
    await prisma.ticket.deleteMany({});
    await prisma.apiPoolKey.deleteMany({});
    await prisma.customer.deleteMany({});
    await prisma.order.deleteMany({});
  });
  afterEach(() => {
    if (original === undefined) delete process.env.LEGACY_API_POOL_MODE;
    else process.env.LEGACY_API_POOL_MODE = original;
  });
  afterAll(async () => {
    await (await getPrisma()).$disconnect();
  });

  it("readonly: activation succeeds with an empty pool and assigns no key", async () => {
    process.env.LEGACY_API_POOL_MODE = "readonly";
    const prisma = await getPrisma();
    await prisma.apiPoolKey.create({ data: { storeId: "aerolink", key: SAMPLE_PROVIDER_KEYS.deepseek } });
    const { redeemOrder } = await import("@/lib/services/redemption");

    const result = await redeemOrder("ORDER-RO-1", "AeroLink $100 balance", "aerolink");

    expect(result.balanceCents).toBeGreaterThan(0);
    expect(await prisma.apiKey.count({ where: { customerId: result.customerId } })).toBe(0);
    expect((await prisma.apiPoolKey.findFirstOrThrow()).status).toBe("AVAILABLE");
  });

  it("active: activation takes a key from its own store only, and an empty store pool does not block it", async () => {
    process.env.LEGACY_API_POOL_MODE = "active";
    const prisma = await getPrisma();
    await prisma.apiPoolKey.create({ data: { storeId: "chefapi", key: SAMPLE_PROVIDER_KEYS.openaiProject } });
    const { redeemOrder } = await import("@/lib/services/redemption");

    const first = await redeemOrder("ORDER-A-1", "AeroLink $50 balance", "aerolink");
    expect(await prisma.apiKey.count({ where: { customerId: first.customerId } })).toBe(0);
    expect((await prisma.apiPoolKey.findFirstOrThrow()).status).toBe("AVAILABLE"); // other store's key untouched

    await prisma.apiPoolKey.create({ data: { storeId: "aerolink", key: SAMPLE_PROVIDER_KEYS.anthropic } });
    const second = await redeemOrder("ORDER-A-2", "AeroLink $50 balance", "aerolink");
    expect((await prisma.apiKey.findUniqueOrThrow({ where: { customerId: second.customerId } })).key).toBe(SAMPLE_PROVIDER_KEYS.anthropic);
    const claimed = await prisma.apiPoolKey.findUniqueOrThrow({ where: { key: SAMPLE_PROVIDER_KEYS.anthropic } });
    expect(claimed).toMatchObject({ status: "ASSIGNED", customerId: second.customerId, orderId: "ORDER-A-2" });
  });

  it("active: an API ticket swaps the key once, from the same store, and retires the old one", async () => {
    process.env.LEGACY_API_POOL_MODE = "active";
    const prisma = await getPrisma();
    const customer = await createCustomer({ balanceCents: 1000, storeId: "aerolink" });
    const old = await prisma.apiPoolKey.create({ data: { storeId: "aerolink", key: `sk-${"1".repeat(32)}`, status: "ASSIGNED", customerId: customer.id } });
    await prisma.apiKey.create({ data: { customerId: customer.id, key: old.key } });
    await prisma.apiPoolKey.create({ data: { storeId: "chefapi", key: `sk-${"2".repeat(32)}`, createdAt: new Date(0) } }); // older, wrong store
    await prisma.apiPoolKey.create({ data: { storeId: "aerolink", key: `sk-${"3".repeat(32)}` } });
    const { createTicket } = await import("@/lib/services/tickets");

    const ticket = await createTicket({ customerId: customer.id, type: "API_ISSUE", title: "401", description: "broken", storeId: "aerolink" });

    expect(ticket.status).toBe("AUTO_RESOLVED");
    expect((await prisma.apiKey.findUniqueOrThrow({ where: { customerId: customer.id } })).key).toBe(`sk-${"3".repeat(32)}`);
    expect(await prisma.apiPoolKey.findUniqueOrThrow({ where: { id: old.id } })).toMatchObject({ status: "PROBLEMATIC", customerId: null });
    expect((await prisma.apiPoolKey.findUniqueOrThrow({ where: { key: `sk-${"2".repeat(32)}` } })).status).toBe("AVAILABLE");

    const again = await createTicket({ customerId: customer.id, type: "API_ISSUE", title: "401 again", description: "still", storeId: "aerolink" });
    expect(again.status).toBe("OPEN"); // second fix goes to manual review
  });

  it("readonly: an API ticket stays open with gateway guidance and never touches keys", async () => {
    process.env.LEGACY_API_POOL_MODE = "readonly";
    const prisma = await getPrisma();
    const customer = await createCustomer({ balanceCents: 1000 });
    await prisma.apiPoolKey.create({ data: { storeId: "aerolink", key: SAMPLE_PROVIDER_KEYS.openrouter } });
    const { createTicket } = await import("@/lib/services/tickets");

    const ticket = await createTicket({ customerId: customer.id, type: "API_ISSUE", title: "401", description: "broken", storeId: "aerolink" });

    expect(ticket.status).toBe("OPEN");
    const [message] = await prisma.ticketMessage.findMany({ where: { ticketId: ticket.id } });
    expect(message.body).toContain("API Access");
    expect(await prisma.apiKey.count()).toBe(0);
    expect((await prisma.apiPoolKey.findFirstOrThrow()).status).toBe("AVAILABLE");
  });

  it("readonly: admin customer rows carry a masked key and ignore key writes", async () => {
    process.env.LEGACY_API_POOL_MODE = "readonly";
    const prisma = await getPrisma();
    const customer = await createCustomer({ balanceCents: 1000 });
    await prisma.apiKey.create({ data: { customerId: customer.id, key: SAMPLE_PROVIDER_KEYS.anthropic } });
    const { customerInclude, updateCustomer } = await import("@/lib/services/customers");
    const { toCustomerRow } = await import("@/lib/serialize");

    const row = toCustomerRow(await prisma.customer.findUniqueOrThrow({ where: { id: customer.id }, include: customerInclude }));
    expect(row.apiKeyEditable).toBe(false);
    expect(findProviderKeys(JSON.stringify(row))).toEqual([]);

    await prisma.admin.upsert({ where: { id: "admin-test" }, update: {}, create: { id: "admin-test", email: "t@example.com", name: "Tester", passwordHash: "x" } });
    await updateCustomer(customer.id, { apiKey: SAMPLE_PROVIDER_KEYS.google }, "admin-test", "Tester");
    expect((await prisma.apiKey.findUniqueOrThrow({ where: { customerId: customer.id } })).key).toBe(SAMPLE_PROVIDER_KEYS.anthropic);
  });

  it("manual usage is one honest row, charged and refunded at face value", async () => {
    const prisma = await getPrisma();
    await prisma.admin.upsert({ where: { id: "admin-test" }, update: {}, create: { id: "admin-test", email: "t@example.com", name: "Tester", passwordHash: "x" } });
    await prisma.setting.upsert({
      where: { storeId_key: { storeId: "aerolink", key: "usage_cost_multiplier" } },
      update: { value: "2" },
      create: { storeId: "aerolink", key: "usage_cost_multiplier", value: "2" },
    });
    const customer = await createCustomer({ balanceCents: 5000 });
    const { recordUsageFromAmount, MANUAL_CHARGE_MODEL } = await import("@/lib/services/usage-quick");
    const { deleteUsageLog } = await import("@/lib/services/usage-logs");

    await recordUsageFromAmount(customer.id, "May usage", 1234, "admin-test", "Tester", "aerolink");

    const rows = await prisma.usageLog.findMany({ where: { customerId: customer.id } });
    expect(rows).toHaveLength(1);
    expect(rows[0]).toMatchObject({ model: MANUAL_CHARGE_MODEL, latency: "", requestId: null, keyLabel: "May usage" });
    const remaining = async () => {
      const c = await prisma.customer.findUniqueOrThrow({ where: { id: customer.id } });
      return c.initialBalanceCents - c.usedBalanceCents;
    };
    expect(await remaining()).toBe(5000 - 1234); // face value, not × multiplier

    await deleteUsageLog(rows[0].id, "admin-test", "Tester", "aerolink");
    expect(await remaining()).toBe(5000);
  });
});
