import { afterAll, beforeAll, beforeEach, expect, it, vi } from "vitest";
import { Redis } from "@upstash/redis";
import { describeIntegration, getPrisma, truncateAll } from "../helpers/db";
import { createCustomer, createGatewayToken, createMockModel, ensureStore } from "../helpers/fixtures";
import { startMockUpstream, type MockUpstream } from "../mock-upstream/server";

// Shared state through Redis (docker-compose.test.yml → Upstash-compatible
// REST proxy on :58079). Two independent clients stand in for two Vercel
// instances.
const REDIS_URL = process.env.TEST_REDIS_REST_URL ?? "http://localhost:58079";
const REDIS_TOKEN = process.env.TEST_REDIS_REST_TOKEN ?? "test-token";

const pendingAfter: Promise<unknown>[] = [];
vi.mock("next/server", () => ({
  after: (fn: () => unknown) => {
    pendingAfter.push(Promise.resolve().then(fn));
  },
}));
const settled = async () => {
  while (pendingAfter.length) await Promise.allSettled(pendingAfter.splice(0));
};

describeIntegration("rate limits, leases and breaker across processes (WS3/WS4)", () => {
  let mock: MockUpstream;
  let handleGateway: typeof import("@/lib/gateway/handler").handleGateway;
  let redisA: Redis;
  let redisB: Redis;

  beforeAll(async () => {
    process.env.SESSION_SECRET = "test-secret-test-secret-test-secret";
    process.env.GATEWAY_RESERVATIONS = "off";
    process.env.GATEWAY_RATE_LIMITS = "true";
    process.env.GATEWAY_REDIS_BREAKER = "true";
    process.env.REDIS_DISABLED = "false";
    process.env.UPSTASH_REDIS_REST_URL = REDIS_URL;
    process.env.UPSTASH_REDIS_REST_TOKEN = REDIS_TOKEN;
    redisA = new Redis({ url: REDIS_URL, token: REDIS_TOKEN });
    redisB = new Redis({ url: REDIS_URL, token: REDIS_TOKEN });
    await redisA.flushall();
    await truncateAll();
    await ensureStore();
    mock = await startMockUpstream();
    ({ handleGateway } = await import("@/lib/gateway/handler"));
  });
  beforeEach(async () => {
    mock.reset();
    await redisA.flushall();
    const prisma = await getPrisma();
    await prisma.customer.deleteMany({});
    await prisma.notification.deleteMany({});
    await prisma.provider.deleteMany({});
    await prisma.gatewayModel.deleteMany({});
    (await import("@/lib/gateway/registry")).invalidateModelRegistry();
    (await import("@/lib/gateway/breaker"))._resetBreakersForTests();
    (await import("@/lib/gateway/limits"))._resetLimitsForTests();
    (await import("@/lib/redis"))._setRedisForTests(undefined);
  });
  afterAll(async () => {
    await mock.close();
    await (await getPrisma()).$disconnect();
  });

  const call = (token: string, body: Record<string, unknown>, wire: "openai" | "anthropic" = "openai") =>
    handleGateway(
      new Request(`http://gateway.test/v1/${wire === "openai" ? "chat/completions" : "messages"}`, {
        method: "POST",
        headers: { "content-type": "application/json", authorization: `Bearer ${token}` },
        body: JSON.stringify(
          wire === "openai"
            ? { model: "mock-model", messages: [{ role: "user", content: "hello" }], ...body }
            : { model: "mock-model", max_tokens: 64, messages: [{ role: "user", content: "hello" }], ...body }
        ),
      }),
      wire
    );

  it("a breaker opened by one process is seen by another", async () => {
    const { _setRedisForTests } = await import("@/lib/redis");
    const { breakerState, recordFailure } = await import("@/lib/gateway/breaker");
    const cfg = { failureThreshold: 2, windowMs: 60_000, openMs: 30_000 };

    _setRedisForTests(redisA); // process A
    expect(await recordFailure("pm-shared", cfg)).toBe("counted");
    expect(await recordFailure("pm-shared", cfg)).toBe("tripped");

    _setRedisForTests(redisB); // process B
    const first = await breakerState("pm-shared");
    const second = await breakerState("pm-shared");
    expect([first, second].sort()).toEqual(["half-open", "open"]);
    expect(await recordFailure("pm-shared", cfg)).toBe("open"); // already open, not tripped again
  });

  it("leases are shared: the second process sees the first one's slots", async () => {
    const { _setRedisForTests } = await import("@/lib/redis");
    const { acquireLease, releaseLease } = await import("@/lib/gateway/limits");
    const base = { customerId: "c1", storeId: "aerolink", maxConcurrent: 1, storeCeiling: 10, ttlMs: 30_000 };
    _setRedisForTests(redisA);
    expect((await acquireLease({ ...base, requestId: "a1" })).ok).toBe(true);
    _setRedisForTests(redisB);
    expect((await acquireLease({ ...base, requestId: "b1" })).ok).toBe(false);
    await releaseLease({ requestId: "a1", customerId: "c1", storeId: "aerolink" });
    expect((await acquireLease({ ...base, requestId: "b1" })).ok).toBe(true);
  });

  it("returns 429 with Retry-After in both wire formats when the RPM is exceeded", async () => {
    const prisma = await getPrisma();
    await createMockModel({ baseUrl: mock.url, slug: "mock-model" });
    const plan = await prisma.plan.create({ data: { storeId: "aerolink", name: "Tiny", priceCents: 1000, limitUsageCents: 500, rpm: 2, maxConcurrent: 5 } });
    const c = await createCustomer({ balanceCents: 1000 });
    await prisma.customer.update({ where: { id: c.id }, data: { planId: plan.id } });
    const token = await createGatewayToken(c.id);

    expect((await call(token, {})).status).toBe(200);
    expect((await call(token, {})).status).toBe(200);
    const o = await call(token, {});
    expect(o.status).toBe(429);
    expect(Number(o.headers.get("retry-after"))).toBeGreaterThanOrEqual(1);
    const ob = (await o.json()) as { error: { type: string; code: string } };
    expect(ob.error.type).toBe("rate_limit_error");
    expect(ob.error.code).toBe("rate_limit_exceeded");

    const a = await call(token, {}, "anthropic");
    expect(a.status).toBe(429);
    expect(a.headers.get("retry-after")).toBeTruthy();
    const ab = (await a.json()) as { type: string; error: { type: string } };
    expect(ab.type).toBe("error");
    expect(ab.error.type).toBe("rate_limit_error");
    await settled();
  });

  it("rejects the (maxConcurrent + 1)th open stream and frees the slot when a stream ends", async () => {
    const prisma = await getPrisma();
    await createMockModel({ baseUrl: mock.url, slug: "mock-model" });
    const plan = await prisma.plan.create({ data: { storeId: "aerolink", name: "Two", priceCents: 1000, limitUsageCents: 500, rpm: 1000, maxConcurrent: 2 } });
    const c = await createCustomer({ balanceCents: 1000 });
    await prisma.customer.update({ where: { id: c.id }, data: { planId: plan.id } });
    const token = await createGatewayToken(c.id);
    mock.setScenario({ chunkCount: 20, chunkDelayMs: 40 });

    const s1 = await call(token, { stream: true });
    const s2 = await call(token, { stream: true });
    expect(s1.status).toBe(200);
    expect(s2.status).toBe(200);
    const s3 = await call(token, { stream: true });
    expect(s3.status).toBe(429);
    expect(((await s3.json()) as { error: { message: string } }).error.message).toMatch(/in flight/);

    await s1.text(); // stream 1 finishes → settlement releases its lease
    await settled();
    const s4 = await call(token, { stream: true });
    expect(s4.status).toBe(200);
    await s2.text();
    await s4.text();
    await settled();
  });

  it("does not fail over or trip the breaker on an upstream 400", async () => {
    const prisma = await getPrisma();
    const secondary = await startMockUpstream();
    try {
      await createMockModel({ baseUrl: mock.url, slug: "mock-model", providerSlug: "primary", priority: 10 });
      await createMockModel({ baseUrl: secondary.url, slug: "mock-model", providerSlug: "secondary", priority: 20 });
      const c = await createCustomer({ balanceCents: 1000 });
      const token = await createGatewayToken(c.id);
      mock.setScenario({ failBeforeFirstByte: { status: 400, body: { error: { message: "secret upstream wording", type: "invalid_request_error" } } } });

      const r = await call(token, {});
      expect(r.status).toBe(400);
      const body = (await r.json()) as { error: { message: string } };
      expect(body.error.message).not.toContain("secret upstream wording");
      expect(secondary.requests).toHaveLength(0);

      const pm = await prisma.providerModel.findFirstOrThrow({ where: { provider: { slug: "primary" } } });
      const { breakerSnapshot } = await import("@/lib/gateway/breaker");
      expect((await breakerSnapshot(pm.id)).open).toBe(false);
    } finally {
      await secondary.close();
    }
  });

  it("fails over on a 429 before the first byte, trips the breaker after the threshold and notifies", async () => {
    const prisma = await getPrisma();
    const secondary = await startMockUpstream();
    try {
      const { provider } = await createMockModel({ baseUrl: mock.url, slug: "mock-model", providerSlug: "primary", priority: 10 });
      await prisma.provider.update({ where: { id: provider.id }, data: { breakerFailureThreshold: 2, breakerOpenMs: 30_000 } });
      await createMockModel({ baseUrl: secondary.url, slug: "mock-model", providerSlug: "secondary", priority: 20 });
      (await import("@/lib/gateway/registry")).invalidateModelRegistry();
      const c = await createCustomer({ balanceCents: 1000 });
      const token = await createGatewayToken(c.id);
      mock.setScenario({ failBeforeFirstByte: { status: 429 } });
      secondary.setScenario({ text: "from secondary" });

      const r1 = await call(token, {});
      expect(r1.status).toBe(200);
      expect(((await r1.json()) as { choices: Array<{ message: { content: string } }> }).choices[0].message.content).toBe("from secondary");
      const r2 = await call(token, {});
      expect(r2.status).toBe(200);
      await settled();

      expect(mock.requests).toHaveLength(2); // primary tried twice → threshold 2 → open
      const pm = await prisma.providerModel.findFirstOrThrow({ where: { providerId: provider.id } });
      const { breakerSnapshot } = await import("@/lib/gateway/breaker");
      expect((await breakerSnapshot(pm.id)).open).toBe(true);
      expect(await prisma.notification.count({ where: { type: "PROVIDER_BREAKER_OPEN" } })).toBe(1);

      // With the breaker open, the primary is skipped entirely.
      const r3 = await call(token, {});
      expect(r3.status).toBe(200);
      await settled();
      expect(mock.requests.length).toBeLessThanOrEqual(3); // at most the single half-open probe
    } finally {
      await secondary.close();
    }
  });
});
