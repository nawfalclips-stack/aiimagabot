import { afterAll, beforeAll, beforeEach, expect, it, vi } from "vitest";
import { describeIntegration, getPrisma, truncateAll } from "../helpers/db";
import { createCustomer, createGatewayToken, createMockModel, customerState, ensureStore } from "../helpers/fixtures";
import { startMockUpstream, type MockUpstream } from "../mock-upstream/server";

const pendingAfter: Promise<unknown>[] = [];
vi.mock("next/server", () => ({
  after: (fn: () => unknown) => {
    pendingAfter.push(Promise.resolve().then(fn));
  },
}));
const settled = async () => {
  while (pendingAfter.length) await Promise.allSettled(pendingAfter.splice(0));
};

// WS5 acceptance: a client abort reaches the upstream within a second, cut
// streams are metered from delivered bytes, upstream failures mid-stream end
// the stream cleanly without failover and are waived by policy.
// WS6 acceptance: cache-aware usage is priced per component.
describeIntegration("upstream abort, partial metering and cache pricing (WS5/WS6)", () => {
  let mock: MockUpstream;
  let handleGateway: typeof import("@/lib/gateway/handler").handleGateway;

  beforeAll(async () => {
    process.env.SESSION_SECRET = "test-secret-test-secret-test-secret";
    process.env.GATEWAY_RESERVATIONS = "enforce";
    process.env.GATEWAY_RATE_LIMITS = "false";
    process.env.REDIS_DISABLED = "true";
    await truncateAll();
    await ensureStore();
    mock = await startMockUpstream();
    ({ handleGateway } = await import("@/lib/gateway/handler"));
  });
  beforeEach(async () => {
    mock.reset();
    const prisma = await getPrisma();
    await prisma.customer.deleteMany({});
    await prisma.provider.deleteMany({});
    await prisma.gatewayModel.deleteMany({});
    await prisma.setting.deleteMany({});
    (await import("@/lib/gateway/registry")).invalidateModelRegistry();
  });
  afterAll(async () => {
    await mock.close();
    await (await getPrisma()).$disconnect();
  });

  const call = (token: string, body: Record<string, unknown>, wire: "openai" | "anthropic" = "openai", signal?: AbortSignal) =>
    handleGateway(
      new Request(`http://gateway.test/v1/${wire === "openai" ? "chat/completions" : "messages"}`, {
        method: "POST",
        headers: { "content-type": "application/json", authorization: `Bearer ${token}` },
        body: JSON.stringify(
          wire === "openai"
            ? { model: "mock-model", messages: [{ role: "user", content: "hello" }], ...body }
            : { model: "mock-model", max_tokens: 500, messages: [{ role: "user", content: "hello" }], ...body }
        ),
        signal,
      }),
      wire
    );

  async function setup(opts: { balanceCents?: number; dialect?: string; totalTimeoutMs?: number; cachedPrice?: number | null } = {}) {
    const prisma = await getPrisma();
    const { provider, model } = await createMockModel({ baseUrl: mock.url, slug: "mock-model" });
    if (opts.dialect || opts.totalTimeoutMs) {
      await prisma.provider.update({ where: { id: provider.id }, data: { usageDialect: opts.dialect ?? "openai", totalTimeoutMs: opts.totalTimeoutMs ?? null } });
    }
    if (opts.cachedPrice !== undefined) {
      await prisma.gatewayModel.update({ where: { id: model.id }, data: { cachedInputPriceMicroPerMTok: opts.cachedPrice } });
    }
    (await import("@/lib/gateway/registry")).invalidateModelRegistry();
    const c = await createCustomer({ balanceCents: opts.balanceCents ?? 100 });
    const token = await createGatewayToken(c.id);
    return { c, token };
  }

  for (const wire of ["openai", "anthropic"] as const) {
    it(`${wire} wire: a client abort mid-stream cancels the upstream within 1 s and is metered as ESTIMATED / CLIENT_DISCONNECTED`, async () => {
      const { c, token } = await setup();
      mock.setScenario({ chunkCount: 40, chunkDelayMs: 50, text: "x".repeat(1400) });
      const r = await call(token, { stream: true }, wire);
      expect(r.status).toBe(200);
      const reader = r.body!.getReader();
      await reader.read();
      await reader.read();
      const t0 = Date.now();
      await reader.cancel("user pressed ctrl-c");
      const rec = await mock.waitForCancel({ timeoutMs: 1500 });
      expect(rec.cancelled).toBe(true);
      expect(Date.now() - t0).toBeLessThan(1000);
      await settled();

      const prisma = await getPrisma();
      const log = await prisma.usageLog.findFirstOrThrow({ where: { customerId: c.id } });
      expect(log.outcome).toBe("CLIENT_DISCONNECTED");
      expect(log.usageSource).toBe("ESTIMATED");
      expect(log.completionTokens).toBeGreaterThan(0);
      expect(log.completionTokens).toBeLessThan(400); // ~35 chars × 2 chunks / 3.5, not the whole 1400
      expect(log.customerMicroUsd).toBeGreaterThan(0n); // client-caused: charged for what was delivered
      const s = await customerState(c.id);
      expect(s.reservedMicroUsd).toBe(0n);
      expect((await prisma.gatewayReservation.findFirstOrThrow({ where: { customerId: c.id } })).status).toBe("SETTLED");
    });
  }

  it("an upstream error mid-stream ends the stream in-band, never fails over, and is waived by default", async () => {
    const secondary = await startMockUpstream();
    try {
      const { c, token } = await setup();
      await createMockModel({ baseUrl: secondary.url, slug: "mock-model", providerSlug: "secondary", priority: 20 });
      (await import("@/lib/gateway/registry")).invalidateModelRegistry();
      mock.setScenario({ chunkCount: 6, failAfterChunks: 3, failAfterMode: "error_chunk" });

      const r = await call(token, { stream: true });
      const text = await r.text();
      await settled();
      expect(text).toContain("mock mid-stream failure");
      expect(secondary.requests).toHaveLength(0);

      const prisma = await getPrisma();
      const log = await prisma.usageLog.findFirstOrThrow({ where: { customerId: c.id } });
      expect(log.outcome).toBe("UPSTREAM_ERROR");
      expect(log.customerMicroUsd).toBe(0n);
      expect((await customerState(c.id)).balanceMicroUsd).toBe(1_000_000n);
      expect((await customerState(c.id)).reservedMicroUsd).toBe(0n);
    } finally {
      await secondary.close();
    }
  });

  it("a socket drop mid-stream delivers a terminal error chunk to the client", async () => {
    const { c, token } = await setup();
    mock.setScenario({ chunkCount: 6, chunkDelayMs: 40, failAfterChunks: 2, failAfterMode: "socket_close" });
    const r = await call(token, { stream: true });
    const text = await r.text();
    await settled();
    expect(text).toContain('"error"');
    expect(text.trim().endsWith("data: [DONE]")).toBe(true);
    const prisma = await getPrisma();
    expect((await prisma.usageLog.findFirstOrThrow({ where: { customerId: c.id } })).outcome).toBe("UPSTREAM_ERROR");
  });

  it("CHARGE_DELIVERED charges the estimated delivery even on upstream failure", async () => {
    const prisma = await getPrisma();
    const { c, token } = await setup();
    await prisma.setting.create({ data: { storeId: "aerolink", key: "partial_charge_policy", value: "CHARGE_DELIVERED" } });
    mock.setScenario({ chunkCount: 6, failAfterChunks: 3, failAfterMode: "error_chunk", text: "y".repeat(600) });
    const r = await call(token, { stream: true });
    await r.text();
    await settled();
    const log = await prisma.usageLog.findFirstOrThrow({ where: { customerId: c.id } });
    expect(log.outcome).toBe("UPSTREAM_ERROR");
    expect(log.usageSource).toBe("ESTIMATED");
    expect(log.customerMicroUsd).toBeGreaterThan(0n);
  });

  it("the total timeout aborts a slow stream and records TIMEOUT", async () => {
    const { c, token } = await setup({ totalTimeoutMs: 400 });
    mock.setScenario({ chunkCount: 30, chunkDelayMs: 100 });
    const r = await call(token, { stream: true });
    const text = await r.text();
    await settled();
    expect(text).toContain("timeout");
    const rec = await mock.waitForCancel({ timeoutMs: 1500 });
    expect(rec.cancelled).toBe(true);
    const prisma = await getPrisma();
    const log = await prisma.usageLog.findFirstOrThrow({ where: { customerId: c.id } });
    expect(log.outcome).toBe("TIMEOUT");
    expect(log.customerMicroUsd).toBe(0n); // waived: upstream-caused
    expect((await customerState(c.id)).reservedMicroUsd).toBe(0n);
  });

  it("prices cached input at the cached rate (DeepSeek dialect) and shows cache stats to Claude Code", async () => {
    const { c, token } = await setup({ dialect: "deepseek", cachedPrice: 40_000 }); // $0.04/M cached vs $0.40/M
    mock.setScenario({ usageDialect: "deepseek", usage: { prompt: 10_000, cached: 9_000, completion: 100 } });
    const r = await call(token, {}, "anthropic");
    expect(r.status).toBe(200);
    const body = (await r.json()) as { usage: Record<string, number> };
    expect(body.usage.cache_read_input_tokens).toBe(9000);
    expect(body.usage.input_tokens).toBe(1000);
    await settled();
    const prisma = await getPrisma();
    const log = await prisma.usageLog.findFirstOrThrow({ where: { customerId: c.id } });
    // 1000 × 0.40 + 9000 × 0.04 + 100 × 1.60 = 400 + 360 + 160 = 920 µ$ provider → ×2.2 = 2024 µ$
    expect(log.costMicroUsd).toBe(920);
    expect(log.customerMicroUsd).toBe(2_024n);
    expect(log.inputCachedTokens).toBe(9000);
    expect(log.usageSource).toBe("PROVIDER");
    expect(log.rawUsage).toContain("prompt_cache_hit_tokens");
  });

  it("uses DeepInfra's estimated_cost when present", async () => {
    const { c, token } = await setup({ dialect: "deepinfra" });
    mock.setScenario({ usageDialect: "deepinfra", usage: { prompt: 100, completion: 10, cost: 0.0005 } });
    const r = await call(token, {});
    expect(r.status).toBe(200);
    await settled();
    const prisma = await getPrisma();
    const log = await prisma.usageLog.findFirstOrThrow({ where: { customerId: c.id } });
    expect(log.costMicroUsd).toBe(500);
    expect(log.customerMicroUsd).toBe(1_100n);
  });
});
