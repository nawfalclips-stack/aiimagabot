import { afterAll, beforeAll, beforeEach, expect, it } from "vitest";
import { describeIntegration, getPrisma, truncateAll } from "../helpers/db";
import { createCustomer, ensureStore, STORE_ID } from "../helpers/fixtures";

// Plan profit: recorded once per purchase at the plan's current profit,
// never twice for the same purchase, reversed exactly on a voucher clawback,
// and included in the dashboard totals (which sum ProfitHistory).
describeIntegration("plan profit", () => {
  beforeAll(async () => {
    process.env.SESSION_SECRET ??= "test-secret-test-secret-test-secret";
    await truncateAll();
    await ensureStore();
  });
  beforeEach(async () => {
    const prisma = await getPrisma();
    await prisma.customer.deleteMany({});
    await prisma.plan.deleteMany({});
  });
  afterAll(async () => (await getPrisma()).$disconnect());

  async function plan(profitCents: number) {
    const prisma = await getPrisma();
    return prisma.plan.create({ data: { storeId: STORE_ID, name: "Starter", priceCents: 10_000, limitType: "USD", limitUsageCents: 200, profitCents } });
  }

  it("records the plan profit once per purchase and keeps the customer total in step", async () => {
    const prisma = await getPrisma();
    const { recordPlanProfit } = await import("@/lib/services/profit");
    const p = await plan(3_500);
    const c = await createCustomer({ balanceCents: 0 });

    const first = await prisma.$transaction((tx) => recordPlanProfit(tx, { customerId: c.id, plan: p, ref: { type: "RechargeRequest", id: "req_1" } }));
    const replay = await prisma.$transaction((tx) => recordPlanProfit(tx, { customerId: c.id, plan: p, ref: { type: "RechargeRequest", id: "req_1" } }));
    const second = await prisma.$transaction((tx) => recordPlanProfit(tx, { customerId: c.id, plan: p, ref: { type: "RechargeRequest", id: "req_2" } }));

    expect([first, replay, second]).toEqual([3_500, 0, 3_500]);
    expect((await prisma.customer.findUniqueOrThrow({ where: { id: c.id } })).profitCents).toBe(7_000);
    const rows = await prisma.profitHistory.findMany({ where: { customerId: c.id } });
    expect(rows.every((r) => r.source === "PLAN" && r.planId === p.id)).toBe(true);
  });

  it("snapshots the profit: editing the plan does not change recorded purchases", async () => {
    const prisma = await getPrisma();
    const { recordPlanProfit, profitByPlan } = await import("@/lib/services/profit");
    const p = await plan(3_500);
    const c = await createCustomer({ balanceCents: 0 });
    await prisma.$transaction((tx) => recordPlanProfit(tx, { customerId: c.id, plan: p, ref: { type: "Activation", id: c.id } }));
    const edited = await prisma.plan.update({ where: { id: p.id }, data: { profitCents: 5_000 } });
    await prisma.$transaction((tx) => recordPlanProfit(tx, { customerId: c.id, plan: edited, ref: { type: "RechargeRequest", id: "req_3" } }));
    expect(await profitByPlan(STORE_ID)).toEqual(new Map([[p.id, { profitCents: 8_500, purchases: 2 }]]));
  });

  it("records nothing for a plan without profit", async () => {
    const prisma = await getPrisma();
    const { recordPlanProfit } = await import("@/lib/services/profit");
    const p = await plan(0);
    const c = await createCustomer({ balanceCents: 0 });
    expect(await prisma.$transaction((tx) => recordPlanProfit(tx, { customerId: c.id, plan: p, ref: { type: "Voucher", id: "v_0" } }))).toBe(0);
    expect(await prisma.profitHistory.count({ where: { customerId: c.id } })).toBe(0);
  });

  it("reverses a voucher's profit exactly once and nets it out of the totals", async () => {
    const prisma = await getPrisma();
    const { recordPlanProfit, reversePlanProfit, profitByPlan } = await import("@/lib/services/profit");
    const { getDashboardStats } = await import("@/lib/services/analytics");
    const p = await plan(3_500);
    const c = await createCustomer({ balanceCents: 0 });
    await prisma.$transaction((tx) => recordPlanProfit(tx, { customerId: c.id, plan: p, ref: { type: "Voucher", id: "v_1" } }));
    const reversed = await prisma.$transaction((tx) => reversePlanProfit(tx, { ref: { type: "Voucher", id: "v_1" }, reason: "chargeback" }));
    const again = await prisma.$transaction((tx) => reversePlanProfit(tx, { ref: { type: "Voucher", id: "v_1" }, reason: "chargeback" }));

    expect([reversed, again]).toEqual([3_500, 0]);
    expect((await prisma.customer.findUniqueOrThrow({ where: { id: c.id } })).profitCents).toBe(0);
    expect((await profitByPlan(STORE_ID)).get(p.id)).toEqual({ profitCents: 0, purchases: 1 });
    expect((await getDashboardStats(STORE_ID)).totalProfitCents).toBe(0);
  });
});
