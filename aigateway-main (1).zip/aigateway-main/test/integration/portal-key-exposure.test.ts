import { SignJWT } from "jose";
import { afterAll, beforeAll, describe, expect, it } from "vitest";
import { getPrisma, hasTestDb } from "../helpers/db";
import { createCustomer, ensureStore } from "../helpers/fixtures";
import { findProviderKeys, SAMPLE_PROVIDER_KEYS } from "../helpers/provider-key-patterns";

/**
 * WS10 acceptance: no portal route returns a string matching a known provider
 * key pattern. Seeds a customer holding a legacy key (plus a pool key and a
 * usage row labelled with a key, as the old "deduct usage" flow wrote), signs
 * a customer session, and fetches every portal page from a running server.
 *
 * Needs a server using the test database and the same SESSION_SECRET:
 *   DATABASE_URL=$TEST_DATABASE_URL SESSION_SECRET=… npm run dev
 *   PORTAL_TEST_BASE_URL=http://localhost:3000 SESSION_SECRET=… npm run test:integration
 * Skipped when PORTAL_TEST_BASE_URL is unset.
 */
const BASE = process.env.PORTAL_TEST_BASE_URL?.replace(/\/+$/, "") ?? "";
const run = hasTestDb && BASE && (process.env.SESSION_SECRET ?? "").length >= 16 ? describe : describe.skip;

const ROUTES = [
  "/portal",
  "/portal/activity",
  "/portal/api-access",
  "/portal/documentation",
  "/portal/affiliate",
  "/portal/loyalty",
  "/portal/recharge",
  "/portal/review-bonus",
  "/portal/rules",
  "/portal/support",
  "/portal/support/new",
];

run("portal never returns an upstream key (WS10)", () => {
  let cookie = "";

  beforeAll(async () => {
    const prisma = await getPrisma();
    await ensureStore();
    const customer = await createCustomer({ balanceCents: 2000 });
    await prisma.apiKey.create({ data: { customerId: customer.id, key: SAMPLE_PROVIDER_KEYS.anthropic } });
    await prisma.apiPoolKey.create({ data: { storeId: customer.storeId, key: SAMPLE_PROVIDER_KEYS.openrouter, status: "ASSIGNED", customerId: customer.id } });
    await prisma.usageLog.create({
      data: { customerId: customer.id, storeId: customer.storeId, happenedAt: new Date(), keyLabel: SAMPLE_PROVIDER_KEYS.deepseek, model: "legacy", costMicroUsd: 10_000 },
    });
    const token = await new SignJWT({ customerId: customer.id, kind: "customer" })
      .setProtectedHeader({ alg: "HS256" })
      .setIssuedAt()
      .setExpirationTime("10m")
      .sign(new TextEncoder().encode(process.env.SESSION_SECRET));
    cookie = `aerolink_customer_session=${token}`;
  });
  afterAll(async () => {
    await (await getPrisma()).$disconnect();
  });

  it.each(ROUTES.map((r) => [r]))("%s", async (route) => {
    const res = await fetch(`${BASE}${route}`, { headers: { cookie }, redirect: "manual" });
    expect(res.status, `${route} should render for a signed-in customer`).toBe(200);
    const body = await res.text();
    expect(findProviderKeys(body)).toEqual([]);
  });
});
