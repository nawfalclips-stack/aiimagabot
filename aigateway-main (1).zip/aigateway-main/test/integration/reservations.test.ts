import { afterAll, beforeAll, beforeEach, expect, it } from "vitest";
import { describeIntegration, getPrisma, truncateAll } from "../helpers/db";
import { createCustomer, customerState, ensureStore } from "../helpers/fixtures";

// WS2 acceptance: parallel holds never oversell, settle is idempotent, holds
// come back to exactly zero, and the sweeper releases orphaned holds.
describeIntegration("reservations (WS2)", () => {
  beforeAll(async () => {
    process.env.SESSION_SECRET ??= "test-secret-test-secret-test-secret";
    await truncateAll();
    await ensureStore();
  });
  beforeEach(async () => {
    const prisma = await getPrisma();
    await prisma.customer.deleteMany({});
    await prisma.notification.deleteMany({});
  });
  afterAll(async () => (await getPrisma()).$disconnect());

  const future = () => new Date(Date.now() + 60_000);

  it("50 parallel holds against a balance that covers 3 → exactly 3 succeed, reserved returns to 0", async () => {
    const { reserve, settle } = await import("@/lib/billing/reservations");
    const { verifyCustomerLedger } = await import("@/lib/billing/balance-service");
    const c = await createCustomer({ balanceCents: 350 }); // $3.50, holds of $1.00

    const results = await Promise.all(
      Array.from({ length: 50 }, (_, i) =>
        reserve({ requestId: `req_par_${i}`, customerId: c.id, storeId: "aerolink", holdMicroUsd: 1_000_000n, model: "m", expiresAt: future(), mode: "enforce" })
      )
    );
    const held = results.filter((r) => r.ok);
    expect(held).toHaveLength(3);
    expect((await customerState(c.id)).reservedMicroUsd).toBe(3_000_000n);

    // Settle each for less than the hold; the difference is released.
    for (const r of held) {
      if (!r.ok) continue;
      const s = await settle({ reservationId: r.reservation.id, chargeMicroUsd: 900_000n, actor: { label: "Gateway" } });
      expect(s.status).toBe("settled");
    }
    const after = await customerState(c.id);
    expect(after.reservedMicroUsd).toBe(0n);
    expect(after.balanceMicroUsd).toBe(3_500_000n - 2_700_000n);
    expect(after.balanceMicroUsd).toBeGreaterThanOrEqual(0n);
    expect((await verifyCustomerLedger(c.id)).ok).toBe(true);
  });

  it("settles once even when called twice", async () => {
    const { reserve, settle } = await import("@/lib/billing/reservations");
    const c = await createCustomer({ balanceCents: 500 });
    const r = await reserve({ requestId: "req_twice", customerId: c.id, storeId: "aerolink", holdMicroUsd: 1_000_000n, model: "m", expiresAt: future(), mode: "enforce" });
    expect(r.ok).toBe(true);
    const [a, b] = await Promise.all([
      settle({ reservationId: "req_twice", chargeMicroUsd: 400_000n, actor: { label: "Gateway" } }),
      settle({ reservationId: "req_twice", chargeMicroUsd: 400_000n, actor: { label: "Gateway" } }),
    ]);
    expect([a.status, b.status].sort()).toEqual(["already-settled", "settled"]);
    const s = await customerState(c.id);
    expect(s.balanceMicroUsd).toBe(5_000_000n - 400_000n);
    expect(s.reservedMicroUsd).toBe(0n);
  });

  it("never charges below zero when the real cost exceeds the hold and the balance", async () => {
    const { reserve, settle } = await import("@/lib/billing/reservations");
    const c = await createCustomer({ balanceCents: 100 });
    const r = await reserve({ requestId: "req_over", customerId: c.id, storeId: "aerolink", holdMicroUsd: 500_000n, model: "m", expiresAt: future(), mode: "enforce" });
    expect(r.ok).toBe(true);
    const s = await settle({ reservationId: "req_over", chargeMicroUsd: 2_000_000n, actor: { label: "Gateway" } });
    expect(s.status).toBe("settled");
    if (s.status !== "settled") return;
    expect(s.uncollectedMicroUsd).toBe(1_000_000n);
    const state = await customerState(c.id);
    expect(state.balanceMicroUsd).toBe(0n);
    expect(state.reservedMicroUsd).toBe(0n);
  });

  it("shadow mode records the reservation without holding anything", async () => {
    const { reserve } = await import("@/lib/billing/reservations");
    const c = await createCustomer({ balanceCents: 10 });
    const r = await reserve({ requestId: "req_shadow", customerId: c.id, storeId: "aerolink", holdMicroUsd: 99_000_000n, model: "m", expiresAt: future(), mode: "shadow" });
    expect(r.ok).toBe(true);
    if (!r.ok) return;
    expect(r.reservation.amountMicroUsd).toBe(0n);
    expect((await customerState(c.id)).reservedMicroUsd).toBe(0n);
  });

  it("release gives the hold back without a charge", async () => {
    const { reserve, release } = await import("@/lib/billing/reservations");
    const c = await createCustomer({ balanceCents: 200 });
    await reserve({ requestId: "req_rel", customerId: c.id, storeId: "aerolink", holdMicroUsd: 1_500_000n, model: "m", expiresAt: future(), mode: "enforce" });
    expect((await customerState(c.id)).reservedMicroUsd).toBe(1_500_000n);
    expect(await release("req_rel")).toBe(true);
    expect(await release("req_rel")).toBe(false);
    const s = await customerState(c.id);
    expect(s.reservedMicroUsd).toBe(0n);
    expect(s.balanceMicroUsd).toBe(2_000_000n);
  });

  it("the sweeper releases holds whose function died, and tells the admin", async () => {
    const prisma = await getPrisma();
    const { reserve, sweepExpiredReservations } = await import("@/lib/billing/reservations");
    const c = await createCustomer({ balanceCents: 300 });
    await reserve({ requestId: "req_dead", customerId: c.id, storeId: "aerolink", holdMicroUsd: 1_000_000n, model: "m", expiresAt: new Date(Date.now() - 1000), mode: "enforce" });
    await reserve({ requestId: "req_alive", customerId: c.id, storeId: "aerolink", holdMicroUsd: 1_000_000n, model: "m", expiresAt: future(), mode: "enforce" });
    expect((await customerState(c.id)).reservedMicroUsd).toBe(2_000_000n);

    const swept = await sweepExpiredReservations();
    expect(swept.expired).toEqual(["req_dead"]);
    expect((await customerState(c.id)).reservedMicroUsd).toBe(1_000_000n);
    expect((await prisma.gatewayReservation.findUniqueOrThrow({ where: { id: "req_dead" } })).status).toBe("EXPIRED");
    const notes = await prisma.notification.findMany({ where: { type: "RESERVATIONS_SWEPT" } });
    expect(notes).toHaveLength(1);

    // Idempotent: nothing left to sweep.
    expect((await sweepExpiredReservations()).expired).toEqual([]);
  });
});
