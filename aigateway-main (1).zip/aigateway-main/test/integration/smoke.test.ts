import { afterAll, beforeAll, expect, it } from "vitest";
import { describeIntegration, getPrisma, truncateAll } from "../helpers/db";

// Proves the integration harness itself: migrations applied, client connects,
// the store rows the app relies on can be created.
describeIntegration("integration harness", () => {
  beforeAll(async () => {
    await truncateAll();
  });
  afterAll(async () => {
    const prisma = await getPrisma();
    await prisma.$disconnect();
  });

  it("has the baseline schema and can round-trip a store", async () => {
    const prisma = await getPrisma();
    const [{ count }] = await prisma.$queryRaw<Array<{ count: bigint }>>`SELECT COUNT(*)::bigint AS count FROM "_prisma_migrations" WHERE finished_at IS NOT NULL`;
    expect(Number(count)).toBeGreaterThanOrEqual(1);
    await prisma.store.create({ data: { id: "aerolink", name: "AeroLink", logoText: "AeroLink", storeUrl: "https://example.com" } });
    expect(await prisma.store.count()).toBe(1);
  });
});
