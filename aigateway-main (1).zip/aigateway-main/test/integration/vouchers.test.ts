import { afterAll, beforeAll, beforeEach, expect, it } from "vitest";
import { describeIntegration, getPrisma, truncateAll } from "../helpers/db";
import { createCustomer, customerState, ensureStore } from "../helpers/fixtures";

// WS9 acceptance: one code → one redemption under 20 parallel attempts;
// used/revoked/expired fail identically; plaintext never stored; clawback
// through the ledger never below zero; a new buyer goes code → account →
// plan → credit with no admin step (auto-approve on), or to the review queue
// and is credited at approval (auto-approve off, decision #5 default).
describeIntegration("vouchers (WS9)", () => {
  let svc: typeof import("@/lib/vouchers/service");
  let code: typeof import("@/lib/vouchers/code");
  const admin = { adminId: "admin-test", adminName: "Tester" };

  beforeAll(async () => {
    process.env.SESSION_SECRET = "test-secret-test-secret-test-secret";
    process.env.VOUCHER_PEPPER = Buffer.alloc(32, 9).toString("base64");
    process.env.REDIS_DISABLED = "true";
    await truncateAll();
    await ensureStore();
    const prisma = await getPrisma();
    await prisma.admin.create({ data: { id: admin.adminId, email: "tester@example.com", name: admin.adminName, passwordHash: "x" } });
    svc = await import("@/lib/vouchers/service");
    code = await import("@/lib/vouchers/code");
  });
  beforeEach(async () => {
    const prisma = await getPrisma();
    await prisma.voucher.deleteMany({});
    await prisma.voucherBatch.deleteMany({});
    await prisma.customer.deleteMany({});
    await prisma.pack.deleteMany({});
    await prisma.plan.deleteMany({});
    await prisma.setting.deleteMany({});
    await prisma.notification.deleteMany({});
  });
  afterAll(async () => {
    await (await getPrisma()).$disconnect();
  });

  async function setup(opts: { autoApprove?: boolean; bonusCents?: number; maxPerIp?: number } = {}) {
    const prisma = await getPrisma();
    await prisma.setting.create({ data: { storeId: "aerolink", key: "voucher_auto_approve", value: opts.autoApprove ? "true" : "false" } });
    if (opts.maxPerIp !== undefined) await prisma.setting.create({ data: { storeId: "aerolink", key: "voucher_max_redemptions_per_ip_day", value: String(opts.maxPerIp) } });
    const plan = await prisma.plan.create({ data: { storeId: "aerolink", name: "Starter", priceCents: 10_000, limitType: "USD", limitUsageCents: 4545 } });
    const pack = await prisma.pack.create({
      data: { storeId: "aerolink", name: "Starter $100", planId: plan.id, balanceGrantMicroUsd: 100_000_000n, bonusGrantMicroUsd: BigInt(opts.bonusCents ?? 0) * 10_000n },
    });
    const batch = await svc.createVoucherBatch({ storeId: "aerolink", packId: pack.id, quantity: 5, expiresAt: null, ...admin });
    return { plan, pack, batch };
  }

  it("stores only an HMAC and the last 4; plaintext codes appear nowhere in the database", async () => {
    const { batch } = await setup();
    const prisma = await getPrisma();
    const rows = await prisma.voucher.findMany();
    expect(rows).toHaveLength(5);
    for (const formatted of batch.codes) {
      const normalised = code.normaliseVoucherCode(formatted)!;
      expect(normalised).toHaveLength(21);
      const dump = JSON.stringify(await prisma.voucher.findMany()) + JSON.stringify(await prisma.voucherBatch.findMany()) + JSON.stringify(await prisma.activityLog.findMany());
      expect(dump).not.toContain(normalised);
      expect(dump).not.toContain(formatted);
      expect(rows.some((r) => r.codeHmac === code.hmacVoucherCode(normalised) && r.codeLast4 === normalised.slice(16, 20))).toBe(true);
    }
  });

  it("20 parallel redemptions of one code → exactly 1 success, 19 identical failures", async () => {
    const { batch, plan } = await setup({ autoApprove: true, maxPerIp: 100 });
    const results = await Promise.all(
      Array.from({ length: 20 }, (_, i) => svc.redeemVoucher({ storeId: "aerolink", rawCode: batch.codes[0], ip: `10.0.0.${i}` }))
    );
    const ok = results.filter((r) => r.ok);
    const failed = results.filter((r) => !r.ok);
    expect(ok).toHaveLength(1);
    expect(failed).toHaveLength(19);
    expect(new Set(failed.map((r) => (r.ok ? "" : r.message)))).toEqual(new Set([svc.REDEEM_FAILURE_MESSAGE]));

    const prisma = await getPrisma();
    expect(await prisma.customer.count()).toBe(1);
    const c = await prisma.customer.findFirstOrThrow();
    expect(c.isActivated).toBe(true);
    expect(c.planId).toBe(plan.id);
    expect(c.activationSource).toBe("VOUCHER");
    expect((await customerState(c.id)).balanceMicroUsd).toBe(100_000_000n);
    expect(await prisma.ledgerEntry.count({ where: { customerId: c.id, type: "VOUCHER_REDEMPTION" } })).toBe(1);
  });

  it("used, revoked and expired codes fail with the same message; malformed input never hits the database", async () => {
    const { batch } = await setup({ autoApprove: true, maxPerIp: 100 });
    const prisma = await getPrisma();
    const [used, revoked, expiredCode, fresh] = batch.codes;
    expect((await svc.redeemVoucher({ storeId: "aerolink", rawCode: used, ip: "1.1.1.1" })).ok).toBe(true);
    const revokedRow = (await prisma.voucher.findMany()).find((v) => v.codeHmac === code.hmacVoucherCode(code.normaliseVoucherCode(revoked)!))!;
    await svc.revokeVoucher("aerolink", revokedRow.id, "refund", admin.adminId, admin.adminName);
    // Expire the third by moving its batch expiry into the past on a separate batch.
    const { pack } = { pack: await prisma.pack.findFirstOrThrow() };
    const old = await svc.createVoucherBatch({ storeId: "aerolink", packId: pack.id, quantity: 1, expiresAt: new Date(Date.now() - 1000), ...admin });

    const messages = await Promise.all(
      [used, revoked, old.codes[0], "ALK-NOT-A-CODE", ""].map(async (c) => {
        const r = await svc.redeemVoucher({ storeId: "aerolink", rawCode: c, ip: "1.1.1.2" });
        return r.ok ? "OK" : r.message;
      })
    );
    expect(messages).toEqual(Array(5).fill(svc.REDEEM_FAILURE_MESSAGE));
    expect((await prisma.voucher.findMany({ where: { batchId: old.batch.id } }))[0].status).toBe("EXPIRED");
    void expiredCode;
    expect((await svc.redeemVoucher({ storeId: "aerolink", rawCode: fresh, ip: "1.1.1.3" })).ok).toBe(true);
  });

  it("auto-approve off (default): the buyer gets an account but the credit waits for approval", async () => {
    const { batch, pack } = await setup({ autoApprove: false });
    const r = await svc.redeemVoucher({ storeId: "aerolink", rawCode: batch.codes[0], ip: "2.2.2.2" });
    expect(r.ok && r.kind === "new" && r.credited).toBe(false);
    const prisma = await getPrisma();
    const c = await prisma.customer.findFirstOrThrow();
    expect(c.isActivated).toBe(false);
    expect(c.packId).toBe(pack.id);
    expect((await customerState(c.id)).balanceMicroUsd).toBe(0n);
    expect(await prisma.notification.count({ where: { type: "VOUCHER_REVIEW" } })).toBe(1);
    const v = await prisma.voucher.findFirstOrThrow({ where: { status: "REDEEMED" } });
    expect(v.redeemedByCustomerId).toBe(c.id);
    expect(await svc.voucherWasCredited(v.id)).toBe(false);

    // Approval credits the grants from the voucher's pack (what approveActivationAction does).
    await prisma.$transaction(async (tx) => {
      await tx.customer.update({ where: { id: c.id }, data: { isActivated: true } });
      const voucher = await tx.voucher.findUniqueOrThrow({ where: { id: v.id }, include: { pack: true } });
      await svc.creditVoucherGrants(tx, voucher, c.id, { label: "Tester" });
      await svc.creditVoucherGrants(tx, voucher, c.id, { label: "Tester" }); // idempotent
    });
    expect((await customerState(c.id)).balanceMicroUsd).toBe(100_000_000n);
    expect(await svc.voucherWasCredited(v.id)).toBe(true);
  });

  it("IP velocity sends the (N+1)th redemption from one IP to review even with auto-approve on", async () => {
    const { batch } = await setup({ autoApprove: true, maxPerIp: 2 });
    const results = [];
    for (const c of batch.codes.slice(0, 3)) results.push(await svc.redeemVoucher({ storeId: "aerolink", rawCode: c, ip: "9.9.9.9" }));
    expect(results.map((r) => r.ok && r.credited)).toEqual([true, true, false]);
  });

  it("an existing customer tops up with the returning-customer review bonus rules", async () => {
    const { batch, plan } = await setup({ autoApprove: true, bonusCents: 500, maxPerIp: 100 });
    const existing = await createCustomer({ balanceCents: 100 });
    const r = await svc.redeemVoucher({ storeId: "aerolink", rawCode: batch.codes[0], ip: "3.3.3.3", customer: existing, gamsgoOrderId: "GG-123" });
    expect(r.ok && r.kind === "existing" && r.credited).toBe(true);
    const s = await customerState(existing.id);
    expect(s.balanceMicroUsd).toBe(101_000_000n);
    expect(s.bonusMicroUsd).toBe(5_000_000n);
    const prisma = await getPrisma();
    const c = await prisma.customer.findUniqueOrThrow({ where: { id: existing.id } });
    expect(c.planId).toBe(plan.id);
    expect(c.pendingBonusCents).toBe(1500); // 15 % of $100
    expect(c.reviewBonusStatus).toBe("OFFERED");
    expect(await prisma.customer.count()).toBe(1);
    expect((await prisma.voucher.findFirstOrThrow({ where: { status: "REDEEMED" } })).gamsgoOrderId).toBe("GG-123");
  });

  it("clawback takes back min(grant, remaining) through the ledger and never goes negative", async () => {
    const { batch } = await setup({ autoApprove: true, bonusCents: 500, maxPerIp: 100 });
    const existing = await createCustomer({ balanceCents: 0 });
    expect((await svc.redeemVoucher({ storeId: "aerolink", rawCode: batch.codes[0], ip: "4.4.4.4", customer: existing })).ok).toBe(true);
    // Spend most of it first.
    const { debit } = await import("@/lib/billing/balance-service");
    await debit({ customerId: existing.id, pot: "BALANCE", amountMicroUsd: 95_000_000n, type: "USAGE", idempotencyKey: "use:1", actor: { label: "Gateway" } });
    const before = await customerState(existing.id);
    expect(before.balanceMicroUsd).toBe(5_000_000n);
    const prisma = await getPrisma();
    const v = await prisma.voucher.findFirstOrThrow({ where: { status: "REDEEMED" } });
    const r = await svc.clawbackVoucher("aerolink", v.id, { reason: "GamsGo refund", suspendCustomer: true, ...admin });
    expect(r.balanceMicroUsd).toBe(5_000_000n); // only what remained
    expect(r.bonusMicroUsd).toBe(5_000_000n);
    const after = await customerState(existing.id);
    expect(after.balanceMicroUsd).toBe(0n);
    expect(after.bonusMicroUsd).toBe(0n);
    expect((await prisma.customer.findUniqueOrThrow({ where: { id: existing.id } })).status).toBe("SUSPENDED");
    expect(await prisma.ledgerEntry.count({ where: { customerId: existing.id, type: "CLAWBACK" } })).toBe(2);
    await expect(svc.clawbackVoucher("aerolink", v.id, { reason: "again", suspendCustomer: false, ...admin })).rejects.toThrow(/already/);
  });

  it("batch revoke, stock and expiry cron", async () => {
    const { batch, pack } = await setup({ autoApprove: true, maxPerIp: 100 });
    const prisma = await getPrisma();
    await svc.markBatchUploaded("aerolink", batch.batch.id, admin.adminId, admin.adminName);
    expect((await svc.redeemVoucher({ storeId: "aerolink", rawCode: batch.codes[0], ip: "5.5.5.5" })).ok).toBe(true);
    let stock = await svc.packStock("aerolink");
    expect(stock[0]).toMatchObject({ packId: pack.id, uploadedUnredeemed: 4, redeemedLast7Days: 1, low: true });
    expect(await svc.revokeBatch("aerolink", batch.batch.id, "leaked", admin.adminId, admin.adminName)).toBe(4);
    stock = await svc.packStock("aerolink");
    expect(stock[0].uploadedUnredeemed).toBe(0);
    expect((await svc.redeemVoucher({ storeId: "aerolink", rawCode: batch.codes[1], ip: "5.5.5.6" })).ok).toBe(false);

    const old = await svc.createVoucherBatch({ storeId: "aerolink", packId: pack.id, quantity: 3, expiresAt: new Date(Date.now() - 1), ...admin });
    expect(await svc.expireVouchers()).toBe(3);
    expect(await prisma.voucher.count({ where: { batchId: old.batch.id, status: "EXPIRED" } })).toBe(3);
    expect(await svc.notifyLowStock("aerolink")).toEqual([pack.name]);
    expect(await svc.notifyLowStock("aerolink")).toEqual([]); // once a day
  });
});
