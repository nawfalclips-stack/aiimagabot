// Run the mock provider on a fixed port for local development:
//   npx tsx test/mock-upstream/cli.ts 4010
//   npx tsx test/mock-upstream/cli.ts 4011
// then `npx tsx scripts/gateway-dev-seed.ts` registers both as providers.
// Change behaviour at runtime:
//   curl -X POST localhost:4010/__control -d '{"ttfbDelayMs":2000,"usageDialect":"deepseek"}'
import { startMockUpstream } from "./server";

const port = Number(process.argv[2] ?? 4010);
startMockUpstream({ port }).then((m) => {
  console.log(`[mock-upstream] listening on ${m.url}  (POST /__control to script it, GET /__requests to inspect)`);
});
