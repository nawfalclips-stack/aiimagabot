// Scriptable mock LLM provider for tests and local development.
//
// Speaks the two upstream surfaces the gateway talks to:
//   POST {base}/chat/completions   — OpenAI Chat Completions (stream + non-stream)
//   POST {base}/messages           — Anthropic Messages (stream + non-stream)
//   GET  {base}/models             — for the admin "Test connection" probe
// where {base} is "" or "/v1" (both accepted).
//
// A scenario controls timing, failures and the usage dialect. It can be set
// in-process (returned handle) or over HTTP (`POST /__control`) so the same
// server serves Vitest and a `next dev` instance. Every request is recorded,
// including whether the client cancelled it before the response finished —
// that is how the abort tests prove the gateway stopped paying for tokens.

import { createServer, type IncomingMessage, type Server, type ServerResponse } from "node:http";
import { randomUUID } from "node:crypto";
import type { AddressInfo } from "node:net";

export type UsageDialect = "openai" | "deepseek" | "deepinfra" | "openrouter" | "anthropic";

export interface Scenario {
  /** Wait this long before sending headers / the first byte. */
  ttfbDelayMs?: number;
  /** Wait this long between streamed content chunks. */
  chunkDelayMs?: number;
  /** Respond with this HTTP status (and body) before any byte of a normal response. */
  failBeforeFirstByte?: { status: number; body?: unknown };
  /** After this many content chunks, fail mid-stream. */
  failAfterChunks?: number;
  /** How the mid-stream failure manifests. */
  failAfterMode?: "error_chunk" | "socket_close";
  /** Do not send the final usage chunk (simulates providers that omit it). */
  omitUsage?: boolean;
  /** Which provider's usage field names to emit. */
  usageDialect?: UsageDialect;
  /** Completion text; split into `chunkCount` pieces when streaming. */
  text?: string;
  chunkCount?: number;
  /** Emit a tool call instead of (or after) text. */
  toolCall?: { name: string; arguments: Record<string, unknown> };
  /** Emit reasoning content before the answer (OpenAI wire: `reasoning_content`). */
  reasoning?: string;
  /** Token numbers to report. */
  usage?: {
    prompt?: number;
    completion?: number;
    cached?: number;
    cacheWrite?: number;
    reasoning?: number;
    /** USD, for DeepInfra `estimated_cost` / OpenRouter `cost`. */
    cost?: number;
  };
}

export interface RequestRecord {
  id: string;
  method: string;
  path: string;
  headers: Record<string, string | string[] | undefined>;
  body: Record<string, unknown> | null;
  model: string | null;
  stream: boolean;
  startedAt: number;
  finishedAt: number | null;
  chunksSent: number;
  /** Client went away before the response was complete. */
  cancelled: boolean;
  cancelledAt: number | null;
}

export interface MockUpstream {
  url: string;
  port: number;
  server: Server;
  setScenario(s: Scenario): void;
  scenario(): Scenario;
  requests: RequestRecord[];
  lastRequest(): RequestRecord | undefined;
  /** Resolves when a request is marked cancelled (the most recent one by default). */
  waitForCancel(opts?: { id?: string; timeoutMs?: number }): Promise<RequestRecord>;
  reset(): void;
  close(): Promise<void>;
}

const DEFAULT_SCENARIO: Required<Pick<Scenario, "text" | "chunkCount" | "usageDialect" | "failAfterMode">> = {
  text: "Hello from the mock provider.",
  chunkCount: 5,
  usageDialect: "openai",
  failAfterMode: "error_chunk",
};

const sleep = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));

function readBody(req: IncomingMessage): Promise<string> {
  return new Promise((resolve, reject) => {
    const chunks: Buffer[] = [];
    req.on("data", (c: Buffer) => chunks.push(c));
    req.on("end", () => resolve(Buffer.concat(chunks).toString("utf8")));
    req.on("error", reject);
  });
}

function splitText(text: string, parts: number): string[] {
  if (parts <= 1 || text.length === 0) return [text];
  const size = Math.ceil(text.length / parts);
  const out: string[] = [];
  for (let i = 0; i < text.length; i += size) out.push(text.slice(i, i + size));
  return out;
}

/** Build a usage object in the requested provider dialect. */
export function usageFor(dialect: UsageDialect, u: NonNullable<Scenario["usage"]>): Record<string, unknown> {
  const prompt = u.prompt ?? 100;
  const completion = u.completion ?? 20;
  const cached = u.cached ?? 0;
  const cacheWrite = u.cacheWrite ?? 0;
  const reasoning = u.reasoning ?? 0;
  const total = prompt + completion;
  switch (dialect) {
    case "deepinfra":
      return { prompt_tokens: prompt, completion_tokens: completion, total_tokens: total, estimated_cost: u.cost ?? 0.000123 };
    case "deepseek":
      return {
        prompt_tokens: prompt,
        completion_tokens: completion,
        total_tokens: total,
        prompt_tokens_details: { cached_tokens: cached },
        prompt_cache_hit_tokens: cached,
        prompt_cache_miss_tokens: prompt - cached,
        completion_tokens_details: { reasoning_tokens: reasoning },
      };
    case "openrouter":
      return {
        prompt_tokens: prompt,
        completion_tokens: completion,
        total_tokens: total,
        cost: u.cost ?? 0.000123,
        prompt_tokens_details: { cached_tokens: cached, cache_write_tokens: cacheWrite },
        completion_tokens_details: { reasoning_tokens: reasoning },
        cost_details: { upstream_inference_cost: u.cost ?? 0.000123 },
      };
    case "anthropic":
      return {
        input_tokens: prompt - cached - cacheWrite,
        cache_creation_input_tokens: cacheWrite,
        cache_read_input_tokens: cached,
        output_tokens: completion,
      };
    case "openai":
    default:
      return {
        prompt_tokens: prompt,
        completion_tokens: completion,
        total_tokens: total,
        prompt_tokens_details: { cached_tokens: cached },
        completion_tokens_details: { reasoning_tokens: reasoning },
      };
  }
}

export async function startMockUpstream(opts: { port?: number; host?: string } = {}): Promise<MockUpstream> {
  let scenario: Scenario = {};
  const requests: RequestRecord[] = [];
  const cancelWaiters: Array<{ id?: string; resolve: (r: RequestRecord) => void }> = [];

  const markCancelled = (rec: RequestRecord) => {
    if (rec.cancelled || rec.finishedAt !== null) return;
    rec.cancelled = true;
    rec.cancelledAt = Date.now();
    for (const w of [...cancelWaiters]) {
      if (!w.id || w.id === rec.id) {
        cancelWaiters.splice(cancelWaiters.indexOf(w), 1);
        w.resolve(rec);
      }
    }
  };

  const json = (res: ServerResponse, status: number, body: unknown) => {
    res.writeHead(status, { "content-type": "application/json" });
    res.end(JSON.stringify(body));
  };

  const sse = (res: ServerResponse, event: string | null, data: unknown) => {
    const payload = typeof data === "string" ? data : JSON.stringify(data);
    res.write(`${event ? `event: ${event}\n` : ""}data: ${payload}\n\n`);
  };

  const handle = async (req: IncomingMessage, res: ServerResponse) => {
    const url = new URL(req.url ?? "/", "http://mock");
    const path = url.pathname.replace(/^\/v1(?=\/|$)/, "");

    // ── control plane ────────────────────────────────────────────────────
    if (path === "/__control") {
      if (req.method === "POST") {
        scenario = JSON.parse((await readBody(req)) || "{}") as Scenario;
        return json(res, 200, { ok: true, scenario });
      }
      if (req.method === "DELETE") {
        scenario = {};
        requests.length = 0;
        return json(res, 200, { ok: true });
      }
      return json(res, 200, { scenario, requests });
    }
    if (path === "/__requests") return json(res, 200, requests);

    if (req.method === "GET" && path === "/models") {
      return json(res, 200, { object: "list", data: [{ id: "mock-model", owned_by: "mock" }] });
    }

    const isChat = req.method === "POST" && path === "/chat/completions";
    const isMessages = req.method === "POST" && path === "/messages";
    if (!isChat && !isMessages) return json(res, 404, { error: { message: `No route ${req.method} ${url.pathname}` } });

    // ── record ───────────────────────────────────────────────────────────
    const raw = await readBody(req);
    let body: Record<string, unknown> | null = null;
    try {
      body = JSON.parse(raw) as Record<string, unknown>;
    } catch {
      return json(res, 400, { error: { message: "invalid json", type: "invalid_request_error" } });
    }
    const rec: RequestRecord = {
      id: randomUUID(),
      method: req.method ?? "POST",
      path: url.pathname,
      headers: req.headers,
      body,
      model: typeof body.model === "string" ? body.model : null,
      stream: body.stream === true,
      startedAt: Date.now(),
      finishedAt: null,
      chunksSent: 0,
      cancelled: false,
      cancelledAt: null,
    };
    requests.push(rec);
    // `close` before `finish` means the client hung up.
    res.on("close", () => {
      if (!res.writableFinished) markCancelled(rec);
    });
    req.on("aborted", () => markCancelled(rec));

    const s = { ...DEFAULT_SCENARIO, ...scenario };
    const usage = usageFor(s.usageDialect, s.usage ?? {});
    const modelId = rec.model ?? "mock-model";

    if (s.ttfbDelayMs) await sleep(s.ttfbDelayMs);
    if (rec.cancelled) return;

    if (s.failBeforeFirstByte) {
      const { status, body: fb } = s.failBeforeFirstByte;
      const errBody =
        fb ??
        (isMessages
          ? { type: "error", error: { type: status === 429 ? "rate_limit_error" : "api_error", message: `mock failure ${status}` } }
          : { error: { message: `mock failure ${status}`, type: status === 429 ? "rate_limit_error" : "server_error", code: null } });
      json(res, status, errBody);
      rec.finishedAt = Date.now();
      return;
    }

    const pieces = splitText(s.text, s.chunkCount);
    const toolCall = s.toolCall;
    const toolArgs = toolCall ? JSON.stringify(toolCall.arguments) : "";

    // ── OpenAI Chat Completions ──────────────────────────────────────────
    if (isChat) {
      const id = `chatcmpl-${rec.id.slice(0, 8)}`;
      const created = Math.floor(Date.now() / 1000);
      const finish = toolCall ? "tool_calls" : "stop";

      if (!rec.stream) {
        const message: Record<string, unknown> = { role: "assistant", content: toolCall ? null : s.text };
        if (s.reasoning) message.reasoning_content = s.reasoning;
        if (toolCall) {
          message.tool_calls = [{ id: "call_mock1", type: "function", function: { name: toolCall.name, arguments: toolArgs } }];
        }
        const out: Record<string, unknown> = {
          id,
          object: "chat.completion",
          created,
          model: modelId,
          choices: [{ index: 0, message, finish_reason: finish }],
        };
        if (!s.omitUsage) out.usage = usage;
        json(res, 200, out);
        rec.finishedAt = Date.now();
        return;
      }

      res.writeHead(200, { "content-type": "text/event-stream", "cache-control": "no-cache" });
      const chunk = (delta: Record<string, unknown>, finishReason: string | null = null) =>
        sse(res, null, { id, object: "chat.completion.chunk", created, model: modelId, choices: [{ index: 0, delta, finish_reason: finishReason }] });

      chunk({ role: "assistant", content: "" });
      if (s.reasoning) {
        for (const p of splitText(s.reasoning, 2)) {
          chunk({ reasoning_content: p });
          rec.chunksSent++;
          if (s.chunkDelayMs) await sleep(s.chunkDelayMs);
        }
      }
      let failed = false;
      for (const [i, p] of (toolCall ? [] : pieces).entries()) {
        if (rec.cancelled) return;
        if (s.failAfterChunks !== undefined && i >= s.failAfterChunks) {
          failed = true;
          break;
        }
        chunk({ content: p });
        rec.chunksSent++;
        if (s.chunkDelayMs) await sleep(s.chunkDelayMs);
      }
      if (toolCall && !failed) {
        chunk({ tool_calls: [{ index: 0, id: "call_mock1", type: "function", function: { name: toolCall.name, arguments: "" } }] });
        for (const p of splitText(toolArgs, 2)) {
          chunk({ tool_calls: [{ index: 0, function: { arguments: p } }] });
          rec.chunksSent++;
          if (s.chunkDelayMs) await sleep(s.chunkDelayMs);
        }
      }
      if (failed) {
        if (s.failAfterMode === "socket_close") {
          res.destroy();
        } else {
          sse(res, null, { error: { message: "mock mid-stream failure", type: "server_error", code: null } });
          res.end();
        }
        rec.finishedAt = Date.now();
        return;
      }
      chunk({}, finish);
      const includeUsage = (body.stream_options as { include_usage?: boolean } | undefined)?.include_usage !== false;
      if (!s.omitUsage && includeUsage) {
        sse(res, null, { id, object: "chat.completion.chunk", created, model: modelId, choices: [], usage });
      }
      res.write("data: [DONE]\n\n");
      res.end();
      rec.finishedAt = Date.now();
      return;
    }

    // ── Anthropic Messages ───────────────────────────────────────────────
    const msgId = `msg_${rec.id.replace(/-/g, "").slice(0, 24)}`;
    const aUsage = usageFor("anthropic", s.usage ?? {}) as { input_tokens: number; output_tokens: number; cache_creation_input_tokens: number; cache_read_input_tokens: number };
    const stopReason = toolCall ? "tool_use" : "end_turn";

    if (!rec.stream) {
      const content: unknown[] = [];
      if (s.reasoning) content.push({ type: "thinking", thinking: s.reasoning, signature: "mock" });
      if (!toolCall) content.push({ type: "text", text: s.text });
      if (toolCall) content.push({ type: "tool_use", id: "toolu_mock1", name: toolCall.name, input: toolCall.arguments });
      json(res, 200, { id: msgId, type: "message", role: "assistant", model: modelId, content, stop_reason: stopReason, stop_sequence: null, usage: aUsage });
      rec.finishedAt = Date.now();
      return;
    }

    res.writeHead(200, { "content-type": "text/event-stream", "cache-control": "no-cache" });
    sse(res, "message_start", {
      type: "message_start",
      message: { id: msgId, type: "message", role: "assistant", model: modelId, content: [], stop_reason: null, stop_sequence: null, usage: { ...aUsage, output_tokens: 1 } },
    });
    let index = 0;
    if (s.reasoning) {
      sse(res, "content_block_start", { type: "content_block_start", index, content_block: { type: "thinking", thinking: "" } });
      for (const p of splitText(s.reasoning, 2)) {
        sse(res, "content_block_delta", { type: "content_block_delta", index, delta: { type: "thinking_delta", thinking: p } });
        rec.chunksSent++;
        if (s.chunkDelayMs) await sleep(s.chunkDelayMs);
      }
      sse(res, "content_block_stop", { type: "content_block_stop", index });
      index++;
    }
    let failed = false;
    if (!toolCall) {
      sse(res, "content_block_start", { type: "content_block_start", index, content_block: { type: "text", text: "" } });
      for (const [i, p] of pieces.entries()) {
        if (rec.cancelled) return;
        if (s.failAfterChunks !== undefined && i >= s.failAfterChunks) {
          failed = true;
          break;
        }
        sse(res, "content_block_delta", { type: "content_block_delta", index, delta: { type: "text_delta", text: p } });
        rec.chunksSent++;
        if (s.chunkDelayMs) await sleep(s.chunkDelayMs);
      }
      if (!failed) sse(res, "content_block_stop", { type: "content_block_stop", index });
      index++;
    } else {
      sse(res, "content_block_start", { type: "content_block_start", index, content_block: { type: "tool_use", id: "toolu_mock1", name: toolCall.name, input: {} } });
      for (const p of splitText(toolArgs, 2)) {
        sse(res, "content_block_delta", { type: "content_block_delta", index, delta: { type: "input_json_delta", partial_json: p } });
        rec.chunksSent++;
        if (s.chunkDelayMs) await sleep(s.chunkDelayMs);
      }
      sse(res, "content_block_stop", { type: "content_block_stop", index });
      index++;
    }
    if (failed) {
      if (s.failAfterMode === "socket_close") res.destroy();
      else {
        sse(res, "error", { type: "error", error: { type: "overloaded_error", message: "mock mid-stream failure" } });
        res.end();
      }
      rec.finishedAt = Date.now();
      return;
    }
    sse(res, "message_delta", {
      type: "message_delta",
      delta: { stop_reason: stopReason, stop_sequence: null },
      ...(s.omitUsage ? {} : { usage: { output_tokens: aUsage.output_tokens } }),
    });
    sse(res, "message_stop", { type: "message_stop" });
    res.end();
    rec.finishedAt = Date.now();
  };

  const server = createServer((req, res) => {
    handle(req, res).catch((e) => {
      if (!res.headersSent) json(res, 500, { error: { message: String(e) } });
      else res.destroy();
    });
  });

  await new Promise<void>((resolve) => server.listen(opts.port ?? 0, opts.host ?? "127.0.0.1", resolve));
  const { port } = server.address() as AddressInfo;
  const url = `http://${opts.host ?? "127.0.0.1"}:${port}`;

  return {
    url,
    port,
    server,
    setScenario: (s) => {
      scenario = s;
    },
    scenario: () => scenario,
    requests,
    lastRequest: () => requests[requests.length - 1],
    waitForCancel: ({ id, timeoutMs = 5_000 } = {}) => {
      const existing = requests.find((r) => (id ? r.id === id : true) && r.cancelled);
      if (existing) return Promise.resolve(existing);
      return new Promise<RequestRecord>((resolve, reject) => {
        const timer = setTimeout(() => reject(new Error(`No cancellation observed within ${timeoutMs} ms`)), timeoutMs);
        cancelWaiters.push({
          id,
          resolve: (r) => {
            clearTimeout(timer);
            resolve(r);
          },
        });
      });
    },
    reset: () => {
      scenario = {};
      requests.length = 0;
    },
    close: () =>
      new Promise<void>((resolve, reject) => {
        server.closeAllConnections?.();
        server.close((e) => (e ? reject(e) : resolve()));
      }),
  };
}
