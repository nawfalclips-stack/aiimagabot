import { describe, expect, it } from "vitest";
import { sessionPredatesPasswordChange } from "@/lib/admin-password";

describe("admin sessions after a password change", () => {
  const changedAt = new Date("2026-09-27T10:00:00.400Z"); // 10:00:00 in whole seconds
  const at = (iso: string) => Math.floor(new Date(iso).getTime() / 1000);

  it("keeps every session when the password never changed", () => {
    expect(sessionPredatesPasswordChange(at("2026-01-01T00:00:00Z"), null)).toBe(false);
  });

  it("signs out sessions issued before the change", () => {
    expect(sessionPredatesPasswordChange(at("2026-09-27T09:59:59Z"), changedAt)).toBe(true);
  });

  it("keeps the session re-issued right after the change (same second, iat precision)", () => {
    expect(sessionPredatesPasswordChange(at("2026-09-27T10:00:00.900Z"), changedAt)).toBe(false);
    expect(sessionPredatesPasswordChange(at("2026-09-27T10:05:00Z"), changedAt)).toBe(false);
  });

  it("rejects a session without an issue time once a change exists", () => {
    expect(sessionPredatesPasswordChange(undefined, changedAt)).toBe(true);
  });
});
