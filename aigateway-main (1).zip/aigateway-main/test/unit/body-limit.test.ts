import { afterEach, describe, expect, it } from "vitest";
import { maxBodyBytes, PLATFORM_BODY_LIMIT_BYTES, readBodyText, readJsonBody } from "@/lib/gateway/body";
import { errorResponse, GatewayError } from "@/lib/gateway/errors";

// WS12.1: the body cap is enforced from Content-Length and while reading.
function streamOf(parts: string[], headers: Record<string, string> = {}): Request {
  const enc = new TextEncoder();
  const body = new ReadableStream<Uint8Array>({
    start(c) {
      for (const p of parts) c.enqueue(enc.encode(p));
      c.close();
    },
  });
  return new Request("http://gateway.test/v1/chat/completions", { method: "POST", body, headers, duplex: "half" } as RequestInit);
}

describe("request body limit (WS12.1)", () => {
  const env = { ...process.env };
  afterEach(() => {
    process.env = { ...env };
  });

  it("defaults to 4 MB and never exceeds the platform limit", () => {
    delete process.env.GATEWAY_MAX_BODY_BYTES;
    expect(maxBodyBytes()).toBe(4_000_000);
    process.env.GATEWAY_MAX_BODY_BYTES = "99999999";
    expect(maxBodyBytes()).toBe(PLATFORM_BODY_LIMIT_BYTES);
    process.env.GATEWAY_MAX_BODY_BYTES = "nonsense";
    expect(maxBodyBytes()).toBe(4_000_000);
  });

  it("refuses from Content-Length before reading anything", async () => {
    const req = streamOf(["{}"], { "content-length": "5000000" });
    await expect(readBodyText(req, 4_000_000)).rejects.toMatchObject({ status: 413 });
  });

  it("refuses while streaming when the declared length lies or is missing", async () => {
    const req = streamOf(["x".repeat(600), "y".repeat(600)]);
    const err = await readBodyText(req, 1000).catch((e) => e as GatewayError);
    expect(err).toBeInstanceOf(GatewayError);
    expect((err as GatewayError).status).toBe(413);
  });

  it("reads a body under the limit across chunks and parses JSON", async () => {
    const req = streamOf(['{"model":"m",', '"messages":[]}']);
    expect(await readJsonBody(req, 1000)).toEqual({ model: "m", messages: [] });
  });

  it("rejects non-object JSON with 400", async () => {
    await expect(readJsonBody(streamOf(["[1,2]"]), 1000)).rejects.toMatchObject({ status: 400 });
    await expect(readJsonBody(streamOf(["not json"]), 1000)).rejects.toMatchObject({ status: 400 });
  });

  it("413 is wire-shaped with advice", async () => {
    const err = (await readBodyText(streamOf(["z".repeat(20)]), 10).catch((e) => e)) as GatewayError;
    const openai = await errorResponse("openai", err, "req_x").json();
    expect(openai.error.type).toBe("invalid_request_error");
    expect(openai.error.message).toMatch(/Shorten the conversation history/);
    const res = errorResponse("anthropic", err, "req_x");
    const anthropic = await res.json();
    expect(anthropic.type).toBe("error");
    expect(anthropic.request_id).toBe("req_x");
    expect(res.headers.get("x-request-id")).toBe("req_x");
    expect(res.headers.get("cache-control")).toBe("no-store, no-transform");
  });
});
