import { afterEach, describe, expect, it, vi } from "vitest";
import { createTtlCache, ttlFromEnv } from "@/lib/ttl-cache";
import { retentionCutoffs } from "@/lib/services/retention";

describe("ttl cache", () => {
  afterEach(() => vi.useRealTimers());

  it("serves a hit within the TTL and reloads after it", async () => {
    vi.useFakeTimers();
    const cache = createTtlCache<string, number>(10_000);
    let loads = 0;
    const load = async () => ++loads;
    expect(await cache.get("a", load)).toBe(1);
    expect(await cache.get("a", load)).toBe(1);
    vi.advanceTimersByTime(10_001);
    expect(await cache.get("a", load)).toBe(2);
  });

  it("shares one load between concurrent misses", async () => {
    const cache = createTtlCache<string, number>(10_000);
    let loads = 0;
    const load = () => new Promise<number>((r) => setTimeout(() => r(++loads), 5));
    const [a, b] = await Promise.all([cache.get("k", load), cache.get("k", load)]);
    expect([a, b, loads]).toEqual([1, 1, 1]);
  });

  it("invalidate() forces the next read to load", async () => {
    const cache = createTtlCache<string, number>(10_000);
    let loads = 0;
    const load = async () => ++loads;
    await cache.get("a", load);
    cache.invalidate("a");
    expect(await cache.get("a", load)).toBe(2);
    cache.invalidate();
    expect(await cache.get("a", load)).toBe(3);
  });

  it("never caches a failed load", async () => {
    const cache = createTtlCache<string, number>(10_000);
    await expect(cache.get("a", async () => Promise.reject(new Error("db down")))).rejects.toThrow("db down");
    expect(await cache.get("a", async () => 7)).toBe(7);
  });

  it("TTL 0 disables caching", async () => {
    const cache = createTtlCache<string, number>(0);
    let loads = 0;
    await cache.get("a", async () => ++loads);
    await cache.get("a", async () => ++loads);
    expect(loads).toBe(2);
  });

  it("is off under Vitest unless the env var is set explicitly", () => {
    expect(ttlFromEnv("SOME_UNSET_CACHE_TTL", 10_000)).toBe(0);
    process.env.SOME_SET_CACHE_TTL = "2500";
    expect(ttlFromEnv("SOME_SET_CACHE_TTL", 10_000)).toBe(2500);
    delete process.env.SOME_SET_CACHE_TTL;
  });
});

describe("retention cut-offs", () => {
  it("keeps reservations 30 days and raw usage 90 days by default", () => {
    const now = new Date("2026-09-26T05:00:00Z");
    const c = retentionCutoffs(now, { reservationDays: 30, rawUsageDays: 90 });
    expect(c.reservationsBefore.toISOString()).toBe("2026-08-27T05:00:00.000Z");
    expect(c.rawUsageBefore.toISOString()).toBe("2026-06-28T05:00:00.000Z");
  });
});
