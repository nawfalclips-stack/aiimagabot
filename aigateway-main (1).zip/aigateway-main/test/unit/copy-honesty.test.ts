import { readFileSync, readdirSync, statSync } from "node:fs";
import { join, relative, sep } from "node:path";
import { describe, expect, it } from "vitest";
import { renderDocForCustomer } from "@/lib/services/documentation";
import { findProviderKeys } from "../helpers/provider-key-patterns";

/**
 * WS7 / WS10 guards over the source tree:
 *  - seeded guides point at this site's gateway, not the legacy proxies;
 *  - customer-facing code never reads an upstream key except the one
 *    dashboard read that is gated on LEGACY_API_POOL_MODE=active;
 *  - no fabricated usage generator comes back.
 */
const DOCS_DIR = "prisma/docs";
const LEGACY_MARKERS = ["capi.aerolink.lat", "cgapi.aerolink.lat", "already assigned to you", "FreeModel", "wire_api = \"responses\""];
/** Model names the old guides and usage synthesiser invented. */
const INVENTED_MODELS = [/gpt-5\.6/i, /claude-fable/i, /Claude Opus 5\b/, /Claude Sonnet 4\.6/];

const CUSTOMER_ROOTS = ["app/portal", "components/portal", "app/activate", "app/redeem", "app/new", "components/landing"];
/** Files allowed to read an upstream key for the customer (each gated on the pool mode). */
const KEY_READ_ALLOWLIST = new Set(["app/portal/page.tsx"]);

function* walk(path: string): Generator<string> {
  const st = statSync(path, { throwIfNoEntry: false });
  if (!st) return;
  if (st.isFile()) {
    if (/\.(ts|tsx|md)$/.test(path)) yield path;
    return;
  }
  for (const entry of readdirSync(path)) {
    if (entry === "node_modules" || entry === ".next") continue;
    yield* walk(join(path, entry));
  }
}
const rel = (p: string) => relative(process.cwd(), p).split(sep).join("/");

describe("seeded documentation (WS7, decision #13)", () => {
  const docs = [...walk(DOCS_DIR)].filter((f) => f.endsWith(".md") && !rel(f).includes("/fixtures/"));

  it("finds every seeded guide", () => {
    // 7 guides (Claude Code, Claude Desktop, Codex, OpenCode, More agents, Skills, API & SDKs) × 3 OSes.
    expect(docs.length).toBe(21);
  });

  it.each(docs.map((d) => [rel(d)]))("%s points at the gateway only", (file) => {
    const text = readFileSync(file, "utf8");
    for (const marker of LEGACY_MARKERS) expect(text, marker).not.toContain(marker);
    for (const re of INVENTED_MODELS) expect(text).not.toMatch(re);
    expect(text).toContain("{{BASE_URL}}");
    expect(text).toContain("API Access");
    expect(findProviderKeys(text)).toEqual([]);
  });

  it("renders placeholders for a customer and leaves the token placeholder literal", () => {
    const out = renderDocForCustomer("url={{BASE_URL}}/v1 model={{MODEL}} key=YOUR_AEROLINK_API_KEY", {
      baseUrl: "https://aerolink.example",
      model: "deepseek-v3",
    });
    expect(out).toBe("url=https://aerolink.example/v1 model=deepseek-v3 key=YOUR_AEROLINK_API_KEY");
    expect(renderDocForCustomer("{{MODEL}}", { baseUrl: "", model: null })).toBe("MODEL_ID");
  });
});

describe("customer-facing code (WS10)", () => {
  const files = CUSTOMER_ROOTS.flatMap((r) => [...walk(r)]).map(rel);

  it("never touches the legacy pool table", () => {
    const offenders = files.filter((f) => /apiPoolKey/.test(readFileSync(f, "utf8")));
    expect(offenders).toEqual([]);
  });

  it("reads a customer's upstream key only from the allowlisted, mode-gated file", () => {
    const offenders = files.filter((f) => /prisma\.apiKey\.|apiKey:\s*true|include:\s*\{[^}]*apiKey/.test(readFileSync(f, "utf8")) && !KEY_READ_ALLOWLIST.has(f));
    expect(offenders).toEqual([]);
    const dashboard = readFileSync("app/portal/page.tsx", "utf8");
    expect(dashboard).toMatch(/select:\s*\{[^}]*\bkey:\s*poolActive\s*\}/);
  });

  it("carries no legacy proxy URLs", () => {
    const all = [...CUSTOMER_ROOTS, "lib"].flatMap((r) => [...walk(r)]);
    const offenders = all.filter((f) => /c?g?api\.aerolink\.lat/.test(readFileSync(f, "utf8"))).map(rel);
    expect(offenders).toEqual([]);
  });

  it("has no usage synthesiser any more", () => {
    expect(statSync("lib/usage-synth.ts", { throwIfNoEntry: false })).toBeUndefined();
    const all = ["lib", "app", "components"].flatMap((r) => [...walk(r)]);
    expect(all.filter((f) => /usage-synth|synthesizeUsage/.test(readFileSync(f, "utf8"))).map(rel)).toEqual([]);
  });
});
