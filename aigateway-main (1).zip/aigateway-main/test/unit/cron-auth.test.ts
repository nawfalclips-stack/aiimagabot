import { readdirSync, readFileSync, statSync } from "node:fs";
import { join } from "node:path";
import { afterEach, describe, expect, it } from "vitest";
import { isCronAuthorized } from "@/lib/cron-auth";

// WS12.7: every cron and diagnostic route checks the bearer secret through
// one helper, and the helper itself is strict.
function routeFiles(dir: string): string[] {
  const out: string[] = [];
  for (const name of readdirSync(dir)) {
    const p = join(dir, name);
    if (statSync(p).isDirectory()) out.push(...routeFiles(p));
    else if (name === "route.ts") out.push(p);
  }
  return out;
}

describe("cron authorization (WS12.7)", () => {
  const env = { ...process.env };
  afterEach(() => {
    process.env = { ...env };
  });

  const req = (auth?: string) => new Request("http://x/api/cron/y", { headers: auth ? { authorization: auth } : {} });

  it("accepts only the exact bearer secret", () => {
    process.env.CRON_SECRET = "s3cret";
    expect(isCronAuthorized(req("Bearer s3cret"))).toBe(true);
    expect(isCronAuthorized(req("bearer s3cret"))).toBe(true);
    expect(isCronAuthorized(req("Bearer s3cre"))).toBe(false);
    expect(isCronAuthorized(req("Bearer s3cret2"))).toBe(false);
    expect(isCronAuthorized(req("s3cret"))).toBe(false);
    expect(isCronAuthorized(req())).toBe(false);
  });

  it("denies everything when CRON_SECRET is unset", () => {
    delete process.env.CRON_SECRET;
    expect(isCronAuthorized(req("Bearer "))).toBe(false);
    expect(isCronAuthorized(req("Bearer undefined"))).toBe(false);
  });

  it("every /api/cron and /api/diag route uses isCronAuthorized", () => {
    const files = [...routeFiles("app/api/cron"), ...routeFiles("app/api/diag")];
    expect(files.length).toBeGreaterThanOrEqual(4);
    for (const f of files) {
      const src = readFileSync(f, "utf8");
      expect(src, f).toMatch(/isCronAuthorized\(request\)/);
      expect(src, f).not.toMatch(/process\.env\.CRON_SECRET/);
    }
  });
});
