import { afterEach, beforeEach, describe, expect, it, vi } from "vitest";

// WS12.4: versioned ciphertexts. v1 = SESSION_SECRET-derived (decrypt only),
// v2 = PROVIDER_KEY_SECRET (encrypt + decrypt).
const SESSION = "session-secret-session-secret-session-secret";
const KEY = Buffer.alloc(32, 7).toString("base64");

async function crypto() {
  vi.resetModules();
  const m = await import("@/lib/gateway/crypto");
  m._resetCryptoWarningForTests();
  return m;
}

describe("provider-key crypto (WS12.4)", () => {
  const env = { ...process.env };
  beforeEach(() => {
    process.env.SESSION_SECRET = SESSION;
    delete process.env.PROVIDER_KEY_SECRET;
  });
  afterEach(() => {
    process.env = { ...env };
    vi.restoreAllMocks();
  });

  it("without PROVIDER_KEY_SECRET encrypts v1 and warns once", async () => {
    const warn = vi.spyOn(console, "warn").mockImplementation(() => undefined);
    const c = await crypto();
    const a = await c.encryptSecret("sk-one");
    const b = await c.encryptSecret("sk-two");
    expect(c.cipherVersion(a)).toBe("v1");
    expect(await c.decryptSecret(a)).toBe("sk-one");
    expect(await c.decryptSecret(b)).toBe("sk-two");
    expect(warn).toHaveBeenCalledTimes(1);
  });

  it("with PROVIDER_KEY_SECRET encrypts v2 and still decrypts v1", async () => {
    const c1 = await crypto();
    const v1 = await c1.encryptSecret("sk-legacy");
    process.env.PROVIDER_KEY_SECRET = KEY;
    const c2 = await crypto();
    const v2 = await c2.encryptSecret("sk-new");
    expect(c2.cipherVersion(v2)).toBe("v2");
    expect(await c2.decryptSecret(v2)).toBe("sk-new");
    expect(await c2.decryptSecret(v1)).toBe("sk-legacy");
    expect(c2.keySecretConfigured()).toBe(true);
  });

  it("v2 does not depend on SESSION_SECRET", async () => {
    process.env.PROVIDER_KEY_SECRET = KEY;
    const c = await crypto();
    const v2 = await c.encryptSecret("sk-independent");
    process.env.SESSION_SECRET = "rotated-rotated-rotated-rotated";
    const c2 = await crypto();
    expect(await c2.decryptSecret(v2)).toBe("sk-independent");
  });

  it("reencryptSecret migrates v1 and plaintext rows and skips v2", async () => {
    const c1 = await crypto();
    const v1 = await c1.encryptSecret("sk-legacy");
    process.env.PROVIDER_KEY_SECRET = KEY;
    const c = await crypto();
    const migrated = await c.reencryptSecret(v1);
    expect(migrated && c.cipherVersion(migrated)).toBe("v2");
    expect(await c.decryptSecret(migrated!)).toBe("sk-legacy");
    const fromPlain = await c.reencryptSecret("plain-key");
    expect(fromPlain && c.cipherVersion(fromPlain)).toBe("v2");
    expect(await c.reencryptSecret(migrated!)).toBeNull();
    expect(await c.reencryptSecret("")).toBeNull();
  });

  it("rejects a PROVIDER_KEY_SECRET that is not 32 bytes", async () => {
    process.env.PROVIDER_KEY_SECRET = Buffer.alloc(16, 1).toString("base64");
    const c = await crypto();
    await expect(c.encryptSecret("x")).rejects.toThrow(/32 random bytes/);
  });

  it("tolerates legacy plaintext rows on decrypt", async () => {
    const c = await crypto();
    expect(await c.decryptSecret("mock-key")).toBe("mock-key");
    expect(c.cipherVersion("mock-key")).toBe("plain");
  });
});
