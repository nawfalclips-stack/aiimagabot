import { describe, expect, it } from "vitest";
import { applyEnvAliases } from "@/lib/env-aliases.mjs";

describe("Vercel integration variable names", () => {
  it("maps Supabase and Upstash integration variables, adding the pooler parameters", () => {
    const env: Record<string, string | undefined> = {
      POSTGRES_PRISMA_URL: "postgres://u:p@aws-0-us-west-1.pooler.supabase.com:6543/postgres?sslmode=require&pgbouncer=true",
      POSTGRES_URL_NON_POOLING: "postgres://u:p@aws-0-us-west-1.pooler.supabase.com:5432/postgres?sslmode=require",
      KV_REST_API_URL: "https://eu1-x.upstash.io",
      KV_REST_API_TOKEN: "tok",
    };
    expect(applyEnvAliases(env)).toEqual(["DATABASE_URL", "DIRECT_URL", "UPSTASH_REDIS_REST_URL", "UPSTASH_REDIS_REST_TOKEN"]);
    const db = new URL(env.DATABASE_URL!);
    expect(db.port).toBe("6543");
    expect(db.searchParams.get("pgbouncer")).toBe("true");
    expect(db.searchParams.get("connection_limit")).toBe("1");
    expect(db.searchParams.get("sslmode")).toBe("require");
    expect(env.DIRECT_URL).toBe(env.POSTGRES_URL_NON_POOLING);
    expect(env.UPSTASH_REDIS_REST_TOKEN).toBe("tok");
  });

  it("never overrides a variable the app already has", () => {
    const env: Record<string, string | undefined> = { DATABASE_URL: "file:./dev.db", POSTGRES_PRISMA_URL: "postgres://x:y@h:6543/db" };
    expect(applyEnvAliases(env)).toEqual([]);
    expect(env.DATABASE_URL).toBe("file:./dev.db");
  });

  it("keeps an existing connection_limit", () => {
    const env: Record<string, string | undefined> = { POSTGRES_PRISMA_URL: "postgres://x:y@h:6543/db?pgbouncer=true&connection_limit=3" };
    applyEnvAliases(env);
    expect(new URL(env.DATABASE_URL!).searchParams.get("connection_limit")).toBe("3");
  });
});
