import { afterEach, describe, expect, it } from "vitest";
import { legacyPoolMode, maskKey, poolAssignmentsEnabled, redactKeys } from "@/lib/services/legacy-pool";
import { findProviderKeys, SAMPLE_PROVIDER_KEYS } from "../helpers/provider-key-patterns";

describe("LEGACY_API_POOL_MODE (WS10)", () => {
  const original = process.env.LEGACY_API_POOL_MODE;
  afterEach(() => {
    if (original === undefined) delete process.env.LEGACY_API_POOL_MODE;
    else process.env.LEGACY_API_POOL_MODE = original;
  });

  it("defaults to readonly, and anything unknown is readonly", () => {
    delete process.env.LEGACY_API_POOL_MODE;
    expect(legacyPoolMode()).toBe("readonly");
    process.env.LEGACY_API_POOL_MODE = "yes please";
    expect(legacyPoolMode()).toBe("readonly");
    expect(poolAssignmentsEnabled()).toBe(false);
  });

  it("recognises active and off, case-insensitively", () => {
    process.env.LEGACY_API_POOL_MODE = "ACTIVE";
    expect(legacyPoolMode()).toBe("active");
    expect(poolAssignmentsEnabled()).toBe(true);
    process.env.LEGACY_API_POOL_MODE = "off";
    expect(legacyPoolMode()).toBe("off");
    expect(poolAssignmentsEnabled()).toBe(false);
  });
});

describe("maskKey", () => {
  it("keeps a short prefix and the last 4 characters only", () => {
    expect(maskKey("sk-abcdefghijklmnopqrstuvwxyz1234")).toBe("sk-…1234");
    expect(maskKey("aero_live_E7OMTW3xKpqZ9876")).toBe("…9876");
  });

  it("reveals nothing for short or empty values", () => {
    expect(maskKey("abcd1234")).toBe("…");
    expect(maskKey("")).toBe("");
    expect(maskKey(null)).toBe("");
  });

  it("never produces something that still looks like a provider key", () => {
    for (const key of Object.values(SAMPLE_PROVIDER_KEYS)) {
      expect(findProviderKeys(key)).not.toEqual([]); // the sample itself is detected…
      expect(findProviderKeys(maskKey(key))).toEqual([]); // …its mask is not
    }
  });
});

describe("redactKeys", () => {
  it("masks every key shape inside free text outside active mode", () => {
    delete process.env.LEGACY_API_POOL_MODE;
    const text = `label ${Object.values(SAMPLE_PROVIDER_KEYS).join(" / ")} end`;
    const out = redactKeys(text);
    expect(findProviderKeys(out)).toEqual([]);
    expect(out.startsWith("label ")).toBe(true);
    expect(out.endsWith(" end")).toBe(true);
    expect(redactKeys("Laptop · Claude Code")).toBe("Laptop · Claude Code");
  });
});
