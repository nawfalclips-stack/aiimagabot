import { afterEach, beforeAll, beforeEach, describe, expect, it, vi } from "vitest";

// In-process fallbacks (REDIS_DISABLED=true): same semantics as the Redis
// path, per instance. The shared-state behaviour is covered by the
// integration tests against the Redis container.
beforeAll(() => {
  process.env.REDIS_DISABLED = "true";
  process.env.GATEWAY_RATE_LIMITS = "true";
});

describe("rate limit (memory fallback)", () => {
  beforeEach(async () => (await import("@/lib/gateway/limits"))._resetLimitsForTests());
  afterEach(() => vi.useRealTimers());

  it("allows `limit` hits per window and refuses the next with a Retry-After", async () => {
    vi.useFakeTimers();
    const { checkGatewayRpm } = await import("@/lib/gateway/limits");
    const p = { tokenId: "t1", customerId: "c1", rpm: 3 };
    for (let i = 0; i < 3; i++) expect((await checkGatewayRpm(p)).ok).toBe(true);
    const refused = await checkGatewayRpm(p);
    expect(refused.ok).toBe(false);
    expect(refused.retryAfterSeconds).toBeGreaterThanOrEqual(1);
    expect(refused.scope).toBe("token");
    vi.advanceTimersByTime(61_000);
    expect((await checkGatewayRpm(p)).ok).toBe(true);
  });

  it("applies the customer limit across tokens", async () => {
    const { checkGatewayRpm } = await import("@/lib/gateway/limits");
    expect((await checkGatewayRpm({ tokenId: "a", customerId: "shared", rpm: 2 })).ok).toBe(true);
    expect((await checkGatewayRpm({ tokenId: "b", customerId: "shared", rpm: 2 })).ok).toBe(true);
    const r = await checkGatewayRpm({ tokenId: "c", customerId: "shared", rpm: 2 });
    expect(r.ok).toBe(false);
    expect(r.scope).toBe("customer");
  });
});

describe("concurrency lease (memory fallback)", () => {
  beforeEach(async () => (await import("@/lib/gateway/limits"))._resetLimitsForTests());
  afterEach(() => vi.useRealTimers());

  it("caps per customer, then per store, and frees on release", async () => {
    const { acquireLease, releaseLease, activeLeases } = await import("@/lib/gateway/limits");
    const base = { customerId: "c1", storeId: "s1", maxConcurrent: 2, storeCeiling: 3, ttlMs: 60_000 };
    expect((await acquireLease({ ...base, requestId: "r1" })).ok).toBe(true);
    expect((await acquireLease({ ...base, requestId: "r2" })).ok).toBe(true);
    const third = await acquireLease({ ...base, requestId: "r3" });
    expect(third.ok).toBe(false);
    if (!third.ok) expect(third.scope).toBe("customer");
    // another customer hits the store ceiling
    expect((await acquireLease({ ...base, customerId: "c2", requestId: "r4" })).ok).toBe(true);
    const ceiling = await acquireLease({ ...base, customerId: "c3", requestId: "r5" });
    expect(ceiling.ok).toBe(false);
    if (!ceiling.ok) expect(ceiling.scope).toBe("store");
    await releaseLease({ requestId: "r1", customerId: "c1", storeId: "s1" });
    expect(await activeLeases({ customerId: "c1" })).toBe(1);
    expect((await acquireLease({ ...base, requestId: "r6" })).ok).toBe(true);
  });

  it("expires leases from killed requests on their own", async () => {
    vi.useFakeTimers();
    const { acquireLease } = await import("@/lib/gateway/limits");
    const base = { customerId: "c1", storeId: "s1", maxConcurrent: 1, storeCeiling: 10, ttlMs: 1_000 };
    expect((await acquireLease({ ...base, requestId: "dead" })).ok).toBe(true);
    expect((await acquireLease({ ...base, requestId: "next" })).ok).toBe(false);
    vi.advanceTimersByTime(1_500);
    expect((await acquireLease({ ...base, requestId: "next" })).ok).toBe(true);
  });
});

describe("circuit breaker (memory fallback)", () => {
  beforeEach(async () => (await import("@/lib/gateway/breaker"))._resetBreakersForTests());
  afterEach(() => vi.useRealTimers());

  it("opens after the threshold, allows exactly one probe, closes on success", async () => {
    vi.useFakeTimers();
    const { breakerState, recordFailure, recordSuccess } = await import("@/lib/gateway/breaker");
    const cfg = { failureThreshold: 3, windowMs: 60_000, openMs: 10_000 };
    expect(await recordFailure("pm1", cfg)).toBe("counted");
    expect(await recordFailure("pm1", cfg)).toBe("counted");
    expect(await recordFailure("pm1", cfg)).toBe("tripped");
    expect(await breakerState("pm1")).toBe("half-open"); // first caller gets the probe
    expect(await breakerState("pm1")).toBe("open");
    vi.advanceTimersByTime(10_500);
    expect(await breakerState("pm1")).toBe("closed");
    expect(await recordFailure("pm1", cfg)).toBe("counted");
    await recordSuccess("pm1");
    expect(await recordFailure("pm1", cfg)).toBe("counted"); // window reset by the success
  });

  it("forgets failures outside the window", async () => {
    vi.useFakeTimers();
    const { recordFailure } = await import("@/lib/gateway/breaker");
    const cfg = { failureThreshold: 2, windowMs: 1_000, openMs: 1_000 };
    expect(await recordFailure("pm2", cfg)).toBe("counted");
    vi.advanceTimersByTime(1_500);
    expect(await recordFailure("pm2", cfg)).toBe("counted");
  });
});
