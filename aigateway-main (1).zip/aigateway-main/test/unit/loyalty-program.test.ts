import { describe, expect, it } from "vitest";
import {
  DEFAULT_LOYALTY_PROGRAM,
  canRequestReward,
  firstRewardTier,
  getNextTier,
  getTierForPoints,
  loyaltyProgramFromSetting,
  parseLoyaltyProgram,
  pointsForPurchase,
  tierIdFromName,
  type LoyaltyProgram,
} from "@/lib/loyalty";

describe("default loyalty program (unchanged behaviour)", () => {
  it("earns the same points as before", () => {
    expect(pointsForPurchase(5_000).totalPoints).toBe(25); // below $100
    expect(pointsForPurchase(10_000).totalPoints).toBe(35);
    expect(pointsForPurchase(62_000)).toEqual({ basePoints: 100, extraPoints: 18, totalPoints: 118 }); // $620
    expect(pointsForPurchase(100_000).totalPoints).toBe(250);
    expect(pointsForPurchase(0).totalPoints).toBe(0);
  });

  it("keeps the same levels and reward rule", () => {
    expect(getTierForPoints(599).id).toBe("bronze");
    expect(getTierForPoints(600).id).toBe("silver");
    expect(getTierForPoints(1500).id).toBe("vip");
    expect(canRequestReward(599)).toBe(false);
    expect(canRequestReward(600)).toBe(true); // Silver — as the old 600-point rule
    expect(firstRewardTier()?.id).toBe("silver");
    expect(getNextTier(1600)).toBeNull();
  });
});

describe("custom loyalty program", () => {
  const custom: LoyaltyProgram = {
    basePoints: 10,
    overflowPercent: 50,
    brackets: [
      { minCents: 5_000, points: 20 },
      { minCents: 20_000, points: 100 },
    ],
    tiers: [
      { id: "pro", name: "Pro", minPoints: 300, rewardAmountCents: 0, colorHex: "#0ea5e9" },
      { id: "start", name: "Start", minPoints: 0, rewardAmountCents: 0, colorHex: "#64748b" },
      { id: "elite", name: "Elite", minPoints: 900, rewardAmountCents: 5_000, colorHex: "#a855f7" },
    ],
  };

  it("sorts brackets and levels whatever the input order", () => {
    const p = parseLoyaltyProgram(custom);
    expect(p.brackets.map((b) => b.minCents)).toEqual([20_000, 5_000]);
    expect(p.tiers.map((t) => t.id)).toEqual(["start", "pro", "elite"]);
  });

  it("computes points and levels from the store's program", () => {
    expect(pointsForPurchase(4_000, custom).totalPoints).toBe(10);
    expect(pointsForPurchase(30_000, custom)).toEqual({ basePoints: 100, extraPoints: 50, totalPoints: 150 }); // $100 above × 0.5
    expect(getTierForPoints(450, custom.tiers).id).toBe("pro");
    expect(canRequestReward(450, custom.tiers)).toBe(false); // Pro has no reward
    expect(canRequestReward(900, custom.tiers)).toBe(true);
    expect(firstRewardTier(custom.tiers)?.id).toBe("elite");
  });

  it("rejects programs that would break levels", () => {
    expect(() => parseLoyaltyProgram({ ...custom, tiers: custom.tiers.filter((t) => t.id !== "start") })).toThrow(/0 points/);
    expect(() => parseLoyaltyProgram({ ...custom, tiers: [...custom.tiers, { ...custom.tiers[1], id: "dup" }] })).toThrow(/same number of points/);
    expect(() => parseLoyaltyProgram({ ...custom, tiers: [] })).toThrow(/at least one level/);
    expect(() => parseLoyaltyProgram({ ...custom, tiers: [{ ...custom.tiers[1], colorHex: "blue" }] })).toThrow(/#a855f7/);
  });

  it("falls back to the default for a missing or corrupted setting", () => {
    expect(loyaltyProgramFromSetting("")).toBe(DEFAULT_LOYALTY_PROGRAM);
    expect(loyaltyProgramFromSetting("{not json")).toBe(DEFAULT_LOYALTY_PROGRAM);
    expect(loyaltyProgramFromSetting(JSON.stringify(custom)).tiers).toHaveLength(3);
  });

  it("makes unique level ids", () => {
    expect(tierIdFromName("Gold · Lvl 3", [])).toBe("gold-lvl-3");
    expect(tierIdFromName("Level 5", ["level-5"])).toBe("level-5-2");
  });
});
