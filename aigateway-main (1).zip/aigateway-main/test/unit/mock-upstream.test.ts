import { afterAll, beforeAll, beforeEach, describe, expect, it } from "vitest";
import { startMockUpstream, type MockUpstream } from "../mock-upstream/server";

// The mock provider is test infrastructure; these tests pin its contract so
// gateway tests can trust it.
describe("mock upstream", () => {
  let mock: MockUpstream;
  beforeAll(async () => {
    mock = await startMockUpstream();
  });
  afterAll(() => mock.close());
  beforeEach(() => mock.reset());

  const chat = (body: Record<string, unknown>, init: RequestInit = {}) =>
    fetch(`${mock.url}/v1/chat/completions`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ model: "m", messages: [{ role: "user", content: "hi" }], ...body }),
      ...init,
    });

  it("answers a non-streaming chat completion with usage in the requested dialect", async () => {
    mock.setScenario({ usageDialect: "deepseek", usage: { prompt: 1000, cached: 900, completion: 10 } });
    const r = await chat({});
    expect(r.status).toBe(200);
    const j = (await r.json()) as { usage: Record<string, unknown>; choices: Array<{ message: { content: string } }> };
    expect(j.choices[0].message.content).toContain("mock provider");
    expect(j.usage.prompt_cache_hit_tokens).toBe(900);
    expect(j.usage.prompt_cache_miss_tokens).toBe(100);
    expect(mock.lastRequest()?.model).toBe("m");
  });

  it("streams SSE with a final usage chunk and [DONE]", async () => {
    mock.setScenario({ chunkCount: 3, usageDialect: "deepinfra", usage: { cost: 0.5 } });
    const r = await chat({ stream: true, stream_options: { include_usage: true } });
    const text = await r.text();
    const events = text.split("\n\n").filter(Boolean);
    expect(events.at(-1)).toBe("data: [DONE]");
    const usageEvent = events.find((e) => e.includes('"usage"'));
    expect(usageEvent).toContain('"estimated_cost":0.5');
    expect(mock.lastRequest()?.chunksSent).toBe(3);
  });

  it("omits usage when told to", async () => {
    mock.setScenario({ omitUsage: true });
    const text = await (await chat({ stream: true })).text();
    expect(text).not.toContain('"usage"');
  });

  it("fails before the first byte with the given status", async () => {
    mock.setScenario({ failBeforeFirstByte: { status: 429 } });
    const r = await chat({});
    expect(r.status).toBe(429);
    expect(((await r.json()) as { error: { type: string } }).error.type).toBe("rate_limit_error");
  });

  it("fails mid-stream after N chunks with an error chunk", async () => {
    mock.setScenario({ chunkCount: 5, failAfterChunks: 2 });
    const text = await (await chat({ stream: true })).text();
    expect(text).toContain("mock mid-stream failure");
    expect(text).not.toContain("[DONE]");
    expect(mock.lastRequest()?.chunksSent).toBe(2);
  });

  it("records a client cancellation", async () => {
    mock.setScenario({ chunkCount: 20, chunkDelayMs: 50 });
    const ac = new AbortController();
    const r = await chat({ stream: true }, { signal: ac.signal });
    const reader = r.body!.getReader();
    await reader.read();
    ac.abort();
    const rec = await mock.waitForCancel({ timeoutMs: 3000 });
    expect(rec.cancelled).toBe(true);
    expect(rec.finishedAt).toBeNull();
  });

  it("speaks Anthropic messages, streaming, with cache usage", async () => {
    mock.setScenario({ usage: { prompt: 500, cached: 400, cacheWrite: 50, completion: 7 }, toolCall: { name: "read_file", arguments: { path: "a.ts" } } });
    const r = await fetch(`${mock.url}/v1/messages`, {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ model: "m", max_tokens: 10, stream: true, messages: [{ role: "user", content: "hi" }] }),
    });
    const text = await r.text();
    expect(text).toContain("event: message_start");
    expect(text).toContain('"cache_read_input_tokens":400');
    expect(text).toContain('"cache_creation_input_tokens":50');
    expect(text).toContain('"input_tokens":50');
    expect(text).toContain("input_json_delta");
    expect(text).toContain('"stop_reason":"tool_use"');
    expect(text).toContain("event: message_stop");
  });

  it("is scriptable over HTTP", async () => {
    await fetch(`${mock.url}/__control`, { method: "POST", body: JSON.stringify({ text: "scripted" }) });
    const j = (await (await chat({})).json()) as { choices: Array<{ message: { content: string } }> };
    expect(j.choices[0].message.content).toBe("scripted");
  });
});
