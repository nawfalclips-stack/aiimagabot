import { describe, expect, it } from "vitest";
import { aliasSseStream, presentAsAlias } from "@/lib/gateway/metering";

const enc = new TextEncoder();
const dec = new TextDecoder();

async function run(chunks: string[], alias: string): Promise<string> {
  const source = new ReadableStream<Uint8Array>({
    start(c) {
      for (const s of chunks) c.enqueue(enc.encode(s));
      c.close();
    },
  });
  let out = "";
  const reader = source.pipeThrough(aliasSseStream(alias)).getReader();
  for (;;) {
    const { value, done } = await reader.read();
    if (done) break;
    out += dec.decode(value, { stream: true });
  }
  return out;
}

describe("customers only see the model alias", () => {
  it("rewrites the upstream model and drops the provider in JSON responses", () => {
    const json = presentAsAlias({ id: "gen-1", model: "anthropic/claude-opus-4.5", provider: "Anthropic", choices: [] }, "aero-pro");
    expect(json).toEqual({ id: "gen-1", model: "aero-pro", choices: [] });
  });

  it("rewrites every SSE data line, even when a chunk splits an event", async () => {
    const e1 = `data: ${JSON.stringify({ id: "gen-1", model: "anthropic/claude-opus-4.5", provider: "Anthropic", choices: [{ delta: { content: "Hi" } }] })}\n\n`;
    const e2 = `data: ${JSON.stringify({ id: "gen-1", model: "anthropic/claude-opus-4.5", choices: [], usage: { cost: 0.01 } })}\n\n`;
    const all = `: OPENROUTER PROCESSING\n\n${e1}${e2}data: [DONE]\n\n`;
    // Split mid-JSON and mid-multibyte-free boundary.
    const out = await run([all.slice(0, 40), all.slice(40, 97), all.slice(97)], "aero-pro");
    expect(out).not.toContain("anthropic/");
    expect(out).not.toContain("provider");
    expect(out).toContain(': OPENROUTER PROCESSING\n\n');
    expect(out).toContain("data: [DONE]\n\n");
    const events = out.split("\n").filter((l) => l.startsWith("data: {")).map((l) => JSON.parse(l.slice(6)));
    expect(events).toHaveLength(2);
    expect(events.every((e) => e.model === "aero-pro")).toBe(true);
    expect(events[0].choices[0].delta.content).toBe("Hi");
    expect(events[1].usage.cost).toBe(0.01);
  });

  it("passes lines without a model through byte-for-byte", async () => {
    const text = `data: {"error":{"message":"x"}}\r\n\r\ndata: [DONE]\n\n`;
    expect(await run([text], "aero-pro")).toBe(text);
  });
});
