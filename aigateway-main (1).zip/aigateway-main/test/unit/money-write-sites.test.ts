import { readFileSync, readdirSync, statSync } from "node:fs";
import { join, relative, sep } from "node:path";
import { describe, expect, it } from "vitest";

/**
 * Guard: money fields on Customer may only be written from the balance
 * service (WS1) and the reservation module (WS2). Any new write site fails
 * this test until it is moved behind those two files.
 *
 * Not guarded on purpose: `pendingBonusCents` (an offer, not credit) and
 * `affiliateEarnedCents` (a statistic; the payout itself goes through the
 * ledger as AFFILIATE_REWARD).
 */
const MONEY_FIELDS = [
  "initialBalanceCents",
  "usedBalanceCents",
  "initialBonusCents",
  "usedBonusCents",
  "gatewayCarryMicroUsd",
  "balanceCarryMicroUsd",
  "bonusCarryMicroUsd",
  "reservedMicroUsd",
];

const ALLOWED_WRITERS = new Set<string>([
  "lib/billing/balance-service.ts",
  "lib/billing/reservations.ts",
]);

const ROOTS = ["lib", "app", "components", "prisma/seed.ts", "scripts"];
const SKIP_DIRS = new Set(["node_modules", ".next"]);

function* walk(path: string): Generator<string> {
  const st = statSync(path, { throwIfNoEntry: false });
  if (!st) return;
  if (st.isFile()) {
    if (/\.(ts|tsx|mjs)$/.test(path)) yield path;
    return;
  }
  for (const entry of readdirSync(path)) {
    if (SKIP_DIRS.has(entry)) continue;
    yield* walk(join(path, entry));
  }
}

/** Index of the bracket that closes the one at `open` (which must be `(`, `{` or `[`). */
function closingIndex(text: string, open: number): number {
  let depth = 0;
  for (let i = open; i < text.length; i++) {
    const ch = text[i];
    if (ch === "(" || ch === "{" || ch === "[") depth++;
    else if (ch === ")" || ch === "}" || ch === "]") {
      depth--;
      if (depth === 0) return i;
    }
  }
  return text.length - 1;
}

/**
 * A "write" is a money field used as a key inside the `data:` block of a
 * Prisma create/update call, or the `create:`/`update:` blocks of an upsert.
 * Reads in `select`/`where`/math, and plain objects that happen to have a
 * `data` key (action results), are not writes.
 */
const PRISMA_OP = /\.(create|createMany|createManyAndReturn|update|updateMany|upsert)\s*\(/g;
const DATA_BLOCK = /\bdata\s*:\s*\{/g;
const UPSERT_BLOCK = /\b(create|update)\s*:\s*\{/g;
// `field: value`, `field: { increment }`, or the shorthand `field,` / `field }`.
const FIELD_KEY = new RegExp(`(^|[\\s{,])(${MONEY_FIELDS.join("|")})\\s*(?=[:,}\\r\\n])`, "g");

function findWrites(source: string): string[] {
  const hits = new Set<string>();
  for (const op of source.matchAll(PRISMA_OP)) {
    const openParen = op.index + op[0].length - 1;
    const call = source.slice(op.index, closingIndex(source, openParen) + 1);
    const blockKey = op[1] === "upsert" ? UPSERT_BLOCK : DATA_BLOCK;
    for (const b of call.matchAll(blockKey)) {
      const openBrace = b.index + b[0].length - 1;
      const block = call.slice(b.index, closingIndex(call, openBrace) + 1);
      for (const f of block.matchAll(FIELD_KEY)) hits.add(f[2]);
    }
  }
  return [...hits];
}

describe("money write sites", () => {
  const root = process.cwd();
  const offenders: Array<{ file: string; fields: string[] }> = [];
  const seen: string[] = [];

  for (const r of ROOTS) {
    for (const file of walk(join(root, r))) {
      const rel = relative(root, file).split(sep).join("/");
      if (rel.endsWith(".test.ts")) continue;
      const fields = findWrites(readFileSync(file, "utf8"));
      if (fields.length === 0) continue;
      seen.push(rel);
      if (!ALLOWED_WRITERS.has(rel)) offenders.push({ file: rel, fields });
    }
  }

  it("finds the known write sites (sanity check that the scanner works)", () => {
    expect(seen).toContain("lib/billing/balance-service.ts");
    expect(seen).toContain("lib/billing/reservations.ts");
  });

  it("has no writer outside the allowlist", () => {
    expect(offenders, `Unexpected money writes:\n${offenders.map((o) => `  ${o.file}: ${o.fields.join(", ")}`).join("\n")}`).toEqual([]);
  });

  it("has no stale allowlist entries", () => {
    const stale = [...ALLOWED_WRITERS].filter((f) => !seen.includes(f));
    expect(stale, "allowlisted files that no longer write money — remove them").toEqual([]);
  });
});
