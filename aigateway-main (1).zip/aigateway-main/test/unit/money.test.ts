import { describe, expect, it } from "vitest";
import { centsToMicro, formatMicroUsd, potAvailableMicroUsd, potToPricedMicroUsd, pricedToPotMicroUsd, spendableMicroUsd, splitUsageMicroUsd } from "@/lib/billing/money";
import { estimateHoldMicroUsd, estimateInputTokens, maxOutputTokensAffordable } from "@/lib/billing/estimate";
import { bonusConversion, bonusRateFromPlan, rateFromMultiplier, SAME_RATE } from "@/lib/billing/pricing-engine";
import { describeBonusValue } from "@/lib/plan-usage";
import { bonusRealAllowance, customerRealAllowance } from "@/lib/real-usage";
import { computeStatus } from "@/lib/services/status";

describe("money units", () => {
  it("converts cents to micro-USD exactly", () => {
    expect(centsToMicro(1)).toBe(10_000n);
    expect(centsToMicro(30_000)).toBe(300_000_000n);
    expect(() => centsToMicro(1.5)).toThrow(RangeError);
  });

  it("formats whole cents and fractions", () => {
    expect(formatMicroUsd(1_230_000n)).toBe("$1.23");
    expect(formatMicroUsd(1_234n)).toBe("$0.0012");
    expect(formatMicroUsd(-500_000n)).toBe("−$0.50");
  });

  it("derives pot availability from cents minus carry", () => {
    const c = { initialBalanceCents: 1000, usedBalanceCents: 250, initialBonusCents: 100, usedBonusCents: 0, balanceCarryMicroUsd: 4_321n, bonusCarryMicroUsd: 0n };
    expect(potAvailableMicroUsd(c, "BALANCE")).toBe(7_500_000n - 4_321n);
    expect(potAvailableMicroUsd(c, "BONUS")).toBe(1_000_000n);
    expect(spendableMicroUsd({ ...c, reservedMicroUsd: 1_000_000n })).toBe(7_500_000n - 4_321n);
  });
});

describe("balance-first split", () => {
  it("charges the balance only while it can pay (the $100 plan example: $25 → balance $75)", () => {
    const s = splitUsageMicroUsd(25_000_000n, 100_000_000n, 15_000_000n);
    expect(s).toEqual({ balanceMicroUsd: 25_000_000n, bonusMicroUsd: 0n, bonusCoveredMicroUsd: 0n, uncollectedMicroUsd: 0n });
  });

  it("uses the bonus only for what the balance cannot cover", () => {
    const s = splitUsageMicroUsd(1_000_000n, 10_000_000n, 50_000n);
    expect(s).toEqual({ balanceMicroUsd: 1_000_000n, bonusMicroUsd: 0n, bonusCoveredMicroUsd: 0n, uncollectedMicroUsd: 0n });
  });

  it("falls back to bonus when balance is short, never negative", () => {
    const s = splitUsageMicroUsd(1_000_000n, 300_000n, 900_000n);
    expect(s.balanceMicroUsd).toBe(300_000n);
    expect(s.bonusMicroUsd).toBe(700_000n);
    expect(s.uncollectedMicroUsd).toBe(0n);
  });

  it("reports what neither pot can cover", () => {
    const s = splitUsageMicroUsd(1_000_000n, 100_000n, 100_000n);
    expect(s.balanceMicroUsd + s.bonusMicroUsd).toBe(200_000n);
    expect(s.uncollectedMicroUsd).toBe(800_000n);
  });

  it("treats negative availability as zero", () => {
    const s = splitUsageMicroUsd(10n, -5n, -5n);
    expect(s).toEqual({ balanceMicroUsd: 0n, bonusMicroUsd: 0n, bonusCoveredMicroUsd: 0n, uncollectedMicroUsd: 10n });
  });
});

describe("plan bonus rate", () => {
  // $100 plan worth $5 of real usage (×20); $10 bonus worth $0.50 (×20) — the same rate.
  const plan = { priceCents: 10_000, limitType: "USD", limitUsageCents: 500, limitMTokens: 0, bonusCents: 1_000, bonusLimitUsageCents: 50 };
  const usdPlan = plan;

  it("defaults to the balance rate (bonus 0, or no bonus limit)", () => {
    expect(bonusConversion(null)).toEqual(SAME_RATE);
    expect(bonusConversion({ ...plan, bonusCents: 0 })).toEqual(SAME_RATE);
    expect(bonusConversion({ ...plan, bonusLimitUsageCents: 0 })).toEqual(SAME_RATE);
    expect(bonusRateFromPlan({ ...plan, bonusLimitUsageCents: 0 })).toBeNull();
  });

  it("is bonusRate / balanceRate, reduced", () => {
    expect(bonusConversion(usdPlan)).toEqual({ num: 1n, den: 1n });
    const twoX = { ...plan, bonusLimitUsageCents: 25 }; // $10 → $0.25: ×40 vs ×20
    expect(bonusConversion(twoX)).toEqual({ num: 2n, den: 1n });
    const tokens = { priceCents: 10_000, limitType: "TOKENS", limitUsageCents: 0, limitMTokens: 50, bonusCents: 1_000, bonusLimitMTokens: 1 };
    // balance $2/M tokens, bonus $10/M tokens → ×5
    expect(bonusConversion(tokens)).toEqual({ num: 5n, den: 1n });
  });

  it("matches the balance-only split exactly at the same rate", () => {
    const a = splitUsageMicroUsd(1_000_000n, 300_000n, 900_000n);
    const b = splitUsageMicroUsd(1_000_000n, 300_000n, 900_000n, { num: 1n, den: 1n });
    expect(b).toEqual(a);
    expect(a.bonusCoveredMicroUsd).toBe(700_000n);
  });

  it("debits the bonus at its own rate once the balance is empty", () => {
    const s = splitUsageMicroUsd(1_000_000n, 300_000n, 10_000_000n, { num: 4n, den: 1n });
    expect(s.balanceMicroUsd).toBe(300_000n);
    expect(s.bonusMicroUsd).toBe(2_800_000n); // 700 000 × 4
    expect(s.bonusCoveredMicroUsd).toBe(700_000n);
    expect(s.uncollectedMicroUsd).toBe(0n);
  });

  it("leaves what the bonus cannot cover at its rate uncollected", () => {
    const s = splitUsageMicroUsd(1_000_000n, 0n, 1_000_000n, { num: 4n, den: 1n });
    expect(s.bonusMicroUsd).toBe(1_000_000n);
    expect(s.bonusCoveredMicroUsd).toBe(250_000n);
    expect(s.uncollectedMicroUsd).toBe(750_000n);
    expect(s.bonusCoveredMicroUsd + s.uncollectedMicroUsd + s.balanceMicroUsd).toBe(1_000_000n);
  });

  it("converts holds between priced and pot units", () => {
    const k = { num: 4n, den: 1n };
    expect(pricedToPotMicroUsd(1_000_000n, 300_000n, k)).toBe(300_000n + 2_800_000n);
    expect(potToPricedMicroUsd(3_100_000n, 300_000n, k)).toBe(1_000_000n);
    expect(pricedToPotMicroUsd(1_000_000n, 5_000_000n, k)).toBe(1_000_000n);
  });

  it("describes what the bonus is worth", () => {
    expect(describeBonusValue(usdPlan)).toBe("$10.00 bonus = $0.50 of real API usage (×20.00)");
    expect(describeBonusValue({ ...plan, bonusLimitUsageCents: 0 })).toBe("$10.00 bonus = $0.50 of real API usage (same rate as the balance)");
    expect(describeBonusValue({ ...plan, bonusCents: 0 })).toBe("No bonus");
  });

  it("sizes the real-usage allowance with the bonus at its own rate", () => {
    const twoX = { ...plan, bonusLimitUsageCents: 25 };
    expect(bonusRealAllowance(1_000, twoX, 1)).toEqual({ kind: "usd", microUsd: 250_000 });
    // $100 balance → $5, $10 bonus → $0.25
    expect(customerRealAllowance({ initialBalanceCents: 10_000, initialBonusCents: 1_000 }, twoX, 1)).toEqual({ kind: "usd", microUsd: 5_250_000 });
    // no bonus limit: bonus at the balance rate → $0.50
    expect(bonusRealAllowance(1_000, { ...plan, bonusLimitUsageCents: 0 }, 1)).toEqual({ kind: "usd", microUsd: 500_000 });
  });
});

describe("status rule (decision #11)", () => {
  it("is LOW_BALANCE, not FINISHED, while bonus remains", () => {
    expect(computeStatus(0, 1000, "ACTIVE", 500)).toBe("LOW_BALANCE");
    expect(computeStatus(0, 1000, "ACTIVE", 0)).toBe("BALANCE_FINISHED");
    expect(computeStatus(5000, 1000, "ACTIVE", 0)).toBe("ACTIVE");
    expect(computeStatus(0, 1000, "SUSPENDED", 500)).toBe("SUSPENDED");
  });
});

describe("hold estimate", () => {
  const model = { inputPriceMicroPerMTok: 400_000, outputPriceMicroPerMTok: 1_600_000 }; // $0.40 / $1.60 per MTok

  it("counts ~3 bytes per token, conservatively", () => {
    expect(estimateInputTokens(["abcdef"])).toBe(2);
    expect(estimateInputTokens([{ role: "user", content: "hi" }])).toBeGreaterThan(5);
    expect(estimateInputTokens([])).toBe(1);
  });

  it("prices input + max output at the customer rate with margin and a floor", () => {
    // 1000 in × $0.40/M = 400 µ$; 2000 out × $1.60/M = 3200 µ$; ×20 = 72 000; +5 % = 75 600
    const hold = estimateHoldMicroUsd({ rate: rateFromMultiplier(20), model, inputTokens: 1000, outputTokens: 2000, marginPct: 5, minHoldMicroUsd: 10_000n });
    expect(hold).toBe(75_600n);
    const tiny = estimateHoldMicroUsd({ rate: rateFromMultiplier(1), model, inputTokens: 1, outputTokens: 1, marginPct: 0, minHoldMicroUsd: 10_000n });
    expect(tiny).toBe(10_000n);
  });

  it("computes the largest affordable completion for fit-to-balance", () => {
    const rate = rateFromMultiplier(20);
    const affordable = maxOutputTokensAffordable({ rate, model, inputTokens: 1000, marginPct: 5, minHoldMicroUsd: 0n, availableMicroUsd: 75_600n });
    expect(affordable).toBe(2000);
    expect(maxOutputTokensAffordable({ rate, model, inputTokens: 1000, marginPct: 5, minHoldMicroUsd: 0n, availableMicroUsd: 1_000n })).toBe(0);
  });

  it("supports TOKENS-mode plans (flat per-token rate)", () => {
    const hold = estimateHoldMicroUsd({ rate: { kind: "perToken", num: 2n, den: 1n }, model, inputTokens: 100, outputTokens: 400, marginPct: 0, minHoldMicroUsd: 0n });
    expect(hold).toBe(1_000n);
  });
});
