import { readFileSync } from "node:fs";
import { join } from "node:path";
import { describe, expect, it } from "vitest";
import { parseOpenRouterModel, usdPerTokenToMicroPerMTok } from "@/lib/gateway/providers/openrouter";
import { inferUsageDialect } from "@/lib/gateway/providers/catalog";
import { normalizeUsage } from "@/lib/gateway/usage";
import { quote, rateFromMultiplier, rateFromPlan } from "@/lib/billing/pricing-engine";
import { promoBonusCents } from "@/lib/announcements";

const fixture = JSON.parse(readFileSync(join(__dirname, "../fixtures/usage/openrouter.json"), "utf8")) as { usage: unknown };

describe("OpenRouter catalog prices", () => {
  it("converts USD-per-token strings to µ$ per 1M tokens exactly", () => {
    expect(usdPerTokenToMicroPerMTok("0.000003")).toBe(3_000_000); // $3 / M — a float would give 2 999 999.9…
    expect(usdPerTokenToMicroPerMTok("0.0000025")).toBe(2_500_000);
    expect(usdPerTokenToMicroPerMTok("0.00000056")).toBe(560_000);
    expect(usdPerTokenToMicroPerMTok("0.000000075")).toBe(75_000);
    expect(usdPerTokenToMicroPerMTok("0")).toBe(0);
    expect(usdPerTokenToMicroPerMTok("0.0000000000005")).toBe(1); // rounds half up on the 13th decimal
  });

  it("treats OpenRouter's per-request price (-1) and garbage as unknown", () => {
    expect(usdPerTokenToMicroPerMTok("-1")).toBeNull();
    expect(usdPerTokenToMicroPerMTok("abc")).toBeNull();
    expect(usdPerTokenToMicroPerMTok(undefined)).toBeNull();
  });

  it("parses a /models entry with cache prices and limits", () => {
    const e = parseOpenRouterModel({
      id: "anthropic/claude-opus-4.5",
      name: "Anthropic: Claude Opus 4.5",
      context_length: 200_000,
      pricing: { prompt: "0.000005", completion: "0.000025", input_cache_read: "0.0000005", input_cache_write: "0.00000625" },
      top_provider: { context_length: 200_000, max_completion_tokens: 64_000 },
    });
    expect(e).toMatchObject({
      id: "anthropic/claude-opus-4.5",
      inputMicroPerMTok: 5_000_000,
      outputMicroPerMTok: 25_000_000,
      cachedInputMicroPerMTok: 500_000,
      cacheWriteMicroPerMTok: 6_250_000,
      contextWindow: 200_000,
      maxOutputTokens: 64_000,
    });
  });

  it("skips router pseudo-models and non-text models", () => {
    expect(parseOpenRouterModel({ id: "openrouter/auto", pricing: { prompt: "-1", completion: "-1" } })).toBeNull();
    expect(
      parseOpenRouterModel({ id: "x/image", pricing: { prompt: "0.000001", completion: "0.000002" }, architecture: { output_modalities: ["image"] } })
    ).toBeNull();
  });
});

describe("usage dialect", () => {
  it("reads OpenRouter's cost even when the provider was saved with the default dialect", () => {
    expect(inferUsageDialect("https://openrouter.ai/api/v1", "openai")).toBe("openrouter");
    expect(inferUsageDialect("https://api.deepinfra.com/v1/openai", "openai")).toBe("deepinfra");
    expect(inferUsageDialect("https://api.example.com/v1", "openai")).toBe("openai");
    expect(inferUsageDialect("https://openrouter.ai/api/v1", "anthropic")).toBe("anthropic"); // explicit choice wins
  });
});

describe("OpenRouter billing on the customer's plan", () => {
  const model = { inputPriceMicroPerMTok: 5_000_000, outputPriceMicroPerMTok: 25_000_000, cachedInputPriceMicroPerMTok: 500_000, cacheWritePriceMicroPerMTok: 6_250_000 };
  const usage = normalizeUsage("openrouter", fixture.usage)!;

  it("uses the cost OpenRouter reports as the real price", () => {
    expect(usage.providerCostMicroUsd).toBe(4200n); // cost: 0.0042 USD
  });

  it("USD plan: charge = real cost × price / included usage", () => {
    // $100 plan worth $5 of real usage → ×20.
    const rate = rateFromPlan({ priceCents: 10_000, limitType: "USD", limitUsageCents: 500, limitMTokens: 0 })!;
    expect(quote(rate, model, usage, { providerCostMicroUsd: usage.providerCostMicroUsd! })).toBe(84_000n); // $0.084
  });

  it("no plan: charge = real cost × the store multiplier", () => {
    expect(quote(rateFromMultiplier(2.2), model, usage, { providerCostMicroUsd: usage.providerCostMicroUsd! })).toBe(9240n);
  });

  it("TOKENS plan: charge follows tokens, not the provider's cost", () => {
    // $100 for 50M tokens → 2 µ$ per token; cached input counted at 100 %.
    const rate = rateFromPlan({ priceCents: 10_000, limitType: "TOKENS", limitUsageCents: 0, limitMTokens: 50 })!;
    const tokens = 100 + 2500 + 400 + 200 + 50;
    expect(quote(rate, model, usage, { providerCostMicroUsd: usage.providerCostMicroUsd!, cachedTokenWeightPct: 100 })).toBe(BigInt(tokens * 2));
  });
});

describe("recharge promotion", () => {
  it("adds the percentage of the recharged balance, in whole cents rounded down", () => {
    expect(promoBonusCents(10_000, 15)).toBe(1_500); // $100 → +$15
    expect(promoBonusCents(3_333, 15)).toBe(499);
    expect(promoBonusCents(10_000, 0)).toBe(0);
    expect(promoBonusCents(10_000, 500)).toBe(10_000); // clamped to 100 %
    expect(promoBonusCents(-5, 15)).toBe(0);
  });
});
