import { describe, expect, it } from "vitest";
import { quote, rateFromPlan } from "@/lib/billing/pricing-engine";
import { splitUsageMicroUsd } from "@/lib/billing/money";
import { aliasWarnings, publicModelId, publicModelName } from "@/lib/model-alias";

const USD = 1_000_000n;
const noUsage = { inputUncached: 0n, inputCached: 0n, cacheWrite: 0n, output: 0n, reasoning: 0n };
const anyModel = { inputPriceMicroPerMTok: 0, outputPriceMicroPerMTok: 0 };

describe("plan billing — $100 plan worth $2 of real usage", () => {
  const rate = rateFromPlan({ priceCents: 10_000, limitType: "USD", limitUsageCents: 200, limitMTokens: 0 })!;

  it("a request that really costs $0.50 is charged $25", () => {
    expect(quote(rate, anyModel, noUsage, { providerCostMicroUsd: USD / 2n })).toBe(25n * USD);
  });

  it("the $25 comes out of the balance: $100 → $75, bonus untouched", () => {
    const split = splitUsageMicroUsd(25n * USD, 100n * USD, 15n * USD);
    expect(100n * USD - split.balanceMicroUsd).toBe(75n * USD);
    expect(split.bonusMicroUsd).toBe(0n);
  });

  it("$2 of real usage consumes exactly the $100 plan", () => {
    expect(quote(rate, anyModel, noUsage, { providerCostMicroUsd: 2n * USD })).toBe(100n * USD);
  });

  it("tiny requests keep micro-dollar precision", () => {
    expect(quote(rate, anyModel, noUsage, { providerCostMicroUsd: 37n })).toBe(1850n); // $0.000037 → $0.00185
  });
});

describe("public model alias", () => {
  const model = { slug: "claude-opus-5", displayName: "deepseek-v4-flash-latest" };

  it("falls back to the internal names only when no alias is set", () => {
    expect(publicModelId(model)).toBe("claude-opus-5");
    expect(publicModelName(model)).toBe("deepseek-v4-flash-latest");
  });

  it("shows the alias id and name, never the internal display name", () => {
    expect(publicModelId({ ...model, aliasSlug: "aero-pro", aliasName: "Aero Pro" })).toBe("aero-pro");
    expect(publicModelName({ ...model, aliasSlug: "aero-pro", aliasName: "Aero Pro" })).toBe("Aero Pro");
    expect(publicModelName({ ...model, aliasSlug: "aero-pro", aliasName: "" })).toBe("aero-pro");
  });

  it("warns when there is no alias or when the alias reveals the upstream model", () => {
    const upstream = ["~deepseek/deepseek-v4-flash-latest"];
    expect(aliasWarnings(model, upstream)[0]).toMatch(/No public alias/);
    expect(aliasWarnings({ ...model, aliasSlug: "deepseek-fast", aliasName: "Fast" }, upstream)[0]).toMatch(/reveals the real model \(deepseek/);
    expect(aliasWarnings({ ...model, aliasSlug: "aero-pro", aliasName: "Aero Pro" }, upstream)).toEqual([]);
    expect(aliasWarnings({ ...model, aliasSlug: "aero-haiku", aliasName: "Aero" }, ["anthropic/claude-haiku-4.5"])[0]).toMatch(/haiku/);
  });
});
