import { describe, expect, it } from "vitest";
import {
  effectivePrices,
  estimateHold,
  maxOutputTokensAffordable,
  providerCostMicroUsd,
  quote,
  rateFromMultiplier,
  rateFromPlan,
  rateToNumber,
  weightedTokens,
  type UsageComponents,
} from "@/lib/billing/pricing-engine";

// WS8 acceptance: one engine, both plan modes, cache-heavy usage, exact integers.
const model = { inputPriceMicroPerMTok: 400_000, outputPriceMicroPerMTok: 1_600_000, cachedInputPriceMicroPerMTok: 40_000, cacheWritePriceMicroPerMTok: 500_000 };
const usage = (u: Partial<UsageComponents>): UsageComponents => ({ inputUncached: 0n, inputCached: 0n, cacheWrite: 0n, output: 0n, reasoning: 0n, ...u });

describe("pricing engine (WS8)", () => {
  it("builds exact rationals from decimals and plans", () => {
    expect(rateFromMultiplier(2.2)).toEqual({ kind: "multiplier", num: 22n, den: 10n });
    expect(rateFromMultiplier("20")).toEqual({ kind: "multiplier", num: 20n, den: 1n });
    expect(rateFromPlan({ priceCents: 10_000, limitType: "USD", limitUsageCents: 500, limitMTokens: 0 })).toEqual({ kind: "multiplier", num: 10_000n, den: 500n });
    expect(rateFromPlan({ priceCents: 10_000, limitType: "TOKENS", limitUsageCents: 0, limitMTokens: 50 })).toEqual({ kind: "perToken", num: 100_000_000n, den: 50_000_000n });
    expect(rateFromPlan({ priceCents: 10_000, limitType: "USD", limitUsageCents: 0, limitMTokens: 0 })).toBeNull();
    expect(rateToNumber(rateFromMultiplier(2.2))).toBeCloseTo(2.2);
  });

  it("CREDITS mode: provider cost × multiplier, cache discount passes through", () => {
    const rate = rateFromMultiplier(2.2);
    // 1000 uncached × 0.40 + 9000 cached × 0.04 + 100 out × 1.60 = 400 + 360 + 160 = 920 µ$
    const u = usage({ inputUncached: 1000n, inputCached: 9000n, output: 100n });
    expect(providerCostMicroUsd(model, u)).toBe(920n);
    expect(quote(rate, model, u)).toBe(2024n);
    // The same request with no cache would cost 10000 × 0.40 + 160 = 4160 → 9152
    expect(quote(rate, model, usage({ inputUncached: 10_000n, output: 100n }))).toBe(9152n);
    // A provider-reported cost wins when supplied
    expect(quote(rate, model, u, { providerCostMicroUsd: 1000n })).toBe(2200n);
  });

  it("TOKENS mode: weighted tokens × flat rate, cached weight from the plan", () => {
    const rate = rateFromPlan({ priceCents: 10_000, limitType: "TOKENS", limitUsageCents: 0, limitMTokens: 50 })!; // $100 / 50M = 2 µ$/token
    const u = usage({ inputUncached: 1000n, inputCached: 9000n, output: 100n });
    expect(weightedTokens(u, 100)).toBe(10_100n);
    expect(quote(rate, model, u)).toBe(20_200n); // no discount (decision #1)
    expect(quote(rate, model, u, { cachedTokenWeightPct: 10 })).toBe(4_000n); // (1000 + 900 + 100) tokens × 2 µ$
    expect(quote(rate, model, u, { providerCostMicroUsd: 999_999n })).toBe(20_200n); // ignores provider cost
  });

  it("rounds half-up at the micro-dollar and never uses floats", () => {
    const rate = rateFromMultiplier("1.5");
    expect(quote(rate, model, usage({}), { providerCostMicroUsd: 1n })).toBe(2n); // 1.5 → 2
    expect(quote(rate, model, usage({}), { providerCostMicroUsd: 3n })).toBe(5n); // 4.5 → 5
    const third = { kind: "multiplier" as const, num: 1n, den: 3n };
    expect(quote(third, model, usage({}), { providerCostMicroUsd: 10n })).toBe(3n);
    expect(quote(third, model, usage({}), { providerCostMicroUsd: 5n })).toBe(2n); // 1.67 → 2
  });

  it("holds and fit-to-balance agree with the quote", () => {
    const rate = rateFromMultiplier(20);
    const hold = estimateHold(rate, model, { inputTokens: 1000, outputTokens: 2000, marginPct: 5, minHoldMicroUsd: 10_000n });
    expect(hold).toBe(75_600n); // (400 + 3200) × 20 = 72 000 + 5 %
    expect(maxOutputTokensAffordable(rate, model, { inputTokens: 1000, marginPct: 5, availableMicroUsd: 75_600n })).toBe(2000);
    expect(maxOutputTokensAffordable(rate, model, { inputTokens: 1000, marginPct: 5, availableMicroUsd: 1000n })).toBe(0);
    expect(estimateHold(rate, model, { inputTokens: 1, outputTokens: 1, marginPct: 0, minHoldMicroUsd: 10_000n })).toBe(10_000n);
  });

  it("effective prices show the cached rate per plan mode", () => {
    const credits = effectivePrices(rateFromMultiplier(2.2), model);
    expect(credits).toEqual({ inputMicroPerMTok: 880_000n, cachedInputMicroPerMTok: 88_000n, outputMicroPerMTok: 3_520_000n });
    const tokens = effectivePrices(rateFromPlan({ priceCents: 10_000, limitType: "TOKENS", limitUsageCents: 0, limitMTokens: 50 })!, model, 100);
    expect(tokens).toEqual({ inputMicroPerMTok: 2_000_000n, cachedInputMicroPerMTok: 2_000_000n, outputMicroPerMTok: 2_000_000n });
  });
});
