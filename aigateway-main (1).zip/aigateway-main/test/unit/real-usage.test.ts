import { describe, expect, it } from "vitest";
import { EMPTY_REAL_USAGE, formatMicroUsd, formatTokens, realAllowance, realUsedPct } from "@/lib/real-usage";

const usdPlan = { priceCents: 10_000, limitType: "USD", limitUsageCents: 500, limitMTokens: 0 }; // $100 buys $5 real usage
const tokenPlan = { priceCents: 10_000, limitType: "TOKENS", limitUsageCents: 0, limitMTokens: 50 }; // $100 buys 50M tokens

describe("realAllowance", () => {
  it("scales a USD plan's limit with everything credited", () => {
    expect(realAllowance(10_000, usdPlan, 2.2)).toEqual({ kind: "usd", microUsd: 5_000_000 });
    // A $100 recharge on top doubles it.
    expect(realAllowance(20_000, usdPlan, 2.2)).toEqual({ kind: "usd", microUsd: 10_000_000 });
  });

  it("gives tokens for a TOKENS plan", () => {
    expect(realAllowance(10_000, tokenPlan, 2.2)).toEqual({ kind: "tokens", tokens: 50_000_000 });
  });

  it("falls back to the global multiplier without a valid plan", () => {
    expect(realAllowance(2_200, null, 2.2)).toEqual({ kind: "usd", microUsd: 10_000_000 });
    expect(realAllowance(2_200, { ...usdPlan, limitUsageCents: 0 }, 2.2)).toEqual({ kind: "usd", microUsd: 10_000_000 });
  });

  it("has no allowance without credit", () => {
    expect(realAllowance(0, usdPlan, 2.2)).toBeNull();
  });
});

describe("realUsedPct", () => {
  it("compares provider cost or tokens with the allowance", () => {
    expect(realUsedPct({ ...EMPTY_REAL_USAGE, costMicroUsd: 1_250_000 }, { kind: "usd", microUsd: 5_000_000 })).toBe(25);
    expect(realUsedPct({ ...EMPTY_REAL_USAGE, inputTokens: 4_000_000, outputTokens: 1_000_000 }, { kind: "tokens", tokens: 50_000_000 })).toBe(10);
    expect(realUsedPct(EMPTY_REAL_USAGE, null)).toBeNull();
  });
});

describe("formatting", () => {
  it("keeps sub-cent provider costs readable", () => {
    expect(formatMicroUsd(4_200)).toBe("$0.0042");
    expect(formatMicroUsd(12_340_000)).toBe("$12.34");
    expect(formatTokens(1_234_567)).toBe("1.2M");
    expect(formatTokens(812)).toBe("812");
  });
});
