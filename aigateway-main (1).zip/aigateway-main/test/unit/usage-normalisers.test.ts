import { readdirSync, readFileSync } from "node:fs";
import { join } from "node:path";
import { describe, expect, it } from "vitest";
import { normalizeUsage, priceProviderCostMicroUsd, toAnthropicUsage, type NormalizedUsage, type UsageDialect } from "@/lib/gateway/usage";

const dir = join(process.cwd(), "test/fixtures/usage");

describe("usage normalisers (fixture-driven)", () => {
  for (const file of readdirSync(dir).filter((f) => f.endsWith(".json"))) {
    const dialect = file.replace(/\.json$/, "") as UsageDialect;
    const fx = JSON.parse(readFileSync(join(dir, file), "utf8")) as { usage: unknown; expect: Record<string, number | null> };
    it(`${dialect} (${fx ? "fixture" : ""})`, () => {
      const n = normalizeUsage(dialect, fx.usage);
      expect(n).not.toBeNull();
      const got = Object.fromEntries(Object.entries(n as NormalizedUsage).map(([k, v]) => [k, v === null ? null : Number(v)]));
      expect(got).toEqual(fx.expect);
    });
  }

  it("returns null for non-objects and tolerates missing fields", () => {
    expect(normalizeUsage("openai", null)).toBeNull();
    expect(normalizeUsage("openai", "x")).toBeNull();
    expect(normalizeUsage("openai", {})).toEqual({ inputUncached: 0n, inputCached: 0n, cacheWrite: 0n, output: 0n, reasoning: 0n, providerCostMicroUsd: null });
    expect(normalizeUsage("unknown-dialect", { prompt_tokens: 5, completion_tokens: 2 })?.inputUncached).toBe(5n);
  });
});

describe("cache-aware provider cost", () => {
  const m = { inputPriceMicroPerMTok: 1_000_000, outputPriceMicroPerMTok: 4_000_000, cachedInputPriceMicroPerMTok: 100_000, cacheWritePriceMicroPerMTok: 1_250_000 };

  it("prices each component at its own rate", () => {
    const u: NormalizedUsage = { inputUncached: 1_000_000n, inputCached: 1_000_000n, cacheWrite: 1_000_000n, output: 500_000n, reasoning: 500_000n, providerCostMicroUsd: null };
    // 1.00 + 0.10 + 1.25 + 4.00 = $6.35
    expect(priceProviderCostMicroUsd(u, m)).toBe(6_350_000n);
  });

  it("defaults cached input to the uncached price and cache writes to free", () => {
    const u: NormalizedUsage = { inputUncached: 0n, inputCached: 1_000_000n, cacheWrite: 1_000_000n, output: 0n, reasoning: 0n, providerCostMicroUsd: null };
    expect(priceProviderCostMicroUsd(u, { ...m, cachedInputPriceMicroPerMTok: null, cacheWritePriceMicroPerMTok: null })).toBe(1_000_000n);
  });

  it("an agent-style replay with 90 % cache hits costs ~10 % of the naive price", () => {
    const u: NormalizedUsage = { inputUncached: 10_000n, inputCached: 90_000n, cacheWrite: 0n, output: 1_000n, reasoning: 0n, providerCostMicroUsd: null };
    const cacheAware = priceProviderCostMicroUsd(u, m);
    const naive = priceProviderCostMicroUsd({ ...u, inputUncached: 100_000n, inputCached: 0n }, m);
    expect(cacheAware).toBe(10_000n + 9_000n + 4_000n);
    expect(naive).toBe(100_000n + 4_000n);
  });

  it("rounds to the nearest micro-USD", () => {
    const u: NormalizedUsage = { inputUncached: 1n, inputCached: 0n, cacheWrite: 0n, output: 0n, reasoning: 0n, providerCostMicroUsd: null };
    expect(priceProviderCostMicroUsd(u, { ...m, inputPriceMicroPerMTok: 400_000 })).toBe(0n);
    expect(priceProviderCostMicroUsd(u, { ...m, inputPriceMicroPerMTok: 600_000 })).toBe(1n);
  });

  it("maps to the Anthropic usage shape for Claude Code", () => {
    expect(toAnthropicUsage({ inputUncached: 5n, inputCached: 100n, cacheWrite: 20n, output: 7n, reasoning: 3n, providerCostMicroUsd: null })).toEqual({
      input_tokens: 5,
      output_tokens: 10,
      cache_read_input_tokens: 100,
      cache_creation_input_tokens: 20,
    });
  });
});
