import { describe, expect, it } from "vitest";
import { checkChar, formatVoucherCode, normaliseVoucherCode, VOUCHER_ALPHABET, voucherLast4 } from "@/lib/vouchers/format";

// WS9: code format, normalisation and the check character.
const body = "7Q3WX9M2KD5H8RBV4N6T"; // 20 chars, all in the alphabet
const code = body + checkChar(body);

describe("voucher code format (WS9)", () => {
  it("alphabet is Crockford base32 without I, L, O, U", () => {
    expect(VOUCHER_ALPHABET).toHaveLength(32);
    for (const ch of "ILOU") expect(VOUCHER_ALPHABET).not.toContain(ch);
  });

  it("formats with the store prefix and 5-char groups", () => {
    expect(formatVoucherCode(code, "aerolink")).toBe(`ALK-7Q3WX-9M2KD-5H8RB-V4N6T-${code[20]}`);
    expect(formatVoucherCode(code, "chefapi").startsWith("CHF-")).toBe(true);
    expect(voucherLast4(code)).toBe("4N6T");
  });

  it("normalises case, separators, O/0 and I/L/1 confusions and drops the prefix", () => {
    const formatted = formatVoucherCode(code, "aerolink");
    expect(normaliseVoucherCode(formatted)).toBe(code);
    expect(normaliseVoucherCode(formatted.toLowerCase())).toBe(code);
    expect(normaliseVoucherCode(formatted.replace(/-/g, " "))).toBe(code);
    expect(normaliseVoucherCode(` ${formatted} `)).toBe(code);
    // 0 typed as O, 1 typed as I or L
    const confused = formatted.replace(/0/g, "O").replace(/1/g, "L");
    expect(normaliseVoucherCode(confused)).toBe(code);
    // without prefix
    expect(normaliseVoucherCode(code)).toBe(code);
  });

  it("rejects wrong length, bad characters and a wrong check character", () => {
    expect(normaliseVoucherCode(code.slice(0, 20))).toBeNull();
    expect(normaliseVoucherCode(code + "A")).toBeNull();
    expect(normaliseVoucherCode(code.slice(0, 20) + "U")).toBeNull();
    const wrongCheck = code.slice(0, 20) + VOUCHER_ALPHABET[(VOUCHER_ALPHABET.indexOf(code[20]) + 1) % 32];
    expect(normaliseVoucherCode(wrongCheck)).toBeNull();
  });

  it("the check character catches every single substitution and adjacent transposition", () => {
    let caught = 0;
    let total = 0;
    for (let i = 0; i < 20; i++) {
      for (const ch of VOUCHER_ALPHABET) {
        if (ch === body[i]) continue;
        total++;
        const mutated = body.slice(0, i) + ch + body.slice(i + 1) + code[20];
        if (normaliseVoucherCode(mutated) === null) caught++;
      }
    }
    expect(caught).toBe(total);
    for (let i = 0; i < 19; i++) {
      if (body[i] === body[i + 1]) continue;
      const swapped = body.slice(0, i) + body[i + 1] + body[i] + body.slice(i + 2) + code[20];
      expect(normaliseVoucherCode(swapped)).toBeNull();
    }
  });
});
