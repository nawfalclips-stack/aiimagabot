# How a provider fits into the gateway

Read once; the per-provider guides assume it.

## The four objects

```
Provider                     ProviderModel                GatewayModel
(who we call)                (the mapping)                (what customers type)
─────────────                ─────────────                ──────────────────────
slug      deepinfra          providerId  → Provider       slug   deepseek-v3   ← model id in Codex/Claude Code
baseUrl   …/v1/openai        modelId     → GatewayModel   inputPriceMicroPerMTok    what the provider costs US
apiKeyEnc (encrypted)        upstreamModelId              outputPriceMicroPerMTok   (µ$ per 1M tokens)
priority  10 (lower wins)      "deepseek-ai/DeepSeek-V3"  cachedInputPriceMicroPerMTok
usageDialect  openai         priority 100 (within model)  cacheWritePriceMicroPerMTok
supportsStreamUsage true     enabled                      contextWindow / maxOutputTokens
ttfb/totalTimeoutMs          ttfbTimeoutMs (override)     isReasoning
breaker* thresholds                                       enabledStoreIds  ("" = all stores)
```

- **One GatewayModel can have many ProviderModels.** That is failover: the gateway tries them by `Provider.priority`, then `ProviderModel.priority`. A second provider for the same slug is the whole point of the circuit breaker (Phase 2).
- **Prices on GatewayModel are what the model costs *us*.** The customer pays that × their plan's rate (or the store's `usage_cost_multiplier`, default ×2.2). A model left at $0 costs the customer **$0** — always set prices.
- `enabledStoreIds` empty = visible to every store.

## What the customer is charged

`lib/billing/pricing-engine.ts`:

```
provider cost = uncached_in×input + cached_in×cachedInput + cache_write×cacheWrite + (out+reasoning)×output
customer pays = provider cost × plan multiplier          (USD plans / global multiplier)
              = weighted tokens × plan rate              (TOKENS plans, cached weighted by cachedTokenWeightPct)
```

When the provider reports its own cost (DeepInfra `estimated_cost`, OpenRouter `cost`), **that figure is used** instead of our computed one, and a disagreement above 10 % + 100 µ$ logs
`[gateway] provider cost disagreement request=… reported=… computed=…`. That line is your signal that a price list is wrong.

## Fields with no admin UI yet

The Providers and Models pages cover the common fields. These were added in Phases 2–3 and are still **database-only** (a UI for them is WS11, Phase 7):

| Table | Field | Set it when |
|---|---|---|
| `Provider` | `usageDialect` | the provider is not plain OpenAI — `deepinfra`, `openrouter`, `deepseek`, `anthropic` |
| `Provider` | `supportsStreamUsage` | the provider rejects `stream_options.include_usage` (rare) |
| `Provider` | `ttfbTimeoutMs`, `totalTimeoutMs` | the provider is slow to first byte (reasoning models) |
| `Provider` | `breakerFailureThreshold`, `breakerWindowMs`, `breakerOpenMs` | defaults (3 fails / 60 s → open 60 s) don't suit |
| `GatewayModel` | `cachedInputPriceMicroPerMTok`, `cacheWritePriceMicroPerMTok` | the provider prices prompt-cache hits differently (it defaults to the full input price = no discount) |
| `GatewayModel` | `isReasoning` | the model thinks before the first token (raises the default TTFB timeout to 60 s) |
| `ProviderModel` | `ttfbTimeoutMs` | one mapping needs a different TTFB than the provider default |

Set them with `prisma db execute`. All prices are **micro-USD per 1M tokens**: `$0.40 / 1M → 400000`.

```bash
# local (SQLite)
echo "UPDATE \"Provider\" SET \"usageDialect\"='deepinfra' WHERE \"slug\"='deepinfra';" \
  | npx prisma db execute --schema prisma/schema.sqlite.prisma --stdin

# production (Postgres) — DATABASE_URL/DIRECT_URL must point at it
echo "UPDATE \"Provider\" SET \"usageDialect\"='deepinfra' WHERE \"slug\"='deepinfra';" \
  | npx prisma db execute --schema prisma/schema.prisma --stdin
```

The admin pages bump the catalog cache when you save; a raw SQL write does **not**. After SQL, either save any provider/model in the admin once, or wait 60 s, or restart `npm run dev`.

## The usage dialects

`Provider.usageDialect` picks which normaliser reads the provider's `usage` object (`lib/gateway/usage/`):

| Dialect | Reads | Cost from provider? |
|---|---|---|
| `openai` (default) | `prompt_tokens`, `completion_tokens`, `prompt_tokens_details.cached_tokens`, `completion_tokens_details.reasoning_tokens` | no |
| `deepseek` | + `prompt_cache_hit_tokens` / `prompt_cache_miss_tokens` | no |
| `deepinfra` | OpenAI counts + `estimated_cost` (USD) | **yes** |
| `openrouter` | OpenAI details + `prompt_tokens_details.cache_write_tokens`, `cost` / `cost_details.upstream_inference_cost` | **yes** |
| `anthropic` | `input_tokens`, `cache_read_input_tokens`, `cache_creation_input_tokens`, `output_tokens` | no |

Wrong dialect = cached tokens counted as normal input (customer overcharged) or provider cost ignored (margin invisible). It is one `UPDATE`.

## What the gateway sends upstream

- `POST {baseUrl}/chat/completions`, `Authorization: Bearer {key}` — only. Custom headers (OpenRouter's `HTTP-Referer` / `X-Title`, Anthropic-native endpoints) are WS11.
- `GET {baseUrl}/models` for "Test connection" and "Import models".
- On streams, `stream_options: {include_usage: true}` when `supportsStreamUsage` is on.
- The customer's `max_tokens` is clamped to the model's `maxOutputTokens`; unknown body keys are dropped (`CHAT_ALLOWED_KEYS` in `lib/gateway/handler.ts`).
- The base URL must be the one where `/chat/completions` lives, **with no trailing slash**. `https://api.deepinfra.com/v1/openai` ✅, `https://api.deepinfra.com/v1/openai/` ✗, `https://api.deepinfra.com` ✗.

## Local environment for testing

`.env` for local dev (SQLite, no Redis) — the ones that matter here:

```bash
DATABASE_URL="file:./dev.db"
SESSION_SECRET="…32+ chars…"
CRON_SECRET="dev-cron-secret"
VOUCHER_PEPPER="…base64 32 bytes…"   # only if you test vouchers
# optional, all have safe defaults:
GATEWAY_RESERVATIONS="enforce"       # shadow (default) writes holds but never refuses
GATEWAY_RATE_LIMITS="true"
REDIS_DISABLED="true"                # in-process limits/breaker; fine locally
```

Start it:

```bash
npm run dev            # http://localhost:3000
```

## The standard local test loop

Every provider guide ends here. You need a customer with balance and a gateway token.

**1. Get a token.** Sign in to `/admin`, open a customer (or create one with a balance), then either use their portal (`/portal/api-access` → *New token*) or redeem a voucher (`/admin/vouchers` → generate → `/redeem`). Tokens start with `al_`.

```bash
export AL="al_…"
export GW="http://localhost:3000"
```

**2. Catalog** — the models that customer may use:

```bash
curl -s $GW/v1/models -H "Authorization: Bearer $AL" | python -m json.tool | head -30
```

**3. Non-streaming call** (OpenAI wire, what Codex uses):

```bash
curl -s $GW/v1/chat/completions -H "Authorization: Bearer $AL" -H "content-type: application/json" \
  -d '{"model":"<your-slug>","messages":[{"role":"user","content":"Reply with the single word: pong"}],"max_tokens":16}' \
  | python -m json.tool
```

**4. Streaming + client abort** (proves WS5: we stop paying when the customer hits Ctrl-C):

```bash
curl -N $GW/v1/chat/completions -H "Authorization: Bearer $AL" -H "content-type: application/json" \
  -d '{"model":"<your-slug>","stream":true,"messages":[{"role":"user","content":"Count from 1 to 200 slowly"}]}'
# press Ctrl-C after a few chunks
```

**5. Anthropic wire** (what Claude Code uses):

```bash
curl -s $GW/v1/messages -H "x-api-key: $AL" -H "anthropic-version: 2023-06-01" -H "content-type: application/json" \
  -d '{"model":"<your-slug>","max_tokens":64,"messages":[{"role":"user","content":"Say hi"}]}' | python -m json.tool
```

**6. Real client:**

```bash
ANTHROPIC_BASE_URL=$GW ANTHROPIC_API_KEY=$AL ANTHROPIC_MODEL=<your-slug> claude
```

**7. Check what was recorded** — `/admin/usage-logs`, and the customer's profile for the ledger:

| Column | Expect |
|---|---|
| `status` / `outcome` | `200` / `COMPLETED`, and `cancelled` / `CLIENT_DISCONNECTED` for the aborted stream |
| `usageSource` | `PROVIDER` (the provider sent a usage object). `ESTIMATED` on the aborted run is correct. |
| tokens | non-zero, and cached tokens shown in brackets when the provider reports them |
| cost | `costMicroUsd` = provider cost, `customerMicroUsd` = what you charged |

Terminal (`npm run dev`) lines worth watching:

- `[gateway] provider cost disagreement …` → the model's price list is wrong.
- `[gateway] upstream <slug> rejected request: 4xx …` → the customer got a sanitised 400; the real reason is here.
- `[breaker] OPEN <provider>/<model> …` → three failures in a row; requests fail over. "Test connection" resets it.
- `[redis] … PER INSTANCE` → expected locally.

**8. Failover check (optional but worth doing once).** Map the same GatewayModel to two providers with different priorities, then break the first (edit its key to `sk-broken`, save, run a request). It must fail over to the second and log a breaker line. Restore the key afterwards.

## Before you let customers near it

- [ ] prices set on every imported model (never $0) and checked against the provider's price page
- [ ] `usageDialect` set for the provider
- [ ] cached-input price set if the provider discounts cache hits (Claude Code lives on prompt caching)
- [ ] one streaming, one non-streaming and one aborted request in `/admin/usage-logs` with sane numbers
- [ ] a real Claude Code / Codex session against the slug
- [ ] `npm run usage:record -- <dialect> <baseUrl> <model>` run with a real key, so the fixture stops saying `"source": "docs"` (see `docs/testing.md`)
- [ ] the model's slug is what you want customers to type — renaming it later breaks their configs
