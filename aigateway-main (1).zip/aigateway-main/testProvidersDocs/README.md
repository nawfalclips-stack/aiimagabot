# Adding and testing upstream providers

How to plug a provider into the AeroLink gateway and prove it works locally, before customers ever see it.

| Guide | Provider | Why you'd pick it |
|---|---|---|
| [vsllm.md](vsllm.md) | `https://vsllm.cc/v1` (New API relay) | Cheap access to GPT/Claude/Gemini-class models. **Bills per request, not per token** — read the pricing section carefully. |
| [deepinfra.md](deepinfra.md) | `https://api.deepinfra.com/v1/openai` | Open-weight models (DeepSeek, Qwen, Kimi, Llama). Per-token, reports its own cost, and the only provider whose prices we import automatically. |
| [openrouter.md](openrouter.md) | `https://openrouter.ai/api/v1` | One key for ~450 models across many labs, with automatic failover of its own. Per-token, reports cost and cache tokens. |

Read **[00-how-it-works.md](00-how-it-works.md)** first — it explains the four objects you are creating (Provider → ProviderModel → GatewayModel → price), which fields have no admin UI yet, and the local test loop that every guide reuses.

Everything here matches the code as of Phase 5 (`34df24b`). If a step disagrees with the app, the app wins — tell me and I'll fix the doc.
