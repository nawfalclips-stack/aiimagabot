# DeepInfra

Open-weight models (DeepSeek, Qwen, Kimi, GLM, Llama, gpt-oss) at per-token prices. **The only provider whose prices we import automatically**, and one of two that report their own cost per request — so your margin is exact.

| | |
|---|---|
| Base URL | `https://api.deepinfra.com/v1/openai` |
| Auth | `Authorization: Bearer <key>` |
| `usageDialect` | **`deepinfra`** (must be set — the default `openai` would ignore its cost field) |
| `supportsStreamUsage` | `true` (default) |
| Prompt caching | not reported — leave the cached-input price alone |
| Key | dashboard → API keys (`deepinfra.com/dash/api_keys`) |

## Why it is special

`https://api.deepinfra.com/models/list` is public (no key) and carries per-token prices and context sizes. `lib/gateway/providers/deepinfra.ts` reads it, so **Import models** creates catalog entries already priced. Every other provider imports at $0 and you must type prices yourself.

Its `usage` object also carries `estimated_cost` (USD). With `usageDialect = deepinfra` the gateway settles on **DeepInfra's own figure** rather than our price list, and warns when the two disagree by more than 10 % + 100 µ$.

## Option A — one command (recommended)

```bash
DEEPINFRA_API_KEY=… npm run gateway:deepinfra
```

`scripts/gateway-setup-deepinfra.ts` does what the UI does: creates/updates the `deepinfra` provider (key encrypted the same way), reads the public catalog, imports a curated set of coding-friendly, non-deprecated models (DeepSeek V3/R1, Kimi K2, Qwen3-Coder, GLM, gpt-oss, Llama 4 … max 12), prices them, maps them and enables them for every store. Re-running is safe.

Pick your own list instead:

```bash
npm run gateway:deepinfra -- --models deepseek-ai/DeepSeek-V3.2,moonshotai/Kimi-K2.6
```

Then set the dialect (the script does not):

```bash
echo "UPDATE \"Provider\" SET \"usageDialect\"='deepinfra' WHERE \"slug\"='deepinfra';" \
  | npx prisma db execute --schema prisma/schema.sqlite.prisma --stdin
```

Restart `npm run dev` (or save any provider in the admin) so the catalog cache picks it up, and skip to *Verify*.

## Option B — through the admin UI

1. `/admin/providers` → **New provider** → press the **DeepInfra** preset button (fills name, slug, base URL) → paste the key → priority `10` → Enabled → **Add provider**.
2. **Test connection** (plug icon) → *Reachable — N models listed*.
3. **Import models** (download icon) → filter for what you want (e.g. `deepseek`, `qwen3-coder`, `kimi`) → select → **Import**. Prices and context windows come from the catalog.
4. Set the dialect with the SQL above.
5. `/admin/models` → spot-check two imported models against [deepinfra.com/pricing](https://deepinfra.com/pricing). The column *Customer pays* shows the price after the store multiplier.

## Verify

```bash
export DI="…"                                # DeepInfra key
curl -s https://api.deepinfra.com/v1/openai/models -H "Authorization: Bearer $DI" | head -c 300
curl -s https://api.deepinfra.com/v1/openai/chat/completions -H "Authorization: Bearer $DI" \
  -H "content-type: application/json" \
  -d '{"model":"deepseek-ai/DeepSeek-V3.2","messages":[{"role":"user","content":"Reply with the single word: pong"}],"max_tokens":16}' \
  | python -m json.tool | tail -15
```

The `usage` block must contain `estimated_cost`. If it does not, the dialect brings you nothing and you should leave it at `openai`.

Now run the standard loop in [00-how-it-works.md](00-how-it-works.md#the-standard-local-test-loop) with your gateway slug (e.g. `deepseek-v3.2`). In `/admin/usage-logs` check that `costMicroUsd` matches `estimated_cost × 1 000 000` for that request — that is the dialect working.

Record the fixture once you have a working key, so the normaliser test stops relying on documentation:

```bash
RECORD_API_KEY=$DI npm run usage:record -- deepinfra https://api.deepinfra.com/v1/openai deepseek-ai/DeepSeek-V3.2
```

## Notes

- **Slugs.** `deepseek-ai/DeepSeek-V3.2` becomes the slug `deepseek-v3.2` (lowercased tail, dots and dashes kept). That is what customers type. Rename it in `/admin/models` **before** publishing it — changing it later breaks their configs.
- **Deprecated models** are filtered out of the import list; a model DeepInfra retires later starts returning 404 → the gateway answers `Model "…" is not available right now.` and the breaker does *not* trip (4xx never fails over). Re-import to refresh.
- **Re-importing** never overwrites prices you have edited: an existing model is only re-priced when both prices are still 0.
- **Reasoning models** (DeepSeek R1 and friends) can take a minute before the first token. Mark them so the TTFB timeout becomes 60 s:
  ```bash
  echo "UPDATE \"GatewayModel\" SET \"isReasoning\"=true WHERE \"slug\" LIKE 'deepseek-r1%';" \
    | npx prisma db execute --schema prisma/schema.sqlite.prisma --stdin
  ```
  (SQLite: use `1` instead of `true`.)
