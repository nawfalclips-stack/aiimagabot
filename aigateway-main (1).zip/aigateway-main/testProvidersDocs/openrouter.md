# OpenRouter

One key, ~450 models from every major lab, per-token pricing, and a `cost` field in every response. It also reports **prompt-cache tokens**, which matters because Claude Code re-sends its whole context on each turn and lives on cache hits.

| | |
|---|---|
| Base URL | `https://openrouter.ai/api/v1` |
| Auth | `Authorization: Bearer sk-or-v1-…` |
| `usageDialect` | `openrouter` (automatic for the openrouter.ai host) |
| `supportsStreamUsage` | `true` (default) |
| Prompt caching | reported — **set the cached-input price**, see below |
| Key | [openrouter.ai/keys](https://openrouter.ai/keys) |

## 1. Add the provider

`/admin/providers` → **New provider** → press the **OpenRouter** preset → paste the key → priority (e.g. `20` so DeepInfra at `10` is tried first, or `5` to prefer OpenRouter) → Enabled → **Add provider** → **Test connection**.

The usage dialect is set to `openrouter` automatically from the `openrouter.ai` host (existing providers left on the default `openai` are read as `openrouter` too), so every response's real `cost` is read. No SQL needed.

## 2. Import models

**Import models** lists everything the key can reach (~450). Filter and take a handful — each one becomes a model id your customers see. **Rename the slug and display name to your own alias before enabling it** (e.g. `aero-pro`): customers only ever see the alias — responses, usage history and notifications are rewritten so the OpenRouter id and upstream provider never reach them. Good starting picks: `deepseek/deepseek-chat`, `qwen/qwen3-coder`, `moonshotai/kimi-k2`, `anthropic/claude-opus-4.5`.

They arrive **priced**: the import reads OpenRouter's public list (`https://openrouter.ai/api/v1/models`, no key needed) and fills input, output, **cached input** and **cache write** prices, the context window and the max output tokens.

## 3. Keep prices current

- **Models → Sync prices** shows, for every model whose primary provider is OpenRouter (or DeepInfra), the stored price next to OpenRouter's live price, and applies the changes you confirm.
- The daily cron `GET /api/cron/model-prices` (04:30 UTC, `CRON_SECRET`) applies them unattended and raises a `MODEL_PRICES_SYNCED` admin notification listing what changed, or which mapped ids have disappeared from OpenRouter's list.

What the prices are used for — and what they are not:

| | Source |
|---|---|
| What the customer is charged | OpenRouter's **real** `cost` on each response (the gateway sends `usage: {include: true}`), × the customer's plan rate. TOKENS plans ignore cost and bill tokens. |
| Reservation hold, prices on API Access, fallback when no `cost` arrives | The synced list prices |

A difference above 10 % + 100 µ$ between the reported cost and our list price logs `provider cost disagreement` — usually a sign the prices need syncing.

## 4. Verify

```bash
export OR="sk-or-v1-…"
curl -s https://openrouter.ai/api/v1/chat/completions -H "Authorization: Bearer $OR" \
  -H "content-type: application/json" \
  -d '{"model":"deepseek/deepseek-chat","messages":[{"role":"user","content":"Reply with the single word: pong"}],"max_tokens":16}' \
  | python -m json.tool | tail -20
```

The `usage` block should carry `cost` (and `cost_details`). Then run the standard loop in [00-how-it-works.md](00-how-it-works.md#the-standard-local-test-loop).

Cache check, worth doing once because it is the whole reason for step 3: send the *same* long prompt twice within a few minutes to a caching model (`anthropic/claude-opus-4.5`), then look at `/admin/usage-logs`. The second row must show cached tokens in the tokens column and a visibly lower cost. On the Anthropic wire the response's `usage.cache_read_input_tokens` is what Claude Code displays.

Record the fixture:

```bash
RECORD_API_KEY=$OR npm run usage:record -- openrouter https://openrouter.ai/api/v1 deepseek/deepseek-chat
```

## Notes

- **Slugs.** `anthropic/claude-opus-4.5` imports as `claude-opus-4.5`, `deepseek/deepseek-chat` as `deepseek-chat`. If both OpenRouter and DeepInfra serve "the same" model, map them to **one** GatewayModel (Models page → the model's row → *Add provider mapping*) instead of creating two slugs — that is how failover happens.
- **Attribution headers.** OpenRouter optionally credits your app via `HTTP-Referer` / `X-Title`. The gateway sends only `Authorization`; per-provider extra headers are WS11 (Phase 7). Nothing breaks without them.
- **OpenRouter's own routing** may serve a request from any of its upstreams, so latency and cache behaviour vary between calls of the same model. Its reported `cost` is authoritative, which is why the dialect matters.
- **Your OpenRouter credit balance** is separate from customer balances here. When it runs out OpenRouter answers 402 → our breaker treats it as a retriable failure and fails over to the next provider for that model; watch for `[breaker] OPEN openrouter/…` in the logs.
