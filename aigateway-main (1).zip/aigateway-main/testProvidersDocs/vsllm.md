# vsllm.cc (维云 / New API relay)

A [New API](https://github.com/Calcium-Ion/new-api) relay reselling GPT, Claude, Gemini, GLM, DeepSeek, Qwen and others behind one OpenAI-compatible endpoint.

| | |
|---|---|
| Base URL | `https://vsllm.cc/v1` |
| Auth | `Authorization: Bearer sk-…` |
| `usageDialect` | `openai` (the default — **nothing to set**) |
| `supportsStreamUsage` | `true` (default) |
| Reports its own cost | **no** — our price list decides what we think a request cost |
| Public price list | `https://vsllm.cc/api/pricing` (no key needed) |
| Key | the vsllm console → tokens |

## Read this before anything else: it bills per request

Most vsllm models are **per-request** (`quota_type: 1`), not per-token:

| model | price | mode |
|---|---|---|
| `gpt-5.4` | $0.005 / request | per request |
| `gpt-5.6-sol` | $0.015 / request | per request |
| `claude-opus-4-6` | $0.025 / request | per request |
| `deepseek-v4-flash` | $0.0025 / request | per request |
| `MiniMax-M2.5` | ratio 0.25 in, ×2.5 out | per token |

…and everything is multiplied by your **group ratio** (`default` = ×2 at the time of writing; check `group_ratio` in the pricing JSON for your account).

Our gateway prices per token. So for per-request models the `costMicroUsd` we record is an **approximation**, and your real vsllm invoice will differ. Two consequences:

1. Set each model's per-token prices so that a *typical* request lands on the right cost (below).
2. Watch your vsllm balance against `/admin/statistics` margin numbers for the first days; do not treat our cost column as exact for these models.

A proper fix (a per-request price on the mapping) belongs to WS11 in Phase 7 — ask for it if you plan to sell vsllm models at scale.

See the current list and mode for every model:

```bash
curl -s https://vsllm.cc/api/pricing | python -c "
import json,sys
d = json.load(sys.stdin)
print('group_ratio:', d.get('group_ratio'))
for m in d['data']:
    mode = f\"per-request \${m['model_price']}\" if m.get('quota_type') == 1 else f\"ratio in={m.get('model_ratio')} out=x{m.get('completion_ratio')}\"
    print(f\"{m['model_name']:<42} {mode:<28} {','.join(m.get('supported_endpoint_types', []))}\")
"
```

## 1. Check the key outside the app

```bash
export VS="sk-…"
curl -s https://vsllm.cc/v1/models -H "Authorization: Bearer $VS" | python -m json.tool | head -20
curl -s https://vsllm.cc/v1/chat/completions -H "Authorization: Bearer $VS" -H "content-type: application/json" \
  -d '{"model":"deepseek-v4-flash","messages":[{"role":"user","content":"Reply with the single word: pong"}],"max_tokens":16}' \
  | python -m json.tool | tail -15
```

`GET /v1/models` without a key returns `{"error":{"type":"new_api_error","message":"Invalid token"}}` — that response is how you know the relay is up and the base URL is right. The models this call lists are the ones **your key's group** may use; the public pricing list is wider.

## 2. Add the provider

`/admin/providers` → **New provider** (no preset button — type it):

| Field | Value |
|---|---|
| Name | `VSLLM` |
| Slug | `vsllm` |
| Base URL | `https://vsllm.cc/v1` (no trailing slash) |
| API key | your `sk-…` |
| Priority | `20` (DeepInfra stays first at 10) or `5` to prefer vsllm |
| Enabled | on |

**Add provider** → **Test connection** → expect *Reachable — N models listed*.

## 3. Import models

**Import models** → pick 2–3 to start, e.g. `deepseek-v4-flash`, `gpt-5.4`, `claude-opus-4-6` → **Import**.

Check the generated slugs in `/admin/models` before going further:

- the slug is the id's last path segment, lowercased, with anything outside `a-z0-9.` turned into `-`;
- `[opencode]deepseek-v4-pro` → `opencode-deepseek-v4-pro`;
- `MiniMax-M2.5` → `minimax-m2.5`.

Rename anything awkward **now** — the slug is what customers put in their Codex/Claude Code config, and changing it later breaks them.

## 4. Price them (mandatory — they import at $0)

A $0 model charges the customer $0.

**Per-token models** (`MiniMax-M2.5` and friends): New API's ratio is relative to $2 per 1M tokens, then × group ratio.
`price $/M = ratio × 2 × group_ratio`, and the completion price is `input × completion_ratio`.
`MiniMax-M2.5` at ratio 0.25, out ×2.5, group ×2 → **in $1.00/M, out $2.50/M**.

**Per-request models**: decide a typical request shape and back-solve. With `cost_per_request = price × group_ratio`:

```
cost_per_request ≈ (in_tokens × input_price + out_tokens × output_price) / 1_000_000
```

Example — `gpt-5.4`, $0.005 × 2 = **$0.01 per request**, assuming a typical 4 000 in / 1 000 out and keeping the usual 1 : 2.7 input-to-output ratio:

```
4000·x + 1000·2.7x = 10 000 µ$   →   x ≈ 1.49
→ input ≈ $1.50/M, output ≈ $4.00/M
```

Type those into `/admin/models`. After a day of real traffic, compare the vsllm console's spend with the sum of `costMicroUsd` in `/admin/usage-logs` for those slugs and scale both prices by the ratio.

Because vsllm sends no cost field, you will **not** see `[gateway] provider cost disagreement` lines for it — that warning only exists for DeepInfra and OpenRouter. Reconciliation here is manual (and is what WS14, Phase 8, automates).

Prompt caching: `prompt_tokens_details.cached_tokens` may appear for the OpenAI-family models. Since the whole request is billed at a flat price, leave `cachedInputPriceMicroPerMTok` alone unless you deliberately want to give customers a cache discount.

## 5. Test through the gateway

Run the standard loop in [00-how-it-works.md](00-how-it-works.md#the-standard-local-test-loop) with one of your new slugs, e.g.:

```bash
export AL="al_…"; export GW="http://localhost:3000"
curl -s $GW/v1/models -H "Authorization: Bearer $AL" | python -m json.tool | grep '"id"'
curl -N $GW/v1/chat/completions -H "Authorization: Bearer $AL" -H "content-type: application/json" \
  -d '{"model":"deepseek-v4-flash","stream":true,"messages":[{"role":"user","content":"Count from 1 to 200 slowly"}]}'
# Ctrl-C mid-stream, then check /admin/usage-logs for CLIENT_DISCONNECTED
ANTHROPIC_BASE_URL=$GW ANTHROPIC_API_KEY=$AL ANTHROPIC_MODEL=claude-opus-4-6 claude
```

In `/admin/usage-logs` you should see `usageSource = PROVIDER` and non-zero tokens. If `usageSource` is `ESTIMATED` on a completed request, vsllm did not return a usage object for that model — the charge then comes from our byte estimate, which is less accurate; consider dropping that model.

## Notes and gotchas

- **Groups.** `group_ratio` shows `free: 0` and `image_2fen: 0.15` besides `default: 2`. Which group your key is in decides what you pay; a "free" group model costs you nothing but still burns customer balance at your listed price.
- **Model churn.** A relay's line-up changes without notice. A retired id returns 4xx → the customer gets a sanitised `Model "…" is not available right now.` and the breaker does **not** trip (4xx never fails over). Re-run *Import models* now and then and disable what disappeared.
- **Only `/v1/chat/completions` is used.** vsllm also advertises `anthropic`, `gemini` and `openai-response` endpoint types; we speak the Chat Completions wire to every provider and translate to the Anthropic wire ourselves. Native Anthropic passthrough is WS13 (Phase 7).
- **Reasoning models** (`gpt-5.6-sol`, `deepseek-v4-pro` …) can be slow to the first token. Either mark the model reasoning (60 s TTFB):
  ```bash
  echo "UPDATE \"GatewayModel\" SET \"isReasoning\"=1 WHERE \"slug\"='gpt-5.6-sol';" \
    | npx prisma db execute --schema prisma/schema.sqlite.prisma --stdin
  ```
  or raise it for the whole provider:
  ```bash
  echo "UPDATE \"Provider\" SET \"ttfbTimeoutMs\"=45000 WHERE \"slug\"='vsllm';" \
    | npx prisma db execute --schema prisma/schema.sqlite.prisma --stdin
  ```
  (Postgres: `true` instead of `1`.) Restart `npm run dev` afterwards.
- **Legal/branding.** The relay resells other labs' models. Describe them by capability in customer-facing copy; do not imply an official partnership with OpenAI, Anthropic or Google.
